import React from 'react';
import 'bootstrap/dist/css/bootstrap.min.css';
import './App.css';
import DatePicker from "react-datepicker";
import "react-datepicker/dist/react-datepicker.css";
import {
  Modal,
  Row,
  Col,
  Popover,
  OverlayTrigger
} from "react-bootstrap";
import { apiGet, apiPut, apiPost, getBlobImage } from './Api.js';
import { get, isEqual, isEmpty, sum, find } from 'lodash';
import { DAYS_OF_WEEK, timesheet_status_codes, ClockInOuts, toNumber } from './helpers/GeneralHelper';
import moment from 'moment';

const UserActivity = {
  timesheetApproval: 1,
  activityApproval: 2
}

class TimesheetChart extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      weeklyDate: new Date(moment().day(0)),
      actionLogs: [],
      approvedImage: '',
      displayConfirmationPopup: false,
      subLoading: false,
      timesheetid: props.id,
      timesheetdetails: {},
      currentActivityId: null,
      totalHours: 0.0,
      activityTotalsArr: [],
      currentActivityTotalHours: 0,
      currentActivityName: '',
      startWeekDate: moment().day(0),
      weekEndDate: moment().day(6),
      daysOfWeek: [],
      activityApprovalImg: [],
      employeeApprovalImg: '',
      punchOutTime: '',
      punchOutComments: '',
      userApprovalComments: '',
      selectedUserActivity: null,
      timesheetLoading: false,
    };
  }

  componentDidMount() {
    this.getTimesheetRecord();
  }

  getTimesheetRecord = () => {
    const requestDetails = {
      method: `timesheets/${this.state.timesheetid}`,
      params: {}
    };
    this.setState({ timesheetLoading: true });
    apiGet(requestDetails, true).then((response) => {
      if (isEqual(response.status, 200) && response.data) {
        this.updateLayoutData(response.data)
      }
    }).catch(error => {
      console.log(error);
    });
  }

  updateLayoutData = async (data) => {
    const sunday = new Date(moment(get(data, 'startDate')).day(0));
    const nextSunday = new Date(moment(get(data, 'startDate')).day(6));
    const startDay = moment(sunday);
    let employeeApprovalImg, approvedImage = '';
    let activityApprovalImg = [];
    let totalHours = 0;
    const daysOfWeekFromStart = [
      {
        day: DAYS_OF_WEEK[startDay.day()],
        date: startDay.format('MMM D'),
        fullDate: startDay.format('YYYY-MM-DD'),
      }
    ];
    for (let i = 1; i <= 6; ++i) {
      const newDay = startDay;
      newDay.add(1, 'day');
      daysOfWeekFromStart.push({
        day: DAYS_OF_WEEK[newDay.day()],
        date: newDay.format('MMM D'),
        fullDate: newDay.format('YYYY-MM-DD'),
      })
    }
    let dayWiseTotalObj = {};
    let activityTotalsArr = [];
    if (data && data.activityTime && data.activityTime.length > 0) {
      totalHours = sum(data.activityTime.map((activity, i) => {
        return sum(Object.values(DAYS_OF_WEEK).map((day) => activity[`${day.toLowerCase()}Hour`]));
      }));
      data.activityTime.map((x) => {
        Object.entries(x).map((act) => {
          let hourName = act[0].includes('Hour');
          if (hourName) {
            if (dayWiseTotalObj[act[0]]) {
              dayWiseTotalObj[act[0]] = dayWiseTotalObj[act[0]] + Number(act[1])
            } else {
              dayWiseTotalObj[act[0]] = Number(act[1]);
            }
          }
        })
      })
      Object.values(DAYS_OF_WEEK).map((day) => {
        const dayName = `${day.toLowerCase()}Hour`;
        if (dayWiseTotalObj.hasOwnProperty(dayName)) {
          activityTotalsArr.push({ dayName, value: dayWiseTotalObj[dayName] })
        }
      })
    };
    let actionLogs = await this.getActionLogs(data);
    if (data.status >= 300) {
      employeeApprovalImg = await this.getApprovalImage('user_signature', data.uid);
      if (data.status >= 500) {
        approvedImage = await this.getApprovalImage('user_signature', data.approvedBy);
      }
    }
    if (data.activityTime.length > 0) {
      let approvedImageArr = data.activityTime.filter(x => x.approvedBy !== 0);
      if (approvedImageArr.length > 0) {
        approvedImageArr = approvedImageArr.map((x, i) => {
          activityApprovalImg.push({ index: i, approvedBy: x.approvedBy });
          return this.getApprovalImage('user_initial', x.approvedBy)
        })
        await Promise.all(approvedImageArr).then((body) => {
          activityApprovalImg = activityApprovalImg.map((img, key) => {
            return { ...img, src: body[key] }
          })
        })
      }
    }
    this.setState({
      timesheetdetails: data,
      weeklyDate: sunday,
      startWeekDate: moment(sunday).format('YYYY-MM-DD'),
      weekEndDate: moment(nextSunday).format('YYYY-MM-DD'),
      daysOfWeek: daysOfWeekFromStart,
      totalHours,
      actionLogs,
      employeeApprovalImg,
      activityTotalsArr,
      approvedImage,
      currentActivityId: null,
      currentActivityTotalHours: 0.00,
      currentActivityName: '',
      userApprovalComments: '',
      selectedUserActivity: null,
      activityApprovalImg,
      displayConfirmationPopup: false,
      subLoading: false,
      timesheetLoading: false
    });
    document.body.click();
  }

  cancelPopup = () => {
    this.setState({
      currentActivityId: null,
      currentActivityTotalHours: 0.00,
      currentActivityName: '',
      userApprovalComments: '',
      selectedUserActivity: null,
      displayConfirmationPopup: false,
    })
  }

  getActionLogs = async (data) => {
    let arr = [];
    const getRequest = {
      method: `timesheets/action-logs/${data.tid} `
    };
    await apiGet(getRequest, true, false).then((response) => {
      if (isEqual(response.status, 200) && response.data) {
        arr = response.data;
      }
    }).catch(error => {
      console.log(error);
    });
    return arr;
  }

  getApprovalImage = async (type = 'user_signature', uid = '') => {
    let userId = get(localStorage, 'userid', '');
    if (uid) { userId = uid; }
    let imageSrc = '';
    const getRequest = {
      method: `employees/images?id=${userId}&itemtype=${type}`
    };
    await getBlobImage(getRequest).then((response) => {
      if (response.data && response.data.size) {
        imageSrc = URL.createObjectURL(response.data);
      }
    }).catch(error => {
      console.log(error);
    });
    return imageSrc;
  }

  formatDate = (date) => moment(date).format("MMMM D, YYYY");

  isWeekday = (date) => date.getDay() === 0;

  handleWeekChange = (date) => {
    const { timesheetdetails } = this.state;
    const formatDate = moment(date).format('YYYY-MM-DD');
    const request = {
      method: `timesheets/${get(timesheetdetails, 'uid')}/${formatDate}`
    };
    this.setState({ timesheetLoading: true });
    apiGet(request, true, false).then((response) => {
      if (isEqual(response.status, 200) && response.data) {
        this.updateLayoutData(response.data);
      } else if (isEmpty(response.data)) {
        this.setState({ timesheetLoading: false });
        window.alert('No Timesheet is available for selected Week');
        return;
      }
    }).catch((err) => {
      console.log(err);
    })
  }

  setPunchOutComments = (evt) => this.setState({ punchOutComments: evt.target.value })

  setUserApprovalComments = (evt) => this.setState({ userApprovalComments: evt.target.value })

  updateHour = (activityProps, actIndex) => {
    this.setState({ subLoading: true });
    const request = {
      method: 'timesheets/hour',
      params: {
        timesheetID: Number(this.state.timesheetid),
        activityID: activityProps.activityID,
        day: actIndex,
        hours: Number(this.state.punchOutTime),
        reason: this.state.punchOutComments,
        madeBy: Number(get(localStorage, 'userid', '')),
      }
    }
    apiPut(request, true).then(async (response) => {
      if (isEqual(response.status, 200) && response.data) {
        await this.getTimesheetRecord();
      } else if (isEmpty(response.data)) {
        window.alert('Something went wrong!');
        this.setState({ subLoading: false });
        document.body.click();
        return;
      }
    }).catch((err) => {
      console.log(err)
      this.setState({ subLoading: false });
    })
  }

  handleActivityApprovalAction = (activity_id, activityHours, activityName) => {
    this.setState({
      selectedUserActivity: UserActivity.activityApproval,
      currentActivityId: activity_id,
      currentActivityTotalHours: toNumber(activityHours),
      currentActivityName: activityName,
      displayConfirmationPopup: true
    })
  }

  handleTimesheetApprovalAction = () => {
    this.setState({
      userApprovalComments: '',
      selectedUserActivity: UserActivity.timesheetApproval,
      currentActivityTotalHours: toNumber(this.state.totalHours),
      displayConfirmationPopup: true
    })
  }

  handleUserAction = () => {
    const { currentActivityId, userApprovalComments, selectedUserActivity } = this.state;
    this.setState({ subLoading: true });
    let params = {
      timesheetID: this.state.timesheetid,
      madeBy: get(localStorage, 'userid', ''),
      reason: userApprovalComments
    }
    if (selectedUserActivity === UserActivity.activityApproval) {
      params.activityID = currentActivityId;
    }
    const request = {
      method: '',
      params
    }
    switch (selectedUserActivity) {
      case UserActivity.activityApproval:
        request.method = 'timesheets/activity-approve';
        break;
      case UserActivity.timesheetApproval:
        request.method = 'timesheets/approve';
        break;
      default:
        break;
    }
    apiPost(request, true).then((res) => {
      if (isEqual(res.status, 200) && res.data) {
        window.alert(`${selectedUserActivity === UserActivity.activityApproval ? 'Activity' : 'Timesheet'} has been approved.`);
        this.getTimesheetRecord();
      }
      if (res.request && res.request.status !== 200) {
        let obj = JSON.parse(res.request.response);
        window.alert(obj.msg);
        this.cancelPopup();
      }
    }).catch((err) => {
      console.log(err.request);
      this.setState({ subLoading: false });
    })
  }

  render() {
    const { totalHours, timesheetdetails, actionLogs, timesheetLoading, activityTotalsArr, subLoading, approvedImage, activityApprovalImg, employeeApprovalImg, currentActivityName, currentActivityTotalHours } = this.state;
    const popoverComponent = (activityProps, activityDay) => (
      <Popover id={`popover-positioned-top`} className="timesheetpopover">
        <Popover.Title as="h6" className="background-green1 text-white">
          <span className="small_font">{timesheetdetails.userFirstname}, {timesheetdetails.userLastname}</span>
          <span
            aria-label="Close" className="float-right icon-button cursor-pointer"
            onClick={() => document.body.click()}
          >
            x
          </span>
        </Popover.Title>
        <Popover.Content>
          <div className="row px-3">
            <label className="col-xl-3 col-lg-3 col-md-3 col-sm-10 p-0 permission-label">Hour : </label>
            <div className="col-xl-7 col-lg-7 col-md-7 col-sm-10 p-0">
              <input
                type="text"
                className="form-control"
                placeholder=""
                value={this.state.punchOutTime}
                onChange={(evt) => this.setState({ punchOutTime: evt.target.value })}
              />
              {isEmpty(this.state.punchOutTime) && (<p style={{ color: 'red' }}>This is required</p>)}
            </div>
          </div>
          <div className="col-xl-12 col-lg-12 col-md-12 col-sm-12 p-0">
            <textarea
              className="form-control"
              placeholder="Reason for change (required)"
              value={this.state.punchOutComments}
              onChange={this.setPunchOutComments}
            />
            {isEmpty(this.state.punchOutComments) && (<p style={{ color: 'red' }}>This is required</p>)}
          </div>
          <div className="row mt-2 mx-0">
            <button
              disabled={(isEmpty(this.state.punchOutComments) && isEmpty(this.state.punchOutTime)) || this.state.subLoading}
              className="button resend-btn float-right px-4"
              onClick={() => this.updateHour(activityProps, activityDay)}
            >
              {this.state.subLoading ? 'Please Wait' : 'Save'}
            </button>
          </div>
        </Popover.Content>
      </Popover>
    );
    return (
      <div className="App">
        <div className="contentwrapper pb-5 mb-5 text-left">
          <ul className="pl-0 my-2">
            <button onClick={() => this.props.onBackClick()} className="p-0 cursor-pointer button resend-btn py-2 px-4 m-0 mr-2">Back</button>
          </ul>
          <div className="p-3 mb-3 small_font bg-amber border-0">
            <Row className="col-12">
              <Col lg="5" md="5" sm="12">
                <span className="pr-3 font-weight-bold font-16">
                  {timesheetdetails.userLastname ? timesheetdetails.userLastname + ',' : null} {timesheetdetails.userFirstname}
                </span>
              </Col>
              <Col lg="3" md="3" className="text-right" />
              <Col lg="2" md="2" className="text-right">
                <label className="act-text">Week Started</label>
              </Col>
              <Col lg="2" md="2" sm="12" className="pr-0">
                <div className="form-group row mb-0 inner-addon right-addon mr-2">
                  <i className="fa fa-calendar"></i>
                  <DatePicker
                    selected={this.state.weeklyDate}
                    value={this.state.startWeekDate}
                    name="startDate"
                    className="form-control"
                    filterDate={this.isWeekday}
                    onChange={this.handleWeekChange}
                    dateFormat="yyyy-MM-dd"
                    placeholderText="yyyy-MM-dd"
                  />
                </div>
              </Col>
            </Row>
          </div>
          {timesheetLoading ? 'Please Wait...' :
            <>
              <Row>
                <Col lg="12" md="12" sm="12">
                  <table border='1' className="col-12 text-center text-black w-50">
                    <thead>
                      <tr>
                        <th colSpan='3' className="blue-head">
                          {`${get(timesheetdetails, 'userLastname', '')} ${get(timesheetdetails, 'userFirstname', '')}'s Accumulated Time`}
                        </th>
                      </tr>
                    </thead>
                    <tbody>
                      <tr>
                        <th style={{ width: '50%' }}>{`Week (${this.formatDate(this.state.startWeekDate)} - ${this.formatDate(this.state.weekEndDate)})`}</th>
                      </tr>
                      <tr className="blue-num">
                        <td className="font-weight-bold">{toNumber(totalHours) || '-'}</td>
                      </tr>
                    </tbody>
                  </table>
                </Col>
              </Row>
              <div className="mt-3">
                <table border='1' className="col-12 text-black">
                  <thead>
                    <tr>
                      <th colSpan='11' className="blue-head py-2">
                        <Row>
                          <Col lg="6" md="6" sm="12">
                            <div className="pl-2  float-left">
                              <span className="font-12">WEEKLY TIME SHEET</span>
                              <span className="small-font pl-2">
                                {`${this.formatDate(this.state.startWeekDate)} - ${this.formatDate(this.state.weekEndDate)}`}
                              </span>
                            </div>
                          </Col>
                          <Col lg="6" md="6" sm="12">
                            <div className="pr-2 float-right">
                              <span className="pr-2 font-12">{timesheet_status_codes[`${get(timesheetdetails, 'status', '')}`]}</span>
                              <span className="font-small">{`Due on : ${this.formatDate(moment(this.state.weekEndDate).subtract(1, 'day'))}`}</span>
                              <span className="px-1">|</span>
                              <i className="fa fa-print px-1"></i>
                              <i className="fa fa-file-pdf-o px-1"></i>
                            </div>
                          </Col>
                        </Row>
                      </th>
                    </tr>
                  </thead>
                  <tbody className="text-center">
                    <tr>
                      <td colSpan='2' className="font-weight-bold text-right pr-1">NAME:</td>
                      <td colSpan='12' className="pl-1 text-left">
                        {get(timesheetdetails, 'userLastname', '')}, {get(timesheetdetails, 'userFirstname', '')}
                      </td>
                    </tr>
                    <tr>
                      <td colSpan='2' className="font-weight-bold text-right pr-1">GROUP:</td>
                      <td colSpan='12' className="pl-1 text-left">{'-'}</td>
                    </tr>
                    <tr className="text-center font-small p-1 bg-lite-gray">
                      <th colSpan='2'></th>
                      {get(this.state, 'daysOfWeek', []).map((day, index) => (
                        <th key={`${day.day}${index}`}>{day.day}<br />{day.date}</th>
                      ))}
                      <th>Total<br />Hours</th>
                      <th>Initial</th>
                    </tr>
                    {
                      timesheetdetails && get(timesheetdetails, 'activityTime', []).map((activity, i) => {
                        let activityTotal = Object.values(DAYS_OF_WEEK).map((day) => activity[`${day.toLowerCase()}Hour`]).reduce((a, b) => Number(Number(a) + Number(b)).toFixed(2), 0);
                        let actApprovalImg = activity.approvedBy !== 0 ? activityApprovalImg.find(x => x.approvedBy === activity.approvedBy) : null;
                        return <React.Fragment key={i}>
                          {get(activity, 'clockinouts', []).map((clock, index) => (
                            <tr key={activity.activityID + index}>
                              {index === 0 && (<td rowSpan={get(activity, 'clockinouts').length}>{activity.activityName.toUpperCase()}</td>)}
                              <td >{ClockInOuts[clock.type]}</td>
                              {
                                get(this.state, 'daysOfWeek', []).map((day, index) => (
                                  <td key={`${day}${index}${i}`}>
                                    {isEqual(day.day, DAYS_OF_WEEK[moment(clock.clockAt).day()]) ? moment(clock.clockAt).format('h:mm A') : ''}
                                  </td>
                                ))
                              }
                              <td ></td>
                              {index === 0 && (
                                <td rowSpan={get(activity, 'clockinouts').length}></td>
                              )}
                            </tr>
                          ))}
                          <tr className="time-td blue-text bg-lite-gray">
                            <td colSpan='2'>{`${activity.activityName.toUpperCase()} HOURS`}</td>
                            {
                              Object.values(DAYS_OF_WEEK).map((day, index) => {
                                let indexVal = null;
                                if (activity.changes && activity.changes.length > 0) {
                                  activity.changes.map((x) => (
                                    DAYS_OF_WEEK[x.day] === day ? (indexVal = i + 1) : (indexVal = null)
                                  ));
                                }
                                return <OverlayTrigger onToggle={() => this.setState({ currentActivityId: activity.id })} trigger="click" key={index} placement='top' rootClose={true} overlay={popoverComponent(activity, index)}>
                                  <td key={`${day}${index}`} className='text-blue cursor-pointer'>
                                    <span variant="secondary">
                                      {indexVal && <span className="ptoCircle mr-2 text-center"><span className="d-block mt-1">{indexVal}</span></span>}
                                      {activity[`${day.toLowerCase()}Hour`] > 0 ? toNumber(activity[`${day.toLowerCase()}Hour`]) : null}
                                    </span>
                                  </td>
                                </OverlayTrigger>
                              })
                            }
                            <td >{activityTotal}</td>
                            <td className="vertical-align-bottom">
                              {activity.approvedBy === 0 ? (<div className="float-right">
                                <div className="guideList" onClick={() => this.handleActivityApprovalAction(activity.activityID, activityTotal, activity.activityName)}>
                                  <div className="active cursor-pointer">
                                    <span className="activePointer"></span>
                                    <span className="pl-4">SIGN</span>
                                  </div>
                                </div>
                              </div>) : actApprovalImg.src && <img src={actApprovalImg.src} alt='apprvalImage' height={30} width={50} className="float-right" />}
                            </td>
                          </tr>
                        </React.Fragment>
                      })
                    }
                    <tr className="time-td blue-text bg-lite-gray">
                      <td colSpan='2'>TOTAL</td>
                      {activityTotalsArr.map((dTotal, rkey) => <td key={rkey}>{toNumber(dTotal.value) || 0.00 }</td>)}
                      <td className="text-blue">
                        <span variant="secondary">{toNumber(totalHours) || '-'}</span>
                      </td>
                      <td></td>
                    </tr>
                    <tr>
                      <th colSpan='11' className="blue-head text-center py-2">
                        Timesheet Changes
                        </th>
                    </tr>
                    <tr>
                      <td colSpan='11' className="py-2 text-left">
                        {
                          get(timesheetdetails, 'activityTime', []).map((activity, index) => {
                            if (!isEmpty(activity.changes) && !activity.changes.includes(null)) {
                              return activity.changes.map((timesheetChanges, timIndex) => {
                                let actualDay = DAYS_OF_WEEK[timesheetChanges.day];
                                let dateObject = find(get(this.state, 'daysOfWeek', []), { day: actualDay });
                                return <p key={timIndex} className="pl-1 mb-1">
                                  <span className="ptoCircle mr-2 text-center"><span className="d-block mt-1">{index + 1}</span></span>
                                  {activity.activityName} {moment(dateObject.fullDate).format('dddd (MMM DD, YYYY)')} : {timesheetChanges.reason} - Change made by {timesheetChanges.madeByFirstname} {timesheetChanges.madeByLastname}
                                &nbsp; on {moment(timesheetChanges.madeAt).format("hh:mm A MMM DD, YYYY")}.
                              </p>
                              })
                            } else {
                              return null;
                            }
                          })
                        }
                      </td>
                    </tr>
                    <tr>
                      <td colSpan='11' className="py-2"></td>
                    </tr>
                    {!isEmpty(timesheetdetails) && <tr>
                      <td colSpan='4' className="pt-5 text-left">
                        <Row>
                          <Col lg="12" md="12" sm="12">
                            <span className="pl-1 pr-2 font-9">Employee Signature:</span>
                            {timesheetdetails && timesheetdetails.status >= 300 ? (employeeApprovalImg && <img src={employeeApprovalImg} height={50} alt="employeeApprovalImg" />) : null}
                          </Col>
                        </Row>
                      </td>
                      <td colSpan='3' className="pt-5 text-left">
                        <Row className="mr-0 ml-0">
                          <span className="pl-1 font-9">Date: {timesheetdetails.submitDate || ''}</span>
                        </Row>
                      </td>
                      <td colSpan='3' className="pt-5 text-left">
                        {timesheetdetails && timesheetdetails.status < 500 ? <Row>
                          <Col lg="6" md="6" sm="6" className="mt-3">
                            <span className="pl-1 font-9">Approval Signature:</span>
                          </Col>
                          <Col lg="6" md="6" sm="6">
                            <div className="float-right">
                              <div className="guideList" onClick={this.handleTimesheetApprovalAction}>
                                <div className="active cursor-pointer">
                                  <span className="activePointer timesheetSign"></span>
                                  <span className="pl-4">
                                    SIGN
                                  </span>
                                </div>
                              </div>
                            </div>
                          </Col>
                        </Row> : <Row>
                          <Col lg="12" md="12" sm="12">
                            <span className="pl-1 pr-2 font-9">Approval Signature:</span>
                            {approvedImage && <img src={approvedImage} alt="approvalImage" height={50} />}
                          </Col>
                        </Row>}
                      </td>
                      <td colSpan='3' className="pt-5 text-left">
                        <Row className="mr-0 ml-0">
                          <span className="pl-1 font-9">Date: {timesheetdetails.approvalDate || ''}</span>
                        </Row>
                      </td>
                    </tr>}
                    <tr>
                      <th colSpan='11' className="blue-head text-center py-2">
                        Timesheet Action Tracking Log Report
                        </th>
                    </tr>
                    <tr>
                      <td colSpan='4' className="text-left">Action By</td>
                      <td colSpan='2' className="text-left">Actor's IP</td>
                      <td colSpan='2' className="text-left">Date & Time</td>
                      <td colSpan='3' className="text-left">Action Taken</td>
                    </tr>
                    {actionLogs.length > 0 ? actionLogs.map((actionData, actionKey) => {
                      return <tr key={actionKey}>
                        <td colSpan='4' className="text-left">{actionData.userName}</td>
                        <td colSpan='2' className="text-left">{actionData.actionIp}</td>
                        <td colSpan='2' className="text-left">{moment(actionData.actionTime).format('MM/DD/YYYY HH:MM A')}</td>
                        <td colSpan='3' className="text-left">[ {actionData.actionType} ] {actionData.description}</td>
                      </tr>
                    }) : <tr><td colSpan={11}></td></tr>}
                    <tr>
                      <th colSpan='11' className="py-2 text-left">
                        Privacy Act Notification: "This information is subject to the Privacy Act of 1974, (Title 5, USC 522a)"
                        </th>
                    </tr>
                  </tbody>
                </table>
              </div>
            </>
          }
        </div>

        <Modal
          scrollable={true}
          size="md"
          onHide={() => this.cancelPopup()}
          show={this.state.displayConfirmationPopup}
        >
          <Modal.Header closeButton className="h6 background-green1">
            <Modal.Title className="h6 text-white small_font" id="contained-modal-title-vcenter">
              {`${isEqual(this.state.selectedUserActivity, UserActivity.activityApproval) ? 'Activity' : 'Timesheet'} Approval Confirmation`}
            </Modal.Title>
          </Modal.Header>
          <Modal.Body className="show-grid small_font px-5">
            <p className="xs_font text-dark text-center">Please add comment to electronically sign and approve {isEqual(this.state.selectedUserActivity, UserActivity.activityApproval) ? currentActivityName + ' Hours' : 'this timesheet'}. </p>
            <p className="small_font font-weight-bold text-center">
              {`${this.formatDate(this.state.startWeekDate)} - ${this.formatDate(this.state.weekEndDate)}`}
            </p>
            {timesheetdetails.status !== 300 &&
              <div className="form-group row">
                <div className="col-lg-12 col-md-12 col-xl-12 col-sm-12 text-center">
                  <label htmlFor="exampleInputEmail1">Comment :</label>
                  <textarea
                    className="form-control"
                    value={this.state.userApprovalComments}
                    onChange={this.setUserApprovalComments}
                  />
                  {isEmpty(this.state.userApprovalComments) && (<p style={{ color: 'red' }}>This is required</p>)}
                </div>
              </div>}
            <p className="small_font text-center">
              <b>{`${get(timesheetdetails, 'userFirstname', '')}, ${get(timesheetdetails, 'userLastname', '')} - Total Hours ${currentActivityTotalHours}`}</b>
            </p>
            <p className="xs_font text-center">I Certify that all the information in this timesheet is accurate and true.</p>
          </Modal.Body>
          <Modal.Footer>
            <div className="col-12 row mt-2">
              <div className="col-6">
                <button
                  onClick={() => this.cancelPopup()}
                  className="button resend-btn background-red px-2 float-left"
                >
                  No, Cancel
                </button>
              </div>
              <div className="col-6">
                <button
                  disabled={isEmpty(this.state.userApprovalComments) || subLoading}
                  onClick={this.handleUserAction}
                  className="button resend-btn float-right px-4"
                >
                  {subLoading ? 'Please Wait' : 'Yes, Confirm'}
                </button>
              </div>
            </div>
          </Modal.Footer>
        </Modal>
      </div>
    );
  }
}

export default TimesheetChart;
