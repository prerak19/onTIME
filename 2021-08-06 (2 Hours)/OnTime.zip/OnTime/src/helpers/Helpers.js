import { confirmAlert } from 'react-confirm-alert';
import 'react-confirm-alert/src/react-confirm-alert.css';

export const confirmPopup = (submitClick) => {
  return confirmAlert({
    customUI: ({ onClose }) => {
      return (
        <div className='custom-ui'>
          <h3>Are you sure?</h3>
          <p>You want to delete this?</p>
          <button onClick={onClose}>No, Cancel</button>
          <button onClick={async () => {
            await submitClick()
            onClose();
          }}>Yes, Delete it</button>
        </div>
      );
    }
  });
};