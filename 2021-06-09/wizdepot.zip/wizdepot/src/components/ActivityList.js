import React from 'react';
import 'bs-stepper/dist/css/bs-stepper.min.css';
import Stepper from 'bs-stepper';
import { isEmpty, isEqual } from 'lodash';
import { apiGet } from '../Api';

class ActivityList extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      holidayPolicyData: {},
      roundingPolicyData: {},
      loadPolicy: false,
    };
  }

  componentDidMount() {
    this.getData();
  }

  getData = async () => {
    const { activity } = this.props;
    this.setState({ loadPolicy: true });
    if (activity.roundingPolicyID > 0) {
      const getRequest = {
        method: `policies/roundingpolicies/${activity.roundingPolicyID}`,
        params: {}
      };
      await apiGet(getRequest, true, false).then((response) => {
        if (isEqual(response.status, 200) && response.data) {
          this.setState({ roundingPolicyData: response.data, loadPolicy: false });
          this.stepper = new Stepper(document.querySelector('#stepper4'), {
            linear: false,
            animation: true
          });
        }
      }).catch(error => {
        this.setState({ roundingPolicyData: {}, loadPolicy: false });
      });
    }
    if (activity.holidayPolicyID > 0) {
      const getRequest = {
        method: `policies/holidaypolicies/${activity.holidayPolicyID}`,
        params: {}
      };
      await apiGet(getRequest, true, false).then((response) => {
        if (isEqual(response.status, 200) && response.data) {
          this.setState({ holidayPolicyData: response.data, loadPolicy: false });
          this.stepper = new Stepper(document.querySelector('#stepper4'), {
            linear: false,
            animation: true
          });
        }
      }).catch(error => {
        this.setState({ holidayPolicyData: {}, loadPolicy: false });
      });
    }
    this.setState({ loadPolicy: false });
  }

  render() {
    const { activity } = this.props;
    const { holidayPolicyData, roundingPolicyData, loadPolicy } = this.state;
    let holidaysArr = [];
    if (holidayPolicyData && holidayPolicyData.holidayList && holidayPolicyData.holidayList.length > 0) {
      holidaysArr = holidayPolicyData.holidayList.map((x) => x.desc);
    }
    return (
      <div>
        <div className="row mx-0">
          <p onClick={() => this.props.backToMenu()} className=" text-left float-left cursor-pointer font-weight-bolder blue-color"><i className="fa fa-angle-left pr-2"></i>Activities</p>
        </div>
        <div className="w-100 text-left float-left">
          <p className="text-muted mb-3">  View Policies for Activity : {activity && activity.name.toUpperCase()}</p>
          <h6 className="font-weight-bolder">{activity.name.toUpperCase()}({activity.code}) - Activity Policies</h6>
        </div>
        {loadPolicy === true ? 'Please Wait...' :
          (isEmpty(roundingPolicyData) && isEmpty(holidayPolicyData)) ? <div> No Policies Found </div>
            : <div id="stepper4" className="bs-stepper payrollform">
              <div className="bs-stepper-header">
                {!isEmpty(roundingPolicyData) && <div className="step" data-target="#test11">
                  <button className="step-trigger">
                    <span className="bs-stepper-label4">Rounding Policy</span>
                  </button>
                </div>}
                {!isEmpty(holidayPolicyData) && <div className="step" data-target="#test12">
                  <button className="step-trigger">
                    <span className="bs-stepper-label4">Holiday Policy</span>
                  </button>
                </div>}
              </div>
              <div className="stepper-content">
                <div id="test11" className="content small_font ml-4">
                  <p><b>Policy Name : </b>{roundingPolicyData.name}</p>
                  <p><b>Policy Description : </b>This policy rounds the punches of employees who use the time clock to punch in and out to the nearest 0.25 hour. The rounding is performed using a 7/8 split method, meaning any punch 7 minutes or under rounds down, and 8 minutes or up rounds up. </p>
                  <p><b>Punch Type to Round : </b>All</p>
                  <p><b>How to Round : </b>7/8 Split Round</p>
                  <p><b>Round Interval : </b>Nearest 15 minutes</p>
                </div>
                <div id="test12" className="content small_font ml-4">
                  <p><b>Policy Name : </b>{holidayPolicyData.name}</p>
                  <p><b>Policy Description : </b>{holidayPolicyData.description}</p>
                  <p><b>Reoccuring Holidays : </b>{holidaysArr.join(', ')}</p>
                </div>
              </div>
            </div>
        }
      </div>
    );
  }
}
export default ActivityList;