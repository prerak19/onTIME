import React from 'react';
import { Container } from 'react-bootstrap';
import 'bootstrap/dist/css/bootstrap.min.css';
import './App.css';
import AdminHeader from './components/AdminHeader.js';
import ReportingSection from './ReportingSection.js';
import PayrollTable from './components/PayrollTable';
import TimesheetPreview from './components/TimesheetPreview';
import moment from 'moment';
import TimesheetReciept from './components/timesheetRecieptReport';

class Reporting extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      startDate: new Date(moment().day(0).format('YYYY-MM-DD')),
      endDate: new Date(moment().day(6).format('YYYY-MM-DD')),
      activityTimeArr: [],
      summaryArr: [],
      orgImage: null,
      payRollArr: [],
      dutyCodeArr: [],
      withourDutyCodeArr: [],
      finalTotalPayRoll: {},
      disFilterArr: [],
      originalArr: [],
      showreport: '',
      companyDetails: {},
    };
  }

  setProps = (props) => {
    const { showreport, summaryArr, originalArr, detailsArr, activityTimeArr, disFilterArr, payRollArr,
      dutyCodeArr, finalTotalPayRoll, orgImage, withourDutyCodeArr, startDate, endDate, companyDetails } = props;
    if (showreport === 'payroll') {
      this.setState({
        showreport, payRollArr, dutyCodeArr, finalTotalPayRoll,
        withourDutyCodeArr, disFilterArr, startDate, endDate, companyDetails, orgImage
      })
    } else if (showreport === 'original') {
      this.setState({
        showreport, originalArr, startDate, endDate, orgImage
      });
    } else {
      this.setState({
        showreport, summaryArr, detailsArr, activityTimeArr,
        disFilterArr, startDate, endDate, companyDetails, orgImage
      });
    }

  }
  render() {
    const { showreport, startDate, endDate, activityTimeArr, summaryArr, detailsArr, payRollArr,
      dutyCodeArr, withourDutyCodeArr, originalArr, finalTotalPayRoll, disFilterArr, companyDetails, orgImage } = this.state;
    return (
      <div className="App">
        <Container>
          <header className="admin-header">
            <AdminHeader />
          </header>
          <ReportingSection setProps={this.setProps} />
        </Container>
        { showreport === 'payroll' && <PayrollTable  orgImage={orgImage} companyDetails={companyDetails} payRollArr={payRollArr} dutyCodeArr={dutyCodeArr} withourDutyCodeArr={withourDutyCodeArr} finalTotalPayRoll={finalTotalPayRoll} startDate={startDate} endDate={endDate} disFilterArr={disFilterArr} />}
        { showreport === 'timesheet' && <TimesheetPreview orgImage={orgImage} companyDetails={companyDetails} activityTimeArr={activityTimeArr} summaryArr={summaryArr} detailsArr={detailsArr} startDate={startDate} endDate={endDate} disFilterArr={disFilterArr} />}
        { showreport === 'original' && <TimesheetReciept orgImage={orgImage} companyDetails={companyDetails} startDate={startDate} endDate={endDate} originalArr={originalArr} />}
      </div>
    );
  }
}

export default Reporting;
