import React from 'react';
import 'bootstrap/dist/css/bootstrap.min.css';
import './App.css';
import DatePicker from "react-datepicker";
import "react-datepicker/dist/react-datepicker.css";
import moment from 'moment';
import { apiPost, apiGet, getBlobImage } from './Api';
import { difference, find, groupBy, isEmpty, isEqual, sortBy, sum, uniqBy } from 'lodash';
import { activity_types_codes, DAYS_OF_WEEK, employeeStatus, wayToPack } from './helpers/GeneralHelper';

class ReportingSection extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      startDate: new Date(moment().day(0).format('YYYY-MM-DD')),
      endDate: new Date(moment().day(6).format('YYYY-MM-DD')),
      grpIds: [],
      actIds: [],
      indIds: [],
      groupData: [],
      companyDetails: {},
      activityData: [],
      individualData: [],
      reportLoading: false,
      disFilterArr: [],
      employee_type: 'active',
      includesReport: 'allemployees',
      reportingHours: 'allhours',
      packEmployees: 'alphabet',
      subPackEmp: 'group-alphabet',
      preview: 'timesheet',
      showreport: '',
      orgImage: null,
    };
  }

  componentDidMount = () => {
    this.getData();
    this.getOrganizationData();
    this.getOrganizationImage();
  }

  getImage = (data) => {
    return new Promise((resolve) => {
      const reader = new FileReader()
      reader.onloadend = () => resolve(reader.result)
      reader.readAsDataURL(data)
    })
  }
  getOrganizationImage = async (type = 'org_logo') => {
    let imageSrc = '';
    const getRequest = {
      method: `employees/images?id=${localStorage.orgid}&itemtype=${type}`
    };
    await getBlobImage(getRequest).then(async (response) => {
      if (response.data && response.data.size) {
        imageSrc = await this.getImage(response.data);
        this.setState({ orgImage: imageSrc })
      }
    }).catch(error => {
      console.log(error);
    });
  }


  getOrganizationData = (e) => {
    let requestDetails = {
      method: 'organizations/' + localStorage.orgid,
      params: { user_id: localStorage.userid }
    };
    apiGet(requestDetails, true).then((response) => {
      this.setState({ companyDetails: response.data });
    }).catch(error => {
      console.log(error)
    });
  }

  getData = async () => {
    const groupsParams = { method: `groups/all/${localStorage.orgid}`, params: {} };
    const activityParams = { method: `activities/all/${localStorage.orgid}`, params: {} };
    const individualsParams = { method: `employees/all/${localStorage.orgid}`, params: {} };

    const groupApi = apiGet(groupsParams, true, false);
    const activityApi = apiGet(activityParams, true, false);
    const individualApi = apiPost(individualsParams, true, false);

    await Promise.all([groupApi, activityApi, individualApi]).then(([grpRes, actRes, indRes]) => {
      this.setState({
        groupData: grpRes.data || [],
        activityData: actRes.data || [],
        individualData: indRes.data ? indRes.data.users : []
      })
    }).catch(error => {
      this.setState({
        groupData: [],
        activityData: [],
        individualData: []
      })
      console.log(`Error in promises ${error}`)
    });
  }

  loadPreview = async (e) => {
    e.preventDefault();
    const { employee_type, subPackEmp, packEmployees, startDate, endDate, grpIds, actIds, indIds } = this.state;
    let empStatus = employeeStatus[employee_type];
    let packEmp = wayToPack[packEmployees !== 'groups' ? packEmployees : subPackEmp];
    this.setState({ reportLoading: true });
    const request = {
      method: `timesheets/reports/${localStorage.orgid}`,
      params: {
        startDate: startDate ? moment(startDate).format('YYYY-MM-DD') : null,
        endDate: endDate ? moment(endDate).format('YYYY-MM-DD') : null,
        employees: indIds,
        groups: grpIds,
        activitiesOfUser: actIds,
        employeeStatus: empStatus,
        wayToPack: packEmp
      }
    }
    apiPost(request).then((response) => {
      if (isEqual(response.status, 200) && response.data) {
        this.updateLayoutData(response.data);
      } else if (isEmpty(response.data)) {
        window.alert('Something went wrong!');
        this.setState({ reportLoading: false });
        return;
      }
    }).catch((err) => {
      this.setState({ reportLoading: false });
    })
  }

  getDaysBetweenDates = () => {
    const { startDate, endDate } = this.state;
    let now = moment(startDate).clone();
    let dates = [];

    while (now.isSameOrBefore(moment(endDate))) {
      dates.push(now.format('YYYY-MM-DD'));
      now.add(1, 'days');
    }
    return dates;
  };

  updateLayoutData = (response) => {
    const { preview, grpIds, orgImage, actIds, companyDetails, indIds, groupData, activityData, individualData, startDate, endDate } = this.state;

    let disFilterArr = [];
    if (grpIds.length > 0) {
      disFilterArr = groupData.filter((x) => grpIds.includes(x.id));
      disFilterArr = disFilterArr.map((dis) => ({ ...dis, label: 'groups' }));
    } else if (actIds.length > 0) {
      disFilterArr = activityData.filter((x) => actIds.includes(x.actID));
      disFilterArr = disFilterArr.map((dis) => ({ ...dis, label: 'activities' }));
    } else {
      disFilterArr = individualData.filter((x) => indIds.includes(x.userID));
      disFilterArr = disFilterArr.map((dis) => ({ ...dis, label: 'individuals' }));
    }
    if (response.timsheets.length > 0) {
      let reportArr = groupBy(response.timsheets, 'uid');
      if (preview === 'payroll') {
        let payRollArr = [];
        let actTypeArr = [];
        let dutyCodeArr = [];
        let withourDutyCodeArr = [];
        Object.values(reportArr).map((x, i) => {
          let firstName = x[0].userFirstname;
          let lastName = x[0].userLastname;
          let payObj = {};
          x.map((actList) => {
            let sortArr = sortBy(actList.activityTime, 'activityName');
            sortArr.map((act) => {
              const actType = (activity_types_codes[act.activityType]).toUpperCase();
              if (!actTypeArr.includes(actType)) {
                actTypeArr.push(actType);
              }
              if (!dutyCodeArr.includes(act.activityCode) && actType === 'DUTY') {
                dutyCodeArr.push(act.activityCode);
              }
              if (!find(withourDutyCodeArr, { code: act.activityCode }) && actType !== 'DUTY') {
                withourDutyCodeArr.push({ code: act.activityCode, name: actType });
              }
              if (payObj.hasOwnProperty(actType)) {
                if (payObj[actType].find((mn) => mn.code === act.activityCode)) {
                  payObj[actType] = payObj[actType].map((nm) => {
                    if (nm.code === act.activityCode) {
                      return { ...nm, value: nm.value + sum(Object.values(DAYS_OF_WEEK).map((day) => act[`${day.toLowerCase()}Hour`])) }
                    } else {
                      return nm;
                    }
                  })
                } else {
                  payObj[actType].push({
                    code: act.activityCode, name: act.activityName, value: sum(Object.values(DAYS_OF_WEEK).map((day) => act[`${day.toLowerCase()}Hour`]))
                  })
                }
              } else {
                payObj[actType] = [{ code: act.activityCode, name: act.activityName, value: sum(Object.values(DAYS_OF_WEEK).map((day) => act[`${day.toLowerCase()}Hour`])) }];
                return null;
              }
              return null;
            });

            let compareArr = difference(actTypeArr, Object.keys(payObj));
            if (compareArr.length > 0) {
              compareArr.map((cmp) => (!payObj[cmp] ? payObj = { ...payObj, [cmp]: [{ value: 0.0 }] } : null));
            }
            return null;
          });
          dutyCodeArr.map((un) => {
            let oj = find(payObj['DUTY'], { code: un });
            if (!oj) {
              payObj['DUTY'].push({ code: un, value: 0 });
            }
            return null;
          })
          payObj['DUTY'] = sortBy(payObj['DUTY'], 'code');
          let dutyTotal = sum(payObj['DUTY'].map((c) => c.value));
          let allTotal = 0.00;
          Object.values(payObj).map((su) => (allTotal = allTotal + sum(su.map((c) => c.value))))
          payRollArr.push({ firstName, lastName, groupCode: x[0].groupCode, timeObj: payObj, dutyTotal, allTotal, actTypeArr });
          return null;
        })
        let dutyWiseTotal = [];
        payRollArr.map((kj) => {
          Object.values(kj.timeObj).map((ml) => {
            ml.map((cd) => {
              if (find(dutyWiseTotal, { code: cd.code })) {
                dutyWiseTotal = dutyWiseTotal.map((de) => {
                  if (de.code === cd.code) {
                    return { ...de, value: de.value + cd.value }
                  } else {
                    return de;
                  }
                });
              } else {
                cd.code && dutyWiseTotal.push(cd);
              }
              return null;
            })
            return null;
          })
          return null;
        })

        let finalTotalPayRoll = {
          finalRegHoursTtl: sum(payRollArr.map((p) => p.allTotal)),
          allActTotal: sum(payRollArr.map((p) => p.allTotal)),
          allDutyTotal: sum(payRollArr.map((p) => p.dutyTotal)),
          dutyWiseTotal,
        }
        this.props.setProps({
          showreport: preview, payRollArr, dutyCodeArr, finalTotalPayRoll,
          withourDutyCodeArr, disFilterArr,
          startDate,
          orgImage,
          endDate,
          companyDetails
        })
        this.setState({ reportLoading: false });
      } else if (preview === 'original') {
        let originalArr = [];
        response.timsheets.map(async (data, index) => {
          let employeeApprovalImg = '';
          let approvalImage = '';
          const sunday = new Date(moment(data.startDate).day(0));
          const nextSunday = new Date(moment(data.startDate).day(6));
          const startDay = moment(sunday);
          let totalHours = 0;
          const daysOfWeekFromStart = [
            {
              day: DAYS_OF_WEEK[startDay.day()],
              date: startDay.format('MMM D'),
              fullDate: startDay.format('YYYY-MM-DD'),
            }
          ];
          for (let i = 1; i <= 6; ++i) {
            const newDay = startDay;
            newDay.add(1, 'day');
            daysOfWeekFromStart.push({
              day: DAYS_OF_WEEK[newDay.day()],
              date: newDay.format('MMM D'),
              fullDate: newDay.format('YYYY-MM-DD'),
            })
          }
          if (data) {
            totalHours = sum(data.activityTime.map((activity, i) => {
              return sum(Object.values(DAYS_OF_WEEK).map((day) => activity[`${day.toLowerCase()}Hour`]));
            }));
          };

          originalArr.push({
            ...data,
            timesheetdetails: data,
            indexValue: index + 1,
            startWeekDate: moment(sunday).format('YYYY-MM-DD'),
            weekEndDate: moment(nextSunday).format('YYYY-MM-DD'),
            daysOfWeek: daysOfWeekFromStart,
            totalHours,
            employeeApprovalImg,
            activityID: data.activityTime[0].activityID,
            approvalImage,
            timesheetLoading: false,
          });
        })
        this.props.setProps({
          showreport: preview,
          orgImage,
          originalArr,
          companyDetails,
          startDate,
          endDate,
        });
        this.setState({ reportLoading: false });
      } else {
        let activityTimeArr = response.timsheets.map((x) => x.activityTime).flat();
        activityTimeArr = sortBy(uniqBy(activityTimeArr, function (e) { return e.activityName; }), 'activityName');
        activityTimeArr = activityTimeArr.map((x) => x.activityName);
        let dates = this.getDaysBetweenDates();
        let summaryArr = [];
        let detailsArr = [];
        Object.values(reportArr).map((x, i) => {
          let dArr = {};
          x.map((actList) => {
            let startD = actList.startDate;
            let sortArr = sortBy(actList.activityTime, 'activityName');
            const sunday = new Date(moment(startD).day(0));
            const startDay = moment(sunday);
            const daysOfWeekFromStart = [
              {
                day: DAYS_OF_WEEK[startDay.day()],
                date: startDay.format('MMM D'),
                fullDate: startDay.format('YYYY-MM-DD'),
              }
            ];
            for (let i = 1; i <= 6; ++i) {
              const newDay = startDay;
              newDay.add(1, 'day');
              daysOfWeekFromStart.push({
                day: DAYS_OF_WEEK[newDay.day()],
                date: newDay.format('MMM D'),
                fullDate: newDay.format('YYYY-MM-DD'),
              })
            }

            sortArr.map((act) => {
              let month = moment(dates[0]).format('MMMM');
              dates.map((dt, i) => {
                if (month !== moment(dt).format('MMMM')) {
                  month = moment(dt).format('MMMM');
                }
                let obj = {
                  [`${moment(dt).format('D')}_${month}-${dt}`]: daysOfWeekFromStart.find((x) => x.fullDate === dt) ? act[`${daysOfWeekFromStart.find((x) => x.fullDate === dt).day.toLowerCase()}Hour`] : 0.0,
                };
                let actFull = `${act.activityName}_${act.activityCode}`;
                if (dArr[actFull]) {
                  dArr[actFull] = { ...dArr[actFull], ...obj }
                } else {
                  dArr[actFull] = obj;
                }
                return null;
              })
              return null;
            })
            return null;
          })
          detailsArr.push({ ...dArr, firstName: x[0].userFirstname, lastName: x[0].userLastname, groupName: x[0].groupName, groupCode: x[0].groupCode });
          return detailsArr;
        });

        Object.values(reportArr).map((x, i) => {
          let obj = {};
          x.map((actList) => {
            let sortArr = sortBy(actList.activityTime, 'activityName');
            let actArr = [];
            sortArr.map((act) => {
              actArr.push(act.activityName);
              if (obj.hasOwnProperty(act.activityName)) {
                obj[act.activityName] = parseFloat(obj[act.activityName]) + sum(Object.values(DAYS_OF_WEEK).map((day) => act[`${day.toLowerCase()}Hour`]));
              } else {
                obj[act.activityName] = sum(Object.values(DAYS_OF_WEEK).map((day) => act[`${day.toLowerCase()}Hour`]));
              }
              return null;
            })
            let compareArr = difference(activityTimeArr, actArr);
            compareArr.map((x) => (!obj[x] ? obj = { ...obj, [x]: 0.0 } : null));
            obj = Object.keys(obj).sort().reduce((newObj, key) => { newObj[key] = obj[key]; return newObj; }, {});
            return null;
          })
          summaryArr.push({ firstName: x[0].userFirstname, lastName: x[0].userLastname, groupName: x[0].groupName, timeObj: obj });
          return summaryArr;
        })
        this.props.setProps({
          showreport: preview,
          summaryArr,
          orgImage,
          detailsArr,
          activityTimeArr,
          disFilterArr,
          startDate,
          endDate,
          companyDetails
        })
        this.setState({ reportLoading: false });
      }
    }
    else {
      this.props.setProps({
        showreport: '',
        orgImage: null,
        disFilterArr,
        detailsArr: [],
        dutyCodeArr: [],
        withourDutyCodeArr: [],
        finalTotalPayRoll: {},
        payRollArr: [],
        companyDetails:{},
        originalArr: [],
        summaryArr: [], activityTimeArr: []
      })
      this.setState({ reportLoading: false });
      window.alert('No Data Found!!!');
      return;
    }
  }

  getApprovalImage = async (type = 'user_signature', uid = '') => {
    let imageSrc = '';
    const getRequest = {
      method: `employees/images?id=${uid}&itemtype=${type}`
    };
    await getBlobImage(getRequest).then((response) => {
      if (response.data && response.data.size) {
        imageSrc = URL.createObjectURL(response.data);
      }
    }).catch(error => {
      console.log(error);
    });
    return imageSrc;
  }

  changeGroup = (event, name) => {
    let value = Array.from(event.target.selectedOptions, option => Number(option.value));
    this.setState({ [name]: value });
  }
  render() {
    const { groupData, grpIds, actIds, reportLoading, startDate, endDate, packEmployees, preview,
      activityData, indIds, individualData, includesReport, reportingHours } = this.state;
    return (
      <div className="contentwrapper pt-2 pb-5 text-left small_font">
        <h5 className="mt-2">Timesheet Reporting</h5>
        <form onSubmit={this.onSubmit} className="payrollform mt-3">
          <div className="form-group row col-12">
            <label className="col-xl-2 col-lg-2 col-md-2 col-sm-10 p-0 permission-label">Report Time Period</label>
            <div className="col-xl-3 col-lg-3 col-md-3 col-sm-6 inner-addon right-addon pl-0">
              <i className="fa fa-calendar pr-3"></i>
              <DatePicker className="form-control col-xl-12 col-lg-12 col-md-12 col-sm-12 ml-2" placeholderText="Start Date"
                selected={startDate}
                onChange={date => this.setState({ startDate: date })}
                selectsStart
                startDate={startDate}
                endDate={endDate}
              />
            </div>
            <div className="col-xl-3 col-lg-3 col-md-3 col-sm-6 inner-addon right-addon pl-0">
              <i className="fa fa-calendar pr-3"></i>
              <DatePicker className="form-control col-xl-12 col-lg-12 col-md-12 col-sm-12 ml-2" placeholderText="End Date"
                selected={endDate}
                onChange={date => this.setState({ endDate: date })}
                selectsEnd
                startDate={startDate}
                endDate={endDate}
                minDate={startDate}
              />
            </div>
          </div>
          <div className="form-group row col-12 mb-1">
            <label className="col-xl-2 col-lg-2 col-md-2 col-sm-10 p-0 permission-label">Report Includes</label>
            <div className="col-xl-2 col-lg-2 col-md-2 col-sm-10 p-0">
              <input type="radio" value="allemployees" defaultChecked onClick={() => this.setState({ includesReport: 'allemployees', grpIds: [], actIds: [], indIds: [] })} className="form-control permission-checkbox" name="includesReport" />
              <label className="permission-label">All Employees</label>
            </div>
            <div className="col-xl-2 col-lg-2 col-md-2 col-sm-10 p-0">
              <input type="radio" value="groups" onClick={() => this.setState({ includesReport: 'groups', grpIds: [], actIds: [], indIds: [] })} className="form-control permission-checkbox" name="includesReport" />
              <label className="permission-label">Groups</label>
            </div>
            <div className="col-xl-2 col-lg-2 col-md-2 col-sm-10 p-0">
              <input type="radio" value="activities" onClick={() => this.setState({ includesReport: 'activities', grpIds: [], actIds: [], indIds: [] })} className="form-control permission-checkbox" name="includesReport" />
              <label className="permission-label">Activities</label>
            </div>
            <div className="col-xl-2 col-lg-2 col-md-2 col-sm-10 p-0">
              <input type="radio" value="individuals" onClick={() => this.setState({ includesReport: 'individuals', grpIds: [], actIds: [], indIds: [] })} className="form-control permission-checkbox" name="includesReport" />
              <label className="permission-label">Individuals</label>
            </div>
          </div>
          {includesReport === 'groups' && <div className="form-group row col-xl-8 col-lg-8 col-md-8 offset-md-4 offset-lg-4 col-sm-10">
            <label className="permission-label pl-0">Select Group</label>
            <select className="form-control col-xl-3 col-lg-3 col-md-3 col-sm-10 ml-0" multiple='multiple'
              onChange={(event) => this.changeGroup(event, 'grpIds')}
              value={grpIds}>
              {groupData && groupData.map((grp) => {
                return <option value={grp.id} key={grp.id}>{grp.name}</option>
              })}
            </select>
          </div>}
          {includesReport === 'activities' && <div className="form-group row col-xl-8 col-lg-8 col-md-8 offset-md-6 offset-lg-6 col-sm-10">
            <label className="permission-label pl-0">Select Activities</label>
            <select className="form-control col-xl-3 col-lg-3 col-md-3 col-sm-10 ml-0" multiple='multiple'
              onChange={(event) => this.changeGroup(event, 'actIds')}
              value={actIds}>
              {activityData && activityData.map((act) => {
                return <option value={act.actID} key={act.actID}>{act.name}</option>
              })}
            </select>
          </div>}
          {includesReport === 'individuals' && <div className="form-group row col-xl-8 col-lg-8 col-md-8 col-md-4 offset-md-8 offset-lg-8 col-sm-10" >
            <label className="permission-label pl-0">Select Employee</label>
            <select className="form-control col-xl-3 col-lg-3 col-md-3 col-sm-10 ml-0" multiple='multiple'
              onChange={(event) => this.changeGroup(event, 'indIds')}
              value={indIds}>
              {individualData && individualData.map((ind) => {
                return <option value={ind.userID} key={ind.userID}>{ind.lastName} {ind.firstName}</option>
              })}
            </select>
          </div>}
          <div className="form-group row col-12" style={includesReport !== 'individuals' ? {} : { display: 'none' }}>
            <label className="col-xl-2 col-lg-2 col-md-2 col-sm-10 p-0 permission-label">Select Employee Type</label>
            <div className="col-xl-2 col-lg-2 col-md-2 col-sm-10 p-0">
              <input type="radio" value='active' defaultChecked onClick={() => this.setState({ employee_type: 'active' })} className="form-control permission-checkbox" name="employee_type" />
              <label className="permission-label">Active Employees</label>
            </div>
            <div className="col-xl-2 col-lg-2 col-md-2 col-sm-10 p-0">
              <input type="radio" value='inactive' onClick={() => this.setState({ employee_type: 'inactive' })} className="form-control permission-checkbox" name="employee_type" />
              <label className="permission-label">Inactive Employees</label>
            </div>
            <div className="col-xl-2 col-lg-2 col-md-2 col-sm-10 p-0">
              <input type="radio" value='both' onClick={() => this.setState({ employee_type: 'both' })} className="form-control permission-checkbox" name="employee_type" />
              <label className="permission-label">Both Active and Inactive</label>
            </div>
          </div>
          <div className="form-group row col-12 mb-1">
            <label className="col-xl-2 col-lg-2 col-md-2 col-sm-10 p-0 permission-label">Hours to be Reported</label>
            <div className="col-xl-2 col-lg-2 col-md-2 col-sm-10 p-0">
              <input type="radio" value="allhours" defaultChecked onClick={() => this.setState({ reportingHours: 'allhours', actIds: [] })} className="form-control permission-checkbox" name="reportinghours" />
              <label className="permission-label">All Hours</label>
            </div>
            <div className="col-xl-2 col-lg-2 col-md-2 col-sm-10 p-0">
              <input type="radio" value="activities" onClick={() => this.setState({ reportingHours: 'activities', actIds: [] })} className="form-control permission-checkbox" name="reportinghours" />
              <label className="permission-label">Activities</label>
            </div>
          </div>
          {reportingHours === 'activities' && <div className="form-group row col-xl-8 col-lg-8 col-md-8 offset-md-4 offset-lg-4 col-sm-10">
            <label className="permission-label pl-0">Select Activities</label>
            <select className="form-control col-xl-3 col-lg-3 col-md-3 col-sm-10 ml-0" multiple='multiple'
              onChange={(event) => this.changeGroup(event, 'actIds')}
              value={actIds}>
              {activityData && activityData.map((act) => {
                return <option value={act.actID} key={act.actID}>{act.name}</option>
              })}
            </select>
          </div>}
          <div className="form-group row col-12 mb-1">
            <label className="col-xl-2 col-lg-2 col-md-2 col-sm-10 p-0 permission-label">Pack Employees in Report</label>
            <div className="col-xl-2 col-lg-2 col-md-2 col-sm-10 p-0">
              <input type="radio" value="alphabet" defaultChecked onClick={() => this.setState({ packEmployees: 'alphabet' })} className="form-control permission-checkbox" name="packemployees" />
              <label className="permission-label">Alphabetically</label>
            </div>
            <div className="col-xl-2 col-lg-2 col-md-2 col-sm-10 p-0">
              <input type="radio" value="groups" onClick={() => this.setState({ packEmployees: 'groups' })} className="form-control permission-checkbox" name="packemployees" />
              <label className="permission-label">Groups</label>
            </div>
            <div className="col-xl-2 col-lg-2 col-md-2 col-sm-10 p-0">
              <input type="radio" value="wage" onClick={() => this.setState({ packEmployees: 'wage' })} className="form-control permission-checkbox" name="packemployees" />
              <label className="permission-label">Wage Category</label>
            </div>
          </div>
          {packEmployees === 'groups' && <div className="form-group row col-xl-8 col-lg-8 col-md-8 offset-md-4 offset-lg-4 col-sm-10 pl-0">
            <label className="permission-label pl-0">How to Pack within Group</label>
            <div className="col-xl-12 col-lg-12 col-md-12 col-sm-10 ml-0 pl-0">
              <input type="radio" value="group-alphabet" defaultChecked onClick={() => this.setState({ subPackEmp: 'group-alphabet' })} className="form-control mt-0 permission-checkbox" name="packemployeesgroup" />
              <label className="permission-label">Alphabetically</label>
            </div>
            <div className="col-xl-12 col-lg-12 col-md-12 col-sm-10 ml-0 pl-0">
              <input type="radio" value="group-wage" onClick={() => this.setState({ subPackEmp: 'group-wage' })} className="form-control mt-0 permission-checkbox" name="packemployeesgroup" />
              <label className="permission-label">Wage Category</label>
            </div>
          </div>}
          <div className="form-group row col-12">
            <label className="col-xl-2 col-lg-2 col-md-2 col-sm-10 p-0 permission-label">Report Type</label>
            <select value={preview} onChange={(e) => this.setState({ preview: e.target.value })} className="form-control col-xl-6 col-lg-6 col-md-6 col-sm-10 ml-2">
              <option value="timesheet">Timesheet Report</option>
              <option value="original">Original Timesheet Receipt</option>
              <option value="payroll">Payroll Report</option>
              <option value="quickbook" disabled >Export Report for QuickBook</option>
            </select>
          </div>
          <div className="form-group row col-12 h-auto m-auto pt-3">
            <button onClick={this.loadPreview} className="button resend-btn m-auto">{reportLoading ? 'Please Wait...' : 'Generate Report'}</button>
          </div>
        </form>
      </div>
    );
  }
}

export default ReportingSection;
