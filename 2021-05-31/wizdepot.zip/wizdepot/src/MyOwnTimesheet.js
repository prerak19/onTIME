import React from 'react';
import DatePicker from "react-datepicker";
import {
  Modal,
  Row,
  Col,
  Popover,
  OverlayTrigger
} from "react-bootstrap";
import { MDBBtn } from 'mdbreact';
import Timer from 'react-compound-timer';
import { find, get, isEmpty, isEqual, sortBy, sum } from 'lodash';
import moment from 'moment';
import { apiGet, apiPost, apiPut, getBlobImage } from './Api.js';
import { DAYS_OF_WEEK, timesheet_status_codes, ClockInOuts, toNumber } from './helpers/GeneralHelper';
import "react-datepicker/dist/react-datepicker.css";

class MyOwnTimesheet extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      startTime: null,
      stopTime: null,
      weeklyDate: null,
      clockin: true,
      signshow: false,
      companyDetails:{},
      startWeekDate: '',
      weekEndDate: '',
      timesheetdetails: {},
      daysOfWeek: [],
      activityID: '',
      approvalImage: '',
      totalHours: 0.0,
      activityTotalsArr: [],
      displayConfirmationPopup: false,
      subLoading: false,
      employeeApprovalImg: '',
      userName: '',
      passWord: '',
      punchOutTime: '',
      selectedUserActivity: null,
      timesheetLoading: false,
    };
  }

  componentDidMount() {
    const startWeekDate = moment().day(0);
    const weekEndDate = moment().day(6);
    const weeklyDate = new Date(moment());
    this.setState({
      weeklyDate,
      startWeekDate,
      weekEndDate,
    }, () => {
      this.getTimesheetRecord(startWeekDate.format('YYYY-MM-DD'), true, true);
    })
  }

  getTimesheetRecord = async (startDate, sheetLoading = true, lastClockIn = false) => {
    this.setState({ timesheetLoading: sheetLoading });
    const requestDetails = {
      method: `timesheets/${get(localStorage, 'userid', '')}/${startDate}`,
      params: {}
    };
    await apiGet(requestDetails, true, false).then(async (response) => {
      if (isEqual(response.status, 200) && response.data) {
        await this.updateLayoutData(response.data, lastClockIn)
      }
    }).catch(error => {
      this.setState({ timesheetLoading: false });
    });
  }

  updateLayoutData = async (data, lastClockIn) => {
    const sunday = new Date(moment(get(data, 'startDate')).day(0));
    const nextSunday = new Date(moment(get(data, 'startDate')).day(6));
    const startDay = moment(sunday);
    let employeeApprovalImg = '';
    let approvalImage = '';
    let totalHours = 0;
    const daysOfWeekFromStart = [
      {
        day: DAYS_OF_WEEK[startDay.day()],
        date: startDay.format('MMM D'),
        fullDate: startDay.format('YYYY-MM-DD'),
      }
    ];
    for (let i = 1; i <= 6; ++i) {
      const newDay = startDay;
      newDay.add(1, 'day');
      daysOfWeekFromStart.push({
        day: DAYS_OF_WEEK[newDay.day()],
        date: newDay.format('MMM D'),
        fullDate: newDay.format('YYYY-MM-DD'),
      })
    }
    let dayWiseTotalObj = {};
    let activityTotalsArr = [];
    if (data && data.activityTime && data.activityTime.length > 0) {
      totalHours = sum(data.activityTime.map((activity, i) => {
        return sum(Object.values(DAYS_OF_WEEK).map((day) => activity[`${day.toLowerCase()}Hour`]));
      }));
      data.activityTime.map((x) => {
        Object.entries(x).map((act) => {
          let hourName = act[0].includes('Hour');
          if (hourName) {
            if (dayWiseTotalObj[act[0]]) {
              dayWiseTotalObj[act[0]] = dayWiseTotalObj[act[0]] + Number(act[1])
            } else {
              dayWiseTotalObj[act[0]] = Number(act[1]);
            }
          }
          return null;
        })
        return null;
      })
      Object.values(DAYS_OF_WEEK).map((day) => {
        const dayName = `${day.toLowerCase()}Hour`;
        if (dayWiseTotalObj.hasOwnProperty(dayName)) {
          activityTotalsArr.push({ dayName, value: dayWiseTotalObj[dayName] })
        }
        return null;
      })
    };

    if (lastClockIn && data.activityTime && data.activityTime.length > 0) {
      await this.getClockInData(data);
    }
    if (data.status >= 300) {
      employeeApprovalImg = await this.getApprovalImage('user_signature', data.uid);
      if (data.status >= 500) {
        approvalImage = await this.getApprovalImage('user_signature', data.approvedBy);
      }
    }
    this.setState({
      timesheetdetails: data,
      weeklyDate: sunday,
      startWeekDate: moment(sunday).format('YYYY-MM-DD'),
      weekEndDate: moment(nextSunday).format('YYYY-MM-DD'),
      daysOfWeek: daysOfWeekFromStart,
      totalHours,
      activityTotalsArr,
      employeeApprovalImg,
      approvalImage,
      punchOutTime: '',
      subLoading: false,
      timesheetLoading: false,
      signshow: false,
      clockinLoading: false,
      stopTime: null,
      startTime: null
    });
    document.body.click();
  }

  getApprovalImage = async (type = 'user_signature', uid = '') => {
    let userId = get(localStorage, 'userid', '');
    if (uid) { userId = uid; }
    let imageSrc = '';
    const getRequest = {
      method: `employees/images?id=${userId}&itemtype=${type}`
    };
    await getBlobImage(getRequest).then((response) => {
      if (response.data && response.data.size) {
        imageSrc = URL.createObjectURL(response.data);
      }
    }).catch(error => {
      console.log(error);
    });
    return imageSrc;
  }

  cancelPopup = () => {
    this.setState({
      punchOutTime: '',
    })
    document.body.click();
  }


  formatDate = (date) => moment(date).format("MMMM D, YYYY")

  handleWeekChange = (date) => {
    const formatDate = moment(date).format('YYYY-MM-DD');
    const request = {
      method: `timesheets/${get(localStorage, 'userid', '')}/${formatDate}`
    };
    this.setState({ timesheetLoading: true });
    apiGet(request, true, false).then((response) => {
      if (isEqual(response.status, 200) && response.data) {
        this.updateLayoutData(response.data);
      } else if (isEmpty(response.data)) {
        this.setState({ timesheetLoading: false });
        window.alert('No Timesheet is available for selected Week');
        return;
      }
    }).catch((err) => {
      console.log(err);
    })
  }

  updateHourForDay = (activityProps, actIndex) => {
    this.setState({ subLoading: true });
    const request = {
      method: 'timesheets/hour',
      params: {
        timesheetID: activityProps.timesheetID,
        activityID: activityProps.activityID,
        day: actIndex,
        hours: Number(this.state.punchOutTime),
        madeBy: Number(get(localStorage, 'userid', '')),
      }
    }
    apiPut(request, true).then(async (response) => {
      if (isEqual(response.status, 200) && response.data) {
        await this.getTimesheetRecord(this.state.startWeekDate);
      } else if (isEmpty(response.data)) {
        window.alert('Something went wrong!');
        this.setState({ subLoading: false });
        document.body.click();
        return;
      }
    }).catch((err) => {
      console.log(err)
      this.setState({ subLoading: false });
    })
  }

  getClockInData = (data) => {
    const request = {
      method: `activities/last-clockin?uid=${data.uid}`
    };
    apiGet(request, true, false).then((response) => {
      if (isEqual(response.status, 200) && response.data) {
        if (response.data.activityID) {
          this.setState({
            activityID: response.data.activityID,
            startTime: response.data.clockAt,
            clockin: false
          })
        }
      }
    }).catch((err) => {
      console.log(err);
    })
  }
  submitTimeSheet = () => {
    const { timesheetdetails, userName, passWord } = this.state;
    this.setState({ subLoading: true });
    const request = {
      method: `timesheets/submit?tid=${timesheetdetails.tid}`,
      params: {
        userName, passWord
      }
    }
    apiPost(request, true).then((response) => {
      if (isEqual(response.status, 200) && response.data) {
        this.getTimesheetRecord(this.state.startWeekDate);
      } else if (isEmpty(response.data)) {
        window.alert('Something went wrong!');
        this.setState({ subLoading: false });
        return;
      }
    }).catch((err) => {
      this.setState({ subLoading: false });
    })
  }

  isWeekday = (date) => date.getDay() === 0;

  handlePressStartButton = () => {
    this.setState({ clockin: false });
  }

  startClockin = () => {
    const { timesheetdetails, activityID, clockin } = this.state;
    const now = new Date();
    const request = {
      method: 'timesheets/punches',
      params: {
        timesheetID: get(timesheetdetails, 'tid', null),
        activityID: activityID,
        day: now.getDay(),
        userID: Number(get(localStorage, 'userid', '')),
        type: !clockin ? 1 : 2,
        duration: '20',
        madeBy: get(timesheetdetails, 'uid', null)
      }
    }
    this.setState({ clockinLoading: true })
    apiPost(request, true).then(async (response) => {
      if (isEqual(response.status, 200) && response.data) {
        await this.getTimesheetRecord(this.state.startWeekDate, false);
        if (!this.state.clockin) {
          this.setState({
            startTime: moment().format('hh:mm:ss A MMM DD, YYYY'),
            clockinLoading: false
          })
        } else {
          let data = await this.getClockOutData(this.state.activityID);
          if (data.activityID) {
            this.setState({ stopTime: data.clockAt });
          } else {
            this.setState({ stopTime: null });
          }
        }
      }
    }).catch((err) => {
      this.setState({
        startTime: null,
        clockinLoading: false
      })
    })
  }

  renderOptions = () => {
    return get(this.state.timesheetdetails, 'activityTime', []).map((activity) => (
      activity.timingMethod === 1 && <option value={activity.activityID} key={activity.activityID}>{activity.activityName.toUpperCase()} ({activity.activityCode})</option>
    ))
  }

  getClockOutData = async (activityId) => {
    const { timesheetdetails } = this.state;
    let data = null;
    const request = {
      method: `activities/last-clockout?uid=${get(timesheetdetails, 'uid')}&aid=${activityId}`
    };
    await apiGet(request, true, false).then((response) => {
      if (isEqual(response.status, 200) && response.data) {
        data = response.data;
      }
    }).catch((err) => {
      console.log(err);
      this.setState({ stopTime: null });
    })
    return data;
  }

  changeDropdown = async (event) => {
    let activityId = event.target.value;
    this.setState({ clockinLoading: true })
    let response = await this.getClockOutData(activityId);
    if (response.activityID) {
      this.setState({
        stopTime: response.clockAt,
        activityID: response.activityID,
        clockin: true,
        startTime: null,
        clockinLoading: false
      });
    } else {
      this.setState({
        stopTime: null,
        activityID: activityId,
        clockin: true,
        startTime: null,
        clockinLoading: false
      });
    }
  }

  getCompanyDetails = (e) => {
    e.preventDefault();
    let requestDetails = {
      method: 'organizations/' + localStorage.orgid,
      params: { user_id: localStorage.userid }
    };
    apiGet(requestDetails, true).then((response) => {
      if (response && response.data && response.status === 200) {
        this.setState({ companyDetails: response.data, signshow: true, userName: '', passWord: '' })
      }else{
        window.alert('Something Went Wrong!');
      }
    }).catch(error => {
      console.log(error)
    });
  }

  render() {
    const { totalHours, punchOutTime, clockin, clockinLoading, userName, passWord,
      timesheetdetails, timesheetLoading, startWeekDate, weekEndDate, subLoading, weeklyDate,
      approvalImage, employeeApprovalImg, activityID, activityTotalsArr, companyDetails } = this.state;
    const popoverComponent = (activityProps, activityDay) => (
      <Popover
        id={`popover-positioned-top`}
        className="timesheetpopover"
      >
        <Popover.Title as="h6" className="background-green1 text-white">
          <span className="small_font">
            {timesheetdetails.userLastname}, {timesheetdetails.userFirstname}
          </span>
          <span
            aria-label="Close"
            className="float-right icon-button cursor-pointer"
            onClick={() => {
              document.body.click();
              this.setState({ punchOutTime: '' })
            }}
          >
            x
        </span>
        </Popover.Title>
        <Popover.Content>
          <div className="row px-3">
            <label className="col-xl-3 col-lg-3 col-md-3 col-sm-10 p-0 permission-label">Time : </label>
            <div className="col-xl-7 col-lg-7 col-md-7 col-sm-10 p-0">
              <input
                type="text"
                className="form-control"
                placeholder=""
                value={punchOutTime}
                onChange={(evt) => this.setState({ punchOutTime: evt.target.value })}
              />
              {isEmpty(punchOutTime) && (<p style={{ color: 'red' }} className="mb-0">This is required</p>)}
            </div>
          </div>
          <div className="row mt-2">
            <div className="col-6">
            </div>
            <div className="col-6">
              <button
                className="button resend-btn float-right px-4"
                disabled={isEmpty(punchOutTime) || subLoading}
                onClick={() => this.updateHourForDay(activityProps, activityDay)}
              >
                Save
            </button>
            </div>
          </div>
        </Popover.Content>
      </Popover >
    );

    return (
      <div className="App">
        <div className="content">
          <div className="contentwrapper pb-5 mb-5">
            <div className="p-3 mb-3 small_font bg-amber border-0">
              <Row>
                <Col lg="5" md="5" sm="12">
                  <div className="">
                    <span className="pr-3 font-weight-bold font-16">
                      {timesheetdetails.userLastname ? timesheetdetails.userLastname + ',' : null} {timesheetdetails.userFirstname}
                    </span>
                  </div>
                </Col>
                <Col lg="3" md="3" className="text-right" />
                <Col lg="2" md="2" className="text-right">
                  <label className="act-text">Week Started</label>
                </Col>
                <Col lg="2" md="2" sm="12">
                  <div className="form-group row mb-0 inner-addon right-addon mr-2">
                    <i className="fa fa-calendar"></i>
                    <DatePicker
                      selected={weeklyDate}
                      value={moment(startWeekDate).format('YYYY-MM-DD')}
                      name="startDate"
                      className="form-control"
                      filterDate={this.isWeekday}
                      onChange={this.handleWeekChange}
                      dateFormat="yyyy-MM-dd"
                      placeholderText="yyyy-MM-dd"
                    />
                  </div>
                </Col>
              </Row>
            </div>
            {timesheetLoading ? 'Please Wait...' :
              <>
                <Row>
                  <Col lg="8" md="8" sm="12">
                    <table border='1' className="col-12 text-center text-black w-50">
                      <thead>
                        <tr>
                          <th className="blue-head">
                            {`${get(timesheetdetails, 'userFirstname', '')} ${get(timesheetdetails, 'userLastname', '')}'s Accumulated Time`}
                          </th>
                        </tr>
                      </thead>
                      <tbody>
                        <tr>
                          <th>{`Week (${this.formatDate(startWeekDate)} - ${this.formatDate(weekEndDate)})`}</th>
                        </tr>
                        <tr className="blue-num">
                          <td className="font-weight-bold">{toNumber(totalHours) || '0.00'} Hrs</td>
                        </tr>
                      </tbody>
                    </table>
                  </Col>
                  <Col lg="4" md="4" sm="12" className="row my-auto mx-0 pr-0">
                    <select
                      disabled={!clockin}
                      onChange={(event) => this.changeDropdown(event)}
                      value={this.state.activityID}
                      placeholder="Select"
                      className="col-lg-7 col-md-7 col-sm-6 form-control float-left"
                      name="state"
                    >
                      <option value="0">Select Activity</option>
                      {this.renderOptions()}
                    </select>
                    <Timer
                      className="col-12"
                      initialTime={0}
                      startImmediately={false}
                    >
                      {({ start, resume, pause, stop, reset, timerState }) => (
                        <React.Fragment>
                          {clockin && <MDBBtn
                            size="md"
                            className="col-lg-4 col-md-4 col-sm-6 ml-2 btn-success float-right"
                            disabled={timesheetdetails.status >= 300 || Number(activityID) === 0 || clockinLoading}
                            onClick={() => {
                              start();
                              this.setState({ clockin: false, startTime: null, stopTime: null }, () => this.startClockin());
                            }}
                          >
                            Clock In
                  </MDBBtn>}
                          {!clockin && <MDBBtn
                            size="md"
                            className="col-lg-4 col-md-4 col-sm-6 ml-2 btn-danger float-right"
                            onClick={() => this.setState({ clockin: true, startTime: null, stopTime: null }, () => this.startClockin())}
                            disabled={timesheetdetails.status >= 300 || Number(activityID) === 0 || clockinLoading}
                          >
                            Clock Out
                  </MDBBtn>}
                          {!clockin && <div
                            className="small_font text-success col-12 pl-0 mt-2"
                          >
                            {/* <Timer.Hours /> : <Timer.Minutes /> : <Timer.Seconds />  */}
                            {this.state.startTime && <span className="text-right float-right">Start Time : {moment(this.state.startTime).format('hh:mm:ss A MMM DD, YYYY')}</span>}
                          </div>}
                          { clockin && <div className=" text-danger small_font col-12 pl-0 mt-2" >
                            {this.state.stopTime && <span className="text-right float-right">Stop Time : {moment(this.state.stopTime).format('hh:mm:ss A MMM DD, YYYY')}</span>}
                          </div>}
                        </React.Fragment>
                      )}
                    </Timer>
                  </Col>
                </Row>

                <div className="mt-3">
                  {clockinLoading ? 'Please Wait ... ' :
                    <table border='1' className="col-12 text-black">
                      <thead>
                        <tr>
                          <th colSpan='16' className="blue-head py-2">
                            <Row>
                              <Col lg="6" md="6" sm="12">
                                <div className="pl-2  float-left">
                                  <span className="font-12">WEEKLY TIME SHEET</span>
                                  <span className="small-font pl-2">
                                    {`${this.formatDate(startWeekDate)} - ${this.formatDate(weekEndDate)}`}
                                  </span>
                                </div>
                              </Col>
                              <Col lg="6" md="6" sm="12">
                                <div className="pr-2 float-right">
                                  <span className="pr-2 font-12">
                                    {timesheet_status_codes[`${get(timesheetdetails, 'status', '')}`]}
                                  </span>
                                  <span className="font-small">{`Due on : ${this.formatDate(moment(weekEndDate).subtract(1, 'day'))}`}</span>
                                  <span className="px-1">|</span>
                                  <i className="fa fa-print px-1"></i>
                                  <i className="fa fa-file-pdf-o px-1"></i>
                                </div>
                              </Col>
                            </Row>
                          </th>
                        </tr>
                      </thead>
                      <tbody className="text-center">
                        <tr>
                          <td colSpan='2' className="font-weight-bold text-right pr-1">NAME:</td>
                          <td colSpan='11' className="pl-1 text-left">
                            {timesheetdetails.userLastname}, {timesheetdetails.userFirstname}
                          </td>
                        </tr>
                        <tr>
                          <td colSpan='2' className="font-weight-bold text-right pr-1">GROUP:</td>
                          <td colSpan='12' className="pl-1 text-left">{timesheetdetails.groupCode ? `${timesheetdetails.groupName} (${timesheetdetails.groupCode})` : 'N/A'}</td>
                        </tr>
                        <tr className="text-center font-small p-1 bg-lite-gray">
                          <th colSpan='2'></th>
                          {get(this.state, 'daysOfWeek', []).map((day, index) => (
                            <th key={`${day.day}${index}`}>{day.day}<br />{day.date}</th>
                          ))}
                          <th>Total<br />Hours</th>
                        </tr>
                        {
                          timesheetdetails && get(timesheetdetails, 'activityTime', []).map((activity) => {
                            let activityTotal = Object.values(DAYS_OF_WEEK).map((day) => activity[`${day.toLowerCase()}Hour`]).reduce((a, b) => (a + b), 0);
                            let uniqueHours = {};
                            let finalClockIns = {};
                            if (activity.clockinouts && activity.clockinouts.length > 0) {
                              activity.clockinouts.map((x, i) => {
                                let objVal = `${ClockInOuts[x.type]}`;
                                if (uniqueHours[objVal]) {
                                  if (uniqueHours[objVal].length > 0 && find(uniqueHours[objVal], { day: x.day, type: x.type })) {
                                    uniqueHours[`${objVal}_${i}`] = [x];
                                  } else {
                                    uniqueHours[objVal].push(x);
                                  }
                                } else {
                                  uniqueHours[objVal] = [x];
                                }
                                return null;
                              })
                              Object.keys(DAYS_OF_WEEK).map((y) => {
                                Object.entries(uniqueHours).map((xdata) => {
                                  finalClockIns[xdata[0]] = xdata[1];
                                  const uniqueDays = xdata[1].map(x => x.day);
                                  if (!uniqueDays.includes(Number(y))) {
                                    if (xdata[0].includes('IN')) {
                                      finalClockIns[xdata[0]].push({ day: Number(y), type: 1, clockAt: null });
                                    } else {
                                      finalClockIns[xdata[0]].push({ day: Number(y), type: 2, clockAt: null });
                                    }
                                  } else {
                                    return null;
                                  }
                                  return null;
                                })
                                return null;
                              })
                            }
                            return <React.Fragment>
                              {!isEmpty(finalClockIns) && Object.values(finalClockIns).map((x, k) => {
                                const timeType = Object.keys(finalClockIns)[k];
                                return <tr key={k}>
                                  {k === 0 && (<td rowSpan={Object.keys(finalClockIns).length}>{activity.activityName.toUpperCase()}</td>)}
                                  <td >{timeType.split('_')[0]}</td>
                                  {sortBy(x, 'day').map((dt) => <td>{dt.clockAt ? moment(dt.clockAt).format('h:mm A') : ''}</td>)}
                                  <td></td>
                                </tr>
                              })}
                              <tr className="time-td blue-text bg-lite-gray">
                                <td colSpan='2'>{`${activity.activityName.toUpperCase()} HOURS`}</td>
                                {
                                  Object.values(DAYS_OF_WEEK).map((day, index) => (
                                    (activity.enabled && activity.timingMethod === 2 && timesheetdetails.status < 300) ? (
                                      <OverlayTrigger key={`${day}${index}`} trigger="click" placement='top' rootClose={true} overlay={popoverComponent(activity, index)}>
                                        <td colSpan='1' key={`${day}${index}`} className={`text-blue cursor-pointer`}>
                                          <span variant="secondary">{activity[`${day.toLowerCase()}Hour`] > 0 ? toNumber(activity[`${day.toLowerCase()}Hour`]) : ''}</span>
                                        </td>
                                      </OverlayTrigger>
                                    ) : (
                                      <td colSpan='1' key={`${day}${index}`} className={`text-blue`}>
                                        <span variant="secondary">{activity[`${day.toLowerCase()}Hour`] > 0 ? toNumber(activity[`${day.toLowerCase()}Hour`]) : ''}</span>
                                      </td>
                                    )
                                  ))
                                }
                                <td colSpan='1'>{toNumber(activityTotal)}</td>
                              </tr>
                            </React.Fragment>
                          })
                        }
                        <tr className="time-td blue-text bg-lite-gray">
                          <td colSpan='2'>TOTAL</td>
                          {activityTotalsArr.map((dTotal, rkey) => <td key={rkey}>{toNumber(dTotal.value) || 0.00}</td>)}
                          <td className="text-blue">
                            <span variant="secondary">{toNumber(totalHours) || '0.00'}</span>
                          </td>
                        </tr>
                      </tbody>
                      <thead>
                        <tr>
                          <th colSpan='13' className="blue-head text-center py-2">
                            Timesheet Changes
                    </th>
                        </tr>
                      </thead>
                      <tr>
                        <th colSpan='13' className="py-2 text-left">
                          {
                            get(timesheetdetails, 'activityTime', []).map((activity, index) => {
                              if (!isEmpty(activity.changes) && !activity.changes.includes(null)) {
                                return activity.changes.map((timesheetChanges, timIndex) => {
                                  let actualDay = DAYS_OF_WEEK[timesheetChanges.day];
                                  let dateObject = find(get(this.state, 'daysOfWeek', []), { day: actualDay });
                                  return <p key={timIndex} className="pl-1 mb-1">
                                    <span className="ptoCircle mr-2 text-center"><span className="d-block mt-1">{index + 1}</span></span>
                                    {activity.activityName} {moment(dateObject.fullDate).format('dddd (MMM DD, YYYY)')} : {timesheetChanges.reason} - Change made by {timesheetChanges.madeByFirstname} {timesheetChanges.madeByLastname}
                                &nbsp; on {moment(timesheetChanges.madeAt).format("hh:mm A MMM DD, YYYY")}.
                              </p>
                                })
                              } else {
                                return null;
                              }
                            })
                          }
                        </th>
                      </tr>
                      <tr>
                        <th colSpan='13' className="py-2"></th>
                      </tr>
                      <tr>
                        <th colSpan='3' className="pt-5 text-left">
                          <Row>
                            <Col lg="12" md="12" sm="12" >
                              <span className="pl-1 font-9">Employee Signature: &nbsp;</span>
                              {timesheetdetails && timesheetdetails.status >= 300 ? (employeeApprovalImg && <img src={employeeApprovalImg} height={50} alt="employeeApprovalImg" />) :
                                <div className="guideList mr-3 cursor-pointer float-right" onClick={(e) => this.getCompanyDetails(e)}>
                                  <div className="active"><span className="activePointer timesheetSign"></span>
                                    <span className="pl-4">SIGN</span></div>
                                </div>}
                            </Col>
                          </Row>
                        </th>
                        <th colSpan='3' className="pt-5 text-left">
                          <Row>
                            <Col lg="12" md="12" sm="12" >
                              <span className="pl-1 font-9">Date:  &nbsp;
                            {(timesheetdetails && timesheetdetails.status >= 300) ?
                                  moment(timesheetdetails.submitDate).format('YYYY-MM-DD') : null}
                              </span>
                            </Col>
                          </Row>
                        </th>
                        <th colSpan='3' className="pt-5 text-left">
                          <Row>
                            <Col lg="12" md="12" sm="12" >
                              <span className="pl-1 font-9">Approval Signature: &nbsp;</span>
                              {(timesheetdetails && timesheetdetails.status >= 500) ?
                                approvalImage && <img src={approvalImage} alt="approvalImage" height={50} /> : null}
                            </Col>
                          </Row>
                        </th>
                        <th colSpan='3' className="pt-5 text-left">
                          <Row>
                            <Col lg="12" md="12" sm="12" >
                              <span className="pl-1 font-9">Date:  &nbsp;
                            {(timesheetdetails && timesheetdetails.status >= 500) ?
                                  moment(timesheetdetails.approvalDate).format('YYYY-MM-DD') : null}
                              </span>
                            </Col>
                          </Row>
                        </th>
                      </tr>
                    </table>
                  }
                </div>
              </>}
          </div>
        </div>

        {/** Modal to submit timesheet */}
        <Modal
          scrollable={true}
          size="md"
          onHide={() => this.setState({ signshow: false })}
          show={this.state.signshow}
        >
          <Modal.Header closeButton className="h6 background-green1">
            <Modal.Title className="h6 text-white small_font" id="contained-modal-title-vcenter">
              Timesheet Submission Confirmation by {timesheetdetails.userLastname} {timesheetdetails.userFirstname} ({this.formatDate(moment())}).
          </Modal.Title>
          </Modal.Header>
          <Modal.Body className="show-grid small_font px-5">
            <p className="xs_font text-dark text-center">
              Please enter your name and password to electronically sign and submit your timesheet. {companyDetails.name} requires that you certify your timesheet by submitting using this your electronic signature.
          </p>
            <p className="small_font font-weight-bold text-center">
              {moment(startWeekDate).format('ddd, MMMM D, YYYY')} - {moment(weekEndDate).format('ddd, MMMM D, YYYY')}
            </p>
            <div className="form-group row">
              <div className="col-lg-3 col-md-3 col-xl-3 col-sm-12 px-0 text-right">
                <label className="mt-2">Login Name :</label>
              </div>
              <div className="col-lg-6 col-md-6 col-xl-6 col-sm-12">
                <input type="text" className="form-control" placeholder=""
                  value={userName}
                  onChange={(evt) => this.setState({ userName: evt.target.value })} />
              </div>
            </div>
            <div className="form-group row">
              <div className="col-lg-3 col-md-3 col-xl-3 col-sm-12 px-0 text-right">
                <label className="mt-2">Password :</label>
              </div>
              <div className="col-lg-6 col-md-6 col-xl-6 col-sm-12">
                <input type="password" className="form-control" placeholder=""
                  value={passWord}
                  onChange={(evt) => this.setState({ passWord: evt.target.value })} />
              </div>
            </div>
            <p className="small_font text-center">
              <b>{timesheetdetails.userLastname}, {timesheetdetails.userFirstname} - Total Hours {totalHours}</b>
            </p>
            <p className="xs_font text-center">
              I Certify that all the information in my timesheet is accurate and true.
          </p>
          </Modal.Body>
          <Modal.Footer>
            <div className="col-12 row mt-2">
              <div className="col-6">
                <button
                  onClick={() => this.setState({ signshow: false })}
                  className="button resend-btn background-red px-4 float-left"
                >
                  No Cancel
              </button>
              </div>
              <div className="col-6">
                <button
                  className="button resend-btn float-right px-4"
                  disabled={isEmpty(userName) || isEmpty(passWord) || subLoading}
                  onClick={() => this.submitTimeSheet()}
                >
                  Yes, Sign & Submit
                </button>
              </div>
            </div>
          </Modal.Footer>
        </Modal>
      </div>
    )
  }
}

export default MyOwnTimesheet;
