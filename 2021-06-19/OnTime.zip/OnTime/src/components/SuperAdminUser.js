import { isEmpty } from 'lodash';
import React, { Component } from 'react';
import { Modal, Container } from "react-bootstrap";
import { confirmAlert } from 'react-confirm-alert';
import 'react-confirm-alert/src/react-confirm-alert.css';
import { apiPost, apiGet, apiPut, apiDelete, getBlobImage, uploadImage } from '../Api.js';
import { adminTypes } from '../helpers/GeneralHelper.js';

class SuperAdminUser extends Component {
  constructor(props) {
    super(props);
    this.componentRef = React.createRef();
    this.state = {
      userSignature: null,
      userInitials: null,
      userInitial_file: null,
      userSignature_file: null,
      show: false,
      editshow: false,
      supershow: false,
      editsupershow: false,
      reset: false,
      superreset: false,
      existing: false,
      audetails: {},
      error_message: '',
      auerrors: {},
      auerror_message: '',
      adminusers: [],
      employeesList: [],
      userID: '',
      resetname: '',
    };
  }
  componentDidMount() {
    this.getAdminUsers();
    this.getEmployees();
  }

  handleAuFormChange = (e) => {
    let audetails = this.state.audetails;
    let auerrors = this.state.auerrors;
    audetails[e.target.name] = e.target.value;
    auerrors[e.target.name] = "form-control is-valid";
    this.setState({ audetails });
  }

  handlePermissionCheckbox = (e) => {
    let audetails = this.state.audetails;
    let auerrors = this.state.auerrors;
    audetails[e.target.name] = e.target.checked === true ? 1 : 0;
    auerrors[e.target.name] = "form-control is-valid";
    this.setState({ audetails });
  }

  validateAuForm() {
    const { audetails, editsupershow, editshow, existing, userSignature, userInitials } = this.state;
    let auerrors = {};
    let auformIsValid = true;

    if (!audetails["firstName"]) {
      auformIsValid = false;
      auerrors["firstName"] = "form-control is-invalid";
    }
    if (!audetails["lastName"]) {
      auformIsValid = false;
      auerrors["lastName"] = "form-control is-invalid";
    }
    if (!audetails["userName"]) {
      auformIsValid = false;
      auerrors["userName"] = "form-control is-invalid";
    }
    if (!audetails["email"]) {
      auformIsValid = false;
      auerrors["email"] = "form-control is-invalid";
    }
    if (!editsupershow && !editshow && !existing && !audetails["password"]) {
      auformIsValid = false;
      auerrors["password"] = "form-control is-invalid";
    }
    if (!userSignature) {
      auformIsValid = false;
      auerrors["userSignature"] = "form-control is-invalid";
    }
    if (!userInitials) {
      auformIsValid = false;
      auerrors["userInitials"] = "form-control is-invalid";
    }
    if (!auformIsValid) {
      this.setState({
        auerror_message: 'Please fill all * Required Fields!'
      });
      window.scroll({ top: 0, left: 0, behavior: 'smooth' })
    } else {
      this.setState({ auerror_message: '' });
    }
    this.setState({ auerrors: auerrors });
    return auformIsValid;
  }

  uploadPicture = (e) => {
    this.setState({
      orgImage: URL.createObjectURL(e.target.files[0]),
      orgImageFile: e.target.files[0]
    })
  };

  addAdminUserProcess = (d) => {
    this.setState({ editshow: false, existing: false, show: true, audetails: {} });
  }
  addSuperUserProcess = (d) => {
    this.setState({ editsupershow: false, existing: false, supershow: true, audetails: {} });
  }

  clearModal = () => {
    this.setState({
      auerror_message: null, editshow: false, existing: false, show: false, editsupershow: false, supershow: false, audetails: {},
      userInitials: null, userInitial_file: null, userSignature: null, userSignature_file: null
    })
  }

  addEditAdminUserRecord = (e) => {
    const { audetails, existing, editshow } = this.state;
    if (this.validateAuForm()) {
      if (existing || editshow) {
        let userID = existing ? this.state.userID : audetails.userID;
        let requestDetails = {
          method: 'adminusers/' + userID,
          params: {
            userID,
            adminType: audetails.adminType || 50,
            ...this.getUserObject()
          }
        };
        apiPut(requestDetails, true).then((res) => {
          if (res && res.status === 200 && res.data) {
            this.uploadImgDB();
          }
          if (res.request.response && res.request.status !== 200) {
            let obj = JSON.parse(res.request.response);
            this.setState({ auerror_message: obj.msg });
            return;
          }
        }).catch(error => {
          console.log(error)
        });
      } else {
        let requestDetails = {
          method: 'adminusers',
          params: {
            org_id: localStorage.orgid,
            adminType: 50,
            ...this.getUserObject()
          }
        };
        apiPost(requestDetails, true).then((res) => {
          if (res && res.status === 200 && res.data) {
            this.uploadImgDB(res.data.returnValue);
          }
          if (res.request.response && res.request.status !== 200) {
            let obj = JSON.parse(res.request.response);
            this.setState({ auerror_message: obj.msg });
            return;
          }
        }).catch(error => {
          console.log(error)
        });
      }
    }
  }


  addEditSuperUserRecord = (e) => {
    const { audetails, existing, editsupershow } = this.state;
    if (this.validateAuForm()) {
      if (existing || editsupershow) {
        let userID = existing ? this.state.userID : audetails.userID;
        let requestDetails = {
          method: 'adminusers/' + userID,
          params: {
            userID,
            adminType: audetails.adminType || 80,
            ...this.getUserObject()
          }
        };
        apiPut(requestDetails, true).then((res) => {
          if (res && res.status === 200 && res.data) {
            this.uploadImgDB();
          }
          if (res.request.response && res.request.status !== 200) {
            let obj = JSON.parse(res.request.response);
            this.setState({ auerror_message: obj.msg });
            return;
          }
        }).catch(error => {
          console.log(error)
        });
      } else {
        let requestDetails = {
          method: 'adminusers',
          params: {
            org_id: localStorage.orgid,
            adminType: 80,
            ...this.getUserObject()
          }
        };
        apiPost(requestDetails, true).then((res) => {
          if (res && res.status === 200 && res.data) {
            this.uploadImgDB(res.data.returnValue);
          }
          if (res.request.response && res.request.status !== 200) {
            let obj = JSON.parse(res.request.response);
            this.setState({ auerror_message: obj.msg });
            return;
          }
        }).catch(error => {
          console.log(error)
        });
      }
    }
  }

  uploadImgDB = async (id = null) => {
    const { audetails, userInitial_file, userSignature_file } = this.state;
    const { userID } = audetails;
    let userid = id ? id : userID;
    if (this.validateAuForm()) {
      const empUserInitial = { method: `employees/images?id=${userid}&itemtype=user_initial` };
      const empUserSignature = { method: `employees/images?id=${userid}&itemtype=user_signature` };
      let userInitialData = new FormData();
      let userSignData = new FormData();
      userInitialData.append("file", userInitial_file);
      userSignData.append("file", userSignature_file);
      const userInitialApi = uploadImage(empUserInitial, userInitialData);
      const userSignApi = uploadImage(empUserSignature, userSignData);

      await Promise.all([userInitialApi, userSignApi]).then((response) => {
        if (response && response[0].status === 200 && response[0].data) {
          this.clearModal();
          this.getAdminUsers();
        } else {
          window.alert('Something Went Wrong!');
        }
      }).catch(error => {
        console.log(error)
      });
    } else {
      return false;
    }
  }

  getUserObject = (details = {}) => {
    let audetails = !isEmpty(details) ? details : this.state.audetails;
    let obj = {
      userName: audetails.userName,
      password: audetails.password,
      firstName: audetails.firstName,
      lastName: audetails.lastName,
      email: audetails.email,
      rightsSuper: audetails.rightsSuper,
      rightsPolicy: audetails.rightsPolicy,
      rightsEmployee: audetails.rightsEmployee,
      rightsReport: audetails.rightsReport
    }
    return obj;
  }

  editAdminUserProcess = async (d, name = '') => {
    let userID = d.currentTarget.dataset.tag;
    if (name === 'admin') {
      this.setState({ editshow: true, show: true, audetails: {} });
    } else {
      this.setState({ editsupershow: true, supershow: true, audetails: {} });
    }
    const userDetails = { method: `adminusers/${userID}` };
    const userSign = { method: `employees/images?id=${userID}&itemtype=user_signature`, params: {} };
    const userInitial = { method: `employees/images?id=${userID}&itemtype=user_initial`, params: {} };

    const userAPI = apiGet(userDetails, true, false);
    const userSignApi = getBlobImage(userSign);
    const userInitialApi = getBlobImage(userInitial);

    await Promise.all([userAPI, userSignApi, userInitialApi]).then(([userRes, userSignRes, userInitialRes]) => {
      if (userRes.status === 200 && userRes.data) {
        this.setState({ audetails: userRes.data });
      }
      if (userSignRes.data && userSignRes.data.size) {
        let imageSrc = URL.createObjectURL(userSignRes.data);
        this.setState({ userSignature: imageSrc, userSignature_file: new File([userSignRes.data], "image.jpeg") })
      }
      if (userInitialRes.data && userInitialRes.data.size) {
        let imageSrc = URL.createObjectURL(userInitialRes.data);
        this.setState({ userInitials: imageSrc, userInitial_file: new File([userInitialRes.data], "image.jpeg") })
      }
    }).catch(error => {
      this.clearModal();
      console.log(`Error in promises ${error}`)
    });
  }
  resetPassword = (e) => {
    this.setState({ reset: true, audetails: [], resetname: e.currentTarget.dataset.tag });
    let requestDetails = {
      method: 'adminusers/' + e.currentTarget.dataset.tagid,
      params: {}
    };
    apiGet(requestDetails, true).then((response) => {
      this.setState({ audetails: response.data });
    }
    ).catch(error => {
      console.log(error)
    });
  }
  resetPasswordProcess = (d) => {
    const { audetails } = this.state;
    if (audetails.newpass == audetails.pass) {
      let requestDetails = {
        method: 'adminusers/' + audetails.userID,
        params: {
          userID: audetails.userID,
          adminType: audetails.adminType,
          userName: audetails.userName,
          password: audetails.pass,
          firstName: audetails.firstName,
          lastName: audetails.lastName,
          email: audetails.email,
          rightsSuper: audetails.rightsSuper,
          rightsPolicy: audetails.rightsPolicy,
          rightsEmployee: audetails.rightsEmployee,
          rightsReport: audetails.rightsReport
        }
      };
      apiPut(requestDetails, true).then((res) => {
        if (res.request.response && res.request.status !== 200) {
          let obj = JSON.parse(res.request.response);
          this.setState({ auerror_message: obj.msg });
          return;
        } else {
          this.setState({ reset: false });
        }
      }).catch(error => {
        console.log(error)
      });
    } else {
      this.setState({ auerror_message: 'Password does not match with Confirm Password!' });
    }
  }
  deleteProcess = (e) => {
    var dv = e.currentTarget.dataset.tag;
    confirmAlert({
      customUI: ({ onClose }) => {
        return (
          <div className='custom-ui'>
            <h3>Are you sure?</h3>
            <p>You want to delete this?</p>
            <button data-tag={dv} onClick={() => { this.deleteRecord({ dv }); onClose(); }}>Yes, Delete it</button>
            <button onClick={onClose}>No, Cancel</button>
          </div>
        );
      }
    });
  }
  deleteRecord = (e) => {
    let requestDetails = {
      method: 'adminusers/' + e.dv,
      params: {}
    };
    apiDelete(requestDetails, true).then((res) => {
      if (res.request.response && res.request.status !== 200) {
        let obj = JSON.parse(res.request.response);
        window.alert(obj.msg);
        return;
      }else{
        this.getAdminUsers();
      }
    }).catch(error => {
      console.log(error)
    });
  }

  getAdminUsers = (e) => {
    let requestDetails = {
      method: 'adminusers/all/' + localStorage.orgid,
      params: {}
    };
    apiGet(requestDetails, true).then((response) => {
      let arr = [];
      let arr1 = [];
      Array.isArray(response.data) && response.data.map((item, i) => {
        if (item.adminType == 50) {
          arr.push(item);
        } else {
          arr1.push(item);
        }
      })
      this.setState({ adminusers: arr, superusers: arr1 });
    }).catch(error => {
      console.log(error)
    });
  }
  getEmployees = (e) => {
    this.setState({ employeesList: [] });
    let requestDetails1 = {
      method: 'employees/all/' + localStorage.orgid,
      params: {}
    };
    apiPost(requestDetails1, true).then((response) => {
      this.setState({ employeesList: response.data.users });
    }).catch(error => {
      console.log(error)
    });
  }
  handleCheckbox = (e) => {
    this.setState({ existing: !this.state.existing });
  }
  changeExistingEmp = (d) => {
    let requestDetails = {
      method: 'employees/' + d.target.value,
      params: {}
    };
    apiGet(requestDetails, true).then((response) => {
      this.setState({ audetails: response.data, userID: d.target.value });
    }).catch(error => {
      console.log(error)
    });
  }

  changeAdminSuper = async (e, value) => {
    var dv = e.currentTarget.dataset.tag;
    const userDetails = { method: `adminusers/${dv}` };
    let audetails = {};
    await apiGet(userDetails, true, false).then((userRes) => {
      if (userRes.status === 200 && userRes.data) {
        audetails = userRes.data;
      }
    }).catch(error => {
      this.clearModal();
      console.log(`Error in promises ${error}`)
    });
    confirmAlert({
      customUI: ({ onClose }) => {
        return (
          <div className='custom-ui'>
            <h3>Are you sure?</h3>
            <p>You Want to Change to {adminTypes[value]}?</p>
            <button data-tag={dv} onClick={() => { this.changeUserRole(dv, value, audetails); onClose(); }}>Yes, Change it</button>
            <button onClick={onClose}>No, Cancel</button>
          </div>
        );
      }
    });
  }

  changeUserRole = (userID, adminNumber, audetails) => {
    let requestDetails = {
      method: 'adminusers/' + userID,
      params: {
        userID,
        adminType: adminNumber,
        ...this.getUserObject(audetails)
      }
    };
    apiPut(requestDetails, true).then((res) => {
      if (res && res.status === 200 && res.data) {
        this.clearModal();
        this.getAdminUsers();
      }
      if (res.request.response && res.request.status !== 200) {
        let obj = JSON.parse(res.request.response);
        this.setState({ auerror_message: obj.msg });
        return;
      }
    }).catch(error => {
      console.log(error)
    });
  }

  userInitialChange = event => {
    const fileUploaded = event.target.files[0];
    this.setState({ userInitials: URL.createObjectURL(fileUploaded), userInitial_file: fileUploaded });
  };

  userSignatureChange = event => {
    const fileUploaded = event.target.files[0];
    this.setState({ userSignature: URL.createObjectURL(fileUploaded), userSignature_file: fileUploaded });
  };


  render() {
    const { editshow, existing, audetails, editsupershow, userSignature, userInitials } = this.state;
    return (
      <div>
        <h6>Super User Account Management</h6>
        <label>Add Super User<button type="button" onClick={this.addSuperUserProcess} className="button resend-btn mt-1">Add</button></label>

        <p className="mt-1 font-weight-bold">Manage Super User Information and Rights</p>
        {Array.isArray(this.state.superusers) && this.state.superusers.map((item, i) => {
          return <div className="row form-group border-bottom" key={i}>
            <div className="col-xl-3 col-lg-3 col-md-3 col-sm-12">
              <label>{item.firstName + ' ' + item.lastName} {(item.adminType === 90) ? '(Root User)' : ''}</label>
              <p><span className="link-style pl-0" data-tag={item.userID} onClick={(e) => this.editAdminUserProcess(e)}>Edit</span> |
                      {(item.adminType === 80) ?
                  <span>
                    <span className="link-style" data-tag={item.userID} onClick={(e) => this.changeAdminSuper(e, 50)}>Change to Administrator</span> |
                              <span className="link-style" data-tag={item.userID} onClick={this.deleteProcess}>Remove</span> |
                        </span>
                  : <span></span>
                }
                <span className="link-style" data-tagid={item.userID} data-tag={item.userName} onClick={this.resetPassword}>Reset Password</span></p>
            </div>
            <div className="col-xl-9 col-lg-9 col-md-9 col-sm-12 row">
              <div className="col-xl-4 col-lg-4 col-md-4 col-sm-10 p-0">
                <input type="checkbox" checked={item.rightsSuper === 1 ? true : false} disabled className="form-control permission-checkbox" name="country" />
                <label className="permission-label">Final Approval of Timesheet</label>
              </div>
            </div>
          </div>
        })}
        <h6 className="mt-5">Administrator Account Management</h6>
        <label>Add Administrator<button type="button" onClick={this.addAdminUserProcess} className="button resend-btn mt-1">Add</button></label>
        <p className="mt-1 font-weight-bold">Manage Administrator Information and Rights</p>
        {Array.isArray(this.state.adminusers) && this.state.adminusers.map((item, i) => {
          return <div className="row form-group border-bottom" key={i}>
            <div className="col-xl-3 col-lg-3 col-md-3 col-sm-12">
              <label>{item.firstName + ' ' + item.lastName}</label>
              <p><span className="link-style pl-0" data-tag={item.userID} onClick={(e) => this.editAdminUserProcess(e, 'admin')}>Edit</span> |
                    <span className="link-style" data-tag={item.userID} onClick={(e) => this.changeAdminSuper(e, 80)}>Change to Super User</span> |
                    <span className="link-style" data-tag={item.userID} onClick={this.deleteProcess}>Remove</span> |
                    <span className="link-style" data-tagid={item.userID} data-tag={item.userName} onClick={this.resetPassword}>Reset Password</span></p>
            </div>
            <div className="col-xl-9 col-lg-9 col-md-9 col-sm-12 row">
              <div className="col-xl-3 col-lg-3 col-md-3 col-sm-10 p-0">
                <input type="checkbox" checked={item.rightsEmployee === 1 ? true : false} disabled className="form-control permission-checkbox" name="country" />
                <label className="permission-label">Modify Employees</label>
              </div>
              <div className="col-xl-3 col-lg-3 col-md-3 col-sm-10 p-0">
                <input type="checkbox" checked={item.rightsPolicy === 1 ? true : false} disabled className="form-control permission-checkbox" name="country" />
                <label className="permission-label">Modify Policies</label>
              </div>
              <div className="col-xl-2 col-lg-2 col-md-2 col-sm-10 p-0">
                <input type="checkbox" checked={item.rightsReport === 1 ? true : false} disabled className="form-control permission-checkbox" name="country" />
                <label className="permission-label pl-1">Do Reporting</label>
              </div>
              <div className="col-xl-4 col-lg-4 col-md-4 col-sm-10 p-0">
                <input type="checkbox" checked={item.rightsSuper === 1 ? true : false} disabled className="form-control permission-checkbox" name="country" />
                <label className="permission-label">Final Approval of Timesheet</label>
              </div>
            </div>
          </div>
        })}
        <Modal scrollable={true} size="lg" onHide={() => this.clearModal()}
          show={this.state.supershow}
          aria-labelledby="example-modal-sizes-title-lg">
          <Modal.Header closeButton>
            <Modal.Title className="h6" id="example-modal-sizes-title-lg">
              {editsupershow ? 'Edit' : 'Add'} Super User
        </Modal.Title>
          </Modal.Header>
          <Modal.Body className="show-grid small_font" ref={this.componentRef}>
            <Container>
              <div className="text-danger col-12 text-center">{this.state.auerror_message}</div>
              {!editsupershow && <div className="form-group row">
                <div className="col-xl-6 col-lg-6 col-md-6 col-sm-12 pt-4">
                  <input onClick={this.handleCheckbox} disabled type="checkbox" className="form-control permission-checkbox" name="existing" />
                  <label className="permission-label">Select From Existing Employees</label>
                </div>
                <div className="col-xl-6 col-lg-6 col-md-6 col-sm-12">
                  <label className="mr-2">Employees</label>
                  <select onChange={this.changeExistingEmp} disabled={!existing} placeholder="Select" className="form-control" name="employee">
                    <option value=''>Select</option>
                    {Array.isArray(this.state.employeesList) && this.state.employeesList.map((item, i) => {
                      return <option key={i} value={item.userID}>{item.firstName}</option>
                    })
                    }
                  </select>
                </div>
              </div>}
              <div className="form-group row">
                <div className="col-xl-6 col-lg-6 col-md-6 col-sm-12">
                  <label for="exampleInputEmail1">First Name*</label>
                  <input disabled={existing} value={audetails.firstName} name="firstName" onChange={this.handleAuFormChange} type="text" className="form-control" id="exampleInputEmail1" placeholder="Enter First Name" />
                </div>
                <div className="col-xl-6 col-lg-6 col-md-6 col-sm-12">
                  <label for="exampleInputEmail1">Last Name*</label>
                  <input disabled={existing} value={audetails.lastName} name="lastName" onChange={this.handleAuFormChange} type="text" className="form-control" id="exampleInputEmail1" placeholder="Enter Last Name" />
                </div>
              </div>
              <div className="form-group">
                <label for="exampleInputEmail1">Email*</label>
                <input disabled={existing} value={audetails.email} name="email" onChange={this.handleAuFormChange} type="email" className="form-control" placeholder="Enter Email" />
              </div>
              <div className="form-group">
                <label>Login Name*</label>
                <input disabled={existing} value={audetails.userName} name="userName" onChange={this.handleAuFormChange} type="text" className="form-control" placeholder="Enter Login Name" />
              </div>
              {!editsupershow && <div className="form-group">
                <label>Password*</label>
                <input disabled={existing} value={audetails.password} name="password" onChange={this.handleAuFormChange} type="password" className="form-control" placeholder="Enter Password" />
              </div>}
              <div className="form-group row">
                <div className="col-xl-6 col-lg-6 col-md-6 col-sm-12">
                  <label>Upload Signature File*</label>
                  <br />
                  {userSignature && <img src={userSignature} height={40} className="mb-1" alt="user_signature" />}
                  <br />
                  <label className="button resend-btn py-2 px-4 m-0 cursor-pointer">
                    <input id="userSignature" type="file" onChange={this.userSignatureChange} accept=".png, .jpg, .jpeg" style={{ display: 'none' }} />
                      Choose File
                      </label>
                  <p className="mt-1">File size limit: 1 MB</p>
                </div>
                <div className="col-xl-6 col-lg-6 col-md-6 col-sm-12">
                  <label>Upload Initials File*</label>
                  <br />
                  {userInitials && <img src={userInitials || ''} height={40} className="mb-1" alt="user_initial" />}
                  <br />
                  <label className="button resend-btn py-2 px-4 m-0 cursor-pointer">
                    <input id="userInitials" type="file" onChange={this.userInitialChange} accept=".png, .jpg, .jpeg" style={{ display: 'none' }} />
                      Choose File
                      </label>
                  <p className="mt-1">File size limit: 1 MB</p>
                </div>
              </div>
              <div className="form-group row">
                <div className="col-xl-4 col-lg-4 col-md-4 col-sm-10 p-0">
                  <input type="checkbox" checked={audetails.rightsSuper === 1 ? true : false} onChange={this.handlePermissionCheckbox} className="form-control permission-checkbox" name="rightsSuper" />
                  <label className="permission-label">Final Approval of Timesheet</label>
                </div>
              </div>
            </Container>
          </Modal.Body>
          <Modal.Footer>
            <ul className="row form-group mr-0 mt-4 pr-0 list-inline pull-right">
              <li><button onClick={() => this.clearModal()} className="button cancel-btn py-2 px-4 m-0 mr-2">Close</button></li>
              <li><button onClick={this.addEditSuperUserRecord} className="button resend-btn py-2 px-4 m-0">Save</button></li>
            </ul>
          </Modal.Footer>
        </Modal>
        <Modal scrollable={true} size="xl" onHide={() => this.clearModal()}
          show={this.state.show}
          aria-labelledby="example-modal-sizes-title-lg">
          <Modal.Header closeButton>
            <Modal.Title className="h6" id="example-modal-sizes-title-lg">
              {editshow ? 'Edit' : 'Add'} Administrator
        </Modal.Title>
          </Modal.Header>
          <Modal.Body className="show-grid small_font">
            <Container>
              <div className="text-danger col-12 text-center">{this.state.auerror_message}</div>
              {!editshow && <div className="form-group row">
                <div className="col-xl-6 col-lg-6 col-md-6 col-sm-12 pt-4">
                  <input onClick={this.handleCheckbox} disabled type="checkbox" className="form-control permission-checkbox" name="existing" />
                  <label className="permission-label">Select From Existing Employees</label>
                </div>
                <div className="col-xl-6 col-lg-6 col-md-6 col-sm-12">
                  <label className="mr-2">Employees</label>
                  <select onChange={this.changeExistingEmp} disabled={!existing} placeholder="Select" className="form-control" name="employee">
                    <option value=''>Select</option>
                    {Array.isArray(this.state.employeesList) && this.state.employeesList.map((item, i) => {
                      return <option key={i} value={item.userID}>{item.firstName}</option>
                    })
                    }
                  </select>
                </div>
              </div>}
              <div className="form-group row">
                <div className="col-xl-6 col-lg-6 col-md-6 col-sm-12">
                  <label for="exampleInputEmail1">First Name*</label>
                  <input disabled={existing} value={audetails.firstName} name="firstName" onChange={this.handleAuFormChange} type="text" className="form-control" id="exampleInputEmail1" placeholder="Enter First Name" />
                </div>
                <div className="col-xl-6 col-lg-6 col-md-6 col-sm-12">
                  <label for="exampleInputEmail1">Last Name*</label>
                  <input disabled={existing} value={audetails.lastName} name="lastName" onChange={this.handleAuFormChange} type="text" className="form-control" id="exampleInputEmail1" placeholder="Enter Last Name" />
                </div>
              </div>
              <div className="form-group">
                <label for="exampleInputEmail1">Email*</label>
                <input disabled={existing} value={audetails.email} name="email" onChange={this.handleAuFormChange} type="email" className="form-control" placeholder="Enter Email" />
              </div>
              <div className="form-group">
                <label>Login Name*</label>
                <input disabled={existing} value={audetails.userName} name="userName" onChange={this.handleAuFormChange} type="text" className="form-control" placeholder="Enter Login Name" />
              </div>
              {!editshow && <div className="form-group">
                <label>Password*</label>
                <input disabled={existing} value={audetails.password} name="password" onChange={this.handleAuFormChange} type="password" className="form-control" placeholder="Enter Password" />
              </div>}
              <div className="form-group row">
                <div className="col-xl-6 col-lg-6 col-md-6 col-sm-12">
                  <label>Upload Signature File*</label>
                  <br />
                  {userSignature && <img src={userSignature} height={40} className="mb-1" alt="user_signature" />}
                  <br />
                  <label className="button resend-btn py-2 px-4 m-0 cursor-pointer">
                    <input id="userSignature" type="file" onChange={this.userSignatureChange} accept=".png, .jpg, .jpeg" style={{ display: 'none' }} />
                      Choose File
                      </label>
                  <p className="mt-1">File size limit: 1 MB</p>
                </div>
                <div className="col-xl-6 col-lg-6 col-md-6 col-sm-12">
                  <label>Upload Initials File*</label>
                  <br />
                  {userInitials && <img src={userInitials || ''} height={40} className="mb-1" alt="user_initial" />}
                  <br />
                  <label className="button resend-btn py-2 px-4 m-0 cursor-pointer">
                    <input id="userInitials" type="file" onChange={this.userInitialChange} accept=".png, .jpg, .jpeg" style={{ display: 'none' }} />
                      Choose File
                      </label>
                  <p className="mt-1">File size limit: 1 MB</p>
                </div>
              </div>
              <div className="form-group row">
                <div className="col-xl-3 col-lg-3 col-md-3 col-sm-10 p-0">
                  <input type="checkbox" checked={audetails.rightsEmployee === 1 ? true : false} onChange={this.handlePermissionCheckbox} className="form-control permission-checkbox" name="rightsEmployee" />
                  <label className="permission-label">Modify Employees</label>
                </div>
                <div className="col-xl-2 col-lg-2 col-md-2 col-sm-10 p-0">
                  <input type="checkbox" checked={audetails.rightsPolicy === 1 ? true : false} onChange={this.handlePermissionCheckbox} className="form-control permission-checkbox" name="rightsPolicy" />
                  <label className="permission-label">Modify Policies</label>
                </div>
                <div className="col-xl-3 col-lg-3 col-md-3 col-sm-10 p-0 pl-4">
                  <input type="checkbox" checked={audetails.rightsReport === 1 ? true : false} onChange={this.handlePermissionCheckbox} className="form-control permission-checkbox" name="rightsReport" />
                  <label className="permission-label pl-1">Do Reporting</label>
                </div>
                <div className="col-xl-4 col-lg-4 col-md-4 col-sm-10 p-0">
                  <input type="checkbox" checked={audetails.rightsSuper === 1 ? true : false} onChange={this.handlePermissionCheckbox} className="form-control permission-checkbox" name="rightsSuper" />
                  <label className="permission-label">Final Approval of Timesheet</label>
                </div>
              </div>
            </Container>
          </Modal.Body>
          <Modal.Footer>
            <ul className="row form-group mr-0 mt-4 pr-0 list-inline pull-right">
              <li><button onClick={() => this.clearModal()} className="button cancel-btn py-2 px-4 m-0 mr-2">Close</button></li>
              <li><button onClick={this.addEditAdminUserRecord} className="button resend-btn py-2 px-4 m-0">Save</button></li>
            </ul>
          </Modal.Footer>
        </Modal>
        <Modal scrollable={true} size="md" onHide={() => this.setState({ superreset: false })}
          show={this.state.superreset}
          aria-labelledby="example-modal-sizes-title-lg">
          <Modal.Header closeButton>
            <Modal.Title className="h6" id="example-modal-sizes-title-lg">
              Reset Super User Password
        </Modal.Title>
          </Modal.Header>
          <Modal.Body className="show-grid small_font">
            <Container>
              <div className="text-danger col-12 text-center">{this.state.auerror_message}</div>
              <div className="form-group">
                <label for="exampleInputEmail1">Password*</label>
                <input type="email" className="form-control" placeholder="Enter Password" />
              </div>
              <div className="form-group">
                <label>Confirm Password*</label>
                <input type="text" className="form-control" placeholder="Enter Confirm Password" />
              </div>
            </Container>
          </Modal.Body>
          <Modal.Footer>
            <ul className="row form-group mr-0 mt-4 pr-0 list-inline pull-right">
              <li><button onClick={() => this.setState({ superreset: false })} className="button cancel-btn py-2 px-4 m-0 mr-2">Close</button></li>
              <li><button onClick={this.resetPasswordProcess} className="button resend-btn py-2 px-4 m-0">Save</button></li>
            </ul>
          </Modal.Footer>
        </Modal>
        <Modal scrollable={true} size="md" onHide={() => this.setState({ reset: false })}
          show={this.state.reset}
          aria-labelledby="example-modal-sizes-title-lg">
          <Modal.Header closeButton>
            <Modal.Title className="h6" id="example-modal-sizes-title-lg">
              Reset Password
        </Modal.Title>
          </Modal.Header>
          <Modal.Body className="show-grid small_font">
            <Container>
              <div className="text-danger col-12 text-center">{this.state.auerror_message}</div>
              <div className="form-group">
                <label for="exampleInputEmail1">New Password*</label>
                <input type="password" value={audetails.pass} name="pass" onChange={this.handleAuFormChange} className="form-control" placeholder="Enter Password" />
              </div>
              <div className="form-group">
                <label>Confirm New Password*</label>
                <input type="password" value={audetails.newpass} name="newpass" onChange={this.handleAuFormChange} className="form-control" placeholder="Enter Confirm Password" />
              </div>
            </Container>
          </Modal.Body>
          <Modal.Footer>
            <ul className="row form-group mr-0 mt-4 pr-0 list-inline pull-right">
              <li><button onClick={() => this.setState({ reset: false })} className="button cancel-btn py-2 px-4 m-0 mr-2">Close</button></li>
              <li><button onClick={this.resetPasswordProcess} className="button resend-btn py-2 px-4 m-0">Save</button></li>
            </ul>
          </Modal.Footer>
        </Modal>
      </div>
    );
  }
}

export default SuperAdminUser;
