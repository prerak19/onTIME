import React, { Component } from 'react';
import 'bootstrap/dist/css/bootstrap.min.css';
import moment from 'moment';
import { toNumber } from '../helpers/GeneralHelper';
import { chunk, find, groupBy, sum } from 'lodash';
import { Tabs, Tab } from "react-bootstrap";
import html2pdf from "html2pdf.js";
import XLSX from 'xlsx';

class TimesheetPreview extends Component {
  constructor(props) {
    super(props);
    this.state = {
      printData: false,
      activeTab: 'summary',
    };
  }

  savePDF = (e) => {
    e.preventDefault();
    const { activeTab } = this.state;
    this.setState({ printData: true });
    let obj = {
      unit: 'cm', format: 'ledger', orientation: 'landscape',
    }
    let content = document.getElementById('summaryReport');
    if (activeTab === 'details') {
      content = document.getElementById('detailsReport');
    }
    setTimeout(() => {
      var opt = {
        margin: [0, 1, 0, 1],
        filename: `${activeTab}_report.pdf`,
        html2canvas: { y: 0, scrollY: 0, useCORS: true },
        jsPDF: obj
      };
      html2pdf().set(opt).from(content).save();
    }, 1000)
    setTimeout(() => { this.setState({ printData: false }) }, 2000);
  }

  download_csv = () => {
    const { activeTab } = this.state;
    let reportId = activeTab === 'summary' ? 'summaryReport' : 'detailsReport';
    var elt = document.getElementById(reportId);
    var wb = XLSX.utils.table_to_book(elt, { sheet: "Sheet JS" });
    XLSX.write(wb, { bookType: 'xlsx', bookSST: true, type: 'base64' })
    XLSX.writeFile(wb, `${reportId}.xlsx`);
  }

  render() {
    const { printData, activeTab } = this.state;
    const { activityTimeArr = [], summaryArr = [], detailsArr = [], startDate, endDate, disFilterArr, companyDetails = {}, orgImage } = this.props;
    let filterStr = '';
    if (disFilterArr.length > 0) {
      disFilterArr.map((x) => {
        if (x.label === 'groups') {
          filterStr = filterStr + `${x.name} (${x.code}), `;
        } else if (x.label === 'activities') {
          filterStr = filterStr + `${x.name} (${x.actID}), `;
        } else {
          filterStr = filterStr + `${x.lastName} ${x.firstName} (${x.userID}), `;
        }
        return null;
      })
      if (find(disFilterArr, { label: 'groups' })) {
        filterStr = ('GROUPS: ').concat(filterStr);
      } else if (find(disFilterArr, { label: 'activities' })) {
        filterStr = ('ACTIVITIES: ').concat(filterStr);
      } else {
        filterStr = ('INDIVIDUALS: ').concat(filterStr);
      }
    }
    return (
      <div className="mx-4 timesheetReport pb-5">
        <div className="buttonLine container">
          <h6 className="text-center">Report Preview</h6>
          <a id="dd" onClick={(e) => this.download_csv(e)} className="small_font button resend-btn float-right mb-3">Save As Excel</a>
          <button onClick={(e) => this.savePDF(e)} className="button resend-btn ml-2 float-right mb-3">Save As PDF</button>
        </div>
        <div className="payrollform small_font">
          <Tabs
            id="controlled-tab-example"
            activeKey={activeTab}
            onSelect={(k) => this.setState({ activeTab: k })}
          >
            <Tab eventKey="summary" title="Summary Page">
              {detailsArr && activeTab === 'summary' &&
                <div id="summaryReport" className={!printData ? "overflow-auto mt-4" : "mt-4"} >
                  <div className="m-2">
                    <table className="text-center text-black w-100">
                      <thead>
                        <tr>
                          <th colSpan="3" rowSpan="4" className="border-0" width="30%">
                            {orgImage && <img src={orgImage} height="100px" alt="orgImage"/>}
                          </th>
                          <th className="border border-white" colSpan={1 + activityTimeArr.length}>
                            <h6 className="mb-0">{companyDetails && companyDetails.name} TIMESHEET SUMMARY REPORT</h6>
                          </th>
                        </tr>
                        <tr>
                          <th className="border border-white" colSpan={1 + activityTimeArr.length}>
                            {companyDetails ? <h6 className="mb-0">
                              {companyDetails.address1 ? `${companyDetails.address1},` : ''}
                              {companyDetails.address2 ? ` ${companyDetails.address2},` : ''}
                              {companyDetails.city ? ` ${companyDetails.city},` : ''}
                              {companyDetails.zip ? ` ${companyDetails.zip},` : ''}
                              {companyDetails.state ? ` ${companyDetails.state},` : ''}
                            </h6> : <h6>&nbsp;</h6>}
                          </th>
                        </tr>
                        <tr><th className="border border-white" colSpan={1 + activityTimeArr.length}>
                          <h6 className="mb-0">FROM {moment(startDate).format('MM/DD/YYYY')} TO {moment(endDate).format('MM/DD/YYYY')}</h6>
                        </th></tr>
                        <tr>
                          <th className="border-white border-bottom-0" colSpan={1 + activityTimeArr.length}>
                            <h6 className="mb-0">{disFilterArr.length > 0 ? filterStr : `ENTIRE ${companyDetails.name}`}</h6></th>
                        </tr>
                        <tr>
                          <th colSpan='3'>Total Summary</th>
                          <th className="background-green" colSpan={activityTimeArr.length + 1} />
                        </tr>
                        <tr>
                          <th rowSpan='2'>LAST NAME</th>
                          <th rowSpan='2'>FIRST NAME</th>
                          <th rowSpan='2'>GROUP</th>
                          <th colSpan={activityTimeArr.length}>ACTIVITIES</th>
                          <th rowSpan='2'>TOTAL</th>
                        </tr>
                        <tr>
                          {activityTimeArr.length > 0 ? activityTimeArr.map((x, i) => {
                            return <th key={i}>{x}</th>
                          }) : <th />}
                        </tr>
                      </thead>
                      <tbody>
                        {summaryArr && summaryArr.map((x, key) => {
                          return <tr key={key}>
                            <td>{x.lastName}</td>
                            <td>{x.firstName}</td>
                            <td>{x.groupName}</td>
                            {Object.values(x.timeObj).map((act, j) => {
                              return <td key={j}>{toNumber(act)}</td>
                            })}
                            <td>{toNumber(sum(Object.values(x.timeObj)))}</td>
                          </tr>
                        })}
                      </tbody>
                    </table>
                  </div>
                </div>}
            </Tab>
            <Tab eventKey="details" title="Detail Page">
              {detailsArr && activeTab === 'details' &&
                <div id="detailsReport" className={!printData ? "overflow-auto mt-4 reportHeight" : "mt-4"} >
                  <div className="m-2">
                    <table className="w-100 text-center text-black ">
                      <tbody>
                        {detailsArr && detailsArr.map((x, i) => {
                          let finalFirstArr = [];
                          let sumArr = [];
                          let activityArr = [];
                          Object.entries(x).map((val) => {
                            if (typeof val[1] === 'object') {
                              let disActivity = `${val[0].split('_')[0]} (${val[0].split('_')[1]})`;
                              activityArr.push(disActivity)
                              Object.entries(val[1]).map((s) => {
                                if (sumArr.find((x) => x.key === s[0])) {
                                  sumArr = sumArr.map((sn) => {
                                    let vale = sn.value;
                                    return (sn.key === s[0]) ? { ...sn, value: Number(vale) + Number(s[1]) } : sn;
                                  })
                                } else {
                                  sumArr.push({
                                    key: s[0],
                                    value: Number(s[1]),
                                  })
                                }
                                return null;
                              })
                              let arr = chunk(Object.keys(val[1]), 31);
                              arr.map((dateData, i) => {
                                finalFirstArr.push({
                                  value: val[1],
                                  key: i,
                                  activityId: val[0].split('_')[1],
                                  activityName: val[0].split('_')[0],
                                  data: dateData,
                                })
                                return null;
                              })
                            }
                            return null;
                          });
                          const emptyArr = (data) => Array(31 - Number(data.length)).fill('');
                          return <React.Fragment key={i}>
                            {i === 0 && <> <tr>
                              <th colSpan="2" rowSpan="3" className="border-0">
                                {orgImage && <img src={orgImage} height="100px" alt="orgImage"/>}
                              </th>
                              <th className="border border-white" colSpan='32'>
                                <h6 className="mb-0">{companyDetails && companyDetails.name} TIMESHEET DETAILS REPORT</h6>
                              </th>
                            </tr>
                              <tr>
                                <th className="border border-white" colSpan={32}>
                                  {companyDetails ? <h6 className="mb-0">
                                    {companyDetails.address1 ? `${companyDetails.address1},` : ''}
                                    {companyDetails.address2 ? ` ${companyDetails.address2},` : ''}
                                    {companyDetails.city ? ` ${companyDetails.city},` : ''}
                                    {companyDetails.zip ? ` ${companyDetails.zip},` : ''}
                                    {companyDetails.state ? ` ${companyDetails.state},` : ''}
                                  </h6> : <h6>&nbsp;</h6>}
                                </th>
                              </tr>
                            </>}
                            {i === 0 && <tr><th className="border-white border-bottom-0" colSpan='32'>
                              <h6 className="mb-0">FROM {moment(startDate).format('MM/DD/YYYY')} TO {moment(endDate).format('MM/DD/YYYY')}</h6>
                            </th></tr>}
                            <tr>
                              <td colSpan='34'>{x.groupCode && `GROUPS: ${x.groupName} (${x.groupCode}),`} ACTIVITIES: {activityArr.join(', ')}, EMPLOYEE NAME: {x.lastName}, {x.firstName}</td>
                            </tr>
                            {Object.values(groupBy(finalFirstArr, 'key')).map((v, l) => {
                              let obj = {};
                              v[0].data.map((head, k) => {
                                let val = head.split('_')[1];
                                let monthName = val.split('-')[0];
                                if (obj[monthName]) {
                                  obj[monthName].push(val);
                                } else {
                                  obj[monthName] = [val];
                                }
                                return null;
                              });
                              return <React.Fragment key={l}>
                                <tr>
                                  <td colSpan='2'>ACTIVITY</td>
                                  {Object.entries(obj).map((headMonth, k) => <td key={k} colSpan={headMonth[1].length}>{headMonth[0]}</td>)}
                                  {emptyArr(v[0].data).map((emp, k) => <td key={k}>&nbsp;</td>)}
                                  <td>TOTAL</td>
                                </tr>
                                <tr>
                                  <td>ID</td>
                                  <td>Name</td>
                                  {v[0].data.map((hr, k) => {
                                    return <td key={k}>
                                      {hr.split('_')[0]}
                                    </td>
                                  })}
                                  {emptyArr(v[0].data).map((emp, k) => <td key={k}>&nbsp;</td>)}
                                  <td />
                                </tr>
                                {v.map((valueData, dataKey) => {
                                  return <tr key={dataKey}>
                                    <td>{valueData.activityId}</td>
                                    <td>{valueData.activityName}</td>
                                    {valueData.data.map((hr, k) => {
                                      return <td key={k}>
                                        {valueData.value[`${hr}`] !== 0 && toNumber(valueData.value[`${hr}`])}
                                      </td>
                                    })}
                                    {emptyArr(valueData.data).map((emp, k) => <td key={k}>&nbsp;</td>)}
                                    <td>{toNumber(sum(chunk(Object.values(valueData.value), 31)[valueData.key]))} </td>
                                  </tr>
                                })}
                                <tr>
                                  <td colSpan={2}> Summary </td>
                                  {chunk(sumArr, 31)[l].map((hr, k) => {
                                    return <td key={k}>
                                      {toNumber(hr.value)}
                                    </td>
                                  })}
                                  {emptyArr(v[0].data).map((emp, k) => <td key={k}>&nbsp;</td>)}
                                  <td>{toNumber(sum(chunk(sumArr.map((X) => X.value), 31)[l]))} </td>
                                </tr>
                              </React.Fragment>
                            })}
                          </React.Fragment>
                        })}
                      </tbody>
                    </table>
                  </div>
                </div>
              }
            </Tab>
          </Tabs>
        </div>
      </div>
    );
  }
}

export default TimesheetPreview;
