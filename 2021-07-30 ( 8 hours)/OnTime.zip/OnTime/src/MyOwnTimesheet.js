import React from 'react';
import DatePicker from "react-datepicker";
import html2pdf from 'html2pdf.js';
import { Modal, OverlayTrigger, Popover } from "react-bootstrap";
import { MDBBtn } from 'mdbreact';
import ReactTable from './components/common/ReactTable';
import { find, get, groupBy, isEmpty, isEqual, sortBy, sum } from 'lodash';
import moment from 'moment';
import { apiGet, apiPost, apiPut, getBlobImage } from './Api.js';
import { DAYS_OF_WEEK, timesheet_status_codes, ClockInOuts, toNumber, getWeek, fontOptions, momentDate, momentWithFormat } from './helpers/GeneralHelper';
import "react-datepicker/dist/react-datepicker.css";
import { getImageURLs, getReuseSignInit, signImageUpload } from './helpers/commonApi.js';

class MyOwnTimesheet extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      displayTotal: 0.00,
      tempObj: null,
      finalTimesheets: [],
      weekDays: [],
      clockInDay: '',
      submitWeekDate: '',
      weekCount: 1,
      currentDay: '',
      overallTotals: [],
      approvedImage: [],
      personalDetails: {},
      startTime: null,
      stopTime: null,
      signshow: false,
      unsubmittedTimesheets: 0,
      preTsheetsChecked: false,
      companyDetails: {},
      signatureOutput: '',
      signatureText: '',
      currentFont: fontOptions[0].value,
      currentRecordingPeriod: false,
      startWeekDate: moment().day(0).format('YYYY-MM-DD'),
      weekEndDate: moment().day(6).format('YYYY-MM-DD'),
      currentClockInActivity: null,
      subLoading: false,
      employeeSignatureImg: [],
      userName: '',
      passWord: '',
      errors: {},
      signatureImage: '',
      timesheetLoading: false,
      currentClockInTimesheet: {},
      authenticate: true,
      savedSign: true,
      savedFuture: true,
      signType: 'type',
      currentImageId: "",
      supDocuments: [],

      deletePopup: false,
      selEmptyTimesheets: [],
    };
  }

  componentDidMount() {
    this.setCurrentRecordingPeriod(false);
    this.getCompanyDetails();
  }

  setCurrentRecordingPeriod = (checkboxState) => {
    this.setState({ timesheetLoading: true });
    this.setState({ currentRecordingPeriod: !checkboxState });
    const getRequest = {
      method: `timesheets/cur-rec-period/${localStorage.orgid}`,
      params: {}
    };
    apiGet(getRequest).then((response) => {
      if (isEqual(response.status, 200) && response.data) {
        const start = response.data.startDate;
        const end = response.data.endDate;
        this.setState({
          startWeekDate: moment(start).format('YYYY-MM-DD'),
          weekEndDate: moment(end).format('YYYY-MM-DD'),
        }, () => {
          this.getTimesheetRecord(moment(start).format('YYYY-MM-DD'), true, true);
        });
      }
    }).catch(error => {
      this.setState({
        timesheetLoading: false,
        startWeekDate: moment().day(0).format('YYYY-MM-DD'),
        weekEndDate: moment().day(6).format('YYYY-MM-DD')
      });
    });
  }

  getTimesheetRecord = async (startDate, sheetLoading = true, lastClockIn = false) => {
    this.setState({ timesheetLoading: sheetLoading });
    const requestDetails = {
      method: `timesheets/${get(localStorage, 'userid', '')}/${startDate}`,
      params: {}
    };
    await apiGet(requestDetails, false).then(async (res) => {
      if (isEqual(res.status, 200) && res.data) {
        this.updateBiWeeklyData(res.data, lastClockIn);
      }
      if (res.request && res.request.status !== 200) {
        window.alert('No Timesheet is available for selected Week');
        this.setState({ timesheetLoading: false });
      }
    }).catch(error => {
      this.setState({ timesheetLoading: false });
    });
  }

  updateBiWeeklyData = async (data, lastClockIn) => {
    let tempObj = {}, clockInObject = {};
    const finalTimesheets = data.timsheets;
    let currentClockInTimesheet = {};
    const weeklyCount = data.count === 2 ? true : false;
    let weekDays = [], supDocuments = [], overallTotals = [], employeeSignatureImg = [], approvedImage = [], activityApprovalImg = [];
    const personalDetails = {
      userFirstname: finalTimesheets[0].userFirstname || (weeklyCount && finalTimesheets[1].userFirstname) || null,
      userLastname: finalTimesheets[0].userLastname || (weeklyCount && finalTimesheets[1].userLastname) || null,
      groupCode: finalTimesheets[0].groupCode || (weeklyCount && finalTimesheets[1].groupCode) || null,
      groupName: finalTimesheets[0].groupName || (weeklyCount && finalTimesheets[1].groupName) || null,
      status: finalTimesheets[0].status || (weeklyCount && finalTimesheets[1].status) || null,
      uid: finalTimesheets[0].uid || (weeklyCount && finalTimesheets[1].uid) || null
    };
    finalTimesheets.map((xdt) => {
      if (xdt.activityTime && xdt.activityTime.length > 0) {
        xdt.activityTime.map((act) => {
          if (tempObj[act.activityName]) {
            tempObj[act.activityName] = { ...tempObj[act.activityName], week2: { ...act, timesheetID: xdt.tid } }
          } else {
            tempObj[act.activityName] = { week1: { ...act, timesheetID: xdt.tid } }
          }
          return null;
        });
        let approvedImageArr = xdt.activityTime.filter(x => x.approveImg !== 0);
        if (approvedImageArr.length > 0) {
          approvedImageArr = approvedImageArr.map((x, i) => {
            if (!find(activityApprovalImg, { approveImg: x.approveImg })) {
              const actImg = getImageURLs(x.approveImg);
              activityApprovalImg.push({ index: i, approveImg: x.approveImg, src: actImg });
              return null;
            }
            return null;
          })
        }
      }
      if (xdt.dailyTotals && xdt.dailyTotals.length > 0) {
        xdt.dailyTotals.map((dt) => {
          weekDays.push({
            day: moment(dt.date).format('ddd'),
            date: moment(dt.date).format('MMM D'),
            fullDate: moment(dt.date).format('YYYY-MM-DD'),
          })
          if (moment().format('YYYY-MM-DD') === dt.date) {
            currentClockInTimesheet = xdt;
            if (lastClockIn) {
              clockInObject = this.getClockInData(xdt.uid);
            }
          }
          overallTotals.push(dt);
        })
      }
      if (xdt.signImg !== 0) {
        if (!find(employeeSignatureImg, { signImg: xdt.signImg })) {
          const imgsrc = getImageURLs(xdt.signImg);
          employeeSignatureImg.push({ signImg: xdt.signImg, imgsrc });
        }
      }
      if (xdt.approvalImg !== 0) {
        if (!find(approvedImage, { approvalImg: xdt.approvalImg })) {
          const imgAppsrc = getImageURLs(xdt.approvalImg);
          approvedImage.push({ approvalImg: xdt.approvalImg, imgAppsrc });
        }
      }
      if (xdt.changeNotes && xdt.changeNotes.length > 0) {
        xdt.changeNotes.map(async (doc) => {
          if (doc.docName) {
            const response = this.getSupDocuments(doc);
            supDocuments.push({ ...doc, response });
          }
          return null;
        });
      };
      return null;
    });
    await Promise.resolve(clockInObject).then((res) => {
      if (res) {
        clockInObject.startTime = res.startTime;
        clockInObject.currentClockInActivity = res.currentClockInActivity;
      }
      return null;
    });
    await Promise.all(employeeSignatureImg.map((x) => x.imgsrc)).then((body) => {
      employeeSignatureImg = employeeSignatureImg.map((img, key) => {
        return { ...img, src: body[key] }
      })
    });
    await Promise.all(approvedImage.map((x) => x.imgAppsrc)).then((body) => {
      approvedImage = approvedImage.map((img, key) => {
        return { ...img, src: body[key] }
      })
    });
    await Promise.all(activityApprovalImg.map((x) => x.src)).then((body) => {
      activityApprovalImg = activityApprovalImg.map((img, key) => {
        return { ...img, src: body[key] }
      })
    });
    await Promise.all(supDocuments.map((x) => x.response)).then((body) => {
      supDocuments = supDocuments.map((img, key) => {
        const url = URL.createObjectURL(body[key]);
        return { ...img, href: url };
      })
    });
    const sunday = new Date(moment(get(finalTimesheets[0], 'startDate')).day(0));
    const nextSunday = new Date(moment(get(finalTimesheets[1] || finalTimesheets[0], 'startDate')).day(6));
    this.setState({
      weekCount: data.count,
      tempObj,
      currentClockInTimesheet,
      weekDays,
      overallTotals,
      finalTimesheets,
      personalDetails,
      startWeekDate: moment(sunday).format('YYYY-MM-DD'),
      weekEndDate: moment(nextSunday).format('YYYY-MM-DD'),
      employeeSignatureImg,
      approvedImage,
      activityApprovalImg,
      timesheetLoading: false,
      supDocuments,
      startTime: clockInObject.startTime,
      currentClockInActivity: clockInObject.currentClockInActivity,
      clockInDay: ''
    });
  }

  getSupDocuments = async (data) => {
    let docSrc = '';
    const getRequest = {
      method: `timesheets/docs?tid=${data.timesheetID}&doc=${data.docName}`
    };
    await getBlobImage(getRequest, false, false).then((response) => {
      if (response.data && response.data.size) {
        docSrc = response.data;
      }
    }).catch(error => {
      console.log(error);
    });
    return docSrc;
  }

  formatDate = (date) => moment(date).format("MMMM D, YYYY")

  handleWeekChange = (date) => {
    const formatDate = moment(date).format('YYYY-MM-DD');
    this.setState({ currentRecordingPeriod: false }, () => {
      this.getTimesheetRecord(formatDate, true, true);
    })
  }

  updateHourForDay = (activeHour = 0, activityProps, actIndex, timesheet) => {
    const startDate = moment(timesheet.startDate).format('YYYY-MM-DD');
    const request = {
      method: 'timesheets/hour',
      params: {
        timesheetID: activityProps.timesheetID,
        activityID: activityProps.activityID,
        day: actIndex,
        hours: Number(activeHour),
        madeBy: Number(get(localStorage, 'userid', '')),
      }
    }
    apiPut(request).then(async (res) => {
      if (isEqual(res.status, 200) && res.data) {
        await this.getTimesheetRecord(startDate, false, true);
      }
      if (res.request && res.request.response && res.request.status !== 200) {
        let obj = JSON.parse(res.request.response);
        obj.msg ? window.alert(obj.msg) : window.alert('Something Went Wrong!');
        return;
      }
    }).catch((err) => { })
  }

  getClockInData = async (uid) => {
    const request = {
      method: `activities/last-clockin?uid=${uid}`
    };
    return await apiGet(request, false).then((response) => {
      if (isEqual(response.status, 200) && response.data) {
        if (response.data.activityID) {
          return {
            startTime: response.data.clockAt,
            currentClockInActivity: response.data.activityID
          }
        } else {
          return {
            startTime: '',
            currentClockInActivity: '',
          }
        }
      }
    }).catch((err) => {
      console.log(err);
    });
  }
  submitTimeSheet = async (startDate) => {
    const { timesheetID, currentImageId, signatureOutput, savedSign, savedFuture } = this.state;
    let imageId = '';
    if (savedSign) {
      imageId = currentImageId;
    } else if (signatureOutput) {
      imageId = await signImageUpload(signatureOutput, savedFuture);
    }
    const request = {
      method: `timesheets/submit?tid=${timesheetID}&sid=${imageId}`,
      params: {}
    }
    if (imageId) {
      this.setState({ subLoading: true });
      await apiPost(request).then((res) => {
        if (res.status === 200 && res.data) {
          let obj = JSON.parse(res.request.response);
          obj.msg ? window.alert(obj.msg) : window.alert('Timesheet Submitted Successfully!');
          this.clearSignature();
          this.getTimesheetRecord(startDate);
        }
        if (res.request && res.request.response && res.request.status !== 200) {
          this.setState({ subLoading: false });
          let obj = JSON.parse(res.request.response);
          obj.msg ? window.alert(obj.msg) : window.alert('Something Went Wrong!');
          return;
        }
      }).catch((err) => {
        this.setState({ subLoading: false });
      });
    } else {
      window.alert('Please Type In Signature');
      return;
    }
  }

  isWeekday = (date) => date.getDay() === 0;

  startClockin = (activityID, actualDate, day, clockInLabel, timesheet, clockin = true) => {
    const { currentClockInTimesheet } = this.state;
    const startDate = moment(timesheet.startDate).format('YYYY-MM-DD');
    const now = momentDate();
    if (moment(new Date()).format('YYYY-MM-DD') !== actualDate) {
      window.alert(`Please Select Today's ${clockin ? 'Clockin' : 'Clockout'}`);
      return;
    }
    const request = {
      method: 'timesheets/punches',
      params: {
        timesheetID: currentClockInTimesheet.tid,
        activityID: activityID,
        day: now.getDay(),
        userID: Number(get(localStorage, 'userid', '')),
        type: clockin ? 1 : 2,
        duration: '20',
        madeBy: currentClockInTimesheet.uid
      }
    }
    this.setState({ clockInDay: clockInLabel })
    apiPost(request).then(async (res) => {
      if (isEqual(res.status, 200) && res.data) {
        await this.getTimesheetRecord(startDate, false, clockin ? true : false);
        if (clockin) {
          // this.setState({ clockInDay: '' });
        } else {
          let data = await this.getClockOutData(activityID);
          if (data.activityID) {
            this.setState({ stopTime: data.clockAt, currentClockInActivity: data.activityID });
          } else {
            this.setState({ stopTime: null });
          }
        }
      }
      if (res.request && res.request.response && res.request.status !== 200) {
        this.setState({ startTime: null, clockInDay: '', stopTime: null, currentClockInActivity: null });
        let obj = JSON.parse(res.request.response);
        obj.msg ? window.alert(obj.msg) : window.alert('Something Went Wrong!');
        return;
      }
    }).catch((err) => { })
  }


  getClockOutData = async (activityId) => {
    const { currentClockInTimesheet } = this.state;
    let data = null;
    const request = {
      method: `activities/last-clockout?uid=${currentClockInTimesheet.uid}&aid=${activityId}`
    };
    await apiGet(request, false).then((response) => {
      if (isEqual(response.status, 200) && response.data) {
        data = response.data;
      }
    }).catch((err) => {
      console.log(err);
      this.setState({ stopTime: null });
    })
    return data;
  }

  getCompanyDetails = () => {
    let requestDetails = {
      method: 'organizations/' + localStorage.orgid,
      params: { user_id: localStorage.userid }
    };
    apiGet(requestDetails).then((response) => {
      if (response && response.data && response.status === 200) {
        this.setState({ companyDetails: response.data })
      } else {
        window.alert('Something Went Wrong!');
      }
    }).catch(error => {
      console.log(error)
    });
  }

  openSignaturePopup = async (tdetails = {}, displayTotal = 0.00) => {
    const { tid, startDate } = tdetails;
    const request = {
      method: `timesheets/presubmit?tid=${tid}`,
      params: {}
    }
    apiGet(request, false).then(async (res) => {
      if (res && res.status === 200 && res.data) {
        this.setState({
          signshow: true,
          submitWeekDate: startDate,
          unsubmittedTimesheets: res.data.returnValue,
          preTsheetsChecked: res.data.returnValue > 0 ? false : true,
          timesheetID: tid,
          displayTotal,
        })
      }
      if (res.request && res.request.response && res.request.status !== 200) {
        let obj = JSON.parse(res.request.response);
        obj.msg ? window.alert(obj.msg) : window.alert('Something Went Wrong!');
        return;
      }
    });
  }

  authenticateUser = () => {
    const { userName, passWord } = this.state;
    if (this.validateForm()) {
      const request = {
        method: 'employees/authentication',
        params: {
          userName, passWord
        }
      }
      apiPost(request).then(async (res) => {
        if (isEqual(res.status, 200) && res.data) {
          const { signatureImage, imageId } = await getReuseSignInit();
          this.setState({ authenticate: false, errors: {}, signatureImage, currentImageId: imageId, savedSign: (imageId && signatureImage) ? true : false });
        }
        if (res.request && res.request.response && res.request.status !== 200) {
          let obj = JSON.parse(res.request.response);
          obj.msg ? window.alert(obj.msg) : window.alert('Something Went Wrong!');
          return;
        }
      }).catch((err) => { })
    }
  }

  returnCommentIcon = (week, name = '') => {
    return <OverlayTrigger
      key="commentIcon"
      placement='top'
      overlay={
        <Popover id={`popover-positioned-top`}>
          <Popover.Title as="h6" className="background-green1 text-white">Approval Comment</Popover.Title>
          <Popover.Content>
            <p className="mb-0">{week.approvalComment}</p>
          </Popover.Content>
        </Popover>
      }>
      <i onClick={(e) => e.stopPropagation()} className={`${name === 'timesheet' ? 'large_font' : 'font-11'} fa fa-info-circle text-green mr-1`}></i>
    </OverlayTrigger>
  }

  returnImage = (id, key, imgArr, altText, width, height = 50, maxWidth) => {
    const obj = find(imgArr, { [key]: id });
    return obj ? <img src={obj.src} width={width || 'auto'} style={maxWidth ? { maxWidth: maxWidth } : {}} height={height} alt={altText} /> : null;
  }

  ExampleCustomInput = ({ value, onClick }) => (
    <div className="inner-addon right-addon">
      <i className="fa fa-calendar" onClick={onClick}></i>
      <input onClick={onClick} value={value} onChange={() => { }} type="text" className="form-control" placeholder="Select Date" name="date" />
    </div>
  );

  signatureChange = (value, fontValue) => {
    this.setState({ signatureText: value, currentFont: fontValue });
    if (value && fontValue) {
      var tCtx = document.createElement('canvas').getContext('2d');
      tCtx.canvas.width = ((tCtx.measureText(value).width) * 3.5) + 20;
      tCtx.canvas.height = 55;
      tCtx.font = `40px ${fontValue}`;
      tCtx.fillText(value, 10, 40);
      this.setState({ signatureOutput: tCtx.canvas.toDataURL() });
    } else {
      this.setState({ signatureOutput: '' });
    }
  }

  getClockInOutLogic = (timings) => {
    const { currentClockInActivity, startTime, weekDays } = this.state;
    let uniqueHours = {}, finalClockIns = {};
    if (timings && timings.length > 0) {
      const final = groupBy(timings, 'day');
      const resultObj = {};
      Object.values(final).map(groupbyDays => {
        groupbyDays.filter(v => v.type === 1).map((record, i) => {
          const labelNameIn = `${i}_${ClockInOuts[record.type]}`;
          if (resultObj[labelNameIn]) {
            resultObj[labelNameIn].push(record);
          } else {
            resultObj[labelNameIn] = [record];
          }
          return null;
        })

        groupbyDays.filter(v => v.type === 2).map((record, i) => {
          const labelNameOut = `${i}_${ClockInOuts[record.type]}`;
          if (resultObj[labelNameOut]) {
            resultObj[labelNameOut].push(record);
          } else {
            resultObj[labelNameOut] = [record];
          }
          return null;
        })
        return null;
      })
      uniqueHours = Object.keys(resultObj).sort().reduce((obj, key) => { obj[key] = resultObj[key]; return obj; }, {});
      if (final[momentDate().getDay()] && (final[momentDate().getDay()].length === Object.keys(uniqueHours).length)) {
        const keysArr = Object.keys(uniqueHours).map((k) => Number(k.split('_')[0]));
        const maxNumber = Math.max(...keysArr);
        let extraObj = {};
        if (!Object.keys(uniqueHours).includes(`${maxNumber}_IN`) || !Object.keys(uniqueHours).includes(`${maxNumber}_OUT`)) {
          if (Object.keys(uniqueHours).includes(`${maxNumber}_IN`)) {
            extraObj = { ...extraObj, ...{ [`${maxNumber}_OUT`]: [{ clockAt: null, day: momentDate().getDay(), clocks: true, type: 2 }] } }
          } else if (Object.keys(uniqueHours).includes(`${maxNumber}_OUT`)) {
            extraObj = { ...extraObj, ...{ [`${maxNumber}_IN`]: [{ clockAt: null, day: momentDate().getDay(), clocks: true, type: 1 }] } }
          }
        } else {
          extraObj = {
            [`${maxNumber + 1}_IN`]: [{ clockAt: null, day: momentDate().getDay(), clocks: true, type: 1 }],
            [`${maxNumber + 1}_OUT`]: [{ clockAt: null, day: momentDate().getDay(), clocks: true, type: 2 }],
          }
        }
        uniqueHours = { ...uniqueHours, ...extraObj };
      }
      Object.keys(DAYS_OF_WEEK).map((y) => {
        let weekArr1 = [];
        Object.entries(uniqueHours).map((xdata) => {
          finalClockIns[xdata[0]] = xdata[1];
          const uniqueDays = xdata[1].map(x => x.day);
          if (!uniqueDays.includes(Number(y))) {
            if (xdata[0].includes('IN')) {
              const clocksFlagIn = weekArr1.find((dn) => dn.type === 1 && dn.clocks === true);
              if (startTime && weekArr1.find((db) => db.activityID === currentClockInActivity)) {
                finalClockIns[xdata[0]].push({ day: Number(y), type: 1, clockAt: null, clocks: false });
              } else {
                finalClockIns[xdata[0]].push({ day: Number(y), type: 1, clockAt: null, clocks: (!clocksFlagIn && Number(y) >= momentDate().getDay()) ? true : false });
              }
              weekArr1 = [...finalClockIns[xdata[0]], ...weekArr1];
            } else {
              const clocksFlagOut = weekArr1.find((dn) => dn.type === 2 && dn.clocks === true);
              finalClockIns[xdata[0]].push({ day: Number(y), type: 2, clockAt: null, clocks: (!clocksFlagOut && Number(y) >= momentDate().getDay()) ? true : false });
              weekArr1 = [...finalClockIns[xdata[0]], ...weekArr1];
            }
          } else {
            return null;
          }
          return null;
        });
        return null;
      })
    } else {
      if (find(weekDays, { fullDate: moment().format('YYYY-MM-DD') })) {
        finalClockIns = {
          ['0_IN']: Object.keys(DAYS_OF_WEEK).map((dat) => ({ day: Number(dat), type: 1, clockAt: null, clocks: true })),
          ['0_OUT']: Object.keys(DAYS_OF_WEEK).map((dat) => ({ day: Number(dat), type: 2, clockAt: null, clocks: true })),
        }
      }
    }
    return finalClockIns;
  }

  clearSignature = () => {
    this.setState({
      signshow: false, submitWeekDate: '', errors: {}, timesheetID: '', authenticate: true, userName: '', signatureImage: "", subLoading: false,
      unsubmittedTimesheets: 0, preTsheetsChecked: false, deletePopup: false, selEmptyTimesheets: [],
      passWord: '', signatureText: '', currentFont: fontOptions[0].value, savedFuture: true, savedSign: true, displayTotal: 0.00,
    });
  }

  printTimesheetPDF = (e) => {
    const { personalDetails, startWeekDate } = this.state;
    let content = document.getElementById('myOwnTimesheet');

    // -----------> html2pdf working with page breaks,
    html2pdf(content, {
      margin: [0, 10, 10, 10],
      filename: `${personalDetails.userFirstname} ${personalDetails.userLastname} Timesheet ${moment(startWeekDate).format('YYYY-MM-DD')}.pdf`,
      // pagebreak: { after: '.afterClass' },
      //jsPDF: { unit: 'px', format: [content.offsetWidth + 100, content.offsetHeight + 100], orientation: 'l' }
      jsPDF: { unit: 'mm', format: 'ledger', orientation: 'l' }
    });
  }

  layoutDoc = (changes) => {
    const { supDocuments } = this.state;
    const obj = supDocuments.find((x) => x.docName === changes.docName);
    return <a href={obj.href} download={obj.docName}>Document</a>
  }

  validateForm() {
    const { userName, passWord } = this.state;
    let errors = {};
    let formIsValid = true;
    if (!userName) {
      formIsValid = false;
      errors["userName"] = "form-control is-invalid";
    }
    if (!passWord) {
      formIsValid = false;
      errors["passWord"] = "form-control is-invalid";
    }
    this.setState({ errors: errors });
    return formIsValid;
  }

  onEnter = (e) => {
    if (e.key === 'Enter') {
      this.authenticateUser();
    }
  }

  // Delete Empty Timesheet
  openDeletePopup = () => {
    const getRequest = {
      method: `timesheets/empties/${localStorage.userid}`,
      params: {}
    };
    apiGet(getRequest).then((res) => {
      if (res.status === 200 && res.data) {
        let emptyTimesheets = [];
        if (res.data.timsheets.length > 0) {
          res.data.timsheets.map((item) => {
            emptyTimesheets.push({
              ...item,
              start: momentWithFormat(item.startDate),
              timesheetStatus: timesheet_status_codes[item.status]
            })
            return null;
          });
        }
        this.setState({ emptyTimesheets, deletePopup: true });
      }
    }).catch(error => {
      this.setState({
        startWeekDate: moment().day(0).format('YYYY-MM-DD'),
        weekEndDate: moment().day(6).format('YYYY-MM-DD')
      });
    });
  };


  deleteTimesheets = () => {
    const { selEmptyTimesheets, startWeekDate } = this.state;
    const tidList = selEmptyTimesheets.map((x) => x.tid);
    const requestDetails = {
      method: 'timesheets/delete-empty',
      params: {
        tidList,
        madeBy: localStorage.userid,
      }
    };
    apiPost(requestDetails).then((res) => {
      const obj = JSON.parse(res.request.response);
      if (res && res.status === 200) {
        window.alert(obj.msg);
        this.clearSignature();
        this.getTimesheetRecord(startWeekDate);
      } else {
        window.alert(obj.msg);
        return null;
      }
    }).catch(error => {
      console.log(error)
    });
  }

  //render
  render() {
    const { displayTotal, unsubmittedTimesheets, preTsheetsChecked, personalDetails, errors, clockInDay, signatureOutput, currentRecordingPeriod, signatureText, userName, passWord, currentDay, startTime, currentClockInActivity,
      timesheetLoading, startWeekDate, weekEndDate, subLoading, submitWeekDate, weekCount, tempObj, finalTimesheets, currentFont, signatureImage, activityApprovalImg,
      weekDays, currentClockInTimesheet, overallTotals, emptyTimesheets, approvedImage, selEmptyTimesheets, deletePopup, employeeSignatureImg, companyDetails, authenticate, savedSign, savedFuture, signType } = this.state;
    const biweekly = weekCount === 2 ? true : false;
    let week1Total = [];
    let week2Total = [];
    if (overallTotals.length > 0) {
      week1Total = overallTotals.slice(0, 7).map((dTotal) => dTotal.hours);
      week2Total = overallTotals.slice(7, 14).map((d1Total) => d1Total.hours);
    }
    return (
      <div className="App">
        <div className="content">
          <div className="contentwrapper pb-5 mb-5">
            <ul className="pl-0 my-2">
              <button onClick={() => this.openDeletePopup()} className="p-0 cursor-pointer button resend-btn background-red py-2 px-4 m-0 mr-2">Delete Empty</button>
            </ul>
            <div className="p-3 mb-3 small_font bg-amber border-0">
              <div className="row">
                <div className="col-md-10 col-sm-12" />
                <div className="col-md-2 col-sm-12 px-0">
                  <input
                    style={{ float: 'left', width: '25px', marginTop: '3px' }}
                    type="checkbox"
                    id="currentRecordingPeriod"
                    name="current-recording"
                    className="form-control"
                    onChange={() => this.setCurrentRecordingPeriod(currentRecordingPeriod)}
                    checked={currentRecordingPeriod}
                  />
                  <label htmlFor="currentRecordingPeriod" style={{ fontSize: '9pt' }}>Current Recording Period</label>
                </div>
              </div>
              <div className="row">
                <div className="col-md-5 col-sm-12">
                  <span className="pr-3 font-weight-bold font-16">
                    {personalDetails.userLastname ? personalDetails.userLastname + ',' : null} {personalDetails.userFirstname}
                  </span>
                </div>
                <div className="col-md-3 col-sm-1 text-right" />
                <div className="col-md-4 col-sm-4 text-right">
                  <div className="d-flex">
                    <div className="col-md-5 col-sm-5 text-right">
                      <label className="act-text">Week Started</label>
                    </div>
                    <div className="col-md-1 col-sm-1 pl-0 align-self-center">
                      <i className="fa fa-angle-double-left fa-2x" onClick={() => this.handleWeekChange(moment(startWeekDate).subtract(1, 'weeks'))} />
                    </div>
                    <div className="col-md-5 col-sm-5 px-0 ">
                      <DatePicker
                        selected={momentDate(startWeekDate)}
                        value={moment(startWeekDate).format('YYYY-MM-DD')}
                        name="startDate"
                        className="form-control"
                        customInput={<this.ExampleCustomInput />}
                        showMonthDropdown
                        showYearDropdown
                        dropdownMode="select"
                        filterDate={this.isWeekday}
                        onChange={this.handleWeekChange}
                        dateFormat="yyyy-MM-dd"
                        placeholderText="yyyy-MM-dd"
                      />
                    </div>
                    <div className="col-md-1 col-sm-1 align-self-center">
                      <i className="fa fa-angle-double-right fa-2x" onClick={() => this.handleWeekChange(moment(weekEndDate).add(1, 'day'))} />
                    </div>
                  </div>
                </div>
              </div>
            </div>
            {timesheetLoading ? 'Please Wait...' :
              <div className="mt-3" id="myOwnTimesheet">
                <table border='1' className="col-12 text-black">
                  <thead>
                    <tr>
                      <th colSpan='21' className="blue-head py-2">
                        <div className="row">
                          <div className="col-md-6 col-sm-12">
                            <div className="pl-2  float-left">
                              <span className="font-12">{biweekly ? 'BI' : ''} WEEKLY TIME SHEET</span>
                              <span className="small-font pl-2">
                                {`${this.formatDate(startWeekDate)} - ${this.formatDate(weekEndDate)}`}
                              </span>
                            </div>
                          </div>
                          <div className="col-md-6 col-sm-12">
                            <div className="pr-2 float-right">
                              <span className="pr-2 font-12">{timesheet_status_codes[`${get(personalDetails, 'status', '')}`]}</span>
                              <span className="font-small">{`Due on : ${this.formatDate(moment(weekEndDate).subtract(1, 'day'))}`}</span>
                              <span className="px-1">|</span>
                              <i className="fa fa-print cursor-pointer px-1" onClick={() => window.print()}></i>
                              <i className="fa fa-file-pdf-o cursor-pointer px-1" onClick={() => this.printTimesheetPDF()}></i>
                            </div>
                          </div>
                        </div>
                      </th>
                    </tr>
                  </thead>
                  <tbody className="text-center">
                    <tr>
                      <td colSpan='2' className="font-weight-bold text-right pr-1">NAME:</td>
                      <td colSpan='19' className="pl-1 text-left">
                        {get(personalDetails, 'userLastname', '')}, {get(personalDetails, 'userFirstname', '')}
                      </td>
                    </tr>
                    <tr>
                      <td colSpan='2' className="font-weight-bold text-right pr-1">GROUP:</td>
                      <td colSpan='19' className="pl-1 text-left">{personalDetails.groupCode ? `${personalDetails.groupName} (${personalDetails.groupCode})` : 'N/A'}</td>
                    </tr>
                    <tr className="text-center font-small p-1 bg-lite-gray">
                      <th colSpan='2' width="8%"></th>
                      {weekDays.slice(0, 7).map((day, index) => (
                        <th key={`${day.day}${index}`} width="4%">{day.day}<br />{day.date}</th>
                      ))}
                      {biweekly ? <th width="4%">1st Week<br />Total</th> : <th width="4%">Total<br />Hours</th>}
                      <th width="3%">Office Use</th>
                      {biweekly && <>
                        {weekDays.slice(7, 14).map((day, index) => (
                          <th key={`${day.day}${index}`} width="4%">{day.day}<br />{day.date}</th>
                        ))}
                        <th width="4%">2nd Week<br />Total</th>
                        <th width="3%">Office Use</th>
                        <th width="4%">2 Weeks<br />Total</th>
                      </>}
                    </tr>
                    {tempObj && Object.values(tempObj).map((x, i) => {
                      let activityName = x.week1.activityName;
                      let w1finalClockIns = {}, w2finalClockIns = {};
                      const w1activityTotal = x.week1 && Object.values(DAYS_OF_WEEK).map((day) => x.week1[`${day.toLowerCase()}Hour`]).reduce((a, b) => Number(Number(a) + Number(b)).toFixed(2), 0);
                      const w2activityTotal = x.week2 && Object.values(DAYS_OF_WEEK).map((day) => x.week2[`${day.toLowerCase()}Hour`]).reduce((a, b) => Number(Number(a) + Number(b)).toFixed(2), 0);
                      if (x.week1 && x.week1.timingMethod === 1) {
                        w1finalClockIns = this.getClockInOutLogic(x.week1.clockinouts);
                      }
                      if (x.week2 && x.week2.timingMethod === 1) {
                        w2finalClockIns = this.getClockInOutLogic(x.week2.clockinouts);
                      }
                      let finalData = {};
                      let extraArr = Object.keys(DAYS_OF_WEEK).map((dat) => ({ day: Number(dat), type: 1, clockAt: null }));
                      if (Object.entries(w1finalClockIns) > Object.entries(w2finalClockIns)) {
                        Object.entries(w1finalClockIns).map((x) => {
                          if (!isEmpty(w2finalClockIns) && w2finalClockIns[x[0]]) {
                            finalData[x[0]] = [...x[1], ...w2finalClockIns[x[0]]]
                          } else {
                            finalData[x[0]] = [...x[1], ...extraArr]
                          }
                          return null;
                        })
                      } else {
                        Object.entries(w2finalClockIns).map((x) => {
                          if (!isEmpty(w1finalClockIns) && w1finalClockIns[x[0]]) {
                            finalData[x[0]] = [...w1finalClockIns[x[0]], ...x[1]]
                          } else {
                            finalData[x[0]] = [...extraArr, ...x[1]]
                          }
                          return null;
                        })
                      }
                      return <React.Fragment key={i}>
                        {!isEmpty(finalData) && Object.values(finalData).map((clkData, k) => {
                          const timeType = Object.keys(finalData)[k];
                          let w1 = clkData.slice(0, 7);
                          let w2 = clkData.slice(7, 14);
                          return <tr key={k}>
                            {k === 0 && (<td className="font-weight-bold" rowSpan={Object.values(finalData).length + 1}>{activityName.toUpperCase()}</td>)}
                            <td >{timeType.split('_')[1]}</td>
                            {sortBy(w1, 'day').map((dt, clKey) => {
                              const actualDate = weekDays.slice(0, 7).find((we) => we.day === DAYS_OF_WEEK[dt.day]).fullDate;
                              const todayDate = moment(momentDate()).format('YYYY-MM-DD');
                              const clockInLabel1 = `${x.week1.activityID}_${dt.day}_${k}_1`;
                              return <td key={clKey}>
                                {(dt && dt.clockAt) ? moment(dt.clockAt).format('h:mm A') : null}
                                {(!dt.clockAt && actualDate >= todayDate && x.week1.id !== 0 && dt.clocks === true) ?
                                  <>
                                    {dt.type === 1 ? <MDBBtn
                                      size="sm"
                                      className="btn-success xs_font"
                                      disabled={currentClockInTimesheet.status >= 300 || x.week1.enabled === 0 || clockInDay === clockInLabel1 || (startTime && (currentClockInActivity !== x.week1.activityID || (moment(startTime) !== moment(actualDate))))}
                                      onClick={(e) => this.startClockin(x.week1.activityID, actualDate, dt.day, clockInLabel1, finalTimesheets[0], true)}
                                    >Clock In</MDBBtn> :
                                      <MDBBtn
                                        size="sm"
                                        className="btn-danger xs_font px-1"
                                        disabled={currentClockInTimesheet.status >= 300 || x.week1.enabled === 0 || clockInDay === clockInLabel1 || !startTime || (startTime && currentClockInActivity !== x.week1.activityID)}
                                        onClick={(e) => this.startClockin(x.week1.activityID, actualDate, dt.day, clockInLabel1, finalTimesheets[0], false)}
                                      >
                                        Clock Out</MDBBtn>}
                                  </>
                                  : null}
                              </td>
                            })}
                            <td ></td>
                            {biweekly && <>
                              {k === 0 && (<td rowSpan={Object.values(finalData).length}></td>)}
                              {sortBy(w2, 'day').map((dt, clKey) => {
                                const actualDate = weekDays.slice(7, 14).find((we) => we.day === DAYS_OF_WEEK[dt.day]).fullDate;
                                const todayDate = moment(momentDate()).format('YYYY-MM-DD');
                                const clockInLabel2 = `${x.week2.activityID}_${dt.day}_${k}_2`;
                                return <td key={clKey}>
                                  {(dt && dt.clockAt) ? moment(dt.clockAt).format('h:mm A') : null}
                                  {(!dt.clockAt && actualDate >= todayDate && x.week2.id !== 0 && dt.clocks === true) ?
                                    <>
                                      {dt.type === 1 ? <MDBBtn
                                        size="sm"
                                        className="btn-success xs_font"
                                        disabled={currentClockInTimesheet.status >= 300 || x.week2.enabled === 0 || clockInDay === clockInLabel2 || (startTime && (currentClockInActivity !== x.week2.activityID || (moment(startTime) !== moment(actualDate))))}
                                        onClick={(e) => this.startClockin(x.week2.activityID, actualDate, dt.day, clockInLabel2, finalTimesheets[1], true)}
                                      >Clock In</MDBBtn> :
                                        <MDBBtn
                                          size="sm"
                                          className="btn-danger xs_font px-1"
                                          disabled={currentClockInTimesheet.status >= 300 || x.week2.enabled === 0 || clockInDay === clockInLabel2 || !startTime || (startTime && currentClockInActivity !== x.week2.activityID)}
                                          onClick={(e) => this.startClockin(x.week2.activityID, actualDate, dt.day, clockInLabel2, finalTimesheets[1], false)}
                                        >
                                          Clock Out</MDBBtn>}
                                    </>
                                    : null}
                                </td>
                              })}
                              <td ></td>
                            </>}
                            {k === 0 && (<td rowSpan={Object.values(finalData).length}></td>)}
                            {k === 0 && biweekly && (<td rowSpan={Object.values(finalData).length}></td>)}
                          </tr>
                        })}
                        <tr className={`time-td blue-text bg-lite-gray ${Object.keys(finalData).length > 0 ? 'afterClass' : ''}`}>
                          {Object.keys(finalData).length > 0 ?
                            <td>HOURS</td> :
                            <td colSpan='2'>{`${x.week1.activityName.toUpperCase() || x.week2.activityName.toUpperCase()}`}</td>}
                          {Object.values(DAYS_OF_WEEK).map((day, index) => {
                            let multiIndex1 = {};
                            let objDate1 = {};
                            if (finalTimesheets[0].changeNotes.length > 0) {
                              finalTimesheets[0].changeNotes.map((ch) => {
                                const keyName1 = `${ch.activityName}_${ch.day}`;
                                if (objDate1 && objDate1[keyName1]) {
                                  let obj = objDate1[keyName1];
                                  objDate1[keyName1] = { ...objDate1[keyName1], index: [...obj.index, ch.index] };
                                } else {
                                  objDate1[keyName1] = { index: [ch.index], day: ch.day, activityID: ch.activityID };
                                }
                                if ((ch.activityID === x.week1.activityID) && DAYS_OF_WEEK[ch.day] === day) {
                                  if (objDate1[keyName1] && (objDate1[keyName1].index).length > 0) {
                                    multiIndex1 = objDate1[keyName1];
                                  }
                                };
                                return null;
                              });
                            }
                            const hourValue = x.week1[`${day.toLowerCase()}Hour`] > 0 ? toNumber(x.week1[`${day.toLowerCase()}Hour`]) : multiIndex1.index ? '0.00' : null;
                            return <td key={`${day}${index}`} className={`${currentDay === `${x.week1.activityID}_${day}1` ? 'bg-white' : ''} text-blue`}>
                              {(multiIndex1.index && multiIndex1.index.length > 1) ? <OverlayTrigger
                                key={index}
                                placement='top'
                                overlay={
                                  <Popover id={`popover-positioned-top`}>
                                    <Popover.Title as="h6" className="background-green1 text-white">Timesheet Changes</Popover.Title>
                                    <Popover.Content>
                                      <div>Timesheet Changes of Day: </div>
                                      <div>{multiIndex1.index.join(', ')}</div>
                                    </Popover.Content>
                                  </Popover>
                                }>
                                <span onClick={(e) => e.stopPropagation()} className="ptoCircleMultiple mr-2 ptoCircle xs_font">{multiIndex1.index[0]}</span>
                              </OverlayTrigger> :
                                multiIndex1.index && <span onClick={(e) => e.stopPropagation()} className="mr-1 ptoCircle xs_font">{multiIndex1.index[0]}</span>
                              }
                              <div className={multiIndex1.index && "d-inline"}
                                contentEditable={(x.week1.enabled === 1 && x.week1.id !== 0 && x.week1.timingMethod === 2) ? true : false}
                                suppressContentEditableWarning={true}
                                onFocus={(e) => this.setState({ currentDay: (e.currentTarget && e.currentTarget.contentEditable) ? `${x.week1.activityID}_${day}1` : '' })}
                                onBlur={(e) => {
                                  const textContent = e.currentTarget.textContent;
                                  if (toNumber(textContent) !== toNumber(hourValue)) {
                                    this.updateHourForDay(textContent, x.week1, index, finalTimesheets[0])
                                  }
                                  this.setState({ currentDay: '' });
                                }}>{hourValue}</div>
                            </td>
                          })}
                          <td >{w1activityTotal}</td>
                          <td>
                            {x.week1.approvedBy > 0 ? <>
                              {x.week1.approvalComment && this.returnCommentIcon(x.week1)}
                              {this.returnImage(x.week1.approveImg, 'approveImg', activityApprovalImg, 'approvalImage', 40, 30, x.week1.approvalComment ? '25px' : '35px')}
                            </> : null}
                          </td>

                          {/* for 2nd Week */}
                          {biweekly && <>
                            {Object.values(DAYS_OF_WEEK).map((day, index) => {
                              let multiIndex2 = {};
                              let objDate2 = {};
                              if (finalTimesheets[1].changeNotes.length > 0) {
                                finalTimesheets[1].changeNotes.map((ch) => {
                                  const keyName2 = `${ch.activityName}_${ch.day}`;
                                  if (objDate2 && objDate2[keyName2]) {
                                    let obj = objDate2[keyName2];
                                    objDate2[keyName2] = { ...objDate2[keyName2], index: [...obj.index, ch.index] };
                                  } else {
                                    objDate2[keyName2] = { index: [ch.index], day: ch.day, activityID: ch.activityID };
                                  }
                                  if ((ch.activityID === x.week2.activityID) && DAYS_OF_WEEK[ch.day] === day) {
                                    if (objDate2[keyName2] && (objDate2[keyName2].index).length > 0) {
                                      multiIndex2 = objDate2[keyName2];
                                    }
                                  };
                                  return null;
                                });
                              }
                              const hour2Value = x.week2[`${day.toLowerCase()}Hour`] > 0 ? toNumber(x.week2[`${day.toLowerCase()}Hour`]) : multiIndex2.index ? '0.00' : null;
                              return <td key={`${day}${index}`} className={`${currentDay === `${x.week2.activityID}_${day}2` ? 'bg-white' : ''} text-blue`}>
                                {(multiIndex2.index && multiIndex2.index.length > 1) ? <OverlayTrigger
                                  key={index}
                                  placement='top'
                                  overlay={
                                    <Popover id={`popover-positioned-top`}>
                                      <Popover.Title as="h6" className="background-green1 text-white">Timesheet Changes</Popover.Title>
                                      <Popover.Content>
                                        <div>Timesheet Changes of Day: </div>
                                        <div>{multiIndex2.index.join(', ')}</div>
                                      </Popover.Content>
                                    </Popover>
                                  }>
                                  <span onClick={(e) => e.stopPropagation()} className="ptoCircleMultiple mr-2 ptoCircle xs_font">{multiIndex2.index[0]}</span>
                                </OverlayTrigger> :
                                  multiIndex2.index && <span onClick={(e) => e.stopPropagation()} className="mr-1 ptoCircle xs_font">{multiIndex2.index[0]}</span>
                                }
                                <div className={multiIndex2.index && "d-inline"}
                                  contentEditable={(x.week2.enabled === 1 && x.week2.id !== 0 && x.week2.timingMethod === 2) ? true : false}
                                  suppressContentEditableWarning={true}
                                  onFocus={(e) => this.setState({ currentDay: (e.currentTarget && e.currentTarget.contentEditable) ? `${x.week2.activityID}_${day}2` : '' })}
                                  onBlur={(e) => {
                                    const textContent = e.currentTarget.textContent;
                                    if (toNumber(textContent) !== toNumber(hour2Value)) {
                                      this.updateHourForDay(textContent, x.week2, index, finalTimesheets[1])
                                    }
                                    this.setState({ currentDay: '' });
                                  }}>{hour2Value}</div>
                              </td>
                            })}
                            <td >{w2activityTotal}</td>
                            <td>
                              {x.week2.approvedBy > 0 ? <>
                                {x.week2.approvalComment && this.returnCommentIcon(x.week2)}
                                {this.returnImage(x.week2.approveImg, 'approveImg', activityApprovalImg, 'approvalImage', 40, 30, x.week2.approvalComment ? '25px' : '35px')}
                              </> : null}
                            </td>
                            <td >{toNumber(Number(w1activityTotal) + Number(w2activityTotal))}</td>
                          </>}
                        </tr>
                      </React.Fragment>
                    })}
                    <tr className="time-td blue-text bg-lite-gray">
                      <td colSpan='2'>TOTAL</td>
                      {week1Total.map((hour, rkey) => <td key={rkey}>{toNumber(hour) || 0.00}</td>)}
                      <td className="text-blue">{toNumber(sum(week1Total)) || 0.00}</td>
                      <td />
                      {biweekly && <>
                        {week2Total.map((hour2, rkey) => <td key={rkey}>{toNumber(hour2) || 0.00}</td>)}
                        <td className="text-blue">{toNumber(sum(week2Total)) || 0.00}</td>
                        <td />
                        <td>{toNumber(sum(week1Total) + sum(week2Total))} </td>
                      </>}
                    </tr>
                    <tr>
                      <th colSpan='11' className="blue-head text-center py-2">
                        Timesheet Changes
                      </th>
                      {biweekly && <th colSpan='10' className="blue-head text-center py-2">
                        Timesheet Changes
                      </th>}
                    </tr>
                    <tr>
                      <td colSpan='11' className="py-2 text-left align-baseline">
                        {
                          get(finalTimesheets[0], 'changeNotes', []).map((timesheetChanges1, timIndex) => {
                            let actualDay = DAYS_OF_WEEK[timesheetChanges1.day];
                            let dateObject = find(weekDays, { day: actualDay });
                            return <p key={timIndex} className="pl-1 mb-1 small_font">
                              <span className="ptoCircleChg mr-2 text-center">{timesheetChanges1.index}</span>
                              {timesheetChanges1.activityName || ''} {moment(dateObject.fullDate).format('dddd (MMM DD, YYYY)')} : {timesheetChanges1.reason} - Change made by {timesheetChanges1.madeByFirstname} {timesheetChanges1.madeByLastname}
                              &nbsp; on {moment(timesheetChanges1.madeAt).format("hh:mm A MMM DD, YYYY")}. {timesheetChanges1.docName ? this.layoutDoc(timesheetChanges1) : null}
                            </p>
                          })
                        }
                      </td>
                      {biweekly && <td colSpan='10' className="py-2 text-left align-baseline">
                        {get(finalTimesheets[1], 'changeNotes', []).map((timesheetChanges2, timIndex) => {
                          let actualDay = DAYS_OF_WEEK[timesheetChanges2.day];
                          const biweekDays = weekDays.slice(7, 14);
                          const dateObject = find(biweekDays, { day: actualDay });
                          return <p key={timIndex} className="pl-1 mb-1 small_font">
                            <span className="text-center mr-2 ptoCircleChg">{timesheetChanges2.index}</span>
                            {timesheetChanges2.activityName || ''} {moment(dateObject.fullDate).format('dddd (MMM DD, YYYY)')} : {timesheetChanges2.reason} - Change made by {timesheetChanges2.madeByFirstname} {timesheetChanges2.madeByLastname}
                            &nbsp; on {moment(timesheetChanges2.madeAt).format("hh:mm A MMM DD, YYYY")}. {timesheetChanges2.docName ? this.layoutDoc(timesheetChanges2) : null}
                          </p>
                        })}
                      </td>}
                    </tr>
                    <tr>
                      <td colSpan={biweekly ? '21' : '11'} className="py-2"></td>
                    </tr>
                    {!isEmpty(finalTimesheets) && <tr>
                      {/* 1st week data */}
                      <td colSpan='2' className="pt-5 text-left">
                      </td>
                      <td colSpan='5' className="pt-5 text-left">
                        <div className="mb-0">
                          <span className="pl-1 pr-2 font-9">Employee Signature:</span>
                          {finalTimesheets[0] && finalTimesheets[0].status >= 300 ?
                            this.returnImage(finalTimesheets[0].signImg, 'signImg', employeeSignatureImg, 'employeeSignatureImg', 80, 30) :
                            <div className="float-right">
                              <div className="guideList" onClick={() => finalTimesheets[0].tid !== 0 && this.openSignaturePopup(finalTimesheets[0], sum(week1Total))}>
                                <div className="active cursor-pointer">
                                  <span className="activePointer timesheetSign"></span>
                                  <span className="pl-4">
                                    SIGN
                                  </span>
                                </div>
                              </div>
                            </div>
                          }
                        </div>
                        <p className="mb-0">
                          <span className="pl-1 font-9">Date: </span>
                          <span className="pl-1 font-9">{finalTimesheets[0].submitDate || ''}</span>
                        </p>
                      </td>

                      <td colSpan='4' className="pt-5 text-left">
                        <p className="mb-0">
                          <span className="pl-1 pr-2 font-9">Approval Signature:</span>
                          {finalTimesheets[0] && finalTimesheets[0].status < 500 ? null :
                            <>
                              {finalTimesheets[0].approvalComment && this.returnCommentIcon(finalTimesheets[0], 'timesheet')}
                              {this.returnImage(finalTimesheets[0].approvalImg, 'approvalImg', approvedImage, 'approvalImage', 80, 30)}
                            </>}
                        </p>
                        <p className="mb-0">
                          <span className="pl-1 font-9">Date: </span>
                          <span className="pl-1 font-9">{finalTimesheets[0].approvalDate || ''}</span>
                        </p>
                      </td>
                      {/* 2nd week data */}
                      {biweekly && <>
                        <td colSpan='2' className="pt-5 text-left" />
                        <td colSpan='4' className="pt-5 text-left">
                          <div className="mb-0">
                            <span className="pl-1 pr-2 font-9">Employee Signature:</span>
                            {finalTimesheets[1] && finalTimesheets[1].status >= 300 ?
                              this.returnImage(finalTimesheets[1].signImg, 'signImg', employeeSignatureImg, 'employeeSignatureImg', 80, 30) :
                              <div className="float-right">
                                <div className="guideList" onClick={() => finalTimesheets[1].tid !== 0 && this.openSignaturePopup(finalTimesheets[1], sum(week2Total))}>
                                  <div className="active cursor-pointer">
                                    <span className="activePointer timesheetSign"></span>
                                    <span className="pl-4">
                                      SIGN
                                    </span>
                                  </div>
                                </div>
                              </div>}
                          </div>
                          <p className="mb-0">
                            <span className="pl-1 font-9">Date: </span>
                            <span className="pl-1 font-9">{finalTimesheets[1].submitDate || ''}</span>
                          </p>
                        </td>
                        <td colSpan='4' className="pt-5 text-left">
                          <p className="mb-0">
                            <span className="pl-1 pr-2 font-9">Approval Signature:</span>
                            {finalTimesheets[1] && finalTimesheets[1].status < 500 ? null :
                              <>
                                {finalTimesheets[1].approvalComment && this.returnCommentIcon(finalTimesheets[1], 'timesheet')}
                                {this.returnImage(finalTimesheets[1].approvalImg, 'approvalImg', approvedImage, 'approvalImage', 80, 30)}
                              </>}
                          </p>
                          <p className="mb-0">
                            <span className="pl-1 font-9">Date: </span>
                            <span className="pl-1 font-9">{finalTimesheets[1].approvalDate || ''}</span>
                          </p>
                        </td>
                      </>}
                    </tr>}
                  </tbody>
                </table>
              </div>
            }
          </div>
        </div>

        {/** Modal to submit timesheet */}
        <Modal
          scrollable={true}
          size="md"
          onHide={() => this.clearSignature()}
          show={this.state.signshow}
        >
          <Modal.Header closeButton className="h6 background-green1">
            <Modal.Title className="h6 text-white small_font" >
              Timesheet Submission Confirmation by {personalDetails.userLastname} {personalDetails.userFirstname} ({this.formatDate(moment())}).
            </Modal.Title>
          </Modal.Header>
          <Modal.Body className="show-grid small_font px-5">
            <p className="xs_font text-dark text-center mb-2">
              Please enter your name and password to electronically sign and submit your timesheet. {companyDetails.name} requires that you certify your timesheet by submitting using this your electronic signature.
            </p>
            <p className="small_font font-weight-bold text-center mb-2">
              {getWeek(submitWeekDate, submitWeekDate)}
            </p>
            {authenticate ? <>
              {unsubmittedTimesheets > 0 ?
                <div className="text-center">
                  <p className="text-danger mb-1">You have {unsubmittedTimesheets} previous timesheets that have not been submitted. You must submit them first or check the following box to submit them together.</p>
                  <input id="preTsheetsChecked" type="checkbox" checked={preTsheetsChecked} onChange={(e) => this.setState({ preTsheetsChecked: e.target.checked })} className="mr-2 mt-1" name="preTsheetsChecked" />
                  <label htmlFor="preTsheetsChecked" className="small_font">Submit all previous timesheets together</label>
                </div> : null
              }
              {preTsheetsChecked ? <>
                <div className="form-group row mt-3">
                  <div className="col-lg-3 col-md-3 col-xl-3 col-sm-12 px-0 text-right">
                    <label className="mt-2">Login Name*</label>
                  </div>
                  <div className="col-lg-8 col-md-8 col-xl-8 col-sm-12">
                    <input type="text"
                      className={errors['userName'] ? errors['userName'] : "form-control"}
                      placeholder=""
                      value={userName}
                      onKeyPress={(e) => this.onEnter(e)}
                      onChange={(evt) => this.setState({ userName: evt.target.value })} />
                  </div>
                </div>
                <div className="form-group row">
                  <div className="col-lg-3 col-md-3 col-xl-3 col-sm-12 px-0 text-right">
                    <label className="mt-2">Password*</label>
                  </div>
                  <div className="col-lg-8 col-md-8 col-xl-8 col-sm-12">
                    <input type="password"
                      className={errors['passWord'] ? errors['passWord'] : "form-control"}
                      placeholder=""
                      value={passWord}
                      onKeyPress={(e) => this.onEnter(e)}
                      onChange={(evt) => this.setState({ passWord: evt.target.value })} />
                  </div>
                </div>
              </> : null} </> :
              <>
                {signatureImage &&
                  <div className="text-center">
                    <input id="savedSign" type="checkbox" checked={savedSign} onChange={(e) => this.setState({ savedSign: e.target.checked })} className="mr-2 mt-1" name="savedSign" />
                    <label className="mb-0" htmlFor="savedSign">Use the saved signature</label>
                  </div>}
                {(signatureImage && savedSign) ?
                  <div className="text-center">
                    <img src={signatureImage} alt="signatureImage" className="mb-1" />
                  </div> :
                  <>
                    <div className="row mb-2 mt-3">
                      <div className="col-xl-2 col-lg-2 col-md-2 col-sm-12">
                      </div>
                      <div className="col-xl-3 col-lg-3 col-md-3 col-sm-12 pl-0">
                        <input type="radio" value="type" checked={signType === 'type'} onChange={() => this.setState({ signType: 'type' })} className="mr-2 align-middle" name="signType" />
                        <label>Type</label>
                      </div>
                      <div className="col-xl-3 col-lg-3 col-md-3 col-sm-12 pl-0">
                        <input type="radio" value="drawing" checked={signType === 'drawing'} disabled onChange={() => this.setState({ signType: 'drawing' })} className="mr-2 align-middle" name="signType" />
                        <label>Drawing</label>
                      </div>
                      <div className="col-xl-4 col-lg-4 col-md-4 col-sm-12">
                        <input type="radio" value="image" checked={signType === 'image'} disabled onChange={() => this.setState({ signType: 'image' })} className="mr-2 align-middle" name="signType" />
                        <label>Image</label>
                      </div>
                    </div>
                    {signType === 'type' &&
                      <>
                        <div className={`form-group row mt-3 ${signatureOutput ? 'mb-0' : ''}`}>
                          <div className="col-lg-2 col-md-2 col-xl-2 col-sm-12 px-0">
                            <label className="mt-2">Type :</label>
                          </div>
                          <div className="col-lg-7 col-md-7 col-xl-7 col-sm-12 pl-0">
                            <input type="text" id="signatureText" style={{ fontFamily: currentFont, fontSize: signatureText && '3em !important' }} className="form-control" placeholder="Please type here for signature..." value={signatureText} onChange={(evt) => this.signatureChange(evt.target.value, currentFont)} />
                          </div>
                          <div className="col-xl-3 col-lg-3 col-md-3 col-sm-12 px-0">
                            <select value={currentFont} className="form-control p-2" style={{ fontFamily: currentFont }} onChange={(e) => this.signatureChange(signatureText, e.target.value)} name="currentFont">
                              {fontOptions.map((x, fkey) =>
                                <option value={x.value} key={fkey} className="font-12" style={{ fontFamily: `${x.value}` }}>Style</option>
                              )}
                            </select>
                          </div>
                        </div>
                        {signatureOutput && <div className="row mt-2 mb-3 align-items-center">
                          <div className="col-lg-2 col-md-2 col-xl-2 col-sm-12 px-0">
                            <label className="mt-4">Signature :</label>
                          </div>
                          <img src={signatureOutput} style={{ maxWidth: '340px', maxHeight: '60px' }} alt="signatureOutput" />
                        </div>}
                        <div className="text-center mb-2">
                          <input id="savedFuture" type="checkbox" checked={savedFuture} onChange={(e) => this.setState({ savedFuture: e.target.checked })} className="mr-2 mt-1" name="savedFuture" />
                          <label htmlFor="savedFuture">Save for future use</label>
                        </div>
                      </>}
                  </>}
              </>
            }
            {preTsheetsChecked && <>
              <p className="small_font text-center mb-2">
                <b>{personalDetails.userLastname}, {personalDetails.userFirstname} - Total Hours {toNumber(displayTotal)}</b>
              </p>
              <p className="xs_font text-center">
                I Certify that all the information in my timesheet is accurate and true.
              </p>
            </>}
          </Modal.Body>
          <Modal.Footer>
            <div className="col-12 row mt-2">
              <div className="col-6">
                <button
                  onClick={() => this.clearSignature()}
                  className="button resend-btn background-red px-4 float-left"
                >
                  No Cancel
                </button>
              </div>
              {preTsheetsChecked &&
                <div className="col-6">
                  <button
                    className="button resend-btn float-right px-4"
                    disabled={subLoading}
                    onClick={() => authenticate ? this.authenticateUser() : this.submitTimeSheet(submitWeekDate)}
                  >
                    {authenticate ? 'Authenticate' : subLoading ? 'Please Wait...' : 'Yes, Sign & Submit'}
                  </button>
                </div>}
            </div>
          </Modal.Footer>
        </Modal>

        {/** Modal to delete empty timesheets */}
        {deletePopup && <Modal
          scrollable={true}
          size="md"
          onHide={() => this.clearSignature()}
          show={deletePopup}
        >
          <Modal.Header closeButton className="h6 background-green1">
            <Modal.Title className="h6 text-white small_font">
              Delete Empty Timesheets
            </Modal.Title>
          </Modal.Header>
          <Modal.Body className="show-grid small_font px-5">
            <p className="small_font text-center mb-2">
              Please Select Timesheets to delete.
            </p>
            <ReactTable
              className="timesheets"
              columns={[{
                dataField: 'start',
                text: 'Start Date'
              }, {
                dataField: 'timesheetStatus',
                text: 'Status'
              }]}
              isSelection={true}
              onRowSelect={(rows) => this.setState({ selEmptyTimesheets: rows })}
              data={emptyTimesheets}
            />
          </Modal.Body>
          <Modal.Footer>
            <div className="col-12 row mt-2">
              <div className="col-6">
                <button
                  onClick={() => this.clearSignature()}
                  className="button resend-btn background-red px-4 float-left"
                >
                  No Cancel
                </button>
              </div>
              <div className="col-6">
                <button
                  className="button resend-btn float-right px-4"
                  disabled={selEmptyTimesheets.length === 0}
                  onClick={() => this.deleteTimesheets()}
                >
                  Yes, Confirm
                </button>
              </div>
            </div>
          </Modal.Footer>
        </Modal>}
      </div>
    )
  }
}

export default MyOwnTimesheet;