import React from 'react';
import { isEmpty, isEqual, uniqBy } from 'lodash';
import moment from 'moment';
import { MDBBtn } from 'mdbreact';
import DatePicker from "react-datepicker";
import "react-datepicker/dist/react-datepicker.css";
import { Modal, Row, Col, Popover, OverlayTrigger } from "react-bootstrap";
import { apiGet, apiPost } from '../Api.js';
import { toNumber, timesheet_status_codes, isSmallScreenFunction, employeeTypes, momentDate, fontOptions, momentWithFormat } from '../helpers/GeneralHelper';
import TimesheetChart from '../TimesheetChart';
import { getReuseSignInit, signImageUpload } from '../helpers/commonApi';
import { confirmAlert } from 'react-confirm-alert';
import ReactTable from './common/ReactTable.js';

const TimesheetOperation = {
  approve: 1,
  reject: 2
};

const DashboardButtonFunctionality = {
  archivable: 1,
  archived: 2
};

class LoadTimesheetsTable extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      timesheetLoading: false,
      displayMassEntryForm: false,
      displayMassEntryDate: '',
      displayUserApprovalForm: false,
      approveTimesheet: false,
      selectedStartWeekDate: '',
      selectedEndWeekDate: '',
      finalData: null,
      approvedcount: false,
      archivedcount: false,
      timesheetStatusCode: 300,
      displayas: 'Weekly',
      startweeklyDate: '',
      endweeklyDate: '',
      displayType: 1,
      defaultWeekType: 1,
      summaryDetails: {},
      rowresult: [],
      activeTimeSheetId: null,
      currentRecordingPeriod: false,
      employeeType: '',
      employeeTypeCode: '',
      activityId: '',
      selectedTimesheets: [],
      validTimesheets: [],
      activityDropdownOptions: [
        {
          actID: 0,
          name: 'All'
        }
      ],
      massEntryActivitiesDD: [],
      activityColumns: [],
      massEntryHour: '',
      massEntryComments: '',
      massEntryActivity: '',
      massEntryDate: '',
      massEntryFormSubmitBtn: false,
      uniqueActivityTableCols: [],
      selectedTimesheetOperation: null,
      isUserCommentRequired: false,
      userComments: '',
      displayWarningModal: false,
      selectedButtonFunctionality: null,
      isSmallScreen: false,

      savedFuture: true,
      savedSign: true,

      signatureOutput: '',
      signatureText: '',
      signatureFont: fontOptions[0].value,
      signType: 'type',
      currentSignId: "",
      signatureImage: '',

      initialOutput: '',
      initialText: '',
      initialFont: fontOptions[0].value,
      initialType: 'type',
      currentInitialId: '',
      initialImage: '',
    };
    this.onResize = this.onResize.bind(this);
  }


  componentWillUnmount() {
    window.removeEventListener('resize', this.onResize);
  }

  onResize() {
    this.setState({ isSmallScreen: isSmallScreenFunction() }, () => {
      if (this.state.finalData) {
        this.getTimesheetsData(this.state.finalData);
      }
    });
  }

  componentDidMount = async () => {
    this.setState({ timesheetLoading: true });
    await this.getOrganizationData();
    this.setCurrentDates();
    this.getActivitiesInOrganisation();
    window.addEventListener('resize', (e) => {
      this.onResize();
    });
  }

  reloadDataAgain = (loading = false) => {
    this.getSummary();
    this.getTimesheets(loading);
  }

  getOrganizationData = async (e) => {
    let requestDetails = {
      method: 'organizations/' + localStorage.orgid,
      params: { user_id: localStorage.userid }
    };
    await apiGet(requestDetails).then((res) => {
      if (res.data && res.status === 200) {
        this.setState({ displayType: res.data.biweeklyStart ? 2 : 1, defaultWeekType: res.data.biweeklyStart ? 2 : 1 });
      } else {
        const obj = JSON.parse(res.request.response);
        this.setState({ timesheetLoading: false });
        window.alert(obj.msg || 'Something Went Wrong');
        return;
      }
    }).catch(error => {
      console.log(error)
    });
  }

  setCurrentDates = () => {
    this.setState({ timesheetLoading: true });
    const getRequest = {
      method: `timesheets/submitted-period/${localStorage.orgid}`,
      params: {}
    };
    apiGet(getRequest).then((response) => {
      if (isEqual(response.status, 200) && response.data) {
        const start = response.data.startDate;
        const end = response.data.endDate;
        this.setState({
          selectedStartWeekDate: momentDate(start),
          selectedEndWeekDate: momentDate(end),
          startweeklyDate: moment(start).format('YYYY-MM-DD'),
          endweeklyDate: moment(end).format('YYYY-MM-DD')
        }, () => {
          this.reloadDataAgain(true);
        });
      } else { this.setState({ timesheetLoading: false }); }
    }).catch(error => {
      this.setState({
        timesheetLoading: false,
        selectedStartWeekDate: momentDate(),
        selectedEndWeekDate: momentDate(),
        startweeklyDate: moment().format('YYYY-MM-DD'),
        endweeklyDate: moment().format('YYYY-MM-DD')
      });
    });
  }

  getTimesheets = (loading = false) => {
    const { startweeklyDate, endweeklyDate, displayType } = this.state;
    this.setState({ timesheetLoading: loading });
    const requestDetails = {
      method: 'timesheets/management2',
      params: {
        from: startweeklyDate,
        to: endweeklyDate,
        approver_id: localStorage.userid,
        displayType,
        org_id: localStorage.orgid,
        status: this.state.timesheetStatusCode,
        employee_type: this.state.employeeTypeCode,
        activity_id: this.state.activityId
      }
    };
    apiGet(requestDetails).then((response) => {
      if (response.data && response.status === 200) {
        const result = response.data.timsheets || [];
        this.getTimesheetsData(result);
      } else {
        this.setState({
          rowresult: [],
          timesheetLoading: false,
          finalData: [],
          selectedTimesheets: [],
          validTimesheets: [],
          uniqueActivityTableCols: [],
        });
      }
    }).catch(error => {
      console.log(error);
    });
  }

  getTimesheetsData = (result) => {
    const { isSmallScreen, displayType } = this.state;
    const arr = [];
    const activityTableColumns = [];
    result.forEach((timesheet) => {
      const activityTypes = timesheet.activityTime;
      activityTypes && activityTypes.forEach((activity) => {
        activityTableColumns.push({
          timesheetId: timesheet.tid,
          id: activity.activityID,
          text: activity.activityName,
          headerFormatter: (col) => <div><span className="d-inline-flex align-items-center">{col.text} {activity.allowExtra === 1 && <i className="fa fa-clock-o text-danger ml-2" title="Extra Hour Allowance"></i>}</span><br />Hours</div>,
          dataField: `${activity.activityName}`.toLowerCase(),
          width: 150,
          allowExtra: activity.allowExtra,
          totalHours: activity.activityTotal
        })
      })
    });
    let uniqueActivityTableCols = [];
    !isEmpty(activityTableColumns) && activityTableColumns.forEach((col) => {
      const record = uniqueActivityTableCols.filter((uniqueCol) => uniqueCol.id === col.id)
      if (isEmpty(record)) {
        uniqueActivityTableCols.push(col);
      } else {
        if (uniqueActivityTableCols.length > 0) {
          uniqueActivityTableCols = uniqueActivityTableCols.map((x) => {
            if (x.id === col.id && col.allowExtra !== 0) {
              return col
            } else {
              return x;
            }
          })
        }
      }
    });
    const activityHours = (timesheetId) => {
      const rowValues = [];
      uniqueActivityTableCols.forEach((col) => {
        const record = activityTableColumns.find((x) => x.timesheetId === timesheetId && x.id === col.id);
        rowValues.push({
          [col.dataField]: isEmpty(record) ? '0.00' : toNumber(record.totalHours),
        })
      })
      return Object.assign({}, ...rowValues);
    }
    Array.isArray(result) && result.map((item) => {
      const totalHours = item.regularHours + item.overtimeHours;
      const extraHour = item.activityTime && item.activityTime.length > 0 && item.activityTime.find((x) => {
        const ttlHrs = x.activityTotal;
        return ttlHrs > 0 && x.allowExtra === 1
      });
      const startDt = item.startDate.map((x) => x ? momentWithFormat(x) : '').join(' - ');
      arr.push({
        ...item,
        start: (<span>
          {item.warnType !== 0 ?
            <OverlayTrigger rootClose trigger="click" placement="top" overlay={<Popover>
              <Popover.Title className={`${item.warnType === 10 ? 'bg-danger' : 'bg-orange'} text-white`}>
                <span>{item.warnType === 10 ? 'Extra Hour Allowance' : 'Extra Hours Warning'}</span>
                <i className="fa fa-close float-right" onClick={() => document.body.click()}></i>
              </Popover.Title>
              <Popover.Content>
                {item.warnMsg}
              </Popover.Content>
            </Popover>}>
              <i className={`mr-2 fa ${item.warnType === 10 ? 'fa-clock-o text-danger' : 'fa-exclamation-triangle text-warning'}`} />
            </OverlayTrigger>
            :
            <i className="mr-3" />}
          <a title={startDt}
            // href="javascript:void(0)"
            onClick={() => this.setState({ activeTimeSheetId: item.tid[0] || item.tid[1] })}
            className="text-decoration-underline blue-color p-0 cursor-pointer"
          >
            {isSmallScreen ? item.startDate.map((x) => x ? momentWithFormat(x, 'MM-DD') : '').join(' - ') : startDt}
          </a></span>),
        timesheetStatus: item.status,
        status: item.status.map((st) => st ? timesheet_status_codes[st] : 'None').join(' / '),
        last_name: item.userLastname,
        first_name: item.userFirstname,
        total: <div
          className={`${item.warnType === 10 ? 'bg-danger text-white' : ''} ${item.warnType === 20 ? 'bg-orange text-white' : ''}`}>
          {toNumber(totalHours)}
        </div>,
        overtime: <>
          {item.warnType === 10 && displayType === 2 ?
            <i className="fa fa-clock-o text-danger mr-2" onClick={() => this.setState({ activeTimeSheetId: item.tid[0] })} />
            : toNumber(item.overtimeHours)}
        </>,
        maxot: (item.warnType === 10 && displayType === 2) ?
          <i className="fa fa-clock-o text-danger mr-2" onClick={() => this.setState({ activeTimeSheetId: item.tid[0] })} /> :
          extraHour ? toNumber(extraHour.maxOT) : ('0.00'),
        regular: toNumber(item.regularHours),
        ...activityHours(item.tid)
      })
      return null;
    });
    this.setState({
      rowresult: arr,
      timesheetLoading: false,
      finalData: result,
      selectedTimesheets: [],
      validTimesheets: [],
      uniqueActivityTableCols,
    });
  }

  getSummary = (sunday = this.state.startweeklyDate, nextSunday = this.state.endweeklyDate) => {
    const requestDetails = {
      method: `timesheets/summary/${localStorage.orgid}`,
      params: {
        from: !isEmpty(sunday.toString()) ? moment(sunday).format('YYYY-MM-DD') : '',
        to: !isEmpty(nextSunday.toString()) ? moment(nextSunday).format('YYYY-MM-DD') : ''
      }
    };

    apiGet(requestDetails).then((response) => {
      this.setState({
        summaryDetails: response.data,
        selectedTimesheets: [],
        validTimesheets: [],
      });
    }).catch(error => {
      console.log(error);
    });
  }

  getActivitiesInOrganisation = () => {
    const request = {
      method: `activities/all/${localStorage.orgid}`,
      params: {}
    }
    apiGet(request).then((res) => {
      if (!isEmpty(res.data)) {
        const activityInfo = [];
        res.data.forEach((activity) => {
          activityInfo.push({
            actID: activity.actID,
            name: activity.name
          });
        })
        this.setState({
          activityDropdownOptions: [
            ...this.state.activityDropdownOptions,
            ...activityInfo
          ],
        })
      }
    }).catch(err => {
      console.log(err);
    })
  }


  filterByEmployeeType = (evt) => {
    const employeeType = evt.target.value;
    const status = employeeTypes.find((x) => x.name === employeeType);
    this.setState({
      employeeType,
      employeeTypeCode: isEqual(employeeType, 'all') ? '' : parseInt(status.code)
    }, () => {
      this.reloadDataAgain();
    });
  }

  filterByActivity = (evt) => {
    const activityCode = evt.target.value;
    this.setState({
      activityId: isEqual(activityCode, '0') ? '' : parseInt(activityCode)
    }, () => {
      this.reloadDataAgain();
    });
  }

  handleStartWeekChange = (date) => {
    this.setState({
      selectedStartWeekDate: date,
      startweeklyDate: moment(date).format('YYYY-MM-DD'),
      currentRecordingPeriod: false
    }, () => {
      this.reloadDataAgain();
    })
  }

  handleEndWeekChange = (date) => {
    this.setState({
      selectedEndWeekDate: date,
      endweeklyDate: moment(date).format('YYYY-MM-DD'),
      currentRecordingPeriod: false
    }, () => {
      this.reloadDataAgain();
    })
  }

  changeStatus = (evt) => {
    const timeSheetFilterStatus = evt.target.value;
    this.setState({
      timesheetStatusCode: timeSheetFilterStatus,
    }, () => {
      this.reloadDataAgain();
    });
  }

  isWeekday = (date) => {
    const day = date.getDay()
    return day === 0
  }

  ExampleCustomInput = ({ value, onClick }) => (
    <div className="inner-addon right-addon">
      <i className="fa fa-calendar" onClick={onClick}></i>
      <input onClick={onClick} value={value} onChange={() => { }} type="text" className="form-control" placeholder="Select Date" name="date" />
    </div>
  );

  signatureChange = (name, value, fontValue) => {
    this.setState({ [`${name}Text`]: value, [`${name}Font`]: fontValue });
    if (value && fontValue) {
      var tCtx = document.createElement('canvas').getContext('2d');
      tCtx.canvas.width = ((tCtx.measureText(value).width) * 3.5) + 20;
      tCtx.canvas.height = 55;
      tCtx.font = `40px ${fontValue}`;
      tCtx.fillText(value, 10, 40);
      this.setState({ [`${name}Output`]: tCtx.canvas.toDataURL() });
    } else {
      this.setState({ [`${name}Output`]: '' });
    }
  }

  getTimesheetIds = () => {
    const { selectedTimesheets } = this.state;
    let timesheetIds = [];
    selectedTimesheets.map((x) => timesheetIds = [...timesheetIds, ...x.tid]);
    return timesheetIds;
  }

  openUserApprovalForm = async () => {
    const { selectedTimesheetOperation } = this.state;
    const minDate = Math.min(...this.getDates());
    const maxDate = Math.max(...this.getDates());
    const sunday = moment(minDate).day(0).format('ddd MMM DD, YYYY');
    const nextSunday = moment(maxDate).day(6).format('ddd MMM DD, YYYY');
    const obj = {
      displayUserApprovalForm: true,
      displayMassEntryDate: `${sunday} - ${nextSunday}`
    }
    if (selectedTimesheetOperation === 1) {
      const signObj = await getReuseSignInit();
      const initialObj = await getReuseSignInit(true);
      this.setState({
        ...obj,
        currentSignId: signObj.imageId,
        signatureImage: signObj.signatureImage,
        currentInitialId: initialObj.imageId,
        initialImage: initialObj.signatureImage,
        savedSign: signObj.imageId && initialObj.imageId ? true : false
      });
    } else {
      this.setState({ ...obj })
    }
  }

  completeTimesheetOperation = async () => {
    const { currentSignId, currentInitialId, userComments, savedSign, signatureOutput, initialOutput, savedFuture,
      selectedTimesheetOperation } = this.state;
    let imgParams = {};
    let request = {
      method: selectedTimesheetOperation === 1 ? 'timesheets/bulkapprove' : 'timesheets/bulkdisapprove',
      params: {
        tidList: this.getTimesheetIds(),
        madeBy: localStorage.userid,
        reason: userComments,
      }
    };
    if (selectedTimesheetOperation === 1) {
      if (savedSign) {
        imgParams.initID = currentInitialId;
        imgParams.sigID = currentSignId;
      }
      if (!savedSign && signatureOutput && initialOutput) {
        imgParams.sigID = await signImageUpload(signatureOutput, savedFuture);
        imgParams.initID = await signImageUpload(initialOutput, savedFuture, 'user_initial');
      }
      if (imgParams.sigID && imgParams.initID) {
        request.params = { ...request.params, ...imgParams };
        this.approveReject(request);
      } else {
        window.alert('Please Type In Signature & Initial');
        return;
      }
    } else {
      this.approveReject(request);
    }
  }

  approveReject = async (request) => {
    const { selectedTimesheetOperation } = this.state;
    this.setState({ approveTimesheet: true });
    await apiPost(request).then((res) => {
      if (res && res.data && res.status === 200) {
        const message = `Timesheets successfully ${selectedTimesheetOperation === 1 ? 'approved' : 'rejected'}.`
        window.alert(message);
        this.reloadDataAgain(true);
        this.closePopups();
      } else {
        if (res.request && res.request.response && res.request.status !== 200) {
          const obj = JSON.parse(res.request.response);
          window.alert(obj.msg || 'Something Went Wrong');
          return;
        }
      }
    }).catch((err) => console.log(err));
  }

  closePopups = () => {
    this.setState({
      displayWarningModal: false, displayMassEntryForm: false, displayUserApprovalForm: false, selectedButtonFunctionality: null,
      selectedTimesheetOperation: null, isUserCommentRequired: false, userComments: '', displayMassEntryDate: '', massEntryActivity: '',
      massEntryActivitiesDD: [], massEntryComments: '', massEntryDate: '', massEntryHour: '', savedFuture: true, savedSign: true,
      approveTimesheet: false, signatureText: '', signatureFont: fontOptions[0].value, signatureImage: '', currentSignId: '', signatureOutput: '',
      signType: 'type', initialText: '', initialFont: fontOptions[0].value, currentInitialId: '', initialImage: '', initialOutput: '', initialType: 'type',
    })
  }

  getTimesheetStatusArr = () => {
    const { selectedTimesheets } = this.state;
    let timesheetStatusArr = [];
    selectedTimesheets.map((x) => timesheetStatusArr = [...timesheetStatusArr, ...x.timesheetStatus]);
    return timesheetStatusArr;
  }

  approveOrRejectTimesheets = (operation) => {
    const { displayUserApprovalForm } = this.state;
    const timesheetStatusArr = this.getTimesheetStatusArr();
    let validTimesheets = [];
    if (!displayUserApprovalForm) {
      if (!isEmpty(timesheetStatusArr)) {
        let isUserCommentRequired = false;
        switch (operation) {
          case 1:
            validTimesheets = timesheetStatusArr.filter((x) => x < 500 && x >= 100);
            isUserCommentRequired = timesheetStatusArr.some(x => x < 300 && x > 0) ? true : false;
            break;
          case 2:
            validTimesheets = timesheetStatusArr.filter((x) => x === 300 || x === 400);
            isUserCommentRequired = true;
            break;
          default:
            break;
        }
        this.setState({
          validTimesheets,
          isUserCommentRequired,
          selectedTimesheetOperation: operation,
        }, () => {
          return this.openUserApprovalForm()
        })
      }
    }
  }

  getDates = (selectedTimesheets = this.state.selectedTimesheets) => {
    let dts = [];
    selectedTimesheets.map(e => e.startDate.map((x) => dts.push(moment(x))));
    return dts;
  }

  openWarningModal = (buttonNumber) => {
    const minDate = Math.min(...this.getDates());
    const maxDate = Math.max(...this.getDates());
    const sunday = moment(minDate).day(0).format('ddd MMM DD, YYYY');
    const nextSunday = moment(maxDate).day(6).format('ddd MMM DD, YYYY');
    const timesheetStatusArr = this.getTimesheetStatusArr();
    this.setState({
      validTimesheets: timesheetStatusArr.filter((x) => buttonNumber === 1 ? x === 500 : x === 600),
      selectedButtonFunctionality: buttonNumber,
      displayMassEntryDate: `${sunday} - ${nextSunday}`,
      displayWarningModal: true,
    });
  }

  updateTimesheetStatusToArchivedOrArchivable = () => {
    const request = {
      method: this.state.selectedButtonFunctionality === DashboardButtonFunctionality.archivable
        ? 'timesheets/set-archivable' : 'timesheets/set-archived',
      params: {
        tidList: this.getTimesheetIds(),
        madeBy: localStorage.userid
      }
    }
    apiPost(request).then((res) => {
      const obj = JSON.parse(res.request.response);
      if (res.status === 200 && res.data) {
        window.alert(obj.msg);
        this.reloadDataAgain(true);
        this.closePopups();
      }
      if (res.request && res.request.response && res.request.status !== 200) {
        obj.msg ? window.alert(obj.msg) : window.alert('Something Went Wrong!');
        return;
      }
    }).catch((error) => {
      console.log(error);
    });
  }

  onSubmitMassTimeEntry = () => {
    const { massEntryHour, massEntryComments, massEntryDate, massEntryActivity } = this.state;
    const request = {
      method: 'timesheets/masshour',
      params: {
        tidList: this.getTimesheetIds(),
        activityID: parseInt(massEntryActivity),
        date: momentWithFormat(massEntryDate),
        hour: massEntryHour,
        reason: massEntryComments,
        madeBy: localStorage.userid
      }
    };
    apiPost(request).then((res) => {
      if (res.status === 200 && res.data) {
        this.reloadDataAgain(true);
        this.closePopups();
      }
      if (res.request && res.request.response && res.request.status !== 200) {
        let obj = JSON.parse(res.request.response);
        obj.msg ? window.alert(obj.msg) : window.alert('Something Went Wrong!');
        return;
      }
    }).catch((error) => {
      console.log(error);
    });
  }

  openMassEntryForm = () => {
    const { selectedTimesheets } = this.state;
    if (selectedTimesheets.length < 2) {
      window.alert('Please Select more then 1 timesheets with Same week for Mass Entry!');
      return;
    }
    let massTimeEntry = false;
    selectedTimesheets.map((x) => {
      if (JSON.stringify(x.startDate) === JSON.stringify(selectedTimesheets[0].startDate)) {
        massTimeEntry = true;
      } else {
        massTimeEntry = false;
      }
      return null;
    })
    if (massTimeEntry) {
      let massEntryActivitiesDD = [];
      selectedTimesheets.map((x) => {
        if (x.activityTime && x.activityTime.length > 0) {
          x.activityTime.map((activity) => {
            massEntryActivitiesDD.push({
              actID: activity.activityID,
              name: activity.activityName
            });
            return null;
          })
        }
        return null;
      })

      const lookup = massEntryActivitiesDD.reduce((a, e) => {
        a[e.actID] = ++a[e.actID] || 0;
        return a;
      }, {});
      massEntryActivitiesDD = uniqBy(massEntryActivitiesDD.filter(e => lookup[e.actID]), 'actID');
      const minDate = Math.min(...this.getDates());
      const maxDate = Math.max(...this.getDates());
      const sunday = moment(minDate).day(0).format('ddd MMM DD, YYYY');
      const nextSunday = moment(maxDate).day(6).format('ddd MMM DD, YYYY');
      this.setState({
        displayMassEntryForm: true,
        massEntryActivitiesDD,
        massEntryActivity: massEntryActivitiesDD.length > 0 ? massEntryActivitiesDD[0].actID : null,
        displayMassEntryDate: `${sunday} - ${nextSunday}`
      })
    } else {
      window.alert('Please Select Same week for Mass Entry!');
      return;
    }
  }

  changeType = (value) => {
    this.setState({ displayType: Number(value) }, () => this.getTimesheets(true))
  }

  setCurrentRecordingPeriod = (checkboxState) => {
    this.setState({ timesheetLoading: true });
    this.setState({ currentRecordingPeriod: !checkboxState });
    const getRequest = {
      method: `timesheets/cur-rec-period/${localStorage.orgid}`,
      params: {}
    };
    apiGet(getRequest).then((response) => {
      if (isEqual(response.status, 200) && response.data) {
        const start = response.data.startDate;
        const end = response.data.endDate;
        this.setState({
          selectedStartWeekDate: momentDate(start),
          selectedEndWeekDate: momentDate(end),
          startweeklyDate: moment(start).format('YYYY-MM-DD'),
          endweeklyDate: moment(end).format('YYYY-MM-DD')
        }, () => {
          this.reloadDataAgain(true);
        });
      } else { this.setState({ timesheetLoading: false }); }
    }).catch(error => {
      this.setState({
        timesheetLoading: false,
        selectedStartWeekDate: momentDate(),
        selectedEndWeekDate: momentDate(),
        startweeklyDate: moment().format('YYYY-MM-DD'),
        endweeklyDate: moment().format('YYYY-MM-DD')
      });
    });
  }

  openDeletePopup = () => {
    const timesheetStatusArr = this.getTimesheetStatusArr();
    const validTimesheets = timesheetStatusArr.filter((x) => x < 300 && x > 0);
    confirmAlert({
      customUI: ({ onClose }) => {
        return (
          <div className='custom-ui'>
            <p>You are about to delete {validTimesheets.length} timesheets, please confirm to continue.</p>
            <button onClick={onClose}>No, Cancel</button>
            <button onClick={async () => {
              await this.deleteEmpty();
              onClose();
            }}>Yes, Confirm</button>
          </div>
        );
      }
    })
  }

  deleteEmpty = async () => {
    const requestDetails = {
      method: 'timesheets/delete-empty',
      params: {
        tidList: this.getTimesheetIds(),
        madeBy: localStorage.userid,
      }
    };
    await apiPost(requestDetails).then((res) => {
      const obj = JSON.parse(res.request.response);
      if (res && res.status === 200) {
        window.alert(obj.msg);
        this.reloadDataAgain(true);
      } else {
        window.alert(obj.msg);
        return null;
      }
    }).catch(error => {
      console.log(error)
    });
  }

  render() {
    const { timesheetLoading, defaultWeekType, uniqueActivityTableCols, rowresult, selectedButtonFunctionality, currentRecordingPeriod, displayType, selectedStartWeekDate, selectedEndWeekDate, startweeklyDate,
      endweeklyDate, timesheetStatusCode, activityDropdownOptions, summaryDetails, selectedTimesheets, validTimesheets, displayMassEntryForm,
      displayMassEntryDate, massEntryDate, massEntryActivity, massEntryActivitiesDD, massEntryHour, massEntryComments, displayUserApprovalForm, selectedTimesheetOperation, displayWarningModal,
      userComments, isUserCommentRequired, activeTimeSheetId, savedSign, savedFuture, signatureImage, approveTimesheet,
      signType, signatureFont, signatureOutput, signatureText, initialType, initialFont, initialOutput, initialText, initialImage,
    } = this.state;
    if (activeTimeSheetId) {
      return <TimesheetChart
        id={activeTimeSheetId}
        onBackClick={() => {
          this.getTimesheets()
          this.setState({ activeTimeSheetId: null })
        }}
      />
    }
    const defaultColumns = [
      {
        text: displayType === 1 ? 'Weekly' : 'BiWeekly',
        dataField: 'start',
      },
      {
        text: 'Status',
        dataField: 'status',
      },
      {
        text: 'Last Name',
        dataField: 'last_name',
      },
      {
        text: 'First Name',
        dataField: 'first_name',
      },
      {
        text: 'Ttl Hrs',
        dataField: 'total',
      },
      {
        text: 'Overtime',
        dataField: 'overtime',
        headerFormatter: (col) => (<span>{col.text}<br /> Hours</span>),
      },
      {
        text: 'Max OT',
        headerFormatter: (col) => (<span>{col.text}<br /> Allowed</span>),
        dataField: 'maxot',
      },
      {
        text: 'Regular Hours',
        dataField: 'regular',
      },
    ];

    return (
      <React.Fragment>
        <div className="p-3 mb-3 small_font bg-amber border-0">
          <Row>
            <Col lg="4" md="4" sm="12">
              <label className="pr-2 float-left">Date Range : </label>
              <input
                style={{ float: 'left', width: '25px', marginTop: '3px' }}
                type="checkbox"
                id="currentRecord"
                name="current-recording"
                className="form-control"
                onChange={() => this.setCurrentRecordingPeriod(currentRecordingPeriod)}
                checked={currentRecordingPeriod}
              />
              <label
                htmlFor="currentRecord"
                style={{ fontSize: '9pt' }}
              >
                Current Recording Period
              </label>
              <Row>
                <Col lg="6" md="6" sm="6">
                  <label className="pr-2">Start Week</label>
                  <DatePicker
                    selected={selectedStartWeekDate}
                    value={startweeklyDate}
                    showMonthDropdown
                    showYearDropdown
                    dropdownMode="select"
                    name="startDate"
                    className="form-control"
                    customInput={<this.ExampleCustomInput />}
                    filterDate={this.isWeekday}
                    onChange={this.handleStartWeekChange}
                    dateFormat="yyyy-MM-dd"
                    placeholderText="yyyy-MM-dd"
                  />
                </Col>
                <Col lg="6" md="6" sm="6">
                  <label className="pr-2">End Week</label>
                  <DatePicker
                    selected={selectedEndWeekDate}
                    value={endweeklyDate}
                    showMonthDropdown
                    showYearDropdown
                    dropdownMode="select"
                    name="startDate"
                    className="form-control"
                    customInput={<this.ExampleCustomInput />}
                    filterDate={this.isWeekday}
                    onChange={this.handleEndWeekChange}
                    dateFormat="yyyy-MM-dd"
                    placeholder="yyyy-MM-dd"
                  />
                </Col>
              </Row>
            </Col>
            <Col lg="2" md="2" sm="12" className="mb-0 mt-auto">
              <label>Timesheet Status</label>
              <select onChange={this.changeStatus} value={timesheetStatusCode} placeholder="Select" className="form-control dropdown-height" name="state">
                <option value="">All</option>
                <option value="50" >Empty</option>
                <option value="100" >Active</option>
                <option value="200">Inactive</option>
                <option value="300">Submitted</option>
                <option value="400">Approvable</option>
                <option value="500">Approved</option>
                <option value="600">Archivable</option>
                <option value="700" >Archived</option>
              </select>
            </Col>
            <Col lg="2" md="2" sm="12" className="mb-0 mt-auto">
              <label>Activity</label>
              <select onChange={this.filterByActivity} value={this.state.activityId} placeholder="Select" className="form-control dropdown-height" name="state" >
                {activityDropdownOptions.map(activity => <option key={activity.actID} value={activity.actID}>{activity.name}</option>)}
              </select>
            </Col>
            <Col lg="2" md="2" sm="12" className="mb-0 mt-auto">
              <label>Employee Type</label>
              <select onChange={this.filterByEmployeeType} value={this.state.employeeType} placeholder="Select" className="form-control dropdown-height" name="state">
                <option value="all">All</option>
                <option value="Salaried">Salaried</option>
                <option value="Full-Time Hourly">Full Time Hourly</option>
                <option value="Part-Time Hourly">PT Hourly</option>
                <option value="Temporary">Temporary</option>
                <option value="SubContractor">SUB</option>
                <option value="Intern">Intern</option>
              </select>
            </Col>
          </Row>
        </div>
        <p className="small_font mb-2 mt-2 ">Summary on Number of Timesheets in this Period :
          <label className="label label-info"> Empty : {summaryDetails.numOfEmpty || 0}</label>
          <label className="label label-info"> Active : {summaryDetails.numOfActive || 0}</label>
          <label className="label label-danger"> Inactive : {summaryDetails.numOfInactive || 0}</label>
          <label className="label label-success2"> Submitted : {summaryDetails.numOfSubmitted || 0}</label>
          <label className="label label-warning"> Approvable : {summaryDetails.numOfApprovable || 0}</label>
          <label className="label label-success1"> Approved : {summaryDetails.numOfApproved || 0}</label>
          <label className="label label-primary"> Archivable : {summaryDetails.numOfArchivable || 0}</label>
          <label className="label label-default"> Archived : {summaryDetails.numOfArchived || 0}</label>
        </p>
        <div className="row px-0 ml-0 mb-3">
          <div className="col-lg-5 col-md-5 col-xl-5 col-sm-12 pl-0">
            <MDBBtn
              disabled={(selectedTimesheets.length > 0 && selectedTimesheets.every((e) => e.timesheetStatus.some(x => x < 500 && x >= 100))) ? false : true}
              onClick={() => this.approveOrRejectTimesheets(TimesheetOperation.approve)}
              color="success"
              data-toggle="tooltip"
              title="Approve"
            >
              <i className="fa fa-thumbs-up text-white"></i>
            </MDBBtn>
            <MDBBtn
              disabled={(selectedTimesheets.length > 0 && selectedTimesheets.every((e) => e.timesheetStatus.some(x => x === 300 || x === 400))) ? false : true}
              onClick={() => this.approveOrRejectTimesheets(TimesheetOperation.reject)}
              className="ml-2"
              color="danger"
              data-toggle="tooltip"
              title="Reject"
            >
              <i className="fa fa-thumbs-down text-white"></i>
            </MDBBtn>
            {selectedTimesheets.length > 0 && selectedTimesheets.every((e) => e.timesheetStatus.some(x => x < 300 && x > 0)) ?
              <MDBBtn
                onClick={() => this.openDeletePopup()}
                color="danger"
                className="ml-2"
              >
                Delete
              </MDBBtn>
              : null}
            {selectedTimesheets.length > 0 && selectedTimesheets.every((e) => e.timesheetStatus.includes(500)) ?
              <MDBBtn
                onClick={() => this.openWarningModal(DashboardButtonFunctionality.archivable)}
                color="success"
                className="ml-2"
              >
                Set to Archivable
              </MDBBtn>
              : null}
            {selectedTimesheets.length > 0 && selectedTimesheets.every((e) => e.timesheetStatus.includes(600)) ?
              <MDBBtn
                onClick={() => this.openWarningModal(DashboardButtonFunctionality.archived)}
                color="success"
                className="ml-2"
              >
                Set to Archived
              </MDBBtn>
              : null}
          </div>
          <div className="col-md-7 col-sm-12">
            <div className="float-right d-inline-flex align-items-center">
              {defaultWeekType === 2 ? <>
                <span className="mr-2">
                  <input type="radio" id="weekly" checked={displayType === 1} value={1} className="mr-2 align-middle" onChange={(e) => this.changeType(e.target.value)} name="displayType" />
                  <label htmlFor="weekly">Display Weekly</label>
                </span>
                <span className="mr-2">
                  <input type="radio" id="biweekly" checked={displayType === 2} value={2} className="mr-2 align-middle" onChange={(e) => this.changeType(e.target.value)} name="displayType" />
                  <label htmlFor="biweekly">Display BiWeekly</label>
                </span>
              </> : null}
              <button
                onClick={() => this.openMassEntryForm()}
                className="button resend-btn px-3 m-0 float-right ml-2"
                disabled={isEmpty(selectedTimesheets)}
              >
                Mass Time Entry
                <i className="fa fa-book pl-2"></i>
              </button>
            </div>
          </div>
        </div>
        {timesheetLoading ? 'Please Wait...' :
          <Row className="mr-0">
            <Col xs={uniqueActivityTableCols.length > 0 ? 9 : 12} className="pr-0">
              <ReactTable
                striped={true}
                className="timesheets"
                columns={defaultColumns}
                isSelection={true}
                onRowSelect={(rows) => this.setState({ selectedTimesheets: rows })}
                data={rowresult}
              />
            </Col>
            {uniqueActivityTableCols.length > 0 && <Col xs={3} className="px-0 overflow-auto">
              <ReactTable
                className="activitytable timesheets"
                striped={true}
                columns={uniqueActivityTableCols}
                data={rowresult}
              />
            </Col>}
          </Row>
        }
        {/** Modal to perform mass entry form operation */}
        {displayMassEntryForm && <Modal
          scrollable={true}
          size="md"
          onHide={() => this.closePopups()}
          show={displayMassEntryForm}
        >
          <Modal.Header closeButton className="h6 background-blue1">
            <Modal.Title className="h6 text-white" >
              Mass Time Entry
            </Modal.Title>
          </Modal.Header>
          <Modal.Body className="show-grid small_font px-5">
            <p className="xs_font text-dark text-center">
              {`Add hours for the ${this.getTimesheetIds().length} selected timesheets for the week of:`}
            </p>
            <p className="small_font font-weight-bold text-center">
              {displayMassEntryDate}
            </p>
            <div className="form-group row">
              <div className="col-lg-6 col-md-6 col-xl-6 col-sm-12">
                <label>Date:</label>
                <DatePicker
                  selected={massEntryDate ? momentDate(massEntryDate) : null}
                  value={massEntryDate}
                  name="massEntryDate"
                  className="form-control"
                  showMonthDropdown
                  showYearDropdown
                  dropdownMode="select"
                  minDate={momentDate(displayMassEntryDate.split('-')[0])}
                  maxDate={momentDate(displayMassEntryDate.split('-')[1])}
                  customInput={<this.ExampleCustomInput />}
                  onChange={(date) => this.setState({ massEntryDate: date })}
                  dateFormat="yyyy-MM-dd"
                  placeholderText="yyyy-MM-dd"
                />
                {!massEntryDate && (<p style={{ color: 'red' }}>This is required</p>)}
              </div>
              <div className="col-lg-6 col-md-6 col-xl-6 col-sm-12">
                <label>Activity Name:</label>
                <select onChange={(evt) => this.setState({ massEntryActivity: evt.target.value })} defaultValue={massEntryActivity} placeholder="Select" className="form-control" name="state">
                  {massEntryActivitiesDD.map(activity => <option key={activity.actID} value={activity.actID}>{activity.name}</option>)}
                </select>
                {!massEntryActivity && (<p style={{ color: 'red' }}>This is required</p>)}
              </div>
            </div>
            <div className="form-group row">
              <div className="col-lg-6 col-md-6 col-xl-6 col-sm-12">
                <label>Hour:</label>
                <input
                  type="text"
                  className="form-control"
                  placeholder=""
                  value={massEntryHour}
                  onChange={(evt) => this.setState({ massEntryHour: evt.target.value })}
                />
                {!massEntryHour && (<p style={{ color: 'red' }}>This is required</p>)}
              </div>
              <div className="col-lg-6 col-md-6 col-xl-6 col-sm-12">
                <label>Comments*:</label>
                <textarea
                  onChange={(evt) => this.setState({ massEntryComments: evt.target.value })}
                  type="text"
                  className="form-control"
                  placeholder="Enter Activity Description"
                  value={massEntryComments}
                />
                {!massEntryComments && (<p style={{ color: 'red' }}>This is required</p>)}
              </div>
            </div>
          </Modal.Body>
          <Modal.Footer>
            <div className="col-12 row mt-2">
              <p className="small_font text-dark text-center mx-auto mb-2">Are you sure you would like to continue with this mass time entry?</p>
              <div className="col-6">
                <button
                  onClick={() => this.closePopups()}
                  className="button resend-btn background-red px-4 float-left"
                >
                  No, Cancel
                </button>
              </div>
              <div className="col-6">
                <button
                  disabled={!massEntryComments || !massEntryDate || !massEntryHour || !massEntryActivity}
                  className="button resend-btn float-right px-4"
                  onClick={() => this.onSubmitMassTimeEntry()}
                >
                  Yes, Continue
                </button>
              </div>
            </div>
          </Modal.Footer>
        </Modal>
        }
        {/** Modal for user approval to approve or reject a timesheet */}
        <Modal
          scrollable={true}
          size="md"
          onHide={this.closePopups}
          show={displayUserApprovalForm}
        >
          <Modal.Header closeButton className="h6 background-green1">
            <Modal.Title className="h6 text-white small_font" >
              Timesheet {TimesheetOperation.approve === selectedTimesheetOperation ? 'Approval' : 'Rejection'} Confirmation
            </Modal.Title>
          </Modal.Header>
          <Modal.Body className="show-grid small_font px-5">
            <p className="xs_font text-dark text-center mb-0">
              {`You are about to ${TimesheetOperation.approve === selectedTimesheetOperation ? 'approve' : 'reject'} ${validTimesheets.length} timesheets for the period of`}
            </p>
            <p className="small_font font-weight-bold text-center">
              {displayMassEntryDate}
            </p>
            {isUserCommentRequired &&
              <>
                {TimesheetOperation.approve === selectedTimesheetOperation ? <p className="text-center mb-1">
                  Some selected timesheet(s) have not been submitted, <br /> please provide comment:
                </p> : null}
                <div className="form-group row">
                  <div className="col-lg-3 col-md-3 col-xl-3 col-sm-3 text-right">
                    <label>Comment :</label>
                  </div>
                  <div className="col-lg-9 col-md-9 col-xl-9 col-sm-9">
                    <textarea className="form-control" value={userComments} onChange={(evt) => this.setState({ userComments: evt.target.value })}></textarea>
                    {isEmpty(userComments) && (<p className="mb-0" style={{ color: 'red' }}>This is required</p>)}
                  </div>
                </div>
              </>}
            {TimesheetOperation.approve === selectedTimesheetOperation &&
              <>
                {(signatureImage && initialImage) ?
                  <div className="text-center mt-2">
                    <input type="checkbox" id="savedSign" checked={savedSign} onChange={(e) => this.setState({ savedSign: e.target.checked })} className="mr-2" name="savedSign" />
                    <label className="mb-0" htmlFor="savedSign">Use the saved signature & Initial</label>
                  </div> : null}
                {(savedSign) ?
                  <div className="text-center">
                    {signatureImage && <img src={signatureImage} alt="signatureImage" className="mb-1" />}
                    {initialImage && <img src={initialImage} alt="initialImage" className="mb-1 ml-2" />}
                  </div> :
                  <>
                    <div className="border-bottom">
                      <h6 className="text-center mb-0 mt-2">Create Signature</h6>
                      <div className="row mt-2">
                        <div className="col-xl-2 col-lg-2 col-md-2 col-sm-12">
                        </div>
                        <div className="col-xl-3 col-lg-3 col-md-3 col-sm-12 pl-0">
                          <input type="radio" value="type" checked={signType === 'type'} onChange={() => this.setState({ signType: 'type' })} className="mr-2 align-middle" name="signType" />
                          <label>Type</label>
                        </div>
                        <div className="col-xl-3 col-lg-3 col-md-3 col-sm-12 pl-0">
                          <input type="radio" value="drawing" checked={signType === 'drawing'} disabled onChange={() => this.setState({ signType: 'drawing' })} className="mr-2 align-middle" name="signType" />
                          <label>Drawing</label>
                        </div>
                        <div className="col-xl-4 col-lg-4 col-md-4 col-sm-12">
                          <input type="radio" value="image" checked={signType === 'image'} disabled onChange={() => this.setState({ signType: 'image' })} className="mr-2 align-middle" name="signType" />
                          <label>Image</label>
                        </div>
                      </div>
                      {signType === 'type' &&
                        <>
                          <div className="row mt-2 mb-2">
                            <div className="col-lg-2 col-md-2 col-xl-2 col-sm-12 px-0">
                              <label className="mt-2">Type :</label>
                            </div>
                            <div className="col-lg-7 col-md-7 col-xl-7 col-sm-12 pl-0">
                              <input type="text" id="signatureText" style={{ fontFamily: signatureFont, fontSize: signatureText && '3em !important' }} className="form-control" placeholder="Please type here for signature..." value={signatureText} onChange={(evt) => this.signatureChange('signature', evt.target.value, signatureFont)} />
                            </div>
                            <div className="col-xl-3 col-lg-3 col-md-3 col-sm-12 px-0">
                              <select value={signatureFont} className="form-control p-2" style={{ fontFamily: signatureFont }} onChange={(e) => this.signatureChange('signature', signatureText, e.target.value)} name="signatureFont">
                                {fontOptions.map((x, fkey) =>
                                  <option value={x.value} key={fkey} className="font-12" style={{ fontFamily: `${x.value}` }}>Style</option>
                                )}
                              </select>
                            </div>
                          </div>
                          {signatureOutput && <div className="row mt-2 align-items-center">
                            <div className="col-lg-2 col-md-2 col-xl-2 col-sm-12 px-0">
                              <label>Signature :</label>
                            </div>
                            <img src={signatureOutput} style={{ maxWidth: '340px', maxHeight: '60px' }} alt="signatureOutput" />
                          </div>}
                        </>}
                    </div>
                    <div>
                      <h6 className="text-center mb-0 mt-2">Create Initial</h6>
                      <div className="row mt-2">
                        <div className="col-xl-2 col-lg-2 col-md-2 col-sm-12">
                        </div>
                        <div className="col-xl-3 col-lg-3 col-md-3 col-sm-12 pl-0">
                          <input type="radio" value="type" checked={initialType === 'type'} onChange={() => this.setState({ initialType: 'type' })} className="mr-2 align-middle" name="initialType" />
                          <label>Type</label>
                        </div>
                        <div className="col-xl-3 col-lg-3 col-md-3 col-sm-12 pl-0">
                          <input type="radio" value="drawing" checked={initialType === 'drawing'} disabled onChange={() => this.setState({ initialType: 'drawing' })} className="mr-2 align-middle" name="initialType" />
                          <label>Drawing</label>
                        </div>
                        <div className="col-xl-4 col-lg-4 col-md-4 col-sm-12">
                          <input type="radio" value="image" checked={initialType === 'image'} disabled onChange={() => this.setState({ initialType: 'image' })} className="mr-2 align-middle" name="initialType" />
                          <label>Image</label>
                        </div>
                      </div>
                      {initialType === 'type' &&
                        <>
                          <div className="row mt-2 mb-2">
                            <div className="col-lg-2 col-md-2 col-xl-2 col-sm-12 px-0">
                              <label className="mt-2">Type :</label>
                            </div>
                            <div className="col-lg-7 col-md-7 col-xl-7 col-sm-12 pl-0">
                              <input type="text" id="initialText" style={{ fontFamily: initialFont, fontSize: initialText && '3em !important' }} className="form-control" placeholder="Please type here for signature..." value={initialText} onChange={(evt) => this.signatureChange('initial', evt.target.value, initialFont)} />
                            </div>
                            <div className="col-xl-3 col-lg-3 col-md-3 col-sm-12 px-0">
                              <select value={initialFont} className="form-control p-2" style={{ fontFamily: initialFont }} onChange={(e) => this.signatureChange('initial', initialText, e.target.value)} name="initialFont">
                                {fontOptions.map((x, fkey) =>
                                  <option value={x.value} key={fkey} className="font-12" style={{ fontFamily: `${x.value}` }}>Style</option>
                                )}
                              </select>
                            </div>
                          </div>
                          {initialOutput && <div className="row align-items-center">
                            <div className="col-lg-2 col-md-2 col-xl-2 col-sm-12 px-0">
                              <label>Signature :</label>
                            </div>
                            <img src={initialOutput} style={{ maxWidth: '340px', maxHeight: '60px' }} alt="initialOutput" />
                          </div>}
                        </>}
                    </div>
                    <div className="text-center mb-2">
                      <input type="checkbox" id="savedFuture" checked={savedFuture} onChange={(e) => this.setState({ savedFuture: e.target.checked })} className="mr-2 mt-1" name="savedFuture" />
                      <label htmlFor="savedFuture" className="mb-0">Save Signature & Inital for future use</label>
                    </div>
                  </>
                }
              </>
            }
          </Modal.Body>
          <Modal.Footer>
            <div className="col-12 row mt-2">
              <div className="col-6">
                <button
                  onClick={this.closePopups}
                  className="button resend-btn background-red px-4 float-left"
                >
                  No, Cancel
                </button>
              </div>
              <div className="col-6">
                <button
                  disabled={(isUserCommentRequired && isEmpty(userComments)) || approveTimesheet}
                  onClick={this.completeTimesheetOperation}
                  className="button resend-btn float-right px-4"
                >
                  Yes, Confirm
                </button>
              </div>
            </div>
          </Modal.Footer>
        </Modal>
        {/** Modal for archivable and archived feature */}
        <Modal
          scrollable={true}
          size="md"
          onHide={this.closePopups}
          show={displayWarningModal}
        >
          <Modal.Header closeButton className="h6 background-green1">
            <Modal.Title className="h6 text-white small_font" >
              Set to {selectedButtonFunctionality === DashboardButtonFunctionality.archivable ? 'Archivable' : 'Archived'} Confirmation
            </Modal.Title>
          </Modal.Header>
          <Modal.Body className="show-grid small_font px-5">
            <p className="small_font text-dark text-center">
              You are setting {validTimesheets.length} timesheets to {selectedButtonFunctionality === DashboardButtonFunctionality.archivable ? 'Archivable' : 'Archived'}, please confirm to continue.
            </p>
          </Modal.Body>
          <Modal.Footer>
            <div className="col-12 row mt-2">
              <div className="col-6">
                <button
                  onClick={this.closePopups}
                  className="button resend-btn background-red px-4 float-left"
                >
                  No, Cancel
                </button>
              </div>
              <div className="col-6">
                <button
                  onClick={this.updateTimesheetStatusToArchivedOrArchivable}
                  className="button resend-btn float-right px-4"
                >
                  Yes, Confirm
                </button>
              </div>
            </div>
          </Modal.Footer>
        </Modal>
      </React.Fragment>
    )
  }
}

export default LoadTimesheetsTable;