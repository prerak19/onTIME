import React from 'react';
import Logo from './components/assets/img/login-logo.png';
import 'bootstrap/dist/css/bootstrap.min.css';
import './components/assets/css/login.css';
import 'font-awesome/css/font-awesome.css';
import { apiPost } from './Api.js';
import { withRouter } from "react-router";

class ResetPassword extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      userid: (this.props.location.state) ? this.props.location.state.id : '',
      userdetails: '',
      fields: {},
      errors: {},
      error_message: '',
      success_message: ''
    };
  };
  onSubmit = (e) => {
    this.props.history.push("/Login");
  }
  handleChange = (e) => {
    let fields = this.state.fields;
    let errors = this.state.errors;
    fields[e.target.name] = e.target.value;
    if (!e.target.value) {
      errors[e.target.name] = 'form-control is-invalid';
    } else {
      errors[e.target.name] = 'form-control is-valid';
    }
    this.setState({ fields, errors });
  }
  validateForm() {
    let fields = this.state.fields;
    let errors = {};
    let formIsValid = true;
    if (!fields["password"]) {
      formIsValid = false;
      errors["password"] = "form-control is-invalid";
    }
    if (!fields["cpassword"]) {
      formIsValid = false;
      errors["cpassword"] = "form-control is-invalid";
    }
    if (fields["cpassword"] !== fields["password"]) {
      formIsValid = false;
      errors["cpassword"] = "form-control is-invalid";
      errors["password"] = "form-control is-invalid";
      this.setState({ error_message: 'Password & Confirm Password should be similar!' })
    } else {
      if (!formIsValid) {
        this.setState({ error_message: 'Please Enter Required Fields!' });
      } else {
        this.setState({ error_message: '' });
      }
    }
    this.setState({ errors: errors });
    return formIsValid;
  }
  resendEmail = (e) => {
    e.preventDefault();
    const tokenUrl = this.props.location ? this.props.location.search : '';
    if (this.validateForm() && tokenUrl) {
      let requestDetails = {
        method: 'employees/forgot-password-reset',
        params: {
          userName: tokenUrl.split('?token=')[1],
          newPassword: this.state.fields.password,
        }
      };
      apiPost(requestDetails).then((res) => {
        if (res && res.status === 200) {
          this.setState({ success_message: 'Password Reset Successfully!' });
          window.alert('Password Reset Successfully.');
          this.props.history.push({ pathname: "/login" });
        }
        if (res.request && res.request.response && res.request.status !== 200) {
          const obj = JSON.parse(res.request.response);
          this.setState({ error_message: obj.msg || 'Something Went Wrong!' })
          return;
        }
      }).catch((error) => {
        this.setState({ error_message: error.response.data.msg })
        window.scroll({ top: 0, left: 0, behavior: 'smooth' })
      });
    } else {
    }
  }
  render() {
    return (
      <div className="background min-h-100">
        <div className="container">
          <div className="row h-100 justify-content-center align-items-center m-0">
            <div className="col-12 forgot-margin">
              <div className="login-form text-center col-lg-4 col-md-5 col-sm-9">
                <img src={Logo} width="86%" alt="Logo" />
                <img alt="Banner" width="15%" src={require("./components/assets/img/time-icon.png").default} />
                <p className="font-weight-bold font-11 mb-2">Reset Password</p>
                <p className="text-danger small_font">{this.state.error_message}</p>
                <p className="text-success small_font">{this.state.success_message}</p>
                <form>
                  <div className="input-group my-3">
                    <div className="input-group-prepend">
                      <span className="input-group-text"><i className="fa fa-envelope" aria-hidden="true"></i></span>
                    </div>
                    <input type="password" name='password' value={this.state.fields.password} onChange={this.handleChange} className={(this.state.errors["password"] ? this.state.errors["password"] : 'form-control')} placeholder="Password" />
                  </div>
                  <div className="input-group my-3">
                    <div className="input-group-prepend">
                      <span className="input-group-text"><i className="fa fa-envelope" aria-hidden="true"></i></span>
                    </div>
                    <input type="password" name='cpassword' value={this.state.fields.cpassword} onChange={this.handleChange} className={(this.state.errors["cpassword"] ? this.state.errors["cpassword"] : 'form-control')} placeholder="Confirm Password" />
                  </div>
                  <input type="button" onClick={this.resendEmail} className="button w-100 py-2 mb-3" value="Change Password" />
                </form>
              </div>
            </div>
          </div>
        </div></div>
    );
  }
}

export default withRouter(ResetPassword);
