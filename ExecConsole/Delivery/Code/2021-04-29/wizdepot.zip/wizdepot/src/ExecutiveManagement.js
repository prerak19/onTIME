import React from 'react';

class ExecutiveManagement extends React.Component {
  render() {
    return (
      <h1>ExecutiveManagement</h1>
    );
  }
}

export default ExecutiveManagement;
