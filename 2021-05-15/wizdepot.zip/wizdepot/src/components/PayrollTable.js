import React from 'react';
import "react-datepicker/dist/react-datepicker.css";
import '../App.css';
import { Modal } from "react-bootstrap";
import { find, groupBy } from 'lodash';
import { activity_types, toNumber } from '../helpers/GeneralHelper';
import moment from 'moment';

class PayrollTable extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      show: false,
      editshow: false,
      startDate: '',
      startDate1: '',
      startDate2: '',
      timedisabled: true,
      startdisabled: true,
      enddisabled: true,
      isChecked: false,
      holidaypolicy: true,
      rounding: false,
    };
  }
  handleChange = (date) => {
    this.setState({
      startDate: date
    })
  }
  handleChange1 = (date) => {
    this.setState({
      startDate1: date
    })
  }
  handleChange2 = (date) => {
    this.setState({
      startDate2: date
    })
  }
  toggleChange = (e) => {
    if (e.target.checked === true) {
      this.setState({
        timedisabled: false,
        startdisabled: false,
        enddisabled: false,
      });
    } else {
      this.setState({
        timedisabled: true,
        startdisabled: true,
        enddisabled: true,
      });
    }
  }
  toggleChangePolicy = (e) => {
    console.log(e.target.value);
    if (e.target.value === 'Holiday') {
      this.setState({
        holidaypolicy: false,
        rounding: true,
      });
    } else {
      this.setState({
        holidaypolicy: true,
        rounding: false,
      });
    }
  }
  isWeekday = (date) => {
    const day = date.getDay()
    return day === 0
  }
  ExampleCustomInput = ({ value, onClick }) => (
    <button disabled={this.state.startdisabled} className="example-custom-input form-control" style={{
      minWidth: '100px', minHeight: '32px'
    }} onClick={onClick}>
      {value}
    </button>
  );
  isWeekday1 = (date) => {
    const day = date.getDay()
    return day === 6
  }
  ExampleCustomInput1 = ({ value, onClick }) => (
    <button disabled={this.state.enddisabled} className="example-custom-input form-control" style={{
      minWidth: '100px', minHeight: '32px'
    }} onClick={onClick}>
      {value}
    </button>
  );
  ExampleCustomInput2 = ({ value, onClick }) => (
    <button disabled={this.state.timedisabled} className="example-custom-input form-control" style={{
      minWidth: '100px', minHeight: '32px'
    }} onClick={onClick}>
      {value}
    </button>
  );

  render() {
    const { dutyCodeArr, payRollArr, withourDutyCodeArr, finalTotalPayRoll, startDate, endDate } = this.props;
    const { finalRegHoursTtl, allDutyTotal, dutyWiseTotal, allActTotal } = finalTotalPayRoll;
    return (
      <div className="mt-5">
        <h6 className="text-center">Report Preview</h6>
        <button onClick={() => this.setState({ showreport: true })} class="button resend-btn float-right mb-3">Save As Excel</button>
        <button onClick={() => this.setState({ showreport: true })} class="button resend-btn ml-2 float-right mb-3">Save As PDF</button>
        <div className="payrollform">
          <div className="col-12 mb-3 text-center">
            <h6>PAYROLL SUMMARY REPORT</h6>
          </div>
          <table border='1' className="text-center text-black w-100">
            <thead>
              <tr>
                <th rowSpan='2'></th>
                <th colSpan='2' rowSpan='2'>NAME</th>
                <th rowSpan='3'>FINAL REG HOURS</th>
                <th rowSpan='3'>EVENT ATTENTION</th>
                <th rowSpan='3'>HOURS ADJUST</th>
                <th colSpan={dutyCodeArr.length + withourDutyCodeArr.length + 2}>FROM {moment(startDate).format('MM/DD/YYYY')} TO {moment(endDate).format('MM/DD/YYYY')}</th>
              </tr>
              <tr>
                <th rowSpan='2'>TOTAL</th>
                <th rowSpan='2'>TOTAL REG LABOR</th>
                {payRollArr && payRollArr.map((x, i) => {
                  return <React.Fragment key={i}>
                    {i === 0 && x.actTypeArr.map((actType, k) => {
                      return <th key={k} colSpan={actType === 'DUTY' ? dutyCodeArr.length : null}>{actType}</th>
                    })}
                  </React.Fragment>
                })}
              </tr>
              <tr>
                <th>GROUP ID</th>
                <th>LAST NAME</th>
                <th>FIRST NAME</th>
                {dutyCodeArr && dutyCodeArr.map((actId, k) => (<th key={k} >{actId}</th>))}
                {payRollArr && payRollArr.map((x, i) => {
                  return <React.Fragment key={i}>
                    {i === 0 && Object.entries(x.timeObj).map((actType, k) => {
                      return actType[0] !== 'DUTY' ? <th key={k}>{actType[1][0].code}</th> : null
                    })}
                  </React.Fragment>
                })}
              </tr>
            </thead>
            <tbody>
              {payRollArr && payRollArr.map((x, i) => {
                return <React.Fragment key={i}>
                  <tr>
                    <td>{x.groupCode}</td>
                    <td>{x.firstName}</td>
                    <td>{x.lastName}</td>
                    <td className="background-blue">{toNumber(x.allTotal + (x.hoursAdjust || 0.0))}</td>
                    <td />
                    <td />
                    <td>{toNumber(x.allTotal)}</td>
                    <td>{toNumber(x.dutyTotal)}</td>
                    {Object.values(x.timeObj) && Object.values(x.timeObj).map((data, key) => {
                      return data.map((actSum, sKey) => {
                        return <React.Fragment>
                          <td key={sKey}> {toNumber(actSum.value)}</td>
                        </React.Fragment>
                      })
                    })}
                  </tr>
                </React.Fragment>
              })}
              <tr>
                <td colSpan={8 + dutyCodeArr.length + withourDutyCodeArr.length}></td>
              </tr>
              <tr className="background-blue">
                <td />
                <td className="font-weight-bold">Total</td>
                <td />
                <td className="font-weight-bold">{finalRegHoursTtl}</td>
                <td />
                <td />
                <td className="font-weight-bold">{allActTotal}</td>
                <td className="font-weight-bold">{allDutyTotal}</td>
                {dutyWiseTotal && dutyWiseTotal.map((dt, wkey) => <td key={wkey} className="font-weight-bold">{toNumber(dt.value)}</td>)}
              </tr>
              <tr>
                <td colSpan={8 + dutyCodeArr.length + withourDutyCodeArr.length}></td>
              </tr>
              <tr>
                <td /><td className="background-green"></td><td>New Hire</td><td></td><td></td><td></td><td></td>
                <td></td>
                <td colSpan={dutyCodeArr.length + withourDutyCodeArr.length}></td>
              </tr>
              <tr>
                <td></td><td className="background-orange"></td><td>Attention</td><td></td><td></td><td></td><td></td>
                <td></td>
                <td colSpan={dutyCodeArr.length + withourDutyCodeArr.length}></td>
              </tr>
              <tr>
                <td></td><td className="background-red"></td><td>Terminated</td><td></td><td></td><td></td><td></td>
                <td></td>
                <td colSpan={dutyCodeArr.length + withourDutyCodeArr.length}></td>
              </tr>
            </tbody>
          </table>
          <Modal size="lg" onHide={() => this.setState({ show: false })}
            show={this.state.show}>
            <Modal.Header closeButton>
              <Modal.Title className="h6" id="contained-modal-title-vcenter">
                Add Policies
        </Modal.Title>
            </Modal.Header>
            <Modal.Body className="show-grid small_font px-5">
              <div className="form-group">
                <label for="exampleInputEmail1">Policy Name*</label>
                <input type="text" className="form-control" placeholder="Default Rounding Policy" />
              </div>
              <div className="form-group">
                <label for="exampleInputEmail1">Policy Description</label>
                <textarea type="email" className="form-control" placeholder="This is the Default Rounding Policy"></textarea>
              </div>
              <div className="form-group row">
                <div className="col-xl-4 col-lg-4 col-md-4 col-sm-12">
                  <label>Punch type to Round</label>
                  <select placeholder="Select" className="form-control" name="activity_status">
                    <option>All</option>
                    <option>Option 2</option>
                  </select>
                </div>
                <div className="col-xl-4 col-lg-4 col-md-4 col-sm-12">
                  <label>How to Round</label>
                  <select placeholder="Select" className="form-control" name="activity_status">
                    <option>Always Round Up</option>
                    <option>Option 2</option>
                  </select>
                </div>
                <div className="col-xl-4 col-lg-4 col-md-4 col-sm-12">
                  <label>Round Interval</label>
                  <select placeholder="Select" className="form-control" name="activity_status">
                    <option>To Nearest 5 Min</option>
                    <option>Option 2</option>
                  </select>
                </div>
              </div>
            </Modal.Body>
            <Modal.Footer>
              <ul class="row form-group mr-0 mt-4 pr-0 list-inline pull-right">
                <li><button onClick={() => this.setState({ show: false })} class="button cancel-btn py-2 px-4 m-0 mr-2">Cancel</button></li>
                <li><button onClick={() => this.setState({ show: false })} class="button resend-btn py-2 px-4 m-0">Save</button></li>
              </ul>
            </Modal.Footer>
          </Modal>
          <Modal size="lg" onHide={() => this.setState({ editshow: false })}
            show={this.state.editshow}>
            <Modal.Header closeButton>
              <Modal.Title className="h6" id="contained-modal-title-vcenter">
                Edit Rounding Policies
        </Modal.Title>
            </Modal.Header>
            <Modal.Body className="show-grid small_font px-5">
              <div className="form-group">
                <label for="exampleInputEmail1">Policy Name*</label>
                <input type="text" className="form-control" placeholder="Default Rounding Policy" />
              </div>
              <div className="form-group">
                <label for="exampleInputEmail1">Policy Description</label>
                <textarea type="email" className="form-control" placeholder="This is the Default Rounding Policy"></textarea>
              </div>
              <div className="form-group row">
                <div className="col-xl-4 col-lg-4 col-md-4 col-sm-12">
                  <label>Punch type to Round</label>
                  <select placeholder="Select" className="form-control" name="activity_status">
                    <option>All</option>
                    <option>Option 2</option>
                  </select>
                </div>
                <div className="col-xl-4 col-lg-4 col-md-4 col-sm-12">
                  <label>How to Round</label>
                  <select placeholder="Select" className="form-control" name="activity_status">
                    <option>Always Round Up</option>
                    <option>Option 2</option>
                  </select>
                </div>
                <div className="col-xl-4 col-lg-4 col-md-4 col-sm-12">
                  <label>Round Interval</label>
                  <select placeholder="Select" className="form-control" name="activity_status">
                    <option>To Nearest 5 Min</option>
                    <option>Option 2</option>
                  </select>
                </div>
              </div>
            </Modal.Body>
            <Modal.Footer>
              <ul class="row form-group mr-0 mt-4 pr-0 list-inline pull-right">
                <li><button onClick={() => this.setState({ editshow: false })} class="button cancel-btn py-2 px-4 m-0 mr-2">Cancel</button></li>
                <li><button onClick={() => this.setState({ editshow: false })} class="button resend-btn py-2 px-4 m-0">Save Changes</button></li>
              </ul>
            </Modal.Footer>
          </Modal>
        </div>
      </div>
    );
  }
}
export default PayrollTable;