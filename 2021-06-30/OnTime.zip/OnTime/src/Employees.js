import React from 'react';
import { Container } from 'react-bootstrap';
import './App.css';
import 'bootstrap/dist/css/bootstrap.min.css';
import 'bs-stepper/dist/css/bs-stepper.min.css';
import Stepper from 'bs-stepper';
import LoadEmployeesTable from './components/LoadEmployeesTable.js';
import LoadEmployeesGroupTable from './components/LoadEmployeesGroupTable.js';

class Employees extends React.Component {

  componentDidMount() {
    this.stepper = new Stepper(document.querySelector('#stepper1'), {
      linear: false,
      animation: true
    })
  }
  render() {
    return (
      <div className="App">
        <Container>
          <div className="contentwrapper pt-1 pb-5 mb-5">
            <div id="stepper1" className="bs-stepper">
              <div className="bs-stepper-header">
                <div className="step" data-target="#test-l-1">
                  <button className="step-trigger">
                    <span className="bs-stepper-label">Manage Employees</span>
                  </button>
                </div>
                <div className="step" data-target="#test-l-2">
                  <button className="step-trigger">
                    <span className="bs-stepper-label">Manage Groups</span>
                  </button>
                </div>
              </div>
              <div className="bs-stepper-content">
                <div id="test-l-1" className="content  pl-1 small_font">
                  <LoadEmployeesTable />
                </div>
                <div id="test-l-2" className="content  pl-1 small_font">
                  <LoadEmployeesGroupTable />
                </div>
              </div>
            </div>
          </div>
        </Container>
      </div>
    );
  }
}

export default Employees;
