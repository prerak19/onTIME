import React from 'react';
import { MDBDataTable } from 'mdbreact';
import "react-datepicker/dist/react-datepicker.css";
/* import "mdbreact/dist/css/mdb.css";
import "@fortawesome/fontawesome-free/css/all.min.css"; */
import '../App.css';
import { Modal, } from "react-bootstrap";
import DualListBox from 'react-dual-listbox';
import 'react-dual-listbox/lib/react-dual-listbox.css';
import { apiPost, apiGet, apiPut, apiDelete } from '../Api.js';
import { confirmAlert } from 'react-confirm-alert';
import 'react-confirm-alert/src/react-confirm-alert.css';

class LoadEmployeesGroupTable extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      show: false,
      editshow: false,
      startDate: '',
      startDate1: '',
      startDate2: '',
      timedisabled: true,
      startdisabled: true,
      enddisabled: true,
      isChecked: false,
      holidaypolicy: true,
      rounding: false,
      selected: [],
      options: [],
      empselected: [],
      empoptions: [],
      rowresult: [],
      editdetails: [],
      fields: {},
      errors: {},
      error_message: '',
      employeesList: [],
      activityList: [],
      adminusers: [],
    };
  }
  async componentDidMount() {
    await this.getFunction();
    this.getAdminUsers();
  }
  getAdminUsers = (e) => {
    let requestDetails = {
      method: 'adminusers/all/' + localStorage.orgid,
      params: {}
    };
    apiGet(requestDetails, true).then((response) => {
      this.setState({ adminusers: response.data });
      console.log(this.state.adminusers);
    }).catch(error => {
      console.log(error)
    });
  }
  handleFormChange = (e) => {
    let editdetails = this.state.editdetails;
    let errors = this.state.errors;
    editdetails[e.target.name] = e.target.value;
    errors[e.target.name] = "form-control is-valid";
    this.setState({
      editdetails
    });
  }
  validateForm() {
    let editdetails = this.state.editdetails;
    let errors = {};
    let formIsValid = true;

    if (!editdetails["code"]) {
      formIsValid = false;
      errors["code"] = "form-control is-invalid";
    }
    if (!editdetails["name"]) {
      formIsValid = false;
      errors["name"] = "form-control is-invalid";
    }
    if (!formIsValid) {
      this.setState({
        error_message: 'Please fill all * Required Fields!'
      });
    } else {
      this.setState({
        error_message: ''
      });
    }

    this.setState({
      errors: errors
    });
    return formIsValid;
  }
  getActivities = (e) => {
    this.setState({ editdetails: [] });
    this.setState({ selected: [] });
    this.setState({ activityList: [] });
    this.setState({ options: [] });
    let requestDetails1 = {
      method: 'activities/all/' + localStorage.orgid,
      params: {}
    };
    apiGet(requestDetails1, true).then((response) => {
      let arr1 = this.state.options;
      Array.isArray(response.data) && response.data.map((item) => (
        arr1.push({ value: item.actID, label: item.name, labeltype: item.type, labelallowExtra: item.allowExtra })
      ))
      this.setState({ options: arr1 });
    }).catch(error => {
      console.log(error)
    });
  }
  getEmployees = (e) => {
    this.setState({ editdetails: [] });
    this.setState({ empselected: [] });
    this.setState({ employeesList: [] });
    this.setState({ empoptions: [] });
    let requestDetails1 = {
      method: 'employees/all/' + localStorage.orgid,
      params: {}
    };
    apiPost(requestDetails1, true).then((response) => {
      let arr1 = this.state.empoptions;
      Array.isArray(response.data.users) && response.data.users.map((item) => (
        arr1.push({ value: item.userID, label: item.firstName + ' ' + item.lastName })
      ))
      this.setState({ empoptions: arr1 });
    }).catch(error => {
      console.log(error)
    });
  }
  addProcess = (d) => {
    this.setState({ show: true });
    this.setState({ editdetails: [] });
    this.getActivities();
    this.getEmployees();
  }
  addRecord = (e) => {
    if (this.validateForm()) {
      let requestDetails = {
        method: 'groups?uid=' + localStorage.userid,
        params: {
          orgId: localStorage.orgid,
          name: this.state.editdetails.name,
          code: this.state.editdetails.code,
          desc: this.state.editdetails.desc,
          approver: {
            userID: this.state.editdetails.userID
          },
          "groupUsers": this.state.employeesList,
          "groupActivities": this.state.activityList
        }
      };
      apiPost(requestDetails, true).then((response) => {
        this.setState({ show: false });
        this.getFunction();
      }).catch(error => {
        console.log(error)
      });
    }
  }
  editProcess = (d) => {
    this.setState({ editshow: true });
    this.setState({ editdetails: [] });
    this.getActivities();
    this.getEmployees();
    let requestDetails = {
      method: 'groups/' + d.currentTarget.dataset.tag,
      params: {}
    };
    apiGet(requestDetails, true).then((response) => {
      let arrs = response.data;
      arrs.userID = response.data.approver.userID;
      this.setState({ editdetails: arrs });

      console.log(this.state.editdetails);

      let arr = this.state.selected;
      let arr2 = this.state.activityList;
      let arr3 = this.state.empselected;
      let arr4 = this.state.employeesList;
      Array.isArray(response.data.groupActivities) && response.data.groupActivities.map((item1) => {
        arr.push(item1.actID);
        arr2.push({ actID: item1.actID, type: item1.type, allowExtra: item1.allowExtra });
      })
      Array.isArray(response.data.groupUsers) && response.data.groupUsers.map((item2) => {
        arr3.push(item2.userID);
        arr4.push({ userID: item2.userID });
      })
      this.setState({ selected: arr });
      this.setState({ activityList: arr2 });
      this.setState({ empselected: arr3 });
      this.setState({ employeesList: arr4 });
    }
    ).catch(error => {
      console.log(error)
    });
  }
  editRecord = (e) => {
    if (this.validateForm()) {
      let requestDetails = {
        method: 'groups/' + e.currentTarget.dataset.tag,
        params: {
          id: e.currentTarget.dataset.tag,
          orgId: localStorage.orgid,
          name: this.state.editdetails.name,
          code: this.state.editdetails.code,
          desc: this.state.editdetails.desc,
          approver: {
            userID: this.state.editdetails.userID
          },
          "groupUsers": this.state.employeesList,
          "groupActivities": this.state.activityList
        }
      };
      apiPut(requestDetails, true).then((response) => {
        this.setState({ editshow: false });
        this.getFunction();
      }).catch(error => {
        console.log(error)
      });
    } else {

    }
  }
  deleteProcess = (e) => {
    var dv = e.currentTarget.dataset.tag;
    confirmAlert({
      customUI: ({ onClose }) => {
        return (
          <div className='custom-ui'>
            <h3>Are you sure?</h3>
            <p>You want to delete this?</p>
            <button data-tag={dv} onClick={() => {
              this.deleteRecord({ dv });
              onClose();
            }}>Yes, Delete it</button>
            <button onClick={onClose}>No, Cancel</button>
          </div>
        );
      }
    });
  }
  deleteRecord = (e) => {
    let requestDetails = {
      method: 'groups/' + e.dv,
      params: {}
    };
    apiDelete(requestDetails, true).then((response) => {
      this.getFunction();
    }).catch(error => {
      console.log(error)
    });
  }
  getFunction = (e) => {
    let requestDetails = {
      method: 'groups/all/' + localStorage.orgid,
      params: {}
    };
    apiGet(requestDetails, true).then((response) => {
      let result = response.data;
      let arr = [];
      Array.isArray(result) && result.map((item) => (
        arr.push({
          id: item.code,
          name: item.name,
          desc: item.desc,
          approver: item.approver.firstName + ' ' + item.approver.lastName,
          edit: <i className="fa fa-edit" data-tag={item.id} onClick={this.editProcess}></i>,
          delete: <i className="fa fa-trash" data-tag={item.id} onClick={this.deleteProcess}></i>,
        })
      ))
      this.setState({
        rowresult: arr
      })
    }).catch(error => {
      console.log(error)
    });
  }

  onChange = (selected) => {
    let data = this.state.options;
    this.setState({ activityList: [] });
    let arr1 = [];
    selected.map((item) => {
      let obj = data.find(o => o.value === item);
      arr1.push({ actID: obj.value, type: obj.labeltype, allowExtra: obj.labelallowExtra })
    })

    this.setState({ activityList: arr1 });
    this.setState({ selected });
  };
  onChangeEmp = (empselected) => {
    let data = this.state.empoptions;
    this.setState({ employeesList: [] });
    let arr1 = [];
    empselected.map((item) => {
      let obj = data.find(o => o.value === item);
      arr1.push({ userID: obj.value })
    })

    this.setState({ employeesList: arr1 });
    this.setState({ empselected });
  };

  render() {
    let datatable = {
      columns: [
        {
          label: 'Group ID',
          field: 'id',
        },
        {
          label: 'Group Name',
          field: 'name',
        },
        {
          label: 'Description',
          field: 'desc',
        },
        {
          label: 'Approver',
          field: 'approver',
        },
        {
          label: 'Edit',
          field: 'edit',
          sort: 'disabled',
        },
        {
          label: 'Delete',
          field: 'delete',
          sort: 'disabled',
        },
      ],
      rows: this.state.rowresult,
    }
    return (
      <div>
        <div className="col-12 row mr-0 pr-0 pl-0 ml-0 mb-3">
          <h6 className="text-left float-left col-lg-9 col-md-9 col-xl-9 col-sm-12 pl-0">Employee Group List</h6>
          <button onClick={this.addProcess} className="button resend-btn py-2 px-4 col-lg-3 col-xl-3 col-md-3 col-sm-12 m-0"><i className="fa fa-plus pr-2"></i>Add Employee Group</button>
        </div>
        <MDBDataTable
          className="timesheets"
          bordered hover info={false} responsive={true} displayEntries={false} noBottomColumns entriesOptions={[5, 20, 25]} entries={5} pagesAmount={4} data={datatable} searching={false} />
        <Modal scrollable={true} size="lg" onHide={() => this.setState({ show: false })}
          show={this.state.show}>
          <Modal.Header closeButton>
            <Modal.Title className="h6" id="contained-modal-title-vcenter">
              Add Employee Group
        </Modal.Title>
          </Modal.Header>
          <Modal.Body className="show-grid small_font px-5">
            <div className="text-danger col-12 text-center">{this.state.error_message}</div>
            <div className="form-group row">
              <div className="col-xl-6 col-lg-6 col-md-6 col-sm-12">
                <label>Group ID*</label>
                <input type="text" value={this.state.editdetails.code} name="code" onChange={this.handleFormChange} className="form-control" placeholder="Enter Group ID" />
              </div>
              <div className="col-xl-6 col-lg-6 col-md-6 col-sm-12">
                <label>Group Name*</label>
                <input type="text" value={this.state.editdetails.name} name="name" onChange={this.handleFormChange} className="form-control" placeholder="Enter Group Name" />
              </div>
            </div>
            <div className="form-group row">
              <div className="col-xl-6 col-lg-6 col-md-6 col-sm-12">
                <label>Group Description</label>
                <textarea name="desc" onChange={this.handleFormChange} className="form-control" placeholder="Enter Description">
                  {this.state.editdetails.desc}
                </textarea>
              </div>
              <div className="col-xl-6 col-lg-6 col-md-6 col-sm-12">
                <label>Group Timesheet Approver</label>
                <select value={this.state.editdetails.userID} name="userID" onChange={this.handleFormChange} className="form-control">
                  <option value='0'>Select</option>
                  {Array.isArray(this.state.adminusers) && this.state.adminusers.map((item, i) => {
                    return <option key={i} value={item.userID}>{item.firstName + ' ' + item.lastName}</option>
                  })
                  }
                </select>
              </div>
            </div>
            <div className="form-group row">
              <div className="col-xl-12 col-lg-12 col-md-12 col-sm-12">
                <label className="mr-2">Employees</label>
                <DualListBox lang={{
                  selectedHeader: 'Selected Employees',
                  availableHeader: 'Available Employees'
                }}
                  showHeaderLabels={true}
                  options={this.state.empoptions}
                  selected={this.state.empselected}
                  onChange={this.onChangeEmp} className="mt-2" icons={{
                    moveLeft: '<',
                    moveAllLeft: '<<',
                    moveRight: '>',
                    moveAllRight: '>>'
                  }}
                />
              </div>
            </div>
            <div className="form-group row">
              <div className="col-xl-12 col-lg-12 col-md-12 col-sm-12">
                <label className="mr-2">Activities</label>
                <DualListBox lang={{
                  selectedHeader: 'Selected Activities',
                  availableHeader: 'Available Activities'
                }} showHeaderLabels={true}
                  options={this.state.options}
                  selected={this.state.selected}
                  onChange={this.onChange} className="mt-2" icons={{
                    moveLeft: '<',
                    moveAllLeft: '<<',
                    moveRight: '>',
                    moveAllRight: '>>'
                  }}
                />
              </div>
            </div>
          </Modal.Body>
          <Modal.Footer>
            <ul className="row form-group mr-0 mt-4 pr-0 list-inline pull-right">
              <li><button onClick={() => this.setState({ show: false })} className="button cancel-btn py-2 px-4 m-0 mr-2">Cancel</button></li>
              <li><button onClick={this.addRecord} className="button resend-btn py-2 px-4 m-0">Save</button></li>
            </ul>
          </Modal.Footer>
        </Modal>
        <Modal scrollable={true} size="lg" onHide={() => this.setState({ editshow: false })}
          show={this.state.editshow}>
          <Modal.Header closeButton>
            <Modal.Title className="h6" id="contained-modal-title-vcenter">
              Edit Group
        </Modal.Title>
          </Modal.Header>
          <Modal.Body className="show-grid small_font px-5">
            <div className="text-danger col-12 text-center">{this.state.error_message}</div>
            <div className="form-group row">
              <div className="col-xl-6 col-lg-6 col-md-6 col-sm-12">
                <label>Group ID*</label>
                <input type="text" value={this.state.editdetails.code} name="code" onChange={this.handleFormChange} className="form-control" placeholder="Enter Group ID" />
              </div>
              <div className="col-xl-6 col-lg-6 col-md-6 col-sm-12">
                <label>Group Name*</label>
                <input type="text" value={this.state.editdetails.name} name="name" onChange={this.handleFormChange} className="form-control" placeholder="Enter Group Name" />
              </div>
            </div>
            <div className="form-group row">
              <div className="col-xl-6 col-lg-6 col-md-6 col-sm-12">
                <label>Group Description</label>
                <textarea name="desc" value={this.state.editdetails.desc} onChange={this.handleFormChange} className="form-control" placeholder="Enter Description">
                  {this.state.editdetails.desc}
                </textarea>
              </div>
              <div className="col-xl-6 col-lg-6 col-md-6 col-sm-12">
                <label>Group Timesheet Approver</label>
                <select value={this.state.editdetails.userID} name="userID" onChange={this.handleFormChange} className="form-control">
                  <option value='0'>Select</option>
                  {Array.isArray(this.state.adminusers) && this.state.adminusers.map((item, i) => {
                    return <option key={i} value={item.userID}>{item.firstName + ' ' + item.lastName}</option>
                  })
                  }
                </select>
              </div>
            </div>
            <div className="form-group row">
              <div className="col-xl-12 col-lg-12 col-md-12 col-sm-12">
                <label className="mr-2">Employees</label>
                <DualListBox lang={{
                  selectedHeader: 'Selected Employees',
                  availableHeader: 'Available Employees'
                }}
                  showHeaderLabels={true}
                  options={this.state.empoptions}
                  selected={this.state.empselected}
                  onChange={this.onChangeEmp} className="mt-2" icons={{
                    moveLeft: '<',
                    moveAllLeft: '<<',
                    moveRight: '>',
                    moveAllRight: '>>'
                  }}
                />
              </div>
            </div>
            <div className="form-group row">
              <div className="col-xl-12 col-lg-12 col-md-12 col-sm-12">
                <label className="mr-2">Activities</label>
                <DualListBox lang={{
                  selectedHeader: 'Selected Activities',
                  availableHeader: 'Available Activities'
                }} showHeaderLabels={true}
                  options={this.state.options}
                  selected={this.state.selected}
                  onChange={this.onChange} className="mt-2" icons={{
                    moveLeft: '<',
                    moveAllLeft: '<<',
                    moveRight: '>',
                    moveAllRight: '>>'
                  }}
                />
              </div>
            </div>
          </Modal.Body>
          <Modal.Footer>
            <ul className="row form-group mr-0 mt-4 pr-0 list-inline pull-right">
              <li><button onClick={() => this.setState({ editshow: false })} className="button cancel-btn py-2 px-4 m-0 mr-2">Cancel</button></li>
              <li><button data-tag={this.state.editdetails.id} onClick={this.editRecord} className="button resend-btn py-2 px-4 m-0">Save Changes</button></li>
            </ul>
          </Modal.Footer>
        </Modal>
      </div>
    );
  }
}
export default LoadEmployeesGroupTable;