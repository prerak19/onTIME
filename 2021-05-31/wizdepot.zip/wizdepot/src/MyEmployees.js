import React from 'react';
import { Container } from 'react-bootstrap';
import 'bootstrap/dist/css/bootstrap.min.css';
import './App.css';
import MyTeamTabs from './components/MyTeamTabs.js';
import TimesheetPreview from './components/TimesheetPreview';
import TimesheetReciept from './components/timesheetRecieptReport';
import moment from 'moment';

class MyTeam extends React.Component {

  constructor(props) {
    super(props);
    this.state = {
      startDate: new Date(moment().day(0).format('YYYY-MM-DD')),
      endDate: new Date(moment().day(6).format('YYYY-MM-DD')),
      activityTimeArr: [],
      summaryArr: [],
      disFilterArr: [],
      originalArr: [],
      showreport: '',
      companyDetails: {},
    };
  }

  setProps = (props) => {
    const { showreport, summaryArr, originalArr, detailsArr,orgImage, activityTimeArr, disFilterArr, startDate, endDate, companyDetails } = props;
    if (showreport === 'original') {
      this.setState({
        showreport, originalArr, startDate, endDate, companyDetails, orgImage
      });
    } else {
      this.setState({
        showreport, summaryArr, detailsArr, activityTimeArr,
        disFilterArr, startDate, endDate, companyDetails,orgImage
      });
    }

  }

  render() {
		const { showreport, startDate, endDate, activityTimeArr, summaryArr, detailsArr, disFilterArr,orgImage, companyDetails , originalArr} = this.state;
    return (
      <div className="App">
        <Container>
          <div className="contentwrapper pt-1 pb-5 mb-5">
            <MyTeamTabs setPropsData={this.setProps}/>
          </div>
        </Container>
        { showreport === 'timesheet' && <TimesheetPreview orgImage={orgImage} companyDetails={companyDetails} activityTimeArr={activityTimeArr} summaryArr={summaryArr} detailsArr={detailsArr} startDate={startDate} endDate={endDate} disFilterArr={disFilterArr} />}
        { showreport === 'original' && <TimesheetReciept orgImage={orgImage} companyDetails={companyDetails} startDate={startDate} endDate={endDate} originalArr={originalArr} />}
      </div>
    );
  }
}

export default MyTeam;
