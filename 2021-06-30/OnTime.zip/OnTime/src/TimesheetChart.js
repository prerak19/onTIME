import React from 'react';
import 'bootstrap/dist/css/bootstrap.min.css';
import './App.css';
import DatePicker from "react-datepicker";
import "react-datepicker/dist/react-datepicker.css";
import {
  Modal,
  Row,
  Col,
  Popover,
  OverlayTrigger
} from "react-bootstrap";
import { apiGet, apiPost, uploadImage, getBlobImage } from './Api.js';
import { get, isEqual, isEmpty, sum, find, sortBy, groupBy } from 'lodash';
import { DAYS_OF_WEEK, timesheet_status_codes, ClockInOuts, toNumber, getWeek, fontOptions } from './helpers/GeneralHelper';
import moment from 'moment';
import { getImageURLs, getReuseSignInit, signImageUpload } from './helpers/commonApi';

const UserActivity = {
  timesheetApproval: 1,
  activityApproval: 2
}

class TimesheetChart extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      weeklyDate: new Date(moment().day(0)),
      actionLogs: [],
      tempObj: null,
      finalTimesheets: [],
      weekDays: [],
      weekCount: 1,
      overallTotals: [],
      approvedImage: [],
      currentTimesheet: {},
      personalDetails: {},
      displayConfirmationPopup: false,
      subLoading: false,
      timesheetid: props.id,
      currentActivityId: null,
      currentActivityTotalHours: 0,
      startWeekDate: moment().day(0),
      weekEndDate: moment().day(6),
      activityApprovalImg: [],
      employeeApprovalImg: [],
      punchOutTime: '',
      punchOutComments: '',
      userApprovalComments: '',
      selectedUserActivity: null,
      timesheetLoading: false,
      supDocuments: [],
      supporitngDoc: {},

      savedFuture: true,
      savedSign: true,

      signatureOutput: '',
      signatureText: '',
      signatureFont: fontOptions[0].value,
      signType: 'type',
      currentSignId: "",
      signatureImage: '',

      initialOutput: '',
      initialText: '',
      initialFont: fontOptions[0].value,
      initialType: 'type',
      currentInitialId: '',
      initialImage: '',
    };
  }

  componentDidMount() {
    this.getTimesheetRecord();
  }

  getTimesheetRecord = () => {
    const requestDetails = {
      method: `timesheets/${this.state.timesheetid}`,
      params: {}
    };
    this.setState({ timesheetLoading: true });
    apiGet(requestDetails, true, false).then((res) => {
      if (isEqual(res.status, 200) && res.data) {
        this.updateBiWeeklyData(res.data);
      }
      if (res.request && res.request.status !== 200) {
        window.alert('No Timesheet is available for selected Week');
        this.setState({ timesheetLoading: false });
      }
    }).catch(error => {
      console.log(error);
    });
  }

  updateBiWeeklyData = async (data) => {
    let tempObj = {}
    const finalTimesheets = data.timsheets;
    const weeklyCount = data.count === 2 ? true : false;
    let weekDays = [];
    const personalDetails = {
      userFirstname: finalTimesheets[0].userFirstname || (weeklyCount && finalTimesheets[1].userFirstname) || null,
      userLastname: finalTimesheets[0].userLastname || (weeklyCount && finalTimesheets[1].userLastname) || null,
      groupCode: finalTimesheets[0].groupCode || (weeklyCount && finalTimesheets[1].groupCode) || null,
      groupName: finalTimesheets[0].groupName || (weeklyCount && finalTimesheets[1].groupName) || null,
      status: finalTimesheets[0].status || (weeklyCount && finalTimesheets[1].status) || null,
      uid: finalTimesheets[0].uid || (weeklyCount && finalTimesheets[1].uid) || null
    };
    let supDocuments = [], overallTotals = [], employeeApprovalImg = [], approvedImage = [], activityApprovalImg = [];
    finalTimesheets.map((xdt) => {
      if (xdt.activityTime && xdt.activityTime.length > 0) {
        xdt.activityTime.map((act) => {
          if (tempObj[act.activityName]) {
            tempObj[act.activityName] = { ...tempObj[act.activityName], week2: { ...act, timesheetID: xdt.tid, startDate: xdt.startDate, status: xdt.status } }
          } else {
            tempObj[act.activityName] = { week1: { ...act, timesheetID: xdt.tid, startDate: xdt.startDate, status: xdt.status } }
          }
          return null;
        })

        let approvedImageArr = xdt.activityTime.filter(x => x.approveImg !== 0);
        if (approvedImageArr.length > 0) {
          approvedImageArr = approvedImageArr.map((x, i) => {
            if (!find(activityApprovalImg, { approveImg: x.approveImg })) {
              const actImg = getImageURLs(x.approveImg);
              activityApprovalImg.push({ index: i, approveImg: x.approveImg, src: actImg });
              return null;
            }
            return null;
          })
        }
      }
      if (xdt.dailyTotals && xdt.dailyTotals.length > 0) {
        xdt.dailyTotals.map((dt) => {
          weekDays.push({
            day: moment(dt.date).format('ddd'),
            date: moment(dt.date).format('MMM D'),
            fullDate: moment(dt.date).format('YYYY-MM-DD'),
          })
          overallTotals.push(dt);
          return null;
        })
      }
      if (xdt.signImg !== 0) {
        if (!find(employeeApprovalImg, { signImg: xdt.signImg })) {
          const imgsrc = getImageURLs(xdt.signImg);
          employeeApprovalImg.push({ signImg: xdt.signImg, src: imgsrc });
        }
      }
      if (xdt.approvalImg !== 0) {
        if (!find(approvedImage, { approvalImg: xdt.approvalImg })) {
          const imgAppsrc = getImageURLs(xdt.approvalImg);
          approvedImage.push({ approvalImg: xdt.approvalImg, src: imgAppsrc });
        }
      }

      if (xdt.changeNotes && xdt.changeNotes.length > 0) {
        xdt.changeNotes.map((doc) => {
          if (doc.docName) {
            const response = this.getSupDocuments(doc);
            supDocuments.push({ ...doc, response });
          }
          return null;
        });
      };
      return null;
    });
    await Promise.all(supDocuments.map((x) => x.response)).then((body) => {
      supDocuments = supDocuments.map((img, key) => {
        if (body[key]) {
          const url = URL.createObjectURL(body[key]);
          return { ...img, href: url };
        }
      })
    });

    await Promise.all(employeeApprovalImg.map((x) => x.src)).then((body) => {
      employeeApprovalImg = employeeApprovalImg.map((img, key) => {
        return { ...img, src: body[key] }
      })
    });

    await Promise.all(approvedImage.map((x) => x.src)).then((body) => {
      approvedImage = approvedImage.map((img, key) => {
        return { ...img, src: body[key] }
      })
    });

    await Promise.all(activityApprovalImg.map((x) => x.src)).then((body) => {
      activityApprovalImg = activityApprovalImg.map((img, key) => {
        return { ...img, src: body[key] }
      })
    });
    const sunday = new Date(moment(get(finalTimesheets[0], 'startDate')).day(0));
    const nextSunday = new Date(moment(get(finalTimesheets[1] || finalTimesheets[0], 'startDate')).day(6));
    let actionLogs = await this.getActionLogs(data);
    this.setState({
      weekCount: data.count,
      tempObj,
      weekDays,
      overallTotals,
      finalTimesheets,
      personalDetails,
      weeklyDate: sunday,
      startWeekDate: moment(sunday).format('YYYY-MM-DD'),
      weekEndDate: moment(nextSunday).format('YYYY-MM-DD'),
      actionLogs,
      employeeApprovalImg,
      approvedImage,
      currentActivityId: null,
      currentActivityTotalHours: 0.00,
      userApprovalComments: '',
      selectedUserActivity: null,
      activityApprovalImg,
      displayConfirmationPopup: false,
      subLoading: false,
      timesheetLoading: false,
      supDocuments
    });
  }

  getSupDocuments = async (data) => {
    let docSrc = '';
    const getRequest = {
      method: `timesheets/docs?tid=${data.timesheetID}&doc=${data.docName}`
    };
    await getBlobImage(getRequest, false, false).then((response) => {
      if (response.data && response.data.size) {
        docSrc = response.data;
      }
    }).catch(error => {
      console.log(error);
    });
    return docSrc;
  }

  cancelPopup = () => {
    this.setState({
      currentActivityId: null, currentTimesheet: {}, currentActivityTotalHours: 0.00, userApprovalComments: '', selectedUserActivity: null,
      displayConfirmationPopup: false, savedFuture: true, savedSign: true,
      signatureText: '', signatureFont: fontOptions[0].value, signatureImage: '', currentSignId: '', signatureOutput: '', signType: 'type',
      initialText: '', initialFont: fontOptions[0].value, currentInitialId: '', initialImage: '', initialOutput: '', initialType: 'type',
    })
  }

  getActionLogs = async (data) => {
    let arr = [];
    const getWeek1Request = { method: `timesheets/action-logs/${data.timsheets[0].tid}` };
    let apiArr = [apiGet(getWeek1Request, true, false)];
    if (data.count === 2) {
      const getWeek2Request = { method: `timesheets/action-logs/${data.timsheets[1].tid} ` };
      apiArr.push(apiGet(getWeek2Request, true, false));
    }
    await Promise.all(apiArr).then(([week1, week2]) => {
      if (week1 && week1.data && week1.data.length > 0) {
        arr.push(...week1.data);
      }
      if (week2 && week2.data && week2.data.length > 0) {
        arr.push(...week2.data);
      }
    }).catch(error => {
    });
    return arr;
  }

  formatDate = (date) => moment(date).format("MMMM D, YYYY");

  isWeekday = (date) => date.getDay() === 0;

  handleWeekChange = (date) => {
    const { personalDetails } = this.state;
    const formatDate = moment(date).format('YYYY-MM-DD');
    const request = {
      method: `timesheets/${get(personalDetails, 'uid')}/${formatDate}`
    };
    this.setState({ timesheetLoading: true });
    apiGet(request, true, false).then((res) => {
      if (isEqual(res.status, 200) && res.data) {
        this.updateBiWeeklyData(res.data);
      }
      if (res.request && res.request.status !== 200) {
        window.alert('No Timesheet is available for selected Week');
        this.setState({ timesheetLoading: false });
      }
    }).catch((err) => {
      console.log(err);
    })
  }

  setPunchOutComments = (evt) => this.setState({ punchOutComments: evt.target.value })

  setUserApprovalComments = (evt) => this.setState({ userApprovalComments: evt.target.value })

  updateHour = (activityProps, actIndex) => {
    const { supporitngDoc } = this.state;
    this.setState({ subLoading: true });
    let updateHour = new FormData();
    const params = {
      timesheetID: Number(activityProps.timesheetID),
      activityID: activityProps.activityID,
      day: actIndex,
      hours: Number(this.state.punchOutTime),
      reason: this.state.punchOutComments,
      madeBy: Number(get(localStorage, 'userid', '')),
    }
    updateHour.append("data", JSON.stringify(params))
    if (supporitngDoc) {
      updateHour.append("file", supporitngDoc);
    }
    const request = {
      method: 'timesheets/changes',
    }
    uploadImage(request, updateHour).then(async (response) => {
      if (response.status === 200 && response.data) {
        this.clearPopover();
        this.getTimesheetRecord();
      }
    }).catch(error => {
      this.setState({ subLoading: false });
      document.body.click();
      let obj = JSON.parse(error.request.response);
      obj.msg ? window.alert(obj.msg) : window.alert('Something Went Wrong!');
      return;
    });
  }

  handleActivityApprovalAction = async (activity, activityHours = 0.0) => {
    const { activityID, timesheetID } = activity;
    const signObj = await getReuseSignInit();
    const initialObj = await getReuseSignInit(true);
    this.setState({
      selectedUserActivity: UserActivity.activityApproval,
      currentActivityId: activityID,
      currentTimesheet: activity,
      timesheetid: timesheetID,
      currentActivityTotalHours: toNumber(activityHours),
      displayConfirmationPopup: true,
      currentSignId: signObj.imageId,
      signatureImage: signObj.signatureImage,
      currentInitialId: initialObj.imageId,
      initialImage: initialObj.signatureImage,
      savedSign: signObj.imageId || initialObj.imageId ? true : false
    })
  }

  handleTimesheetApprovalAction = async (tDetails, total = 0.00) => {
    const { tid } = tDetails;
    const signObj = await getReuseSignInit();
    const initialObj = await getReuseSignInit(true);
    this.setState({
      userApprovalComments: '',
      currentTimesheet: tDetails,
      timesheetid: tid,
      selectedUserActivity: UserActivity.timesheetApproval,
      currentActivityTotalHours: toNumber(total) || 0.00,
      displayConfirmationPopup: true,
      currentSignId: signObj.imageId,
      signatureImage: signObj.signatureImage,
      currentInitialId: initialObj.imageId,
      initialImage: initialObj.signatureImage,
      savedSign: signObj.imageId || initialObj.imageId ? true : false
    })
  }

  signatureChange = (name, value, fontValue) => {
    this.setState({ [`${name}Text`]: value, [`${name}Font`]: fontValue });
    if (value && fontValue) {
      var tCtx = document.createElement('canvas').getContext('2d');
      tCtx.canvas.width = (tCtx.measureText(value).width) * 4;
      tCtx.canvas.height = 70;
      tCtx.font = `40px ${fontValue}`;
      tCtx.fillText(value, 0, 40);
      this.setState({ [`${name}Output`]: tCtx.canvas.toDataURL() });
    } else {
      this.setState({ [`${name}Output`]: '' });
    }
  }

  handleUserAction = async () => {
    const { currentActivityId, userApprovalComments, currentSignId, currentInitialId, savedSign, signatureOutput, initialOutput, savedFuture, selectedUserActivity } = this.state;
    this.setState({ subLoading: true });
    let params = {
      timesheetID: this.state.timesheetid,
      madeBy: get(localStorage, 'userid', ''),
      reason: userApprovalComments,
    }
    if (selectedUserActivity === UserActivity.activityApproval) {
      params.activityID = currentActivityId;
      params.initID = currentInitialId;
    } else {
      params.initID = currentInitialId;
      params.sigID = currentSignId;
    }

    if (!savedSign) {
      if (signatureOutput) { params.sigID = await signImageUpload(signatureOutput, savedFuture); }
      if (initialOutput) { params.initID = await signImageUpload(initialOutput, savedFuture, 'user_initial'); }
    }
    const request = {
      method: '',
      params
    }
    switch (selectedUserActivity) {
      case UserActivity.activityApproval:
        request.method = 'timesheets/activity-approve';
        break;
      case UserActivity.timesheetApproval:
        request.method = 'timesheets/approve';
        break;
      default:
        break;
    }
    apiPost(request, true).then((res) => {
      if (isEqual(res.status, 200) && res.data) {
        window.alert(`${selectedUserActivity === UserActivity.activityApproval ? 'Activity' : 'Timesheet'} has been approved.`);
        this.cancelPopup();
        this.getTimesheetRecord();
      }
      if (res.request && res.request.status !== 200) {
        let obj = JSON.parse(res.request.response);
        obj.msg ? window.alert(obj.msg) : window.alert('Something Went Wrong!');
        this.cancelPopup();
      }
    }).catch((err) => {
      this.setState({ subLoading: false });
    })
  }

  returnImage = (id, key, imgArr, altText, width, height = 50) => {
    const obj = find(imgArr, { [key]: id });
    return obj ? <img src={obj.src} width={width || 'auto'} height={height} alt={altText} /> : null
  }

  ExampleCustomInput = ({ value, onClick }) => (
    <div className="inner-addon right-addon">
      <i className="fa fa-calendar" onClick={onClick}></i>
      <input onClick={onClick} value={value} onChange={() => { }} type="text" className="form-control" placeholder="Select Date" name="date" />
    </div>
  );

  getClockInOutLogic = (timings) => {
    let uniqueHours = {}, finalClockIns = {};
    if (timings && timings.length > 0) {
      const final = groupBy(timings, 'day');
      const resultObj = {};
      if (final) {
        Object.values(final).map(groupbyDays => {
          groupbyDays.filter(v => v && v.type === 1).map((record, i) => {
            const labelNameIn = `${i}_${ClockInOuts[record.type]}`;
            if (resultObj[labelNameIn]) {
              resultObj[labelNameIn].push(record);
            } else {
              resultObj[labelNameIn] = [record];
            }
            return null;
          })

          groupbyDays.filter(v => v && v.type === 2).map((record, i) => {
            const labelNameOut = `${i}_${ClockInOuts[record.type]}`;
            if (resultObj[labelNameOut]) {
              resultObj[labelNameOut].push(record);
            } else {
              resultObj[labelNameOut] = [record];
            }
            return null;
          })
          return null;
        })
        uniqueHours = Object.keys(resultObj).sort().reduce((obj, key) => { obj[key] = resultObj[key]; return obj; }, {});
        Object.keys(DAYS_OF_WEEK).map((y) => {
          Object.entries(uniqueHours).map((xdata) => {
            finalClockIns[xdata[0]] = xdata[1];
            const uniqueDays = xdata[1].map(x => x.day);
            if (!uniqueDays.includes(Number(y))) {
              if (xdata[0].includes('IN')) {
                finalClockIns[xdata[0]].push({ day: Number(y), type: 1, clockAt: null });
              } else {
                finalClockIns[xdata[0]].push({ day: Number(y), type: 2, clockAt: null });
              }
            } else {
              return null;
            }
            return null;
          });
          return null;
        })
      }
    }
    return finalClockIns;
  }

  layoutDoc = (changes) => {
    const { supDocuments } = this.state;
    const obj = supDocuments.find((x) => x.docName === changes.docName);
    return <a href={obj.href} download={obj.docName}>Document</a>
  }

  clearPopover = () => {
    this.setState({ punchOutTime: '', punchOutComments: '', supporitngDoc: {} })
    document.body.click()
  }

  render() {
    const { weekCount, tempObj, userApprovalComments, currentTimesheet, savedSign, savedFuture, signatureImage, supporitngDoc,
      signType, signatureFont, signatureOutput, signatureText, initialType, initialFont, initialOutput, initialText, initialImage,
      finalTimesheets, weekDays, overallTotals, personalDetails, actionLogs, selectedUserActivity, timesheetLoading, subLoading, approvedImage, activityApprovalImg, employeeApprovalImg, currentActivityTotalHours } = this.state;
    const biweekly = weekCount === 2 ? true : false;
    let week1Total = [];
    let week2Total = [];
    if (overallTotals.length > 0) {
      week1Total = overallTotals.slice(0, 7).map((dTotal) => dTotal.hours);
      week2Total = overallTotals.slice(7, 14).map((d1Total) => d1Total.hours);
    }
    const popoverComponent = (activityProps, activityDay) => (
      <Popover id="popover-positioned-top" className="timesheetpopover">
        <Popover.Title as="h6" className="background-green1 text-white">
          <span className="small_font">{personalDetails.userFirstname}, {personalDetails.userLastname}</span>
          <span
            aria-label="Close" className="float-right icon-button cursor-pointer"
            onClick={() => this.clearPopover()}
          >
            x
          </span>
        </Popover.Title>
        <Popover.Content>
          <div className="row p-3">
            <label className="col-xl-3 col-lg-3 col-md-3 col-sm-10 p-0 permission-label">Hour : </label>
            <div className="col-xl-7 col-lg-7 col-md-7 col-sm-10 p-0">
              <input
                type="text"
                className="form-control"
                placeholder=""
                value={this.state.punchOutTime}
                onChange={(evt) => this.setState({ punchOutTime: evt.target.value })}
              />
              {isEmpty(this.state.punchOutTime) && (<p className="text-danger mb-0">This is required</p>)}
            </div>
          </div>
          <div className="col-xl-12 col-lg-12 col-md-12 col-sm-12 p-0">
            <textarea
              className="form-control"
              placeholder="Reason for change (required)"
              value={this.state.punchOutComments}
              onChange={this.setPunchOutComments}
            />
            {isEmpty(this.state.punchOutComments) && (<p className="text-danger mb-0">This is required</p>)}
          </div>
          <div className="row mt-2 mx-0">
            <label className="mr-1 text-blue cursor-pointer font-10" style={{ textDecoration: 'underline' }}>
              <input id="userSignature" type="file" onChange={(e) => this.setState({ supporitngDoc: e.target.files[0] })} style={{ display: 'none' }} />
              Upload
              </label>
              supporting document
          </div>
          {supporitngDoc && <div className="row mx-0">
            {supporitngDoc.name}
          </div>}
          <div className="row mt-2 mx-0">
            <button
              disabled={(isEmpty(this.state.punchOutComments) && isEmpty(this.state.punchOutTime)) || this.state.subLoading}
              className="button resend-btn float-right px-4"
              onClick={() => this.updateHour(activityProps, activityDay)}
            >
              {this.state.subLoading ? 'Please Wait' : 'Save'}
            </button>
          </div>
        </Popover.Content>
      </Popover>
    );
    return (
      <React.Fragment>
        <ul className="pl-0 my-2">
          <button onClick={() => this.props.onBackClick()} className="p-0 cursor-pointer button resend-btn py-2 px-4 m-0 mr-2">Back</button>
        </ul>
        <div className="p-3 mb-3 small_font bg-amber border-0">
          <Row >
            <Col lg="5" md="5" sm="12">
              <span className="pr-3 font-weight-bold font-16">
                {personalDetails.userLastname ? personalDetails.userLastname + ',' : null} {personalDetails.userFirstname}
              </span>
            </Col>
            <Col lg="3" md="3" className="text-right" />
            <Col lg="2" md="2" className="text-right">
              <label className="act-text">Week Started</label>
            </Col>
            <Col lg="2" md="2" sm="12" className="pr-0">
              <div className="form-group row mb-0 mr-2">
                <DatePicker
                  selected={this.state.weeklyDate}
                  value={this.state.startWeekDate}
                  customInput={<this.ExampleCustomInput />}
                  showMonthDropdown
                  showYearDropdown
                  dropdownMode="select"
                  name="startDate"
                  className="form-control"
                  filterDate={this.isWeekday}
                  onChange={this.handleWeekChange}
                  dateFormat="yyyy-MM-dd"
                  placeholderText="yyyy-MM-dd"
                />
              </div>
            </Col>
          </Row>
        </div>
        {timesheetLoading ? 'Please Wait...' :
          <>
            <div className="mt-3">
              <table border='1' className="w-100 text-black">
                <thead>
                  <tr>
                    <th colSpan='21' className="blue-head py-2">
                      <Row>
                        <Col lg="6" md="6" sm="12">
                          <div className="pl-2  float-left">
                            <span className="font-12">{biweekly ? 'BI' : ''} WEEKLY TIME SHEET</span>
                            <span className="small-font pl-2">
                              {`${this.formatDate(this.state.startWeekDate)} - ${this.formatDate(this.state.weekEndDate)}`}
                            </span>
                          </div>
                        </Col>
                        <Col lg="6" md="6" sm="12">
                          <div className="pr-2 float-right">
                            <span className="pr-2 font-12">{timesheet_status_codes[`${get(personalDetails, 'status', '')}`]}</span>
                            <span className="font-small">{`Due on : ${this.formatDate(moment(this.state.weekEndDate).subtract(1, 'day'))}`}</span>
                            <span className="px-1">|</span>
                            <i className="fa fa-print px-1"></i>
                            <i className="fa fa-file-pdf-o px-1"></i>
                          </div>
                        </Col>
                      </Row>
                    </th>
                  </tr>
                </thead>
                <tbody className="text-center">
                  <tr>
                    <td colSpan='2' className="font-weight-bold text-right pr-1">NAME:</td>
                    <td colSpan='19' className="pl-1 text-left">
                      {get(personalDetails, 'userLastname', '')}, {get(personalDetails, 'userFirstname', '')}
                    </td>
                  </tr>
                  <tr>
                    <td colSpan='2' className="font-weight-bold text-right pr-1">GROUP:</td>
                    <td colSpan='19' className="pl-1 text-left">{personalDetails.groupCode ? `${personalDetails.groupName} (${personalDetails.groupCode})` : 'N/A'}</td>
                  </tr>
                  <tr className="text-center font-small p-1 bg-lite-gray">
                    <th colSpan='2' width="8%"></th>
                    {weekDays.slice(0, 7).map((day, index) => (
                      <th key={`${day.day}${index}`} width="4%">{day.day}<br />{day.date}</th>
                    ))}
                    {biweekly ? <th width="4%">1st Week<br />Total</th> : <th width="4%">Total<br />Hours</th>}
                    <th width="3%">Initial</th>
                    {biweekly && <>
                      {weekDays.slice(7, 14).map((day, index) => (
                        <th key={`${day.day}${index}`} width="4%">{day.day}<br />{day.date}</th>
                      ))}
                      <th width="4%">2nd Week<br />Total</th>
                      <th width="3%">Initial</th>
                      <th width="4%">2 Weeks<br />Total</th>
                    </>}
                  </tr>
                  {tempObj && Object.values(tempObj).map((x, i) => {
                    let activityName = x.week1.activityName;
                    let w1finalClockIns = {}, w2finalClockIns = {};
                    const w1activityTotal = x.week1 && Object.values(DAYS_OF_WEEK).map((day) => x.week1[`${day.toLowerCase()}Hour`]).reduce((a, b) => Number(Number(a) + Number(b)).toFixed(2), 0);
                    const w2activityTotal = x.week2 && Object.values(DAYS_OF_WEEK).map((day) => x.week2[`${day.toLowerCase()}Hour`]).reduce((a, b) => Number(Number(a) + Number(b)).toFixed(2), 0);
                    if (x.week1 && x.week1.clockinouts && x.week1.clockinouts.length > 0) {
                      w1finalClockIns = this.getClockInOutLogic(x.week1.clockinouts);
                    }
                    if (x.week2 && x.week2.clockinouts && x.week2.clockinouts.length > 0) {
                      w2finalClockIns = this.getClockInOutLogic(x.week2.clockinouts);
                    }
                    let finalData = {};
                    let extraArr = Object.keys(DAYS_OF_WEEK).map((dat) => ({ day: Number(dat), type: 1, clockAt: null }));
                    if (Object.entries(w1finalClockIns) > Object.entries(w2finalClockIns)) {
                      Object.entries(w1finalClockIns).map((x) => {
                        if (!isEmpty(w2finalClockIns) && w2finalClockIns[x[0]]) {
                          finalData[x[0]] = [...x[1], ...w2finalClockIns[x[0]]]
                        } else {
                          finalData[x[0]] = [...x[1], ...extraArr]
                        }
                        return null;
                      })
                    } else {
                      Object.entries(w2finalClockIns).map((x) => {
                        if (!isEmpty(w1finalClockIns) && w1finalClockIns[x[0]]) {
                          finalData[x[0]] = [...w1finalClockIns[x[0]], ...x[1]]
                        } else {
                          finalData[x[0]] = [...extraArr, ...x[1]]
                        }
                        return null;
                      })
                    }
                    return <React.Fragment key={i}>
                      {!isEmpty(finalData) && Object.values(finalData).map((x, k) => {
                        const timeType = Object.keys(finalData)[k];
                        let w1 = x.slice(0, 7);
                        let w2 = x.slice(7, 14);
                        return <tr key={k}>
                          {k === 0 && (<td className="font-weight-bold" rowSpan={Object.values(finalData).length + 1}>{activityName.toUpperCase()}</td>)}
                          <td >{timeType.split('_')[1]}</td>
                          {sortBy(w1, 'day').map((dt, i) => <td key={i}>{(dt && dt.clockAt) ? moment(dt.clockAt).format('h:mm A') : ''}</td>)}
                          <td ></td>
                          {biweekly && <>
                            {k === 0 && (<td rowSpan={Object.values(finalData).length}></td>)}
                            {sortBy(w2, 'day').map((dt, i) => <td key={i}>{(dt && dt.clockAt) ? moment(dt.clockAt).format('h:mm A') : ''}</td>)}
                            <td ></td>
                          </>}
                          {k === 0 && (<td rowSpan={Object.values(finalData).length}></td>)}
                          {k === 0 && biweekly && (<td rowSpan={Object.values(finalData).length}></td>)}
                        </tr>
                      })}
                      <tr className="time-td blue-text bg-lite-gray">
                        {Object.keys(finalData).length > 0 ?
                          <td>HOURS</td> :
                          <td colSpan='2'>{`${x.week1.activityName.toUpperCase() || x.week2.activityName.toUpperCase()}`}</td>}
                        {Object.values(DAYS_OF_WEEK).map((day, index) => {
                          let multiIndex1 = {};
                          let objDate1 = {};
                          if (finalTimesheets[0].changeNotes.length > 0) {
                            finalTimesheets[0].changeNotes.map((ch) => {
                              const keyName1 = `${ch.activityName}_${ch.day}`;
                              if (objDate1 && objDate1[keyName1]) {
                                let obj = objDate1[keyName1];
                                objDate1[keyName1] = { ...objDate1[keyName1], index: [...obj.index, ch.index] };
                              } else {
                                objDate1[keyName1] = { index: [ch.index], day: ch.day, activityID: ch.activityID };
                              }
                              if ((ch.activityID === x.week1.activityID) && DAYS_OF_WEEK[ch.day] === day) {
                                if (objDate1[keyName1] && (objDate1[keyName1].index).length > 0) {
                                  multiIndex1 = objDate1[keyName1];
                                }
                              };
                              return null;
                            });
                          }
                          return <OverlayTrigger trigger={x.week1.id !== 0 && "click"} key={index} placement='top' rootClose={true} overlay={popoverComponent(x.week1, index)}>
                            <td key={`${day}${index}`} className={`text-blue ${x.week1.id !== 0 && 'cursor-pointer'}`}>
                              {(multiIndex1.index && multiIndex1.index.length > 1) ? <OverlayTrigger
                                key={index}
                                placement='top'
                                overlay={
                                  <Popover id={`popover-positioned-top`}>
                                    <Popover.Title as="h6" className="background-green1 text-white">Timesheet Changes</Popover.Title>
                                    <Popover.Content>
                                      <div>Timesheet Changes of Day: </div>
                                      <div>{multiIndex1.index.join(', ')}</div>
                                    </Popover.Content>
                                  </Popover>
                                }>
                                <span onClick={(e) => e.stopPropagation()} className="ptoCircleMultiple mr-2 ptoCircle xs_font">{multiIndex1.index[0]}</span>
                              </OverlayTrigger> :
                                multiIndex1.index && <span onClick={(e) => e.stopPropagation()} className="mr-1 ptoCircle xs_font">{multiIndex1.index[0]}</span>
                              }
                              {x.week1[`${day.toLowerCase()}Hour`] > 0 ? toNumber(x.week1[`${day.toLowerCase()}Hour`]) : multiIndex1.index ? '0.00' : null}
                            </td>
                          </OverlayTrigger>
                        })}
                        <td >{w1activityTotal}</td>
                        <td className="vertical-align-bottom">
                          {x.week1.approvedBy === 0 ? (<div className="float-right">
                            <div className="guideList" onClick={() => x.week1.id !== 0 && this.handleActivityApprovalAction(x.week1, w1activityTotal)}>
                              <div className="active cursor-pointer">
                                <span className="activePointer"></span>
                                <span>SIGN</span>
                              </div>
                            </div>
                          </div>) : this.returnImage(x.week1.approveImg, 'approveImg', activityApprovalImg, 'approvalImage', 40, 30)}
                        </td>


                        {/* for 2nd Week */}
                        {biweekly && <>
                          {Object.values(DAYS_OF_WEEK).map((day, index) => {
                            let multiIndex2 = {};
                            let objDate2 = {};
                            if (finalTimesheets[1].changeNotes.length > 0) {
                              finalTimesheets[1].changeNotes.map((ch) => {
                                const keyName2 = `${ch.activityName}_${ch.day}`;
                                if (objDate2 && objDate2[keyName2]) {
                                  let obj = objDate2[keyName2];
                                  objDate2[keyName2] = { ...objDate2[keyName2], index: [...obj.index, ch.index] };
                                } else {
                                  objDate2[keyName2] = { index: [ch.index], day: ch.day, activityID: ch.activityID };
                                }
                                if ((ch.activityID === x.week2.activityID) && DAYS_OF_WEEK[ch.day] === day) {
                                  if (objDate2[keyName2] && (objDate2[keyName2].index).length > 0) {
                                    multiIndex2 = objDate2[keyName2];
                                  }
                                };
                                return null;
                              });
                            }
                            return <OverlayTrigger trigger={x.week2.id !== 0 && "click"} key={index} placement='top' rootClose={true} overlay={popoverComponent(x.week2, index)}>
                              <td key={`${day}${index}`} className={`text-blue ${x.week2.id !== 0 && 'cursor-pointer'}`}>
                                {(multiIndex2.index && multiIndex2.index.length > 1) ? <OverlayTrigger
                                  key={index}
                                  placement='top'
                                  overlay={
                                    <Popover id={`popover-positioned-top`}>
                                      <Popover.Title as="h6" className="background-green1 text-white">Timesheet Changes</Popover.Title>
                                      <Popover.Content>
                                        <div>Timesheet Changes of Day: </div>
                                        <div>{multiIndex2.index.join(', ')}</div>
                                      </Popover.Content>
                                    </Popover>
                                  }>
                                  <span onClick={(e) => e.stopPropagation()} className="ptoCircleMultiple mr-2 ptoCircle xs_font">{multiIndex2.index[0]}</span>
                                </OverlayTrigger> :
                                  multiIndex2.index && <span onClick={(e) => e.stopPropagation()} className="mr-1 ptoCircle xs_font">{multiIndex2.index[0]}</span>
                                }
                                {x.week2[`${day.toLowerCase()}Hour`] > 0 ? toNumber(x.week2[`${day.toLowerCase()}Hour`]) : multiIndex2.index ? '0.00' : null}
                              </td>
                            </OverlayTrigger>
                          })}
                          <td >{w2activityTotal}</td>
                          <td className="vertical-align-bottom">
                            {x.week2.approvedBy === 0 ? (<div className="float-right">
                              <div className="guideList" onClick={() => x.week2.id !== 0 && this.handleActivityApprovalAction(x.week2, w2activityTotal)}>
                                <div className="active cursor-pointer">
                                  <span className="activePointer"></span>
                                  <span>SIGN</span>
                                </div>
                              </div>
                            </div>) : this.returnImage(x.week2.approveImg, 'approveImg', activityApprovalImg, 'approvalImage', 40, 30)}
                          </td>
                          <td >{toNumber(Number(w1activityTotal) + Number(w2activityTotal))}</td>
                        </>}
                      </tr>
                    </React.Fragment>
                  })}
                  <tr className="time-td blue-text bg-lite-gray">
                    <td colSpan='2'>TOTAL</td>
                    {week1Total.map((hour, rkey) => <td key={rkey}>{toNumber(hour) || 0.00}</td>)}
                    <td className="text-blue">{toNumber(sum(week1Total)) || 0.00}</td>
                    <td />
                    {biweekly && <>
                      {week2Total.map((hour2, rkey) => <td key={rkey}>{toNumber(hour2) || 0.00}</td>)}
                      <td className="text-blue">{toNumber(sum(week2Total)) || 0.00}</td>
                      <td />
                      <td>{toNumber(sum(week1Total) + sum(week2Total))} </td>
                    </>}
                  </tr>
                  <tr>
                    <th colSpan='11' className="blue-head text-center py-2">
                      Timesheet Changes
                        </th>
                    {biweekly && <th colSpan='10' className="blue-head text-center py-2">
                      Timesheet Changes
                        </th>}
                  </tr>
                  <tr>
                    <td colSpan='11' className="py-2 text-left align-baseline">
                      {
                        get(finalTimesheets[0], 'changeNotes', []).map((timesheetChanges, timIndex) => {
                          let actualDay = DAYS_OF_WEEK[timesheetChanges.day];
                          let dateObject = find(weekDays, { day: actualDay });
                          return <p key={timIndex} className="pl-1 mb-1 small_font">
                            <span className="ptoCircleChg mr-2 text-center"><span className="d-block mt-1">{timesheetChanges.index}</span></span>
                            {timesheetChanges.activityName || ''} {moment(dateObject.fullDate).format('dddd (MMM DD, YYYY)')} : {timesheetChanges.reason} - Change made by {timesheetChanges.madeByFirstname} {timesheetChanges.madeByLastname}
                                &nbsp; on {moment(timesheetChanges.madeAt).format("hh:mm A MMM DD, YYYY")}. {timesheetChanges.docName ? this.layoutDoc(timesheetChanges) : null}
                          </p>
                        })
                      }
                    </td>
                    {biweekly && <td colSpan='10' className="py-2 text-left align-baseline">
                      {
                        get(finalTimesheets[1], 'changeNotes', []).map((timesheetChanges, timIndex) => {
                          let actualDay = DAYS_OF_WEEK[timesheetChanges.day];
                          const biweekDays = weekDays.slice(7, 14);
                          const dateObject = find(biweekDays, { day: actualDay });
                          return <p key={timIndex} className="pl-1 mb-1 small_font">
                            <span className="ptoCircleChg mr-2 text-center"><span className="d-block mt-1">{timesheetChanges.index}</span></span>
                            {timesheetChanges.activityName || ''} {moment(dateObject.fullDate).format('dddd (MMM DD, YYYY)')} : {timesheetChanges.reason} - Change made by {timesheetChanges.madeByFirstname} {timesheetChanges.madeByLastname}
                                &nbsp; on {moment(timesheetChanges.madeAt).format("hh:mm A MMM DD, YYYY")}. {timesheetChanges.docName ? this.layoutDoc(timesheetChanges) : null}
                          </p>
                        })
                      }
                    </td>}
                  </tr>
                  <tr>
                    <td colSpan={biweekly ? '21' : '11'} className="py-2"></td>
                  </tr>

                  {!isEmpty(finalTimesheets) && <tr>
                    {/* 1st week data */}
                    <td colSpan='2' className="pt-5 text-left">
                    </td>
                    <td colSpan='4' className="pt-5 text-left">
                      <p className="mb-0">
                        <span className="pl-1 pr-2 font-9">Employee Signature:</span>
                        {finalTimesheets[0] && finalTimesheets[0].status >= 300 ?
                          this.returnImage(finalTimesheets[0].signImg, 'signImg', employeeApprovalImg, 'employeeApprovalImg', 80, 30) : null}
                      </p>
                      <p className="mb-0">
                        <span className="pl-1 font-9">Date: </span>
                        <span className="pl-1 font-9">{finalTimesheets[0].submitDate || ''}</span>
                      </p>
                    </td>

                    <td colSpan='4' className="pt-5 text-left">
                      <div className="mb-0">
                        <span className="pl-1 pr-2 font-9">Approval Signature:</span>
                        {finalTimesheets[0] && finalTimesheets[0].status < 500 ? <div className="float-right">
                          <div className="guideList" onClick={() => finalTimesheets[0].tid !== 0 && this.handleTimesheetApprovalAction(finalTimesheets[0], sum(week1Total))}>
                            <div className="active cursor-pointer">
                              <span className="activePointer timesheetSign"></span>
                              <span className="pl-4">
                                SIGN
                                  </span>
                            </div>
                          </div>
                        </div> :
                          this.returnImage(finalTimesheets[0].approvalImg, 'approvalImg', approvedImage, 'approvalImage', 80, 30)}
                      </div>
                      <p className="mb-0">
                        <span className="pl-1 font-9">Date: </span>
                        <span className="pl-1 font-9">{finalTimesheets[0].approvalDate || ''}</span>
                      </p>
                    </td>
                    <td colSpan="1" className="pt-5 text-left"></td>

                    {/* 2nd week data */}
                    {biweekly && <>
                      <td colSpan='4' className="pt-5 text-left">
                        <p className="mb-0">
                          <span className="pl-1 pr-2 font-9">Employee Signature:</span>
                          {finalTimesheets[1] && finalTimesheets[1].status >= 300 ?
                            this.returnImage(finalTimesheets[1].signImg, 'signImg', employeeApprovalImg, 'employeeApprovalImg', 80, 30) : null}
                        </p>
                        <p className="mb-0">
                          <span className="pl-1 font-9">Date: </span>
                          <span className="pl-1 font-9">{finalTimesheets[1].submitDate || ''}</span>
                        </p>
                      </td>
                      <td colSpan='4' className="pt-5 text-left">
                        <div>
                          <span className="pl-1 pr-2 font-9">Approval Signature:</span>
                          {finalTimesheets[1] && finalTimesheets[1].status < 500 ? <div className="float-right">
                            <div className="guideList" onClick={() => finalTimesheets[1].tid !== 0 && this.handleTimesheetApprovalAction(finalTimesheets[1], sum(week2Total))}>
                              <div className="active cursor-pointer">
                                <span className="activePointer timesheetSign"></span>
                                <span className="pl-4">
                                  SIGN
                                  </span>
                              </div>
                            </div>
                          </div> :
                            this.returnImage(finalTimesheets[1].approvalImg, 'approvalImg', approvedImage, 'approvalImage', 80, 30)}
                        </div>
                        <p className="mb-0">
                          <span className="pl-1 font-9">Date: </span>
                          <span className="pl-1 font-9">{finalTimesheets[1].approvalDate || ''}</span>
                        </p>
                      </td>
                      <td colSpan="2" className="pt-5 text-left"></td>
                    </>}
                  </tr>}
                </tbody>
              </table>
              <table border='1' className="w-100 text-black">
                <thead>
                  <tr>
                    <th colSpan={biweekly ? '21' : '11'} className="blue-head text-center py-2">
                      Timesheet Action Tracking Log Report
                        </th>
                  </tr>
                </thead>
                <tbody>
                  <tr>
                    <td width="20%" className="text-left">Action By</td>
                    <td width="15%" className="text-left">Actor's IP</td>
                    <td width="20%" className="text-left">Date & Time</td>
                    <td width="45%" className="text-left">Action Taken</td>
                  </tr>
                  {actionLogs.length > 0 ? actionLogs.map((actionData, actionKey) => {
                    return <tr key={actionKey}>
                      <td width="20%" className="text-left">{actionData.userName}</td>
                      <td width="15%" className="text-left">{actionData.actionIp}</td>
                      <td width="20%" className="text-left">{moment(actionData.actionTime).format('MM/DD/YYYY HH:MM A')}</td>
                      <td width="45%" className="text-left">[ {actionData.actionType} ] {actionData.description}</td>
                    </tr>
                  }) : <tr><td colSpan={biweekly ? '21' : '11'}></td></tr>}
                  <tr>
                    <th colSpan={biweekly ? '21' : '11'} className="py-2 text-left">
                      Privacy Act Notification: "This information is subject to the Privacy Act of 1974, (Title 5, USC 522a)"
                        </th>
                  </tr>
                </tbody>
              </table>
            </div>
          </>
        }
        <Modal
          scrollable={true}
          size="md"
          onHide={() => this.cancelPopup()}
          show={this.state.displayConfirmationPopup}
        >
          <Modal.Header closeButton className="h6 background-green1">
            <Modal.Title className="h6 text-white small_font" id="contained-modal-title-vcenter">
              {`${isEqual(selectedUserActivity, UserActivity.activityApproval) ? 'Activity' : 'Timesheet'} Approval Confirmation`}
            </Modal.Title>
          </Modal.Header>
          <Modal.Body className="show-grid small_font px-5">
            {selectedUserActivity === UserActivity.activityApproval ?
              <p className="text-dark text-center mb-2">You are approving the {currentTimesheet.activityName} hours for the week of: </p>
              :
              <p className="text-dark text-center mb-2">You are approving the following timesheet for the week of: </p>
            }
            <p className="small_font font-weight-bold text-center mb-2">
              {getWeek(currentTimesheet.startDate, currentTimesheet.startDate, 'MMMM D, YYYY')}
            </p>
            <p className="small_font text-center mb-2">
              <b>{`${get(personalDetails, 'userFirstname', '')}, ${get(personalDetails, 'userLastname', '')} - Total Hours ${currentActivityTotalHours}`}</b>
            </p>
            {currentTimesheet.status !== 300 &&
              <div className="row">
                <div className="col-lg-12 col-md-12 col-xl-12 col-sm-12 text-center">
                  <label>Comment :</label>
                  <textarea
                    className="form-control"
                    value={userApprovalComments}
                    onChange={this.setUserApprovalComments}
                  />
                  {isEmpty(userApprovalComments) && (<p className="mb-0" style={{ color: 'red' }}>This is required</p>)}
                </div>
              </div>}
            {signatureImage &&
              <div className="text-center mt-2">
                <input type="checkbox" id="savedSign" checked={savedSign} onChange={(e) => this.setState({ savedSign: e.target.checked })} className="mr-2" name="savedSign" />
                <label className="mb-0" htmlFor="savedSign">Use the saved signature & Initial</label>
              </div>}
            {(savedSign) ?
              <div className="text-center">
                {signatureImage && <img src={signatureImage} alt="signatureImage" className="mb-1" />}
                {initialImage && <img src={initialImage} alt="initialImage" className="mb-1 ml-2" />}
              </div> :
              <>
                <div className="border-bottom">
                  <h6 className="text-center mb-0 mt-2">Create Signature</h6>
                  <div className="row mt-2">
                    <div className="col-xl-2 col-lg-2 col-md-2 col-sm-12">
                    </div>
                    <div className="col-xl-3 col-lg-3 col-md-3 col-sm-12 pl-0">
                      <input type="radio" value="type" checked={signType === 'type'} onChange={() => this.setState({ signType: 'type' })} className="mr-2 align-middle" name="signType" />
                      <label>Type</label>
                    </div>
                    <div className="col-xl-3 col-lg-3 col-md-3 col-sm-12 pl-0">
                      <input type="radio" value="drawing" checked={signType === 'drawing'} disabled onChange={() => this.setState({ signType: 'drawing' })} className="mr-2 align-middle" name="signType" />
                      <label>Drawing</label>
                    </div>
                    <div className="col-xl-4 col-lg-4 col-md-4 col-sm-12">
                      <input type="radio" value="image" checked={signType === 'image'} disabled onChange={() => this.setState({ signType: 'image' })} className="mr-2 align-middle" name="signType" />
                      <label>Image</label>
                    </div>
                  </div>
                  {signType === 'type' &&
                    <>
                      <div className="row mt-2 mb-2">
                        <div className="col-lg-2 col-md-2 col-xl-2 col-sm-12 px-0">
                          <label className="mt-2">Type :</label>
                        </div>
                        <div className="col-lg-7 col-md-7 col-xl-7 col-sm-12 pl-0">
                          <input type="text" id="signatureText" style={{ fontFamily: signatureFont, fontSize: signatureText && '3em !important' }} className="form-control" placeholder="Please type here for signature..." value={signatureText} onChange={(evt) => this.signatureChange('signature', evt.target.value, signatureFont)} />
                        </div>
                        <div className="col-xl-3 col-lg-3 col-md-3 col-sm-12 px-0">
                          <select value={signatureFont} className="form-control p-2" style={{ fontFamily: signatureFont }} onChange={(e) => this.signatureChange('signature', signatureText, e.target.value)} name="signatureFont">
                            {fontOptions.map((x, fkey) =>
                              <option value={x.value} key={fkey} className="font-12" style={{ fontFamily: `${x.value}` }}>Style</option>
                            )}
                          </select>
                        </div>
                      </div>
                      {signatureOutput && <div className="row mt-2 align-items-center">
                        <div className="col-lg-2 col-md-2 col-xl-2 col-sm-12 px-0">
                          <label>Signature :</label>
                        </div>
                        <img src={signatureOutput} style={{ maxWidth: '340px', maxHeight: '60px' }} alt="signatureOutput" />
                      </div>}
                    </>}
                </div>
                <div>
                  <h6 className="text-center mb-0 mt-2">Create Initial</h6>
                  <div className="row mt-2">
                    <div className="col-xl-2 col-lg-2 col-md-2 col-sm-12">
                    </div>
                    <div className="col-xl-3 col-lg-3 col-md-3 col-sm-12 pl-0">
                      <input type="radio" value="type" checked={initialType === 'type'} onChange={() => this.setState({ initialType: 'type' })} className="mr-2 align-middle" name="initialType" />
                      <label>Type</label>
                    </div>
                    <div className="col-xl-3 col-lg-3 col-md-3 col-sm-12 pl-0">
                      <input type="radio" value="drawing" checked={initialType === 'drawing'} disabled onChange={() => this.setState({ initialType: 'drawing' })} className="mr-2 align-middle" name="initialType" />
                      <label>Drawing</label>
                    </div>
                    <div className="col-xl-4 col-lg-4 col-md-4 col-sm-12">
                      <input type="radio" value="image" checked={initialType === 'image'} disabled onChange={() => this.setState({ initialType: 'image' })} className="mr-2 align-middle" name="initialType" />
                      <label>Image</label>
                    </div>
                  </div>
                  {initialType === 'type' &&
                    <>
                      <div className="row mt-2 mb-0">
                        <div className="col-lg-2 col-md-2 col-xl-2 col-sm-12 px-0">
                          <label className="mt-2">Type :</label>
                        </div>
                        <div className="col-lg-7 col-md-7 col-xl-7 col-sm-12 pl-0">
                          <input type="text" id="initialText" style={{ fontFamily: initialFont, fontSize: initialText && '3em !important' }} className="form-control" placeholder="Please type here for signature..." value={initialText} onChange={(evt) => this.signatureChange('initial', evt.target.value, initialFont)} />
                        </div>
                        <div className="col-xl-3 col-lg-3 col-md-3 col-sm-12 px-0">
                          <select value={initialFont} className="form-control p-2" style={{ fontFamily: initialFont }} onChange={(e) => this.signatureChange('initial', initialText, e.target.value)} name="initialFont">
                            {fontOptions.map((x, fkey) =>
                              <option value={x.value} key={fkey} className="font-12" style={{ fontFamily: `${x.value}` }}>Style</option>
                            )}
                          </select>
                        </div>
                      </div>
                      {initialOutput && <div className="row mt-2 align-items-center">
                        <div className="col-lg-2 col-md-2 col-xl-2 col-sm-12 px-0">
                          <label>Signature :</label>
                        </div>
                        <img src={initialOutput} style={{ maxWidth: '340px', maxHeight: '60px' }} alt="initialOutput" />
                      </div>}
                    </>}
                </div>
                <div className="text-center mb-2 mt-2">
                  <input type="checkbox" id="savedFuture" checked={savedFuture} onChange={(e) => this.setState({ savedFuture: e.target.checked })} className="mr-2 mt-1" name="savedFuture" />
                  <label htmlFor="savedFuture" className="mb-0">Save Signature & Inital for future use</label>
                </div>
              </>
            }
          </Modal.Body>
          <Modal.Footer>
            <div className="col-12 row mt-2">
              <div className="col-6">
                <button
                  onClick={() => this.cancelPopup()}
                  className="button resend-btn background-red px-4 float-left"
                >
                  No, Cancel
                </button>
              </div>
              <div className="col-6">
                <button
                  disabled={(currentTimesheet.status !== 300 && isEmpty(userApprovalComments)) || subLoading}
                  onClick={this.handleUserAction}
                  className="button resend-btn float-right px-4"
                >
                  {subLoading ? 'Please Wait' : 'Yes, Confirm'}
                </button>
              </div>
            </div>
          </Modal.Footer>
        </Modal>
      </React.Fragment>
    );
  }
}

export default TimesheetChart;
