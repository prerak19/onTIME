import React from 'react';

// Libs
import { get, find, isEmpty, isEqual, sortBy, every } from 'lodash';
import moment from 'moment';
import { MDBDataTable, MDBBtn } from 'mdbreact';
import DatePicker from "react-datepicker";
import "react-datepicker/dist/react-datepicker.css";
import 'bootstrap/dist/css/bootstrap.min.css';
import '../App.css';
import { Modal, Row, Col } from "react-bootstrap";
import { apiGet, apiPost } from '../Api.js';
import { timesheet_status,toNumber, timesheet_status_codes, isSmallScreenFunction, DAYS_OF_WEEK, employeeTypes } from '../helpers/GeneralHelper';
import TimesheetChart from '../TimesheetChart';

const TimesheetOperation = {
  approve: 1,
  reject: 2
};

const DashboardButtonFunctionality = {
  archivable: 1,
  archived: 2
};

class LoadTimesheetsTable extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      displayMassEntryForm: false,
      displayMassEntryDate: '',
      displayUserApprovalForm: false,
      selectedStartWeekDate: '',
      selectedEndWeekDate: '',
      finalData: null,
      approvedcount: false,
      archivedcount: false,
      approveCounter: 0,
      timesheetstatus: 'Approvable',
      timesheetStatusCode: 400,
      displayas: 'Weekly',
      startweeklyDate: '',
      endweeklyDate: '',
      summaryDetails: {},
      rowresult: [],
      activeTimeSheetId: null,
      currentRecordingPeriod: false,
      employeeType: '',
      employeeTypeCode: '',
      activityId: '',
      selectedTimesheets: [],
      isSelectAll: false,
      activityDropdownOptions: [
        {
          actID: 0,
          name: 'All'
        }
      ],
      activityColumns: [],
      approveBtnDisabled: true,
      rejectBtnDisabled: true,
      archivableBtnDisabled: true,
      archivedBtnDisabled: true,
      massEntryHour: '',
      massEntryComments: '',
      massEntryActivity: '',
      massEntryDate: '',
      massEntryFormSubmitBtn: false,
      uniqueActivityTableCols: [],
      selectedTimesheetOperation: null,
      validTimeSheetDataArr: [],
      isUserCommentRequired: false,
      userComments: '',
      displayWarningModal: false,
      selectedButtonFunctionality: null,
      displayInformationModal: false,
      contentForInformationModal: '',
      isSmallScreen: false,
    };
    this.onResize = this.onResize.bind(this);
  }

  componentDidMount = async () => {
    await this.setCurrentRecordingPeriod(false);
    await this.getActivitiesInOrganisation();
    this.onResize();
    window.addEventListener('resize', (e) => {
      this.onResize();
    });
  }

  componentWillUnmount() {
    window.removeEventListener('resize', this.onResize);
  }

  onResize() {
    this.setState({
      isSmallScreen: isSmallScreenFunction()
    }, () => {
      if (this.state.finalData) {
        this.getTimesheetsData(this.state.finalData);
      }
    });
  }


  selectAllHandler = (evt) => {
    const isChecked = evt.target.checked;
    this.setState({
      isSelectAll: isChecked
    }, () => {
      this.setState({
        selectedTimesheets: isChecked ? this.state.rowresult.map(res => res.tid.toString()) : []
      }, () => {
        this.setState({
          rowresult: this.state.rowresult.map((x, i) => {
            return {
              ...x, check: (
                <input
                  key={`${x.tid}`}
                  type='checkbox'
                  id={`${x.tid}`}
                  value={`${x.tid}`}
                  checked={this.state.selectedTimesheets.includes(`${x.tid}`)}
                  onChange={(e) => this.checkboxHandler(e.target.value, e.target.checked)}
                />
              )
            }
          }),
          approveBtnDisabled: this.state.selectedTimesheets.length < 1,
          rejectBtnDisabled: this.state.selectedTimesheets.length < 1,
        })
      })
    })
  }

  handleStartWeekChange = (date) => {
    this.setState({
      selectedStartWeekDate: date,
      startweeklyDate: moment(date).format('YYYY-MM-DD'),
      currentRecordingPeriod: false
    }, () => {
      this.getSummary(date, this.state.endweeklyDate);
      this.getTimesheets(date, this.state.endweeklyDate);
    })
  }

  handleEndWeekChange = (date) => {
    this.setState({
      selectedEndWeekDate: date,
      endweeklyDate: moment(date).format('YYYY-MM-DD'),
      currentRecordingPeriod: false
    }, () => {
      this.getSummary(this.state.startweeklyDate, date);
      this.getTimesheets(this.state.startweeklyDate, date);
    })
  }

  changeStatus = (evt) => {
    const timeSheetFilterStatus = evt.target.value;
    const status = find(timesheet_status, { name: timeSheetFilterStatus });
    if (!isEmpty(status) && isEqual(status.name, 'Approved')) {
      if (get(localStorage, 'userdetails.adminType') < 80 || this.state.selectedTimesheets.length < 1) {
        this.setState({ archivableBtnDisabled: true })
      }
    }
    if (!isEmpty(status) && isEqual(status.name, 'Archivable')) {
      if (get(localStorage, 'userdetails.adminType') < 80 || this.state.selectedTimesheets.length < 1) {
        this.setState({ archivedBtnDisabled: true })
      }
    }

    this.setState({
      timesheetstatus: timeSheetFilterStatus,
      timesheetStatusCode: isEqual(timeSheetFilterStatus, 'all') ? '' : parseInt(status.code),
    }, () => {
      this.getSummary(this.state.startweeklyDate, this.state.endweeklyDate);
      this.getTimesheets(this.state.startweeklyDate, this.state.endweeklyDate);
    });
  }

  isWeekday = (date) => {
    const day = date.getDay()
    return day === 0
  }

  ExampleCustomInput = ({ value, onClick }) => (
    <div className="inner-addon right-addon">
      <i className="fa fa-calendar"></i>
      <input onClick={onClick} value={value} type="text" className="example-custom-input form-control" placeholder="Select Date" name="date" />
    </div>
  );

  ExampleCustomInput1 = ({ value, onClick }) => (
    <div className="inner-addon right-addon">
      <i className="fa fa-calendar"></i>
      <input onClick={onClick} value={value} type="text" className="example-custom-input form-control" placeholder="Select Date" name="date" />
    </div>
  );

  getSummary = (sunday, nextSunday) => {
    const requestDetails = {
      method: `timesheets/summary/${localStorage.orgid}`,
      params: {
        from: !isEmpty(sunday.toString()) ? moment(sunday).format('YYYY-MM-DD') : '',
        to: !isEmpty(nextSunday.toString()) ? moment(nextSunday).format('YYYY-MM-DD') : ''
      }
    };

    apiGet(requestDetails, true).then((response) => {
      this.setState({
        summaryDetails: response.data,
        selectedTimesheets: [],
        validTimeSheetDataArr: [],
        approveCounter: 0,
        approveBtnDisabled: true,
        rejectBtnDisabled: true,
        empName: ''
      });
    }).catch(error => {
      console.log(error);
    });
  }

  getActivitiesInOrganisation = () => {
    const request = {
      method: `activities/all/${localStorage.orgid}`,
      params: {}
    }

    apiGet(request, true).then((res) => {
      if (!isEmpty(res.data)) {
        const activityInfo = []
        res.data.forEach((activity) => {
          activityInfo.push({
            actID: activity.actID,
            name: activity.name
          });
        })
        this.setState({
          activityDropdownOptions: [
            ...this.state.activityDropdownOptions,
            ...activityInfo
          ],
          massEntryActivity: activityInfo[0].actID,
        })
      }
    }).catch(err => {
      console.log(err);
    })
  }

  checkboxHandler = (timesheetId, checked) => {
    const timesheet = this.state.selectedTimesheets.find(checkboxId => isEqual(checkboxId, timesheetId));
    if (isEmpty(timesheet)) {
      this.setState({
        selectedTimesheets: [
          ...this.state.selectedTimesheets,
          timesheetId
        ]
      }, () => {
        let timesheetStatusArr = [...this.state.validTimeSheetDataArr, find(this.state.rowresult, { tid: parseInt(timesheetId) })];
        if (checked === false) {
          timesheetStatusArr = timesheetStatusArr.filter((x) => x.tid !== Number(timesheetId));
        }
        this.setState({
          rowresult: this.state.rowresult.map((x, i) => {
            if (x.tid === Number(timesheetId)) {
              return {
                ...x,
                check: (
                  <input
                    key={`${x.tid}`}
                    type='checkbox'
                    id={`${x.tid}`}
                    value={`${x.tid}`}
                    checked={this.state.selectedTimesheets.includes(`${x.tid}`)}
                    onChange={(e) => this.checkboxHandler(e.target.value, e.target.checked)}
                  />
                ),
              }
            }
            else {
              return x;
            }
          }),
          isSelectAll: this.state.selectedTimesheets.length === this.state.rowresult.length,
          approveBtnDisabled: this.state.selectedTimesheets.length < 1,
          rejectBtnDisabled: this.state.selectedTimesheets.length < 1,
          validTimeSheetDataArr: timesheetStatusArr,
        })
      })
    } else {
      this.setState({
        selectedTimesheets: this.state.selectedTimesheets.filter(checkboxId => !isEqual(checkboxId, timesheetId))
      }, () => {
        let timesheetStatusArr = [...this.state.validTimeSheetDataArr, find(this.state.rowresult, { tid: parseInt(timesheetId) })];
        if (checked === false) {
          timesheetStatusArr = timesheetStatusArr.filter((x) => x.tid !== Number(timesheetId));
        }
        this.setState({
          rowresult: this.state.rowresult.map((x, i) => {
            if (x.tid === Number(timesheetId)) {
              return {
                ...x,
                check: (
                  <input
                    key={`${x.tid}`}
                    type='checkbox'
                    id={`${x.tid}`}
                    value={`${x.tid}`}
                    checked={this.state.selectedTimesheets.includes(`${x.tid}`)}
                    onChange={(e) => this.checkboxHandler(e.target.value, e.target.checked)}
                  />
                ),
              }
            }
            else {
              return x;
            }
          }),
          isSelectAll: this.state.selectedTimesheets.length === this.state.rowresult.length,
          approveBtnDisabled: this.state.selectedTimesheets.length < 1,
          rejectBtnDisabled: this.state.selectedTimesheets.length < 1,
          validTimeSheetDataArr: timesheetStatusArr,
        })
      })
    }
  }

  getTimesheets = (sunday, nextSunday) => {
    const requestDetails = {
      method: 'timesheets/management',
      params: {
        from: !isEmpty(sunday.toString()) ? moment(sunday).format('YYYY-MM-DD') : '',
        to: !isEmpty(nextSunday.toString()) ? moment(nextSunday).format('YYYY-MM-DD') : '',
        approver_id: localStorage.userid,
        org_id: localStorage.orgid,
        status: this.state.timesheetStatusCode,
        employee_type: this.state.employeeTypeCode,
        activity_id: this.state.activityId
      }
    };
    apiGet(requestDetails, true).then((response) => {
      const result = get(response.data, 'timsheets', []);
      this.getTimesheetsData(result);
    }).catch(error => {
      console.log(error);
    });
  }

  getTimesheetsData = (result) => {
    const { isSmallScreen } = this.state;
    const arr = [];
    const activityTimesheetInfo = [];
    const activityTableColumns = [];
    result.forEach((timesheet) => {
      const activityTypes = timesheet.activityTime;
      activityTypes.forEach((activity) => {
        activityTableColumns.push({
          id: activity.activityID,
          label: <span>{activity.activityName} <br /> Hours </span>,
          field: `${activity.activityName}`.toLowerCase(),
        })
        activityTimesheetInfo.push({
          timesheetId: activity.timesheetID,
          activityId: activity.activityID,
          label: <span>{activity.activityName} <br /> Hours </span>,
          field: `${activity.activityName}`.toLowerCase(),
          totalHours: Object.values(DAYS_OF_WEEK).map((day) => activity[`${day.toLowerCase()}Hour`]).reduce((a, b) => Number(Number(a) + Number(b)).toFixed(2), 0)
        })
      })
    });
    const uniqueActivityTableCols = [];
    !isEmpty(activityTableColumns) && activityTableColumns.forEach((col) => {
      const record = uniqueActivityTableCols.filter((uniqueCol) => uniqueCol.id === col.id)
      if (isEmpty(record)) {
        uniqueActivityTableCols.push(col);
      }
    })
    const activityHours = (timesheetId) => {
      const rowValues = [];
      uniqueActivityTableCols.forEach((col) => {
        const record = find(activityTimesheetInfo, { timesheetId, activityId: col.id });
        rowValues.push({
          [col.field]: isEmpty(record) ? '0.00' : toNumber(record.totalHours),
        })
      })
      return Object.assign({}, ...rowValues);
    }
    Array.isArray(result) && result.map((item) => {
      arr.push({
        ...item,
        check: (
          <input
            key={`${item.tid}`}
            type='checkbox'
            id={`${item.tid}`}
            value={`${item.tid}`}
            checked={false}
            onChange={(e) => this.checkboxHandler(e.target.value, e.target.checked)}
          />
        ),
        start: (<a
          title={moment(item.startDate).format('YYYY-MM-DD')}
          href="javascript:void(0);"
          onClick={() => this.setState({ activeTimeSheetId: item.tid })}
          className="text-decoration-underline blue-color p-0 cursor-pointer"
        >
          { isSmallScreen ? moment(item.startDate).format('MM-DD') : moment(item.startDate).format('YYYY-MM-DD')}
        </a>),
        timesheetStatus: item.status,
        status: timesheet_status_codes[`${item.status}`],
        last_name: item.userLastname,
        first_name: item.userFirstname,
        total: toNumber(item.overtimeHours + item.regularHours),
        overtime: toNumber(item.overtimeHours),
        maxot: '0.00',
        regular: toNumber(item.regularHours),
        ...activityHours(item.tid)
      })
    });
    this.setState({
      rowresult: arr,
      finalData: result,
      selectedTimesheets: [],
      validTimeSheetDataArr: [],
      approveCounter: 0,
      empName: '',
      approveBtnDisabled: true,
      rejectBtnDisabled: true,
      uniqueActivityTableCols,
      isSelectAll: false
    });
  }

  setCurrentRecordingPeriod = (checkboxState) => {
    this.setState({ currentRecordingPeriod: !checkboxState });
    const getRequest = {
      method: `timesheets/cur-rec-period/${localStorage.orgid}`,
      params: {}
    };
    apiGet(getRequest, true).then((response) => {
      const start = response.data.startDate;
      const end = response.data.endDate;
      this.setState({
        selectedStartWeekDate: new Date(start),
        selectedEndWeekDate: new Date(end),
        startweeklyDate: moment(start).format('YYYY-MM-DD'),
        endweeklyDate: moment(end).format('YYYY-MM-DD')
      }, () => {
        this.getSummary(start, end);
        this.getTimesheets(start, end);
      });
    }).catch(error => {
      this.setState({
        selectedStartWeekDate: new Date(),
        selectedEndWeekDate: new Date(),
        startweeklyDate: moment().format('YYYY-MM-DD'),
        endweeklyDate: moment().format('YYYY-MM-DD')
      });
    });
  }

  filterByEmployeeType = (evt) => {
    const employeeType = evt.target.value;
    const status = find(employeeTypes, { name: employeeType });
    this.setState({
      employeeType,
      employeeTypeCode: isEqual(employeeType, 'all') ? '' : parseInt(status.code)
    }, () => {
      this.getSummary(this.state.startweeklyDate, this.state.endweeklyDate);
      this.getTimesheets(this.state.startweeklyDate, this.state.endweeklyDate);
    });
  }

  filterByActivity = (evt) => {
    const activityCode = evt.target.value;
    this.setState({
      activityId: isEqual(activityCode, '0') ? '' : parseInt(activityCode)
    }, () => {
      this.getSummary(this.state.startweeklyDate, this.state.endweeklyDate);
      this.getTimesheets(this.state.startweeklyDate, this.state.endweeklyDate);
    });
  }

  completeTimesheetOperation = async () => {
    const { validTimeSheetDataArr, approveCounter } = this.state;
    const tId = validTimeSheetDataArr[approveCounter - 1].tid;
    const request = {
      method: this.state.selectedTimesheetOperation === 1 ? 'timesheets/approve' : 'timesheets/disapprove',
      params: {
        timesheetID: tId,
        madeBy: localStorage.userid,
        reason: this.state.userComments
      }
    };

    await apiPost(request).then((response) => {
      if (response && validTimeSheetDataArr.length > 1 && approveCounter !== validTimeSheetDataArr.length) {
        let timeObj = validTimeSheetDataArr[approveCounter];
        const minDate = moment(timeObj.startDate);
        const sunday = moment(minDate).day(0).format('ddd MMM DD, YYYY');
        const nextSunday = moment(minDate).day(6).format('ddd MMM DD, YYYY');
        this.setState({
          approveCounter: approveCounter + 1,
          displayMassEntryDate: `${sunday} - ${nextSunday}`,
          isUserCommentRequired: timeObj.timesheetStatus < 300 ? true : false,
          userComments: '',
          empName: `${timeObj.userFirstname} ${timeObj.userLastname}`
        });
      } else {
        this.setState({
          displayUserApprovalForm: false,
          userComments: '',
          empName: '',
        });
        if (approveCounter === validTimeSheetDataArr.length) {
          const message = `${approveCounter} out of ${this.state.selectedTimesheets.length} selected timesheet${approveCounter > 1 ? 's' : ''} successfully ${this.state.selectedTimesheetOperation === 1 ? 'approved' : 'rejected'}`
          window.alert(message);
          this.getSummary(this.state.startweeklyDate, this.state.endweeklyDate);
          this.getTimesheets(this.state.startweeklyDate, this.state.endweeklyDate);
        }
      }
    }).catch((err) => console.log(err));
  }

  openUserApprovalForm = () => {
    const { validTimeSheetDataArr } = this.state;
    const minDate = Math.min(...validTimeSheetDataArr.map(e => moment(e.startDate)));
    const sunday = moment(minDate).day(0).format('ddd MMM DD, YYYY');
    const nextSunday = moment(minDate).day(6).format('ddd MMM DD, YYYY');
    this.setState({
      displayUserApprovalForm: true,
      approveCounter: 1,
      displayMassEntryDate: `${sunday} - ${nextSunday}`
    });
  }

  openWarningModal = (buttonNumber) => {
    const { validTimeSheetDataArr } = this.state;
    const minDate = Math.min(...validTimeSheetDataArr.map(e => moment(e.startDate)));
    const sunday = moment(minDate).day(0).format('ddd MMM DD, YYYY');
    const nextSunday = moment(minDate).day(6).format('ddd MMM DD, YYYY');
    this.setState({
      selectedButtonFunctionality: buttonNumber,
      displayMassEntryDate: `${sunday} - ${nextSunday}`,
      displayWarningModal: true,
    });
  }

  closeUserApprovalForm = () => {
    this.setState({
      displayUserApprovalForm: false,
      selectedTimesheetOperation: null,
      isUserCommentRequired: false,
      userComments: '',
      displayMassEntryDate: '',
    }, () => {
      this.getSummary(this.state.startweeklyDate, this.state.endweeklyDate);
      this.getTimesheets(this.state.startweeklyDate, this.state.endweeklyDate);
    })
  }

  approveOrRejectTimesheets = (operation) => {
    const { displayUserApprovalForm, selectedTimesheets, rowresult } = this.state;
    if (!displayUserApprovalForm) {
      const timesheetIds = selectedTimesheets;
      let timesheetStatusArr = [];
      timesheetIds.map((x, i) => (timesheetStatusArr = [...timesheetStatusArr, find(rowresult, { tid: parseInt(x) })]));
      timesheetStatusArr = sortBy(timesheetStatusArr, (value) => value.startDate);
      if (!isEmpty(timesheetStatusArr)) {
        switch (operation) {
          case 1:
            this.setState({
              validTimeSheetDataArr: timesheetStatusArr,
              isUserCommentRequired: timesheetStatusArr[0].timesheetStatus < 300 ? true : false,
              selectedTimesheetOperation: operation,
              empName: `${timesheetStatusArr[0].userFirstname} ${timesheetStatusArr[0].userLastname}`
            }, () => {
              return this.openUserApprovalForm()
            })
            break;
          case 2:
            this.setState({
              validTimeSheetDataArr: timesheetStatusArr,
              isUserCommentRequired: true,
              selectedTimesheetOperation: operation,
              empName: `${timesheetStatusArr[0].userFirstname} ${timesheetStatusArr[0].userLastname}`
            }, () => {
              return this.openUserApprovalForm()
            })
            break;
          default:
            break;
        }
      }
    }
  }

  updateTimesheetStatusToArchivedOrArchivable = () => {
    const { validTimeSheetDataArr } = this.state;
    const validTimesheets = [];
    const timesheetIds = this.state.selectedTimesheets;
    if (!isEmpty(timesheetIds)) {
      timesheetIds.forEach((timesheetId) => {
        switch (this.state.selectedButtonFunctionality) {
          case DashboardButtonFunctionality.archivable:
            const archivableSt = find(validTimeSheetDataArr.filter((x) => x.timesheetStatus === 500), { tid: parseInt(timesheetId) });
            if (archivableSt) {
              validTimesheets.push(parseInt(timesheetId));
            }
            break;
          case DashboardButtonFunctionality.archived:
            const archivedSt = find(validTimeSheetDataArr.filter((x) => x.timesheetStatus === 600), { tid: parseInt(timesheetId) });
            if (archivedSt) {
              validTimesheets.push(parseInt(timesheetId));
            }
            break;
          default:
            break;
        }
      })
    }

    if (!isEmpty(validTimesheets)) {
      const request = {
        method: this.state.selectedButtonFunctionality === DashboardButtonFunctionality.archivable
          ? 'timesheets/set-archivable' : 'timesheets/set-archived',
        params: {
          tidList: validTimesheets,
          madeBy: localStorage.userid
        }
      }
      apiPost(request, true).then((response) => {
        const message = `${validTimesheets} out of ${this.state.selectedTimesheets.length} selected timesheet's successfully ${this.state.selectedButtonFunctionality === 1 ? 'archivable' : 'archived'}.`
        window.alert(message);
        this.getSummary(this.state.startweeklyDate, this.state.endweeklyDate);
        this.getTimesheets(this.state.startweeklyDate, this.state.endweeklyDate);
        this.closeWarningModal();
      }).catch((error) => {
        console.log(error);
      });
    }
  }

  onSubmitMassTimeEntry = () => {
    const request = {
      method: 'timesheets/masshour',
      params: {
        tidList: this.state.selectedTimesheets.map((timesheetId) => parseInt(timesheetId)),
        activityID: parseInt(this.state.massEntryActivity),
        day: moment(this.state.massEntryDate).day(),
        hour: this.state.massEntryHour,
        reason: this.state.massEntryComments,
        madeBy: localStorage.userid
      }
    };
    apiPost(request, true).then((response) => {
      this.getSummary(this.state.startweeklyDate, this.state.endweeklyDate);
      this.getTimesheets(this.state.startweeklyDate, this.state.endweeklyDate);
      this.cancelMassEntry();
    }).catch((error) => {
      console.log(error);
    });
  }

  handleUserComments = (evt) => this.setState({ userComments: evt.target.value })

  handleMassEntryComments = (evt) => this.setState({ massEntryComments: evt.target.value })

  closeWarningModal = () => {
    this.setState({
      displayWarningModal: false,
      selectedButtonFunctionality: null,
      displayMassEntryDate: '',
    })
  }

  openMassEntryForm = () => {
    const { rowresult, selectedTimesheets } = this.state;
    let arr = rowresult.filter((x, i) => selectedTimesheets.includes(`${x.tid}`));
    const maxDate = Math.max(...arr.map(e => moment(e.startDate)));
    const minDate = Math.min(...arr.map(e => moment(e.startDate)));
    if (moment(minDate).format('YYYY-MM-DD') === moment(maxDate).format('YYYY-MM-DD')) {
      const sunday = moment(minDate).day(0).format('ddd MMM DD, YYYY');
      const nextSunday = moment(minDate).day(6).format('ddd MMM DD, YYYY');
      this.setState({
        displayMassEntryForm: true,
        displayMassEntryDate: `${sunday} - ${nextSunday}`
      })
    } else {
      window.alert('Please Select Same week for Mass Entry!');
      return;
    }
  }

  cancelMassEntry = () => {
    this.setState({
      displayMassEntryForm: false,
      displayMassEntryDate: '',
      massEntryActivity: this.state.activityDropdownOptions.slice(1)[0].actID,
      massEntryComments: '',
      massEntryDate: '',
      massEntryHour: ''
    });
  }
  closeInformationModal = () => this.setState({ displayInformationModal: false })

  selectActivityForMassEntry = (evt) => this.setState({ massEntryActivity: evt.target.value })

  render() {
    const { isSelectAll, uniqueActivityTableCols, rowresult, currentRecordingPeriod, selectedStartWeekDate, selectedEndWeekDate, startweeklyDate,
      endweeklyDate, timesheetstatus, activityDropdownOptions, summaryDetails, approveBtnDisabled, rejectBtnDisabled, selectedTimesheets, displayMassEntryForm,
      displayMassEntryDate, massEntryDate, massEntryActivity, massEntryHour, massEntryComments, displayUserApprovalForm, selectedTimesheetOperation, displayWarningModal,
      validTimeSheetDataArr, empName, userComments, isUserCommentRequired, activeTimeSheetId, isSmallScreen
    } = this.state;
    if (activeTimeSheetId) {
      return <TimesheetChart
        id={activeTimeSheetId}
        onBackClick={() => {
          this.getTimesheets(startweeklyDate, endweeklyDate)
          this.setState({ activeTimeSheetId: null })
        }}
      />
    }
    const defaultColumns = [
      {
        label: 'Week Start',
        field: 'start',
      },
      {
        label: 'Status',
        field: 'status',
      },
      {
        label: 'Last Name',
        field: 'last_name',
      },
      {
        label: 'First Name',
        field: 'first_name',
      },
      {
        label: 'Ttl Hrs',
        field: 'total',
      },
      {
        label: (<span>Overtime<br /> Hours</span>),
        field: 'overtime',
      },
      {
        label: (<span>Max OT<br /> Allowed</span>),
        field: 'maxot',
      },
      {
        label: (isSmallScreen ? <span title="Regular Hours <=40">{'Regular Hours'} </span> : <span>{'Regular Hours'} <br />{' <= 40'}</span>),
        field: 'regular',
      },
    ];

    const datatable = {
      columns: [
        {
          label: (
            <input
              type="checkbox"
              id="colhead_checkbox"
              onChange={this.selectAllHandler}
              checked={isSelectAll}
            />
          ),
          field: 'check',
          sort: 'asc',
        },
        ...defaultColumns,
      ],
      rows: rowresult,
    }

    const activityDataTable = {
      columns: uniqueActivityTableCols,
      rows: rowresult,
    }
    return (
      <div>
        <div className="p-3 mb-3 small_font bg-amber border-0">
          <Row>
            <Col lg="4" md="4" sm="12">
              <label className="pr-2 float-left">Date Range : </label>
              <input
                style={{ float: 'left', width: '25px', marginTop: '3px' }}
                type="checkbox"
                name="current-recording"
                className="form-control"
                onChange={() => this.setCurrentRecordingPeriod(currentRecordingPeriod)}
                checked={currentRecordingPeriod}
              />
              <label
                onClick={() => this.setCurrentRecordingPeriod(currentRecordingPeriod)}
                style={{ fontSize: '9pt' }}
              >
                Current Recording Period
              </label>
              <Row>
                <Col lg="6" md="6" sm="6">
                  <label className="pr-2">Start Week</label>
                  <DatePicker
                    selected={selectedStartWeekDate}
                    value={startweeklyDate}
                    name="startDate"
                    className="form-control"
                    customInput={<this.ExampleCustomInput />}
                    filterDate={this.isWeekday}
                    onChange={this.handleStartWeekChange}
                    dateFormat="yyyy-MM-dd"
                    placeholderText="yyyy-MM-dd"
                  />
                </Col>
                <Col lg="6" md="6" sm="6">
                  <label className="pr-2">End Week</label>
                  <DatePicker
                    selected={selectedEndWeekDate}
                    value={endweeklyDate}
                    name="startDate"
                    className="form-control"
                    customInput={<this.ExampleCustomInput1 />}
                    filterDate={this.isWeekday}
                    onChange={this.handleEndWeekChange}
                    dateFormat="yyyy-MM-dd"
                    placeholder="yyyy-MM-dd"
                  />
                </Col>
              </Row>
            </Col>
            <Col lg="2" md="2" sm="12" className="mb-0 mt-auto">
              <label>Timesheet Status</label>
              <select onChange={this.changeStatus} placeholder="Select" className="form-control dropdown-height" name="state">
                <option value="all">All</option>
                <option value="Active" selected={timesheetstatus === 'Active' ? 'selected' : ''}>Active</option>
                <option value="Inactive" selected={timesheetstatus === 'Inactive' ? 'selected' : ''}>Inactive</option>
                <option value="Submitted" selected={timesheetstatus === 'Submitted' ? 'selected' : ''}>Submitted</option>
                <option value="Approvable" selected={timesheetstatus === 'Approvable' ? 'selected' : ''}>Approvable</option>
                <option value="Approved" selected={timesheetstatus === 'Approved' ? 'selected' : ''}>Approved</option>
                <option value="Archivable" selected={timesheetstatus === 'Archivable' ? 'selected' : ''}>Archivable</option>
                <option value="Archived" selected={timesheetstatus === 'Archived' ? 'selected' : ''}>Archived</option>
              </select>
            </Col>
            <Col lg="2" md="2" sm="12" className="mb-0 mt-auto">
              <label>Activity</label>
              <select onChange={this.filterByActivity} placeholder="Select" className="form-control dropdown-height" name="state" >
                {activityDropdownOptions.map(activity => <option key={activity.actID} value={activity.actID}>{activity.name}</option>)}
              </select>
            </Col>
            <Col lg="2" md="2" sm="12" className="mb-0 mt-auto">
              <label>Employee Type</label>
              <select onChange={this.filterByEmployeeType} placeholder="Select" className="form-control dropdown-height" name="state">
                <option value="all">All</option>
                <option value="Salaried">Salaried</option>
                <option value="Full-Time Hourly">Full Time Hourly</option>
                <option value="Part-Time Hourly">PT Hourly</option>
                <option value="Temporary">Temporary</option>
                <option value="SubContractor">SUB</option>
                <option value="Intern">Intern</option>
              </select>
            </Col>
          </Row>
        </div>
        <p className="small_font mb-2 mt-2 ">Summary on Number of Timesheets in this Period :
          <label className="label label-info"> Active : {get(summaryDetails, 'numOfActive', 0)}</label>
          <label className="label label-danger"> Inactive : {get(summaryDetails, 'numOfInactive', 0)}</label>
          <label className="label label-success2"> Submitted : {get(summaryDetails, 'numOfSubmitted', 0)}</label>
          <label className="label label-warning"> Approvable : {get(summaryDetails, 'numOfApprovable', 0)}</label>
          <label className="label label-success1"> Approved : {get(summaryDetails, 'numOfApproved', 0)}</label>
          <label className="label label-primary"> Archivable : {get(summaryDetails, 'numOfArchivable', 0)}</label>
          <label className="label label-default"> Archived : {get(summaryDetails, 'numOfArchived', 0)}</label>
        </p>
        <div className="row px-0 ml-0 mb-3">
          <div className="text-left float-left col-lg-7 col-md-7 col-xl-7 col-sm-12 pl-0">
            <MDBBtn
              disabled={approveBtnDisabled || validTimeSheetDataArr.some((e) => e.timesheetStatus > 400)}
              onClick={() => this.approveOrRejectTimesheets(TimesheetOperation.approve)}
              color="success"
              data-toggle="tooltip"
              title="Approve"
            >
              <i className="fa fa-thumbs-up text-white"></i>
            </MDBBtn>
            <MDBBtn
              disabled={rejectBtnDisabled || validTimeSheetDataArr.some((e) => e.timesheetStatus !== 300 && e.timesheetStatus !== 400)}
              onClick={() => this.approveOrRejectTimesheets(TimesheetOperation.reject)}
              className="ml-2"
              color="danger"
              data-toggle="tooltip"
              title="Reject"
            >
              <i className="fa fa-thumbs-down text-white"></i>
            </MDBBtn>
            <MDBBtn
              onClick={() => this.openWarningModal(DashboardButtonFunctionality.archivable)}
              style={(validTimeSheetDataArr.length > 0 && every(validTimeSheetDataArr, { 'timesheetStatus': 500 })) ? {} : { display: 'none' }}
              color="success"
              className="ml-2"
            >
              Set to Archivable
            </MDBBtn>
            <MDBBtn
              onClick={() => this.openWarningModal(DashboardButtonFunctionality.archived)}
              style={(validTimeSheetDataArr.length > 0 && every(validTimeSheetDataArr, { 'timesheetStatus': 600 })) ? {} : { display: 'none' }}
              color="success"
              className="ml-2"
            >
              Set to Archived
            </MDBBtn>
          </div>
          <div className="row col-lg-3 col-xl-3 col-md-3 col-sm-12"></div>
          <div className="col-lg-2 col-xl-2 col-md-2 col-sm-12 px-0">
            <button
              onClick={() => this.openMassEntryForm()}
              className="button resend-btn py-2 px-3 m-0 float-right"
              disabled={isEmpty(selectedTimesheets)}
            >
              Mass Time Entry
              <i className="fa fa-book pl-2"></i>
            </button>
          </div>
        </div>
        <Row className="mr-0">
          <Col xs={uniqueActivityTableCols.length > 0 ? 9 : 12} className="pr-0">
            <MDBDataTable
              className="activitytable timesheets fieldTable"
              responsive={true}
              noBottomColumns
              striped
              info={false}
              bordered
              hover
              displayEntries={false}
              data={datatable}
              searching={false}
              paging={false}
            />
          </Col>
          {uniqueActivityTableCols.length > 0 && <Col xs={3} className="pl-0">
            <MDBDataTable
              className="activitytable timesheets"
              responsive={true}
              noBottomColumns
              striped
              info={false}
              bordered
              hover
              displayEntries={false}
              data={activityDataTable}
              searching={false}
              paging={false}
            />
          </Col>}
        </Row>
        {/** Modal to perform mass entry form operation */}
        { displayMassEntryForm && <Modal
          scrollable={true}
          size="md"
          onHide={() => this.cancelMassEntry()}
          show={displayMassEntryForm}
        >
          <Modal.Header closeButton className="h6 background-blue1">
            <Modal.Title className="h6 text-white" id="contained-modal-title-vcenter">
              Mass Time Entry
            </Modal.Title>
          </Modal.Header>
          <Modal.Body className="show-grid small_font px-5">
            <p className="xs_font text-dark text-center">
              {`Add a punch or time entry for the ${selectedTimesheets.length} selected employee${selectedTimesheets.length > 1 ? 's' : ''} for the week of:`}
            </p>
            <p className="small_font font-weight-bold text-center">
              {displayMassEntryDate}
            </p>
            <div className="form-group row">
              <div className="col-lg-6 col-md-6 col-xl-6 col-sm-12">
                <label htmlFor="exampleInputEmail1">Date:</label>
                <input
                  type="date"
                  className="form-control"
                  placeholder="DD-MM-YYYY"
                  value={massEntryDate}
                  min={moment(displayMassEntryDate.split('-')[0]).format('YYYY-MM-DD')}
                  max={moment(displayMassEntryDate.split('-')[1]).format('YYYY-MM-DD')}
                  onChange={(evt) => this.setState({ massEntryDate: evt.target.value })}
                />
                {isEmpty(massEntryDate) && (<p style={{ color: 'red' }}>This is required</p>)}
              </div>
              <div className="col-lg-6 col-md-6 col-xl-6 col-sm-12">
                <label htmlFor="exampleInputEmail1">Activity Name:</label>
                <select onChange={this.selectActivityForMassEntry} defaultValue={massEntryActivity} placeholder="Select" className="form-control" name="state">
                  {activityDropdownOptions.slice(1).map(activity => <option key={activity.actID} value={activity.actID}>{activity.name}</option>)}
                </select>
              </div>
            </div>
            <div className="form-group row">
              <div className="col-lg-6 col-md-6 col-xl-6 col-sm-12">
                <label htmlFor="exampleInputEmail1">Hour:</label>
                <input
                  type="text"
                  className="form-control"
                  placeholder=""
                  value={massEntryHour}
                  onChange={(evt) => this.setState({ massEntryHour: evt.target.value })}
                />
                {isEmpty(massEntryHour) && (<p style={{ color: 'red' }}>This is required</p>)}
              </div>
              <div className="col-lg-6 col-md-6 col-xl-6 col-sm-12">
                <label htmlFor="exampleInputEmail1">Comments*:</label>
                <textarea
                  onChange={this.handleMassEntryComments}
                  type="text"
                  className="form-control"
                  placeholder="Enter Activity Description"
                  value={massEntryComments}
                />
                {isEmpty(massEntryComments) && (<p style={{ color: 'red' }}>This is required</p>)}
              </div>
            </div>
          </Modal.Body>
          <Modal.Footer>
            <div className="col-12 row mt-2">
              <p className="small_font text-dark text-center mx-auto mb-2">Are you sure you would like to continue with this mass time entry?</p>
              <div className="col-6">
                <button
                  onClick={() => this.cancelMassEntry()}
                  className="button resend-btn background-red px-2 float-left"
                >
                  No, Cancel
                </button>
              </div>
              <div className="col-6">
                <button
                  disabled={isEmpty(massEntryComments) || isEmpty(massEntryDate) || isEmpty(massEntryHour)}
                  className="button resend-btn float-right px-4"
                  onClick={() => this.onSubmitMassTimeEntry()}
                >
                  Yes, Continue
                </button>
              </div>
            </div>
          </Modal.Footer>
        </Modal>
        }
        {/** Modal for user approval to approve or reject a timesheet */}
        <Modal
          scrollable={true}
          size="md"
          onHide={this.closeUserApprovalForm}
          show={displayUserApprovalForm}
        >
          <Modal.Header closeButton className="h6 background-green1">
            <Modal.Title className="h6 text-white small_font" id="contained-modal-title-vcenter">
              {`User Approval Form`}
            </Modal.Title>
          </Modal.Header>
          <Modal.Body className="show-grid small_font px-5">
            <p className="xs_font text-dark text-center">
              {`You are about to ${isEqual(TimesheetOperation.approve, selectedTimesheetOperation) ? 'approve' : 'reject'} ${empName}'s timesheet. Please confirm to continue`}
            </p>
            <p className="small_font font-weight-bold text-center">
              {displayMassEntryDate}
            </p>
            {
              isUserCommentRequired && (
                <div className="form-group row">
                  <div className="col-lg-3 col-md-3 col-xl-3 col-sm-3 text-right">
                    <label htmlFor="exampleInputEmail1">Comment :</label>
                  </div>
                  <div className="col-lg-9 col-md-9 col-xl-9 col-sm-9">
                    <textarea className="form-control" value={userComments} onChange={this.handleUserComments}></textarea>
                    {isEmpty(userComments) && (<p className="mb-0" style={{ color: 'red' }}>This is required</p>)}
                  </div>
                </div>
              )
            }
          </Modal.Body>
          <Modal.Footer>
            <div className="col-12 row mt-2">
              <div className="col-6">
                <button
                  onClick={this.closeUserApprovalForm}
                  className="button resend-btn background-red px-2 float-left"
                >
                  No, Cancel
                </button>
              </div>
              <div className="col-6">
                <button
                  disabled={isUserCommentRequired && isEmpty(userComments)}
                  onClick={this.completeTimesheetOperation}
                  className="button resend-btn float-right px-4"
                >
                  Yes, Confirm
                </button>
              </div>
            </div>
          </Modal.Footer>
        </Modal>
        {/** Modal for archivable and archived feature */}
        <Modal
          scrollable={true}
          size="md"
          onHide={this.closeWarningModal}
          show={displayWarningModal}
        >
          <Modal.Header closeButton className="h6 background-green1">
            <Modal.Title className="h6 text-white small_font" id="contained-modal-title-vcenter">
              {`Warning`}
            </Modal.Title>
          </Modal.Header>
          <Modal.Body className="show-grid small_font px-5">
            <p className="xs_font text-dark text-center">
              {`Please confirm to continue`}
            </p>
            <p className="small_font font-weight-bold text-center">
              {displayMassEntryDate}
            </p>
          </Modal.Body>
          <Modal.Footer>
            <div className="col-12 row mt-2">
              <div className="col-6">
                <button
                  onClick={this.closeWarningModal}
                  className="button resend-btn background-red px-2 float-left"
                >
                  No, Cancel
                </button>
              </div>
              <div className="col-6">
                <button
                  onClick={this.updateTimesheetStatusToArchivedOrArchivable}
                  className="button resend-btn float-right px-4"
                >
                  Yes, Confirm
                </button>
              </div>
            </div>
          </Modal.Footer>
        </Modal>
        {/** Modal to show information to user */}
        <Modal
          scrollable={true}
          size="md"
          onHide={this.closeInformationModal}
          show={this.state.displayInformationModal}
        >
          <Modal.Header closeButton className="h6 background-green1">
            <Modal.Title className="h6 text-white small_font" id="contained-modal-title-vcenter">
              {`Information`}
            </Modal.Title>
          </Modal.Header>
          <Modal.Body className="show-grid small_font px-5">
            <p className="xs_font text-dark text-center">
              {this.state.contentForInformationModal}
            </p>
          </Modal.Body>
          <Modal.Footer>
            <div className="col-12 row mt-2">
              <div className="col-6">
              </div>
              <div className="col-6">
                <button
                  onClick={this.closeInformationModal}
                  className="button resend-btn float-right px-4"
                >
                  Ok
                </button>
              </div>
            </div>
          </Modal.Footer>
        </Modal>
      </div>
    )
  }
}

export default LoadTimesheetsTable;