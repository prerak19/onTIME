import { apiGet, getBlobImage, uploadImage } from "../Api";

export async function signImageUpload(imageData, savedFuture = true) {
    let imageId = '';
    const signImageFile = new File([imageData], "image.jpeg", { type: "image/png" });
    const userid = localStorage.userid;
    let requestDetails3 = { method: `employees/images/sig-init?id=${userid}&itemtype=user_signature&reuse=${savedFuture ? 0 : 1} ` };
    let signImage = new FormData();
    if (signImageFile) {
        signImage.append("file", signImageFile);
    }
    await uploadImage(requestDetails3, signImage).then((res) => {
        if (res.status === 200 && res.data && res.data.returnValue) {
            imageId = res.data.returnValue;
        }
    }).catch(error => {
        console.log(error)
    });
    return imageId;
}

export async function getImageReuse(imageId) {
    let signatureImage = '';
    const requestDetails = { method: `employees/images/${imageId}` };
    await apiGet(requestDetails).then((response) => {
        if (response.data) {
            signatureImage = response.data;
        }
    }).catch(error => {
        console.log(error);
    });
    return signatureImage;
}

export async function getReuseSignInit(Init = false) {
    let obj = {
        imageId: "",
        signatureImage: "",
    };
    const requestDetails = { method: `employees/images/reuse-${Init ? 'init' : 'sig'}?uid=${localStorage.userid}` };
    await apiGet(requestDetails, true, false).then(async (res) => {
        if (res.status === 200 && res.data && res.data.returnValue) {
            obj.imageId = Number(res.data.returnValue);
            obj.signatureImage = await getImageReuse(obj.imageId)
        }
    }).catch((err) => {
        console.log(err);
    })
    return obj;
}