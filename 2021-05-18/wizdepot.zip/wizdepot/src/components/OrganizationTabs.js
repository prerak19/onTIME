import React, { Component } from 'react';
import moment from 'moment';
import DatePicker from "react-datepicker";
import "react-datepicker/dist/react-datepicker.css";
import 'bootstrap/dist/css/bootstrap.min.css';
import 'bs-stepper/dist/css/bs-stepper.min.css';
import Stepper from 'bs-stepper';
import {Modal,Container,Toast,Row,Col} from "react-bootstrap";
import { confirmAlert } from 'react-confirm-alert'; 
import 'react-confirm-alert/src/react-confirm-alert.css'; 
import {apiPost,apiGet,apiPut,apiDelete,apiPostFile} from '../Api.js';

class OrganizationTabs extends Component {
  constructor(props) {
    super(props);
    this.componentRef = React.createRef();
    this.state = {
      show: false,
      close: false,
      viewshow: false,
      editshow: false,
      supershow: false,
      editsupershow: false,
      name: 'React',
      remove: false,
      edit: true,
      editable: true,
      timeedit: true,
      timeeditable: true,
      reset: false,
      superreset: false,
      existing: true,
      existingfields: false,
      existingfname: '',
      existinglname: '',
      existingemail: '',
      existingloginname: '',
      existingpass: '',
      editdetails:[],
      audetails:[],
      fields: {},
      errors: {},
      error_message: '',
      aufields: {},
      auerrors: {},
      auerror_message: '',
      payStartDate: '',
      payEndDate1: '',
      adminusers:[],
      employeesList:[],
      userID:'',
      resetname:'',
      file:{},
      imageurl:''
    };
  } 
  async componentDidMount() { 
    this.stepper = new Stepper(document.querySelector('#stepper1'), {
      linear: false,
      animation: true
    })  
    await this.getFunction();
    console.log(localStorage.getItem('usertype'))
    this.getAdminUsers(); 
    this.getEmployees();
  } 

  handleFormChange = (e) => {
    let editdetails = this.state.editdetails;
    let errors = this.state.errors;
    editdetails[e.target.name] = e.target.value;
    errors[e.target.name] = "form-control is-valid";
    this.setState({
      editdetails
    });
  }
  handleAuFormChange = (e) => {
    let audetails = this.state.audetails;
    let auerrors = this.state.auerrors;
    audetails[e.target.name] = e.target.value;
    auerrors[e.target.name] = "form-control is-valid";
    this.setState({
      audetails
    });
  }
  validateForm() {
    let editdetails = this.state.editdetails;
    let errors = {};
    let formIsValid = true;

    if (!editdetails["name"]) {
      formIsValid = false;
      errors["name"] = "form-control is-invalid";
    }
    if(!formIsValid){
      this.setState({
        error_message: 'Please fill all * Required Fields!'
      });
      this.componentRef.current.scrollTop = 0;
      window.scroll({top: 0, left: 0, behavior: 'smooth' })
    }else{
      this.setState({
        error_message: ''
      });
    }
    
    this.setState({
      errors: errors
    });
    return formIsValid;
  }
  validateAuForm() {
    let audetails = this.state.audetails;
    let auerrors = {};
    let auformIsValid = true;

    if (!audetails["firstName"]) {
      auformIsValid = false;
      auerrors["firstName"] = "form-control is-invalid";
    }
    if (!audetails["lastName"]) {
      auformIsValid = false;
      auerrors["lastName"] = "form-control is-invalid";
    }
    if (!audetails["userName"]) {
      auformIsValid = false;
      auerrors["userName"] = "form-control is-invalid";
    }
    if (!audetails["email"]) {
      auformIsValid = false;
      auerrors["email"] = "form-control is-invalid";
    }
    if (!audetails["password"]) {
      auformIsValid = false;
      auerrors["password"] = "form-control is-invalid";
    }
    if(!auformIsValid){
      this.setState({
        auerror_message: 'Please fill all * Required Fields!'
      });
      window.scroll({top: 0, left: 0, behavior: 'smooth' })
    }else{
      this.setState({
        auerror_message: ''
      });
    }
    
    this.setState({
      auerrors: auerrors
    });
    return auformIsValid;
  }
  uploadPicture = (e) => {
    console.log(e.target.files[0]);
    this.setState({
        imageurl : URL.createObjectURL(e.target.files[0]),
        file : e.target.files[0]
    })
  };
  editRecord = (e) => {
    if (this.validateForm()) {
      let requestDetails3 = { 
        method:'employees/images?id='+e.currentTarget.dataset.tag+'&phototype=org_logo',
        params:{
          id : e.currentTarget.dataset.tag,
          phototype : 'org_logo',
          file: this.state.file
        }
      };
      console.log(this.state.file);
      apiPostFile(requestDetails3, true).then((response)=> {
      }).catch(error => {
        console.log(error)
      });

      let requestDetails = { 
        method:'organizations/'+localStorage.orgid+'?user_id='+localStorage.userid,
        params:{
          id : e.currentTarget.dataset.tag,
          address1 : this.state.editdetails.address1,
          address2 : this.state.editdetails.address2,
          city : this.state.editdetails.city,
          state : this.state.editdetails.state,
          country : this.state.editdetails.country,
          zip : this.state.editdetails.zip,
          phone : this.state.editdetails.phone,
          email : this.state.editdetails.email,
          fax : this.state.editdetails.fax,
          website : this.state.editdetails.website,
          recPeriod : this.state.editdetails.recPeriod,
          dateFormat : this.state.editdetails.dateFormat,
          timeFormat : this.state.editdetails.timeFormat,
          weekStartday : this.state.editdetails.weekStartday,
          payFreq : this.state.editdetails.payFreq,
          payStartDate : moment(this.state.payStartDate).format('YYYY-MM-DD'),
          payEndDate : moment(this.state.payEndDate).format('YYYY-MM-DD'),
          roundInterval : this.state.editdetails.roundInterval
        }
      };
      apiPut(requestDetails, true).then((response)=> { 
        this.setState({ edit: true,editable:true })
        this.getFunction();
      }).catch(error => {
        console.log(error)
      });    
    }
  }
  editRecord1 = (e) => {
    if (this.validateForm()) {
      let requestDetails = { 
        method:'organizations/'+localStorage.orgid+'?user_id='+localStorage.userid,
        params:{
          id : e.currentTarget.dataset.tag,
          address1 : this.state.editdetails.address1,
          address2 : this.state.editdetails.address2,
          city : this.state.editdetails.city,
          state : this.state.editdetails.state,
          country : this.state.editdetails.country,
          zip : this.state.editdetails.zip,
          phone : this.state.editdetails.phone,
          email : this.state.editdetails.email,
          fax : this.state.editdetails.fax,
          website : this.state.editdetails.website,
          recPeriod : this.state.editdetails.recPeriod,
          dateFormat : this.state.editdetails.dateFormat,
          timeFormat : this.state.editdetails.timeFormat,
          weekStartday : this.state.editdetails.weekStartday,
          payFreq : this.state.editdetails.payFreq,
          payStartDate : moment(this.state.payStartDate).format('YYYY-MM-DD'),
          payEndDate : moment(this.state.payEndDate).format('YYYY-MM-DD'),
          roundInterval : this.state.editdetails.roundInterval
        }
      };
      apiPut(requestDetails, true).then((response)=> { 
        this.setState({ timeedit: true,timeeditable:true })
        this.getFunction();
      }).catch(error => {
        console.log(error)
      });    
    }
  }
  addAdminUserProcess = (d) => {
    this.setState({existing: true});
    this.setState({existingfields: false});
    this.setState({ show: true });
    this.setState({ audetails: [] });
  }
  addSuperUserProcess = (d) => {
    this.setState({existing: true});
    this.setState({existingfields: false});
    this.setState({ supershow: true });
    this.setState({ audetails: [] });
  }
  addAdminUserRecord = (e) => {
    if (this.validateAuForm()) {
      let requestDetails = { 
        method:'adminusers',
        params:{
          type : "adminUser",
          org_id : localStorage.orgid,
          adminType : 50,
          userName : this.state.audetails.userName,
          password : this.state.audetails.password,
          firstName : this.state.audetails.firstName,
          lastName : this.state.audetails.lastName,
          email : this.state.audetails.email,
          rightsSuper : this.state.audetails.rightsSuper,
          rightsPolicy : this.state.audetails.rightsPolicy,
          rightsEmployee : this.state.audetails.rightsEmployee,
          rightsReport : this.state.audetails.rightsReport
        }
      };
      apiPost(requestDetails, true).then((response)=> { 
        this.setState({ show: false });
        this.getAdminUsers();
      }).catch(error => {
        console.log(error)
      });    
    }
  }
  addSuperUserRecord = (e) => {
    if (this.validateAuForm()) {
      if(this.state.existingfields === true){
        let requestDetails = { 
          method:'adminusers/'+this.state.userID,
          params:{
            userID : this.state.userID,
            adminType : 80 ,
            userName : this.state.audetails.userName,
            password : this.state.audetails.password,
            firstName : this.state.audetails.firstName,
            lastName : this.state.audetails.lastName,
            email : this.state.audetails.email,
            rightsSuper : this.state.audetails.rightsSuper,
            rightsPolicy : this.state.audetails.rightsPolicy,
            rightsEmployee : this.state.audetails.rightsEmployee,
            rightsReport : this.state.audetails.rightsReport
          }
        };
        apiPut(requestDetails, true).then((response)=> { 
          this.setState({ supershow: false });
          this.getAdminUsers();
        }).catch(error => {
          console.log(error)
        }); 
      }else{
        let requestDetails = { 
          method:'adminusers',
          params:{
            type : "adminUser",
            org_id : localStorage.orgid,
            adminType : 80,
            userName : this.state.audetails.userName,
            password : this.state.audetails.password,
            firstName : this.state.audetails.firstName,
            lastName : this.state.audetails.lastName,
            email : this.state.audetails.email,
            rightsSuper : this.state.audetails.rightsSuper,
            rightsPolicy : this.state.audetails.rightsPolicy,
            rightsEmployee : this.state.audetails.rightsEmployee,
            rightsReport : this.state.audetails.rightsReport
          }
        };
        apiPost(requestDetails, true).then((response)=> { 
          this.setState({ supershow: false });
          this.getAdminUsers();
        }).catch(error => {
          console.log(error)
        }); 
      }
      
         
    }
  }
  editAdminUserProcess = (d) => {
    this.setState({ editshow: true });
    this.setState({ audetails: [] });
    this.setState({existing: true});
    this.setState({existingfields: false});
    let requestDetails = { 
      method:'adminusers/'+d.currentTarget.dataset.tag,
      params:{}
    };
    apiGet(requestDetails, true).then((response)=> { 
      this.setState({ audetails: response.data });   
    }
    ).catch(error => {
      console.log(error)
    }); 
  }
  editSuperUserProcess = (d) => {
    this.setState({ editsupershow: true });
    this.setState({ audetails: [] });
    this.setState({existing: true});
    this.setState({existingfields: false});
    let requestDetails = { 
      method:'adminusers/'+d.currentTarget.dataset.tag,
      params:{}
    };
    apiGet(requestDetails, true).then((response)=> { 
      this.setState({ audetails: response.data });   
    }
    ).catch(error => {
      console.log(error)
    }); 
  }
  editSuperUserRecord = (e) => {
    if (this.validateAuForm()) {
        let requestDetails = { 
          method:'adminusers/'+this.state.audetails.userID,
          params:{
            userID : this.state.audetails.userID,
            adminType : 80,
            userName : this.state.audetails.userName,
            password : this.state.audetails.password,
            firstName : this.state.audetails.firstName,
            lastName : this.state.audetails.lastName,
            email : this.state.audetails.email,
            rightsSuper : this.state.audetails.rightsSuper,
            rightsPolicy : this.state.audetails.rightsPolicy,
            rightsEmployee : this.state.audetails.rightsEmployee,
            rightsReport : this.state.audetails.rightsReport
          }
        };
        apiPut(requestDetails, true).then((response)=> { 
          this.setState({ editsupershow: false });
          this.getAdminUsers();
        }).catch(error => {
          console.log(error)
        });
    }
  }
  editAdminUserRecord = (e) => {
    if (this.validateAuForm()) {
        let requestDetails = { 
          method:'adminusers/'+this.state.audetails.userID,
          params:{
            userID : this.state.audetails.userID,
            adminType : 50,
            userName : this.state.audetails.userName,
            password : this.state.audetails.password,
            firstName : this.state.audetails.firstName,
            lastName : this.state.audetails.lastName,
            email : this.state.audetails.email,
            rightsSuper : this.state.audetails.rightsSuper,
            rightsPolicy : this.state.audetails.rightsPolicy,
            rightsEmployee : this.state.audetails.rightsEmployee,
            rightsReport : this.state.audetails.rightsReport
          }
        };
        apiPut(requestDetails, true).then((response)=> { 
          this.setState({ editshow: false });
          this.getAdminUsers();
        }).catch(error => {
          console.log(error)
        });
    }
  }
  resetPassword = (e) => {
    this.setState({ reset: true,audetails:[],resetname:e.currentTarget.dataset.tag });
    let requestDetails = { 
      method:'adminusers/'+e.currentTarget.dataset.tagid,
      params:{}
    };
    apiGet(requestDetails, true).then((response)=> { 
      this.setState({ audetails: response.data });   
    }
    ).catch(error => {
      console.log(error)
    });
  }
  resetPasswordProcess = (d) => {
    if(this.state.audetails.newpass == this.state.audetails.pass){
      let requestDetails = { 
        method:'adminusers/'+this.state.audetails.userID,
        params:{
          userID : this.state.audetails.userID,
          adminType : this.state.audetails.adminType,
          userName : this.state.audetails.userName,
          password : this.state.audetails.pass,
          firstName : this.state.audetails.firstName,
          lastName : this.state.audetails.lastName,
          email : this.state.audetails.email,
          rightsSuper : this.state.audetails.rightsSuper,
          rightsPolicy : this.state.audetails.rightsPolicy,
          rightsEmployee : this.state.audetails.rightsEmployee,
          rightsReport : this.state.audetails.rightsReport
        }
      };
      apiPut(requestDetails, true).then((response)=> { 
        this.setState({ reset: false });
      }).catch(error => {
        console.log(error)
      }); 
    }else{
      this.setState({ auerror_message: 'Password does not match with Confirm Password!' });
    }    
  }
deleteProcess = (e) => {
    var dv = e.currentTarget.dataset.tag;
    confirmAlert({
      customUI: ({ onClose }) => {
        return (
          <div className='custom-ui'>
            <h3>Are you sure?</h3>
            <p>You want to delete this?</p>            
            <button data-tag={dv} onClick={() => {
            this.deleteRecord({dv});
            onClose();
          }}>Yes, Delete it</button>
            <button onClick={onClose}>No, Cancel</button>
          </div>
        );
      }
    });
  }
  deleteRecord = (e) => {
    let requestDetails = { 
      method:'adminusers/'+e.dv,
      params:{}
    };
    apiDelete(requestDetails, true).then((response)=> {
      this.getAdminUsers();
    }).catch(error => {
      console.log(error)
    });  
  }
  getFunction = (e) => {
    let requestDetails = { 
      method:'organizations/'+localStorage.orgid,
      params:{user_id: localStorage.userid}
    };
    apiGet(requestDetails, true).then((response)=> {
      console.log(response)
      this.setState({ editdetails: response.data });   
      this.setState({ payStartDate: response.data.payStartDate }); 
      this.setState({ payEndDate: response.data.payEndDate });             
    }).catch(error => {
      console.log(error)
    });
  }
  getAdminUsers = (e) => {
    let requestDetails = { 
      method:'adminusers/all/'+localStorage.orgid,
      params:{}
    };
    apiGet(requestDetails, true).then((response)=> {
      let arr = [];
      let arr1 = [];
      { Array.isArray(response.data) &&  response.data.map((item,i) =>{
        if(item.adminType == 50){
          arr.push(item);
        }else{
          arr1.push(item);
        }           
      }
      )}
      this.setState({ adminusers: arr });
      this.setState({ superusers: arr1 });
      console.log(this.state.adminusers);         
    }).catch(error => {
      console.log(error)
    });
  }
  getEmployees = (e) => {
    this.setState({ employeesList: [] });
    let requestDetails1 = { 
      method:'employees/all/'+localStorage.orgid,
      params:{}
    };
    apiPost(requestDetails1, true).then((response)=> {       
      this.setState({ employeesList: response.data.users });
    }).catch(error => {
      console.log(error)
    });
  }
  handleCheckbox = (e) => {
    this.setState({existing: !this.state.existing});
    this.setState({existingfields: !this.state.existingfields});
  } 
  changeExistingEmp = (d) => {
    let requestDetails = { 
      method:'employees/'+d.target.value,
      params:{}
    };
    apiGet(requestDetails, true).then((response)=> {
      this.setState({ audetails: response.data, userID:d.target.value }); 
    }).catch(error => {
      console.log(error)
    });
  }

  onSubmit(e) {
    e.preventDefault()
  }

  submit = () => {
    confirmAlert({
      customUI: ({ onClose }) => {
        return (
          <div className='custom-ui'>
            <h3>Are you sure?</h3>
            <p>You want to delete?</p>            
            <button
              onClick={() => {
                onClose();
              }}
            >
              Yes, Delete
            </button>
            <button onClick={onClose}>No, Cancel</button>
          </div>
        );
      }
    });
  };
  handleChange = (date) => {
    this.setState({
      payStartDate: date
    })
  }
  handleChange1 = (date) => {
    this.setState({
      payEndDate: date
    })
  }
  ExampleCustomInput = ({ value, onClick }) => (
    <div class="inner-addon right-addon">
      <i class="fa fa-calendar"></i>
      <input disabled={this.state.timeeditable} onClick={onClick} value={value} type="text" class="example-custom-input form-control" placeholder="Select Date" name="payStartDate" />
    </div>
  );
  ExampleCustomInput1 = ({ value, onClick }) => (
    <div class="inner-addon right-addon">
      <i class="fa fa-calendar"></i>
      <input disabled={this.state.timeeditable} onClick={onClick} value={value} type="text" class="example-custom-input form-control" placeholder="Select Date" name="payEndDate" />
    </div>
  );
  render() {
    return (
      <div>
        <div id="stepper1" className="bs-stepper">
          <div className="bs-stepper-header">
            <div className="step" data-target="#test-l-1">
              <button className="step-trigger">
                <span className="bs-stepper-label">Organization Profile</span>
              </button>
            </div>
            <div className="step" data-target="#test-l-2">
              <button className="step-trigger">
                <span className="bs-stepper-label">Date/Time Preferences</span>
              </button>
            </div>
            <div className="step" data-target="#test-l-3">
              <button className="step-trigger">
                <span className="bs-stepper-label">Manage Super/Admin User</span>
              </button>
              
            </div>
          </div>
          <div className="bs-stepper-content">
            <form onSubmit={this.onSubmit}>
              <div id="test-l-1" className="content  pl-1 width-80 small_font">
                <div className="form-group row">
                  <div className="col-xl-6 col-lg-6 col-md-6 col-sm-12">
                  <label for="exampleInputEmail1">Organization Name*</label>
                  <input type="text" value={this.state.editdetails.name}  name="name" onChange={this.handleFormChange} disabled='disabled' className="form-control" id="exampleInputEmail1" placeholder="Enter Organization Name" />
                  </div>
                  <div className="col-xl-6 col-lg-6 col-md-6 col-sm-12">
                    <label>TIN Number*</label>
                    <input type="text" value={this.state.editdetails.tin}  name="tin" onChange={this.handleFormChange} disabled='disabled' className="form-control" placeholder="TIN Number"/>
                  </div>
                </div>
                <div className="form-group">
                  <label for="exampleInputEmail1">Upload Logo</label>
                  <Row className="">
                    <Col lg="3" md="3" sm="12" className="mt-1">
                        <img alt="Banner" class="profile-img"  width="45%"
                        src={this.state.imageurl ? this.state.imageurl : require("./assets/img/user-default.png").default} />                        
                    </Col>
                    <Col lg="3" md="3" sm="12" className="mt-3">
                        <input type="file" name="image" onChange={this.uploadPicture}/>
                        <p className="mt-1">File size limit: 1 MB</p>
                    </Col>
                </Row>
                </div>
                <div className="form-group">
                  <label>Address*</label>
                  <input type="text" value={this.state.editdetails.address1}  name="address1" onChange={this.handleFormChange} disabled={this.state.editable} className="form-control" placeholder="Enter Address" />
                </div>
                <div className="form-group">
                  <label>Address 2</label>
                  <input type="text" value={this.state.editdetails.address2}  name="address2" onChange={this.handleFormChange} disabled={this.state.editable} className="form-control" placeholder="Enter Address 2" />
                </div>
                <div className="row form-group">
                  <div className="col-xl-4 col-lg-4 col-md-4 col-sm-12">
                    <label>City*</label>
                      <input type="text" value={this.state.editdetails.city}  name="city" onChange={this.handleFormChange} disabled={this.state.editable} className="form-control" placeholder="City"/>
                  </div>
                  <div className="col-xl-4 col-lg-4 col-md-4 col-sm-12">
                  <label>State*</label>
                      <select placeholder="State" value={this.state.editdetails.state}  name="state" onChange={this.handleFormChange} disabled={this.state.editable} className="form-control">
                          <option>State</option>
                          <option value='AL'>Alabama - AL</option>
                          <option value='AK'>Alaska - AK</option>
                          <option value='AL'>Alabama - AL</option>
                          <option value='AZ'>Arizona - AZ</option>
                          <option value='AR'>Arkansas - AR</option>
                          <option value='CA'>California - CA</option>
                          <option value='CO'>Colorado - CO</option>
                          <option value='CT'>Connecticut - CT</option>
                          <option value='DE'>Delaware - DE</option>
                          <option value='DC'>District of Columbia - DC</option>
                          <option value='FL'>Florida - FL</option>
                          <option value='GA'>Georgia - GA</option>
                          <option value='HI'>Hawaii - HI</option>
                          <option value='ID'>Idaho - ID</option>
                          <option value='IL'>Illinois - IL</option>
                          <option value='IN'>Indiana - IN</option>
                          <option value='IA'>Iowa - IA</option>
                          <option value='KS'>Kansas - KS</option>
                          <option value='KY'>Kentucky - KY</option>
                          <option value='LA'>Louisiana - LA</option>
                          <option value='ME'>Maine - ME</option>
                          <option value='MD'>Maryland - MD</option>
                          <option value='MA'>Massachusetts - MA</option>
                          <option value='MI'>Michigan - MI</option>
                          <option value='MN'>Minnesota - MN</option>
                          <option value='MS'>Mississippi - MS</option>
                          <option value='MO'>Missouri - MO</option>
                          <option value='MT'>Montana - MT</option>
                          <option value='NE'>Nebraska - NE</option>
                          <option value='NV'>Nevada - NV</option>
                          <option value='NH'>New Hampshire - NH</option>
                          <option value='NJ'>New Jersey - NJ</option>
                          <option value='NM'>New Mexico - NM</option>
                          <option value='NY'>New York - NY</option>
                          <option value='NC'>North Carolina - NC</option>
                          <option value='ND'>North Dakota - ND</option>
                          <option value='OH'>Ohio - OH</option>
                          <option value='OK'>Oklahoma - OK</option>
                          <option value='OR'>Oregon - OR</option>
                          <option value='PA'>Pennsylvania - PA</option>
                          <option value='PR'>Puerto Rico - PR</option>
                          <option value='RI'>Rhode Island - RI</option>
                          <option value='SC'>South Carolina - SC</option>
                          <option value='SD'>South Dakota - SD</option>
                          <option value='TN'>Tennessee - TN</option>
                          <option value='TX'>Texas - TX</option>
                          <option value='UT'>Utah - UT</option>
                          <option value='VT'>Vermont - VT</option>
                          <option value='VA'>Virginia - VA</option>
                          <option value='WA'>Washington - WA</option>
                          <option value='WV'>West Virginia - WV</option>
                          <option value='WI'>Wisconsin - WI</option>
                          <option value='WY'>Wyoming - WY</option>
                      </select>
                  </div>
                  <div className="col-xl-4 col-lg-4 col-md-4 col-sm-12">
                    <label>Zip Code*</label>
                    <input type="text" value={this.state.editdetails.zip}  name="zip" onChange={this.handleFormChange} disabled={this.state.editable} className="form-control" placeholder="Zip Code"/>
                  </div>
                </div>
                <div className="row form-group">
                  <div className="col-xl-4 col-lg-4 col-md-4 col-sm-12">
                    <label>Country*</label>
                      <input type="text" value={this.state.editdetails.country}  name="country" onChange={this.handleFormChange} disabled={this.state.editable} className="form-control" placeholder="Country"/>
                  </div>
                  <div className="col-xl-4 col-lg-4 col-md-4 col-sm-12">
                    <label>Phone Number*</label>
                    <input type="text" value={this.state.editdetails.phone}  name="phone" onChange={this.handleFormChange} disabled={this.state.editable} className="form-control" placeholder="Phone Number"/>  
                  </div>
                  <div className="col-xl-4 col-lg-4 col-md-4 col-sm-12">
                    <label>Fax Number</label>
                    <input type="text" value={this.state.editdetails.fax}  name="fax" onChange={this.handleFormChange} disabled={this.state.editable} className="form-control" placeholder="Fax Number"/>
                  </div>
                </div>
                <div className="row form-group">
                  <div className="col-xl-4 col-lg-4 col-md-4 col-sm-12">
                    <label>Email*</label>
                      <input type="email" value={this.state.editdetails.email}  name="email" onChange={this.handleFormChange} disabled={this.state.editable} className="form-control" placeholder="Email"/>
                  </div>
                  <div className="col-xl-4 col-lg-4 col-md-4 col-sm-12">
                    <label>Website</label>
                    <input type="text" value={this.state.editdetails.website}  name="website" onChange={this.handleFormChange} disabled={this.state.editable} className="form-control" placeholder="Website"/>  
                  </div>
                </div>
                <ul style={this.state.edit === true ? {} : { display: 'none' }} className="row form-group mr-0 mt-4 pr-0 list-inline pull-right">
                  <li><button  onClick={() => this.setState({ edit: false,editable:false })} className="button resend-btn py-2 px-4 m-0 mr-2">Edit</button></li>
                </ul>
                <ul style={this.state.edit === true ? { display: 'none' } : {}} className="row form-group mr-0 mt-4 pr-0 list-inline pull-right">
                  <li><button  onClick={() => this.setState({ edit: true,editable:true })} className="button cancel-btn py-2 px-4 m-0 mr-2">Cancel</button></li>
                  <li><button data-tag={this.state.editdetails.id} onClick={this.editRecord} className="button resend-btn py-2 px-4 m-0">Save Changes</button></li>
                </ul>
              </div>
              <div id="test-l-2" className="content  pl-1 width-80 small_font">
                <div className="row form-group">
                  <div className="col-xl-6 col-lg-6 col-md-6 col-sm-12">
                    <label>Timesheet Recording Period*</label>
                      <select value={this.state.editdetails.recPeriod}  name="recPeriod" onChange={this.handleFormChange} placeholder="Select" disabled={this.state.timeeditable} className="form-control">
                          <option value='Weekly'>Weekly</option>
                          <option value='Bi-Weekly'>Bi-Weekly</option>
                      </select>
                  </div>
                </div>
                <div className="row form-group">
                  <div className="col-xl-6 col-lg-6 col-md-6 col-sm-12">
                    <label>Date Format*</label>
                      <select value={this.state.editdetails.dateFormat}  name="dateFormat" onChange={this.handleFormChange} placeholder="Select" disabled={this.state.timeeditable} className="form-control">
                          <option value='mm/dd/yyyy'>mm/dd/yyyy</option>
                          <option value='dd-mm-yyyy'>dd-mm-yyyy</option>
                      </select>
                  </div>
                  <div className="col-xl-6 col-lg-6 col-md-6 col-sm-12">
                    <label>Time Format*</label>
                      <select value={this.state.editdetails.timeFormat}  name="timeFormat" onChange={this.handleFormChange} placeholder="Select" disabled={this.state.timeeditable} className="form-control">
                          <option value='HH:MM AM/PM'>HH:MM AM/PM</option>
                          <option value='HH:MM:SS AM/PM'>HH:MM:SS AM/PM</option>
                      </select>
                  </div>
                </div>
                <div className="row form-group">
                  <div className="col-xl-6 col-lg-6 col-md-6 col-sm-12">
                    <label>Day of the week calendar starts on*</label>
                      <select value={this.state.editdetails.weekStartday}  name="weekStartday" onChange={this.handleFormChange} placeholder="Select" disabled={this.state.timeeditable} className="form-control">
                          <option value='Sunday'>Sunday</option>
                          <option value='Monday'>Monday</option>
                          <option value='Tuesday'>Tuesday</option>
                          <option value='Wednesday'>Wednesday</option>
                          <option value='Thursday'>Thursday</option>
                          <option value='Friday'>Friday</option>
                          <option value='Saturday'>Saturday</option>
                      </select>
                  </div>
                  <div className="col-xl-6 col-lg-6 col-md-6 col-sm-12">
                      <label>Pay Period Frequency*</label>
                      <select value={this.state.editdetails.payFreq}  name="payFreq" onChange={this.handleFormChange} placeholder="Select" disabled={this.state.timeeditable} className="form-control">
                          <option value='Bi-Weekly'>Bi-Weekly(26/year)</option>
                          <option value='Semi-Monthly'>Semi-Monthly(24/year)</option>
                      </select>
                  </div>
                </div>
                <div className="row form-group">
                  <div className="col-xl-12 col-lg-12 col-md-12 col-sm-12">
                    <label>Current Payroll Period*</label>
                  </div>
                  <div className="col-xl-6 col-lg-6 col-md-6 col-sm-12">
                    <label>Start Date*</label>
                    <DatePicker selected={this.state.payStartDate ? new Date(this.state.payStartDate) : null}
          name="payStartDate" className="form-control" customInput={<this.ExampleCustomInput />} 
           onChange={ this.handleChange } className="form-control col-12"  name="payStartDate" 
          dateFormat="yyyy-MM-dd"/>
          </div>
                  <div className="col-xl-6 col-lg-6 col-md-6 col-sm-12">
                    <label>End Date*</label>
                    <DatePicker selected={this.state.payEndDate ? new Date(this.state.payEndDate) : null}
          name="payEndDate" className="form-control" customInput={<this.ExampleCustomInput1 />} 
           onChange={ this.handleChange1 } className="form-control col-12"   name="payEndDate"
          dateFormat="yyyy-MM-dd"/>
                  </div>
                </div>
                <ul style={this.state.timeedit === true ? {} : { display: 'none' }} className="row form-group mr-0 mt-4 pr-0 list-inline pull-right">
                  <li><button  onClick={() => this.setState({ timeedit: false,timeeditable:false })} className="button resend-btn py-2 px-4 m-0 mr-2">Edit</button></li>
                </ul>
                <ul style={this.state.timeedit === true ? { display: 'none' } : {}} className="row form-group mr-0 mt-4 pr-0 list-inline pull-right">
                  <li><button  onClick={() => this.setState({ timeedit: true,timeeditable:true })} className="button cancel-btn py-2 px-4 m-0 mr-2">Cancel</button></li>
                  <li><button   data-tag={this.state.editdetails.id} onClick={this.editRecord1} className="button resend-btn py-2 px-4 m-0">Save Changes</button></li>
                </ul>
              </div>
              <div id="test-l-3" className="content pl-1 small_font">
                <h6>Super User Account Management</h6>
                <label>Add Super User<button type="button" onClick={this.addSuperUserProcess} className="button resend-btn mt-1">Add</button></label>
               
                <p className="mt-1 font-weight-bold">Manage Super User Information and Rights</p>
                { Array.isArray(this.state.superusers) &&  this.state.superusers.map((item,i) =>{
                  return  <div className="row form-group border-bottom" key={i}>
                    <div className="col-xl-3 col-lg-3 col-md-3 col-sm-12">
                      <label>{item.firstName +' '+ item.lastName} {(item.adminType === 90) ? '(Root User)' : '' }</label>
                      <p><span className="link-style pl-0" data-tag={item.userID} onClick={this.editSuperUserProcess}>Edit</span> | 
                      { (item.adminType === 80) ?
                        <span>
                              <span className="link-style" onClick={this.submit}>Change to Administrator</span> | 
                              <span className="link-style" data-tag={item.userID} onClick={this.deleteProcess}>Remove</span> | 
                        </span> 
                        : <span></span>                                               
                      } 
                      <span className="link-style" data-tagid={item.userID} data-tag={item.userName} onClick={this.resetPassword}>Reset Password</span></p>                  
                    </div>
                    <div className="col-xl-9 col-lg-9 col-md-9 col-sm-12 row">                    
                    <div className="col-xl-4 col-lg-4 col-md-4 col-sm-10 p-0">
                      <input type="checkbox" defaultChecked={item.rightsSuper === 1 ? true : false} disabled='disabled' className="form-control permission-checkbox" name="country"/>
                      <label className="permission-label">Final Approval of Timesheet</label>
                    </div> 
                    </div>
                  </div>
                  })
                }
                <h6 className="mt-5">Administrator Account Management</h6>
                <label>Add Administrator<button type="button" onClick={this.addAdminUserProcess} className="button resend-btn mt-1">Add</button></label>
                <p className="mt-1 font-weight-bold">Manage Administrator Information and Rights</p>
                { Array.isArray(this.state.adminusers) &&  this.state.adminusers.map((item,i) =>{
                return  <div className="row form-group border-bottom" key={i}>
                  <div className="col-xl-3 col-lg-3 col-md-3 col-sm-12">
                    <label>{item.firstName +' '+ item.lastName}</label>
                    <p><span className="link-style pl-0" data-tag={item.userID} onClick={this.editAdminUserProcess}>Edit</span> | 
                    <span className="link-style" onClick={this.submit}>Change to Super User</span> | 
                    <span className="link-style" data-tag={item.userID} onClick={this.deleteProcess}>Remove</span> | 
                    <span className="link-style" data-tagid={item.userID} data-tag={item.userName} onClick={this.resetPassword}>Reset Password</span></p>                  
                  </div>
                  <div className="col-xl-9 col-lg-9 col-md-9 col-sm-12 row">
                  <div className="col-xl-3 col-lg-3 col-md-3 col-sm-10 p-0">
                    <input type="checkbox" defaultChecked={item.rightsEmployee === 1 ? true : false} disabled='disabled' className="form-control permission-checkbox" name="country"/>
                    <label className="permission-label">Modify Employees</label>
                  </div>
                  <div className="col-xl-3 col-lg-3 col-md-3 col-sm-10 p-0">
                    <input type="checkbox" defaultChecked={item.rightsPolicy === 1 ? true : false} disabled='disabled' className="form-control permission-checkbox" name="country"/>
                    <label className="permission-label">Modify Policies</label>
                  </div>
                  <div className="col-xl-2 col-lg-2 col-md-2 col-sm-10 p-0">
                    <input type="checkbox" defaultChecked={item.rightsReport === 1 ? true : false} disabled='disabled' className="form-control permission-checkbox" name="country"/>
                    <label className="permission-label pl-1">Do Reporting</label>
                  </div>
                  <div className="col-xl-4 col-lg-4 col-md-4 col-sm-10 p-0">
                    <input type="checkbox" defaultChecked={item.rightsSuper === 1 ? true : false} disabled='disabled' className="form-control permission-checkbox" name="country"/>
                    <label className="permission-label">Final Approval of Timesheet</label>
                  </div> 
                  </div>
                </div>
                })
              }                
              </div>
            </form>
            <Modal scrollable={true} size="lg" onHide={() => this.setState({ supershow: false })}
          show={this.state.supershow}
           aria-labelledby="example-modal-sizes-title-lg">
      <Modal.Header closeButton>
        <Modal.Title className="h6" id="example-modal-sizes-title-lg">
        Add Super User
        </Modal.Title>
      </Modal.Header>
      <Modal.Body className="show-grid small_font" ref={ this.componentRef }>
        <Container>
        <div className="text-danger col-12 text-center">{this.state.auerror_message}</div>
          <div className="form-group row">
            <div className="col-xl-6 col-lg-6 col-md-6 col-sm-12 pt-4">
              <input onClick={this.handleCheckbox} type="checkbox" className="form-control permission-checkbox" name="existing"/>
              <label className="permission-label">Select From Existing Employees</label>
            </div>
                <div className="col-xl-6 col-lg-6 col-md-6 col-sm-12">
                  <label className="mr-2">Employees</label>
                  <select onChange={this.changeExistingEmp} disabled={this.state.existing} placeholder="Select" className="form-control" name="employee">
                    <option value=''>Select</option>
                    { Array.isArray(this.state.employeesList) &&  this.state.employeesList.map((item,i) =>{
                        return <option key={i} value={item.userID}>{item.firstName}</option>
                    })
                    }
                  </select>
                </div>
            </div>
            <div className="form-group row">
                <div className="col-xl-6 col-lg-6 col-md-6 col-sm-12">
                  <label for="exampleInputEmail1">First Name*</label>
                  <input disabled={this.state.existingfields} value={this.state.audetails.firstName}  name="firstName" onChange={this.handleAuFormChange} type="text" className="form-control" id="exampleInputEmail1" placeholder="Enter First Name" />
                </div>
                <div className="col-xl-6 col-lg-6 col-md-6 col-sm-12">
                  <label for="exampleInputEmail1">Last Name*</label>
                  <input disabled={this.state.existingfields} value={this.state.audetails.lastName}  name="lastName" onChange={this.handleAuFormChange}  type="text" className="form-control" id="exampleInputEmail1" placeholder="Enter Last Name" />
                </div>
            </div>
            <div className="form-group">
              <label for="exampleInputEmail1">Email*</label>
              <input disabled={this.state.existingfields}  value={this.state.audetails.email}  name="email" onChange={this.handleAuFormChange}  type="email" className="form-control" placeholder="Enter Email"/>
            </div>
            <div className="form-group">
              <label>Login Name*</label>
              <input disabled={this.state.existingfields}  value={this.state.audetails.userName}  name="userName" onChange={this.handleAuFormChange}  type="text" className="form-control" placeholder="Enter Login Name" />
            </div>
            <div className="form-group">
              <label>Password*</label>
              <input disabled={this.state.existingfields}  value={this.state.audetails.password}  name="password" onChange={this.handleAuFormChange}  type="password" className="form-control" placeholder="Enter Password" />
            </div>
            <div className="p-3 form-group row">              
              <div className="col-xl-4 col-lg-4 col-md-4 col-sm-10 p-0">
              <input type="checkbox" value='1' checked={1 === this.state.audetails.rightsSuper} onChange={this.handleAuFormChange} className="form-control permission-checkbox" name="rightsSuper"/>
              <label className="permission-label">Final Approval of Timesheet</label>
            </div>  
          </div>        
        </Container>
      </Modal.Body>
      <Modal.Footer>
      <ul class="row form-group mr-0 mt-4 pr-0 list-inline pull-right">
        <li><button onClick={() => this.setState({ supershow: false })} class="button cancel-btn py-2 px-4 m-0 mr-2">Close</button></li>
        <li><button onClick={this.addSuperUserRecord} class="button resend-btn py-2 px-4 m-0">Save</button></li>
      </ul>
      </Modal.Footer>
    </Modal>
    <Modal scrollable={true} size="lg"  onHide={() => this.setState({ editsupershow: false })}
          show={this.state.editsupershow}
           aria-labelledby="example-modal-sizes-title-lg">
      <Modal.Header closeButton>
        <Modal.Title className="h6" id="example-modal-sizes-title-lg">
        Edit Super User
        </Modal.Title>
      </Modal.Header>
      <Modal.Body className="show-grid small_font">
        <Container>
        <div className="text-danger col-12 text-center">{this.state.auerror_message}</div>
          
            <div className="form-group row">
                <div className="col-xl-6 col-lg-6 col-md-6 col-sm-12">
                  <label for="exampleInputEmail1">First Name*</label>
                  <input disabled={this.state.existingfields} value={this.state.audetails.firstName}  name="firstName" onChange={this.handleAuFormChange} type="text" className="form-control" id="exampleInputEmail1" placeholder="Enter First Name" />
                </div>
                <div className="col-xl-6 col-lg-6 col-md-6 col-sm-12">
                  <label for="exampleInputEmail1">Last Name*</label>
                  <input disabled={this.state.existingfields} value={this.state.audetails.lastName}  name="lastName" onChange={this.handleAuFormChange}  type="text" className="form-control" id="exampleInputEmail1" placeholder="Enter Last Name" />
                </div>
            </div>
            <div className="form-group">
              <label for="exampleInputEmail1">Email*</label>
              <input disabled={this.state.existingfields}  value={this.state.audetails.email}  name="email" onChange={this.handleAuFormChange}  type="email" className="form-control" placeholder="Enter Email"/>
            </div>
            <div className="form-group">
              <label>Login Name*</label>
              <input disabled={this.state.existingfields}  value={this.state.audetails.userName}  name="userName" onChange={this.handleAuFormChange}  type="text" className="form-control" placeholder="Enter Login Name" />
            </div>
            <div className="p-3 form-group row">              
              <div className="col-xl-4 col-lg-4 col-md-4 col-sm-10 p-0">
              <input type="checkbox" checked={1 === this.state.audetails.rightsSuper}  value='1'  onChange={this.handleAuFormChange} className="form-control permission-checkbox" name="rightsSuper"/>
              <label className="permission-label">Final Approval of Timesheet</label>
            </div>  
          </div>       
        </Container>
      </Modal.Body>
      <Modal.Footer>
      <ul class="row form-group mr-0 mt-4 pr-0 list-inline pull-right">
        <li><button onClick={() => this.setState({ editsupershow: false })} class="button cancel-btn py-2 px-4 m-0 mr-2">Close</button></li>
        <li><button data-tag={this.state.audetails.userID} onClick={this.editSuperUserRecord} class="button resend-btn py-2 px-4 m-0">Save</button></li>
      </ul>
      </Modal.Footer>
    </Modal>
    <Modal scrollable={true} size="xl"  onHide={() => this.setState({ show: false })}
          show={this.state.show}
           aria-labelledby="example-modal-sizes-title-lg">
      <Modal.Header closeButton>
        <Modal.Title className="h6" id="example-modal-sizes-title-lg">
        Add Administrator
        </Modal.Title>
      </Modal.Header>
      <Modal.Body className="show-grid small_font">
        <Container>
        <div className="text-danger col-12 text-center">{this.state.auerror_message}</div>
        <div className="form-group row">
                <div className="col-xl-6 col-lg-6 col-md-6 col-sm-12 pt-4">
                  <input onClick={this.handleCheckbox} type="checkbox" className="form-control permission-checkbox" name="existing"/>
                  <label className="permission-label">Select From Existing Employees</label>
                </div>
                <div className="col-xl-6 col-lg-6 col-md-6 col-sm-12">
                  <label className="mr-2">Employees</label>
                  <select onChange={this.changeExistingEmp} disabled={this.state.existing} placeholder="Select" className="form-control" name="employee">
                    <option value=''>Select</option>
                    { Array.isArray(this.state.employeesList) &&  this.state.employeesList.map((item,i) =>{
                        return <option key={i} value={item.userID}>{item.firstName}</option>
                    })
                    }
                  </select>
                </div>
            </div>
            <div className="form-group row">
                <div className="col-xl-6 col-lg-6 col-md-6 col-sm-12">
                  <label for="exampleInputEmail1">First Name*</label>
                  <input disabled={this.state.existingfields} value={this.state.audetails.firstName}  name="firstName" onChange={this.handleAuFormChange} type="text" className="form-control" id="exampleInputEmail1" placeholder="Enter First Name" />
                </div>
                <div className="col-xl-6 col-lg-6 col-md-6 col-sm-12">
                  <label for="exampleInputEmail1">Last Name*</label>
                  <input disabled={this.state.existingfields} value={this.state.audetails.lastName}  name="lastName" onChange={this.handleAuFormChange}  type="text" className="form-control" id="exampleInputEmail1" placeholder="Enter Last Name" />
                </div>
            </div>
            <div className="form-group">
              <label for="exampleInputEmail1">Email*</label>
              <input disabled={this.state.existingfields}  value={this.state.audetails.email}  name="email" onChange={this.handleAuFormChange}  type="email" className="form-control" placeholder="Enter Email"/>
            </div>
            <div className="form-group">
              <label>Login Name*</label>
              <input disabled={this.state.existingfields}  value={this.state.audetails.userName}  name="userName" onChange={this.handleAuFormChange}  type="text" className="form-control" placeholder="Enter Login Name" />
            </div>
            <div className="form-group">
              <label>Password*</label>
              <input disabled={this.state.existingfields}  value={this.state.audetails.password}  name="password" onChange={this.handleAuFormChange}  type="password" className="form-control" placeholder="Enter Password" />
            </div>
            <div className="p-3 form-group row">
              <div className="col-xl-3 col-lg-3 col-md-3 col-sm-10 p-0">
              <input type="checkbox" value='1' checked={1 === this.state.audetails.rightsEmployee} onChange={this.handleAuFormChange} className="form-control permission-checkbox" name="rightsEmployee"/>
              <label className="permission-label">Modify Employees</label>
              </div>
              <div className="col-xl-2 col-lg-2 col-md-2 col-sm-10 p-0">
              <input type="checkbox" value='1' checked={1 === this.state.audetails.rightsPolicy} onChange={this.handleAuFormChange} className="form-control permission-checkbox" name="rightsPolicy"/>
              <label className="permission-label">Modify Policies</label>
              </div>
              <div className="col-xl-3 col-lg-3 col-md-3 col-sm-10 p-0 pl-4">
              <input type="checkbox" value='1' checked={1 === this.state.audetails.rightsReport} onChange={this.handleAuFormChange} className="form-control permission-checkbox" name="rightsReport"/>
              <label className="permission-label pl-1">Do Reporting</label>
              </div>
              <div className="col-xl-4 col-lg-4 col-md-4 col-sm-10 p-0">
              <input type="checkbox" value='1' checked={1 === this.state.audetails.rightsSuper} onChange={this.handleAuFormChange} className="form-control permission-checkbox" name="rightsSuper"/>
              <label className="permission-label">Final Approval of Timesheet</label>
              </div>  
              </div>        
        </Container>
      </Modal.Body>
      <Modal.Footer>
      <ul class="row form-group mr-0 mt-4 pr-0 list-inline pull-right">
        <li><button onClick={() => this.setState({ show: false })} class="button cancel-btn py-2 px-4 m-0 mr-2">Close</button></li>
        <li><button onClick={this.addAdminUserRecord} class="button resend-btn py-2 px-4 m-0">Save</button></li>
      </ul>
      </Modal.Footer>
    </Modal>
    <Modal scrollable={true} size="xl"  onHide={() => this.setState({ editshow: false })}
          show={this.state.editshow}
           aria-labelledby="example-modal-sizes-title-lg">
      <Modal.Header closeButton>
        <Modal.Title className="h6" id="example-modal-sizes-title-lg">
        Edit Administrator User
        </Modal.Title>
      </Modal.Header>
      <Modal.Body className="show-grid small_font">
        <Container>
        <div className="text-danger col-12 text-center">{this.state.auerror_message}</div>
          <div className="form-group row">
                <div className="col-xl-6 col-lg-6 col-md-6 col-sm-12">
                  <label for="exampleInputEmail1">First Name*</label>
                  <input disabled={this.state.existingfields} value={this.state.audetails.firstName}  name="firstName" onChange={this.handleAuFormChange} type="text" className="form-control" id="exampleInputEmail1" placeholder="Enter First Name" />
                </div>
                <div className="col-xl-6 col-lg-6 col-md-6 col-sm-12">
                  <label for="exampleInputEmail1">Last Name*</label>
                  <input disabled={this.state.existingfields} value={this.state.audetails.lastName}  name="lastName" onChange={this.handleAuFormChange}  type="text" className="form-control" id="exampleInputEmail1" placeholder="Enter Last Name" />
                </div>
            </div>
            <div className="form-group">
              <label for="exampleInputEmail1">Email*</label>
              <input disabled={this.state.existingfields}  value={this.state.audetails.email}  name="email" onChange={this.handleAuFormChange}  type="email" className="form-control" placeholder="Enter Email"/>
            </div>
            <div className="form-group">
              <label>Login Name*</label>
              <input disabled={this.state.existingfields}  value={this.state.audetails.userName}  name="userName" onChange={this.handleAuFormChange}  type="text" className="form-control" placeholder="Enter Login Name" />
            </div>
            <div className="p-3 form-group row">
              <div className="col-xl-3 col-lg-3 col-md-3 col-sm-10 p-0">
              <input type="checkbox" value='1' checked={1 === this.state.audetails.rightsEmployee} onChange={this.handleAuFormChange} className="form-control permission-checkbox" name="rightsEmployee"/>
              <label className="permission-label">Modify Employees</label>
              </div>
              <div className="col-xl-2 col-lg-2 col-md-2 col-sm-10 p-0">
              <input type="checkbox" value='1' checked={1 === this.state.audetails.rightsPolicy} onChange={this.handleAuFormChange} className="form-control permission-checkbox" name="rightsPolicy"/>
              <label className="permission-label">Modify Policies</label>
              </div>
              <div className="col-xl-3 col-lg-3 col-md-3 col-sm-10 p-0 pl-4">
              <input type="checkbox" value='1' checked={1 === this.state.audetails.rightsReport} onChange={this.handleAuFormChange} className="form-control permission-checkbox" name="rightsReport"/>
              <label className="permission-label pl-1">Do Reporting</label>
              </div>
              <div className="col-xl-4 col-lg-4 col-md-4 col-sm-10 p-0">
              <input type="checkbox" value='1' checked={1 === this.state.audetails.rightsSuper} onChange={this.handleAuFormChange} className="form-control permission-checkbox" name="rightsSuper"/>
              <label className="permission-label">Final Approval of Timesheet</label>
              </div>  
              </div>        
        </Container>
      </Modal.Body>
      <Modal.Footer>
      <ul class="row form-group mr-0 mt-4 pr-0 list-inline pull-right">
        <li><button onClick={() => this.setState({ editshow: false })} class="button cancel-btn py-2 px-4 m-0 mr-2">Close</button></li>
        <li><button data-tag={this.state.audetails.userID} onClick={this.editAdminUserRecord} class="button resend-btn py-2 px-4 m-0">Save</button></li>
      </ul>
      </Modal.Footer>
    </Modal>
    <Modal scrollable={true} size="md"  onHide={() => this.setState({ superreset: false })}
          show={this.state.superreset}
           aria-labelledby="example-modal-sizes-title-lg">
      <Modal.Header closeButton>
        <Modal.Title className="h6" id="example-modal-sizes-title-lg">
        Reset Super User Password
        </Modal.Title>
      </Modal.Header>
      <Modal.Body className="show-grid small_font">
        <Container>
        <div className="text-danger col-12 text-center">{this.state.auerror_message}</div>
            <div className="form-group">
              <label for="exampleInputEmail1">Password*</label>
              <input type="email" className="form-control" placeholder="Enter Password"/>
            </div>
            <div className="form-group">
              <label>Confirm Password*</label>
              <input type="text" className="form-control" placeholder="Enter Confirm Password" />
            </div>       
        </Container>
      </Modal.Body>
      <Modal.Footer>
      <ul class="row form-group mr-0 mt-4 pr-0 list-inline pull-right">
        <li><button onClick={() => this.setState({ superreset: false })} class="button cancel-btn py-2 px-4 m-0 mr-2">Close</button></li>
        <li><button onClick={this.resetPasswordProcess} class="button resend-btn py-2 px-4 m-0">Save</button></li>
      </ul>
      </Modal.Footer>
    </Modal>
    <Modal scrollable={true} size="md"  onHide={() => this.setState({ reset: false })}
          show={this.state.reset}
           aria-labelledby="example-modal-sizes-title-lg">
      <Modal.Header closeButton>
        <Modal.Title className="h6" id="example-modal-sizes-title-lg">
        Reset Password
        </Modal.Title>
      </Modal.Header>
      <Modal.Body className="show-grid small_font">
        <Container>
        <div className="text-danger col-12 text-center">{this.state.auerror_message}</div>
            <div className="form-group">
              <label for="exampleInputEmail1">New Password*</label>
              <input type="password"  value={this.state.audetails.pass}  name="pass" onChange={this.handleAuFormChange} className="form-control" placeholder="Enter Password"/>
            </div>
            <div className="form-group">
              <label>Confirm New Password*</label>
              <input type="password"  value={this.state.audetails.newpass}  name="newpass" onChange={this.handleAuFormChange} className="form-control" placeholder="Enter Confirm Password" />
            </div>       
        </Container>
      </Modal.Body>
      <Modal.Footer>
      <ul class="row form-group mr-0 mt-4 pr-0 list-inline pull-right">
        <li><button onClick={() => this.setState({ reset: false })} class="button cancel-btn py-2 px-4 m-0 mr-2">Close</button></li>
        <li><button onClick={this.resetPasswordProcess} class="button resend-btn py-2 px-4 m-0">Save</button></li>
      </ul>
      </Modal.Footer>
    </Modal>
          </div>
        </div>
        <div
  aria-live="polite"
  aria-atomic="true"
  style={{
    position: 'relative',
  }}
>
  <Toast
    style={{
      position: 'absolute',
      top: 0,
      left: 0,
    }} onClose={() =>this.setState({ remove: false })} show={this.state.remove} delay={2000} autohide>
          <Toast.Body>Removed Super User Successfully!</Toast.Body>
        </Toast>
      </div>
      </div>
    );
  }
}

export default OrganizationTabs;
