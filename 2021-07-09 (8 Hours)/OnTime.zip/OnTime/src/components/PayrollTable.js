import React from 'react';
import "react-datepicker/dist/react-datepicker.css";
import '../App.css';
import { toNumber } from '../helpers/GeneralHelper';
import moment from 'moment';
import html2pdf from 'html2pdf.js';
import XLSX from 'xlsx';

class PayrollTable extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      printData: false
    };
  }

  download_csv = () => {

    var elt = document.getElementById('payRollReport');
    var wb = XLSX.utils.table_to_book(elt, { sheet: "Sheet JS" });
    XLSX.write(wb, { bookType: 'xlsx', bookSST: true, type: 'base64' })
    XLSX.writeFile(wb, 'payRollReport.xlsx');

    // TableToExcel.convert(document.getElementById("payRollReport"));

    // var table = TableExport(document.getElementById("payRollReport"), {
    //   headers: true,                      // (Boolean), display table headers (th or td elements) in the <thead>, (default: true)
    //   footers: true,                      // (Boolean), display table footers (th or td elements) in the <tfoot>, (default: false)
    //   formats: ["xlsx"],    // (String[]), filetype(s) for the export, (default: ['xlsx', 'csv', 'txt'])
    //   filename: "id",                     // (id, String), filename for the downloaded file, (default: 'id')
    //   bootstrap: true,                   // (Boolean), style buttons using bootstrap, (default: true)
    //   exportButtons: true,                   // (id, String), sheet name for the exported spreadsheet, (default: 'id')
    // });
    // var exportData = table.getExportData();
    // console.log(exportData)
  }

  savePDF = (e) => {
    e.preventDefault();
    this.setState({ printData: true });
    let obj = {
      unit: 'cm', format: 'ledger', orientation: 'landscape',
    }
    let content = document.getElementById('payRollReport');
    setTimeout(() => {
      var opt = {
        margin: [0, 1, 0, 1],
        filename: `payroll_report.pdf`,
        html2canvas: { y: 0, scrollY: 0, useCORS: true },
        jsPDF: obj
      };
      html2pdf().set(opt).from(content).save();
    }, 1000)
    setTimeout(() => { this.setState({ printData: false }) }, 2000);
  }

  render() {
    const { printData } = this.state;
    const { payRollArr, allActivities, finalTotalPayRoll, startDate, endDate, orgImage, companyDetails = {} } = this.props;
    const { finalRegHoursTtl, allDutyTotal, dutyWiseTotal, allActTotal } = finalTotalPayRoll;
    let totalLengthOfCode = [];
    allActivities.map((x) => x.value.map((c) => totalLengthOfCode.push(c)));
    return (
      <div className="mx-4 timesheetReport pb-5">
        <div className="buttonLine container">
          <h6 className="text-center">Report Preview</h6>
          <a id="payrollDD" onClick={(e) => this.download_csv(e)} className="button small_font mt-0 resend-btn float-right mb-3">Save As Excel</a>
          <button onClick={(e) => this.savePDF(e)} className="button resend-btn mt-0 ml-2 float-right mb-3">Save As PDF</button>
        </div>
        <div className="payrollform">
          {payRollArr && payRollArr.length > 0 &&
            <div id="payRollReport" className={!printData ? "mt-4 overflow-auto reportHeight" : "mt-4"} >
              <div className="m-2">
                <table className="text-center text-black w-100">
                  <thead>
                    <tr>
                      <th colSpan="2" rowSpan="5" className="border-0">
                        {orgImage && <img src={orgImage} height="100px" alt="orgImage" />}
                      </th>
                      <th className="border border-white" colSpan={3 + totalLengthOfCode.length}>
                        <h6 className="mb-0">{companyDetails && companyDetails.name} PAYROLL SUMMARY REPORT</h6></th>
                      <th className="border border-white" colSpan={3}>&nbsp;</th>
                    </tr>
                    <tr>
                      <th className="border border-white" colSpan={3 + totalLengthOfCode.length}>
                        {companyDetails ? <h6 className="mb-0">
                          {companyDetails.address1 ? `${companyDetails.address1},` : ''}
                          {companyDetails.address2 ? ` ${companyDetails.address2},` : ''}
                          {companyDetails.city ? ` ${companyDetails.city},` : ''}
                          {companyDetails.zip ? ` ${companyDetails.zip},` : ''}
                          {companyDetails.state ? ` ${companyDetails.state},` : ''}
                        </h6> : <h6>&nbsp;</h6>}
                      </th>
                      <th className="border border-white" colSpan={3}>&nbsp;</th>
                    </tr>
                    <tr>
                      <th className="border-white border-bottom-0" colSpan={3 + totalLengthOfCode.length}>
                        <h6 className="mb-0">FROM {moment(startDate).format('MM/DD/YYYY')} TO {moment(endDate).format('MM/DD/YYYY')}</h6>
                      </th>
                      <th className="border border-white" colSpan={3}>&nbsp;</th>
                    </tr>
                    <tr><th className="border-white border-bottom-0" colSpan={2 + totalLengthOfCode.length}>
                    </th>
                      <th colSpan={2} className="px-0 border-0 text-right">Certified By :</th>
                      <th colSpan={2} className="border-0 text-left pr-0">_________________</th>
                    </tr>
                    <tr>
                      <th className="border-white border-bottom-0" colSpan={2 + totalLengthOfCode.length}>
                      </th>
                      <th colSpan={2} className="px-0 border-0 text-right">Print Name :</th>
                      <th colSpan={2} className="border-0 text-left pr-0">{JSON.parse(localStorage.userdetails).firstName} {JSON.parse(localStorage.userdetails).lastName}</th>
                    </tr>

                    <tr>
                      <th rowSpan='3'>GROUP ID</th>
                      <th colSpan='2'>NAME</th>
                      <th rowSpan='3'>FINAL REG HOURS</th>
                      <th rowSpan='3'>EVENT ATTENTION</th>
                      <th rowSpan='3'>HOURS ADJUST</th>
                      <th colSpan={totalLengthOfCode.length + 2}>FROM {moment(startDate).format('MM/DD/YYYY')} TO {moment(endDate).format('MM/DD/YYYY')}</th>
                    </tr>
                    <tr>
                      <th rowSpan='2'>LAST NAME</th>
                      <th rowSpan='2'>FIRST NAME</th>
                      <th rowSpan='2'>TOTAL</th>
                      <th rowSpan='2'>TOTAL REG LABOR</th>
                      {allActivities && allActivities.map((x, i) => <th key={i} colSpan={x.value.length}>{x.name}</th>)}
                    </tr>
                    <tr>{totalLengthOfCode && totalLengthOfCode.map((x, i) => <th key={i}>{x.code}</th>)}</tr>
                  </thead>
                  <tbody>
                    {payRollArr && payRollArr.map((x, i) => {
                      return <React.Fragment key={i}>
                        <tr>
                          <td>{x.groupCode}</td>
                          <td>{x.firstName}</td>
                          <td>{x.lastName}</td>
                          <td className="background-blue">{toNumber(x.allTotal + (x.hoursAdjust || 0.0))}</td>
                          <td />
                          <td />
                          <td>{toNumber(x.allTotal)}</td>
                          <td>{toNumber(x.dutyTotal)}</td>
                          {Object.values(x.timeObj) && Object.values(x.timeObj).map((data, key) => {
                            return data.map((actSum, sKey) => {
                              const tempObj = totalLengthOfCode.find((d) => d.code === actSum.code);
                              return <td key={sKey}> {tempObj ? toNumber(actSum.value) : 0.00}</td>
                            })
                          })}
                        </tr>
                      </React.Fragment>
                    })}
                    <tr>
                      <td colSpan={8 + totalLengthOfCode.length}></td>
                    </tr>
                    <tr className="background-blue">
                      <td />
                      <td className="font-weight-bold">Total</td>
                      <td />
                      <td className="font-weight-bold">{finalRegHoursTtl}</td>
                      <td />
                      <td />
                      <td className="font-weight-bold">{toNumber(allActTotal)}</td>
                      <td className="font-weight-bold">{toNumber(allDutyTotal)}</td>
                      {dutyWiseTotal && dutyWiseTotal.map((dt, wkey) => <td key={wkey} className="font-weight-bold">{toNumber(dt.value)}</td>)}
                    </tr>
                    <tr>
                      <td colSpan={8 + totalLengthOfCode.length}></td>
                    </tr>
                    <tr>
                      <td /><td className="background-green"></td><td>New Hire</td><td></td><td></td><td></td><td></td>
                      <td></td>
                      <td colSpan={totalLengthOfCode.length}></td>
                    </tr>
                    <tr>
                      <td></td><td className="bg-orange"></td><td>Attention</td><td></td><td></td><td></td><td></td>
                      <td></td>
                      <td colSpan={totalLengthOfCode.length}></td>
                    </tr>
                    <tr>
                      <td></td><td className="background-red"></td><td>Terminated</td><td></td><td></td><td></td><td></td>
                      <td></td>
                      <td colSpan={totalLengthOfCode.length}></td>
                    </tr>
                  </tbody>
                </table>
              </div>
            </div>}
        </div>
      </div>
    );
  }
}
export default PayrollTable;