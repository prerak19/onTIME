import React from 'react';
import 'bootstrap/dist/css/bootstrap.min.css';
import './App.css';
import AdminHeader from './components/AdminHeader.js';
import DatePicker from "react-datepicker";
import "react-datepicker/dist/react-datepicker.css";
import {
  Modal,
  Container,
  Nav,
  Row,
  Col,
  Popover,
  OverlayTrigger
} from "react-bootstrap";
import { MDBBtn } from 'mdbreact';
import { NavLink } from "react-router-dom";
import { apiGet, apiPut, apiPost } from './Api.js';
import { get, isEqual, isEmpty } from 'lodash';
import * as GeneralHelper from './helpers/GeneralHelper';
import moment from 'moment';

const UserActivity = {
  timesheetApproval: 1,
  activityApproval: 2
}

class TimesheetChart extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      weeklyDate: null,
      displayConfirmationPopup: false,
      timesheetid: props.location.stateid,
      timesheetdetails: {},
      startWeekDate: '',
      weekEndDate: '',
      daysOfWeek: [],
      punchOutTime: '',
      punchOutComments: '',
      userApprovalComments: '',
      selectedUserActivity: null
    };
  }

  componentDidMount() {
    this.getTimesheetRecord();
  }

  getTimesheetRecord = () => {
    const requestDetails = {
      method: `timesheets/${this.state.timesheetid}`,
      params: {}
    };
    apiGet(requestDetails, true).then((response) => {
      console.log(response)
        const sunday = new Date(moment.utc(get(response.data, 'startDate')).day(0));
    const nextSunday = new Date(moment.utc(get(response.data, 'startDate')).day(7));
      const startDay = moment.utc(sunday);
      const daysOfWeekFromStart = [
        {
          day: GeneralHelper.DAYS_OF_WEEK[startDay.day()],
          date: startDay.format('MMM D')
        }
      ];
      for (let i = 1; i <= 6; ++i) {
        const newDay = startDay;
        newDay.add(1, 'day');
        daysOfWeekFromStart.push({
          day: GeneralHelper.DAYS_OF_WEEK[newDay.day()],
          date: newDay.format('MMM D')
        })
      }
      this.setState({
        weeklyDate:sunday,
        startWeekDate: moment.utc(sunday).format('YYYY-MM-DD'),
        weekEndDate: moment.utc(nextSunday).format('YYYY-MM-DD'),
        timesheetdetails: response.data,
        daysOfWeek: daysOfWeekFromStart
      });
    }).catch(error => {
      console.log(error);
    });
  }

  formatDate = (date) => moment.utc(new Date(date)).format("MMMM D, YYYY")

  setPunchOutTime = (date) => this.setState({ punchOutTime: date })

  isWeekday = (date) => date.getDay() === 0

  handleWeekChange = (date) => {
    const formatDate = moment(new Date(date)).format('YYYY-MM-DD')
    console.log(formatDate);
    const request = {
      method: `timesheets/${get(this.state.timesheetdetails, 'uid')}/${formatDate}`
    };
    apiGet(request, true, false).then((response) => {
      console.log(response);
      if (isEqual(response.status, 200)) {
        this.setState({
          weeklyDate: date,
          startWeekDate: formatDate,
          timesheetdetails: !isEmpty(response.data) && response.data
        });
      }
    }).catch((err) => {
      console.log(err);
    })
  }

  setPunchOutComments = (evt) => this.setState({ punchOutComments: evt.target.value })

  setUserApprovalComments = (evt) => this.setState({ userApprovalComments: evt.target.value })

  updateHour = () => {
    const request = {
      method: 'timesheets/hour',
      params: {
        timesheetID: `${this.state.timesheetid}`,
        activityID: '',
        day: '',
        hours: this.state.punchOutTime,
        reason: this.state.punchOutComments,
        madeBy: get(localStorage, 'userid', ''),
      }
    }
    apiPut(request, true).then((response) => {
      console.log('api-response', response);
    }).catch((err) => console.log(err))
  }

  handleActivityApprovalAction = () => {
    this.setState({
      selectedUserActivity: UserActivity.activityApproval,
      displayConfirmationPopup: true
    })
  }

  handleTimesheetApprovalAction = () => {
    this.setState({
      userApprovalComments: '',
      selectedUserActivity: UserActivity.timesheetApproval,
      displayConfirmationPopup: true
    })
  }

  handleUserAction = () => {
    const request = {
      method: '',
      params: {
        timesheetID: this.state.timesheetid,
        activityID: '',
        madeBy: get(localStorage, 'userid', ''),
        reason: this.state.userApprovalComments
      }
    }
    switch (this.state.selectedUserActivity) {
      case UserActivity.activityApproval:
        request.method = 'timesheets/activity-approve';
        break;
      case UserActivity.timesheetApproval:
        request.method = 'timesheets/approve';
        break;
      default:
        break;
    }
    apiPost(request, true).then((response) => {
      // do something
    }).catch((err) => console.log(err))
  }

  render() {
    const popoverComponent = (
      <Popover id={`popover-positioned-top`} className="timesheetpopover">
        <Popover.Title as="h6" className="background-green1 text-white">
          <span className="small_font">{this.state.timesheetdetails.userFirstname}, {this.state.timesheetdetails.userLastname}</span>
          {/* <span className="small_font">Sun Apr 15, 2016</span> */}
          <span
            aria-label="Close" className="float-right icon-button cursor-pointer"
            onClick={() => document.body.click()}
          >
            x
          </span>
        </Popover.Title>
        <Popover.Content>
          <div className="row px-3">
            <label className="col-xl-3 col-lg-3 col-md-3 col-sm-10 p-0 permission-label">Type : </label>
            <label className="col-xl-6 col-lg-6 col-md-6 col-sm-10 p-0 permission-label">Punch Out</label>
          </div>
          <div className="row px-3">
            <label className="col-xl-3 col-lg-3 col-md-3 col-sm-10 p-0 permission-label">Time : </label>
            <div className="col-xl-7 col-lg-7 col-md-7 col-sm-10 p-0">
              <DatePicker
                selected={this.state.punchOutTime}
                onChange={this.setPunchOutTime}
                showTimeSelect
                showTimeSelectOnly
                timeIntervals={15}
                timeCaption="Time"
                className="form-control"
                dateFormat="h:mm aa"
                placeholderText={'Select time'}
              />
              {isEmpty(this.state.punchOutTime) && (<p style={{ color: 'red' }}>This is required</p>)}
            </div>
            <i className="col-xl-1 col-lg-1 col-md-1 mt-auto mb-auto fa fa-clock-o text-danger"></i>
          </div>
          <div className="row px-3">
            <label className="col-xl-3 col-lg-3 col-md-3 col-sm-10 p-0 permission-label"></label>
            <label className="xs_font col-xl-8 col-lg-8 col-md-8 col-sm-10 p-0 permission-label">
              {/* Actual Time : 04/25/2020 5:15PM */}
              {moment().utc().format('YYYY-MM-DD, hh:mm:ss a')}
            </label>
          </div>
          <div className="col-xl-12 col-lg-12 col-md-12 col-sm-12 p-0">
            <textarea
              className="form-control"
              placeholder="Reason for change (required)"
              value={this.state.punchOutComments}
              onChange={this.setPunchOutComments}
            />
            {isEmpty(this.state.punchOutComments) && (<p style={{ color: 'red' }}>This is required</p>)}
          </div>
          <div class="row mt-2">
            <div className="col-6">
              <button
                disabled={isEmpty(this.state.punchOutComments) && isEmpty(this.state.punchOutTime)}
                className="button resend-btn float-right px-4"
                onClick={this.updateHour}
              >
                Save
            </button>
            </div>
          </div>
        </Popover.Content>
      </Popover>
    );
    return (
      <div className="App">
        <Container>
          <header className="admin-header">
            <AdminHeader />
          </header>
          <div className="content">
            <div className="contentwrapper pb-5 mb-5">
              <ul class="pl-0 my-2">
                <Nav.Link as={NavLink} to="/timesheets" className="p-0">
                  <button class="button resend-btn py-2 px-4 m-0 mr-2">Back</button>
                </Nav.Link>
              </ul>
              <div className="p-3 mb-3 small_font bg-amber border-0">
                <Row className="col-12">
                  <Col lg="5" md="5" sm="12">
                    <div className="">
                      <span className="pr-3 font-weight-bold font-16">
                        {get(this.state.timesheetdetails, 'userFirstname', '')}, {get(this.state.timesheetdetails, 'userLastname', '')}
                      </span>
                    </div>
                  </Col>
                  <Col lg="2" md="2" sm="6" className="text-right">
                    <label className="act-text">Week Started</label>
                  </Col>
                  <Col lg="2" md="2" sm="12">
                    <div className="form-group row mb-0 inner-addon right-addon mr-2">
                      <i class="fa fa-calendar"></i>
                      <DatePicker
                        selected={this.state.weeklyDate}
                        value={this.state.startWeekDate}
                        name="startDate"
                        className="form-control"
                        filterDate={this.isWeekday}
                        onChange={this.handleWeekChange}
                        dateFormat="yyyy-MM-dd"
                        placeholderText="yyyy-MM-dd"
                      />
                    </div>
                  </Col>
                </Row>
              </div>
              <Row>
                <Col lg="12" md="12" sm="12">
                  <table border='1' className="col-12 text-center text-black">
                    <thead>
                      <tr>
                        <th colSpan='3' className="blue-head">
                          {`${get(this.state.timesheetdetails, 'userFirstname', '')} ${get(this.state.timesheetdetails, 'userLastname', '')}'s Accumulated Time`}
                        </th>
                      </tr>
                    </thead>
                    <tbody>
                      <tr>
                        <th style={{ width: '50%' }}>{`Week (${this.formatDate(this.state.startWeekDate)} - ${this.formatDate(this.state.weekEndDate)})`}</th>
                        <th style={{ width: '50%' }}>{`Current Bi-Week Period (${this.formatDate(moment.utc(new Date(this.state.startWeekDate)).subtract(7, 'days'))} - ${this.formatDate(this.state.weekEndDate)})`}</th>
                      </tr>
                      <tr className="blue-num">
                        <td className="font-weight-bold">{'-'}</td>
                        <td className="font-weight-bold">{'-'}</td>
                      </tr>
                    </tbody>
                  </table>
                </Col>
              </Row>
              <div className="mt-3">
                <table border='1' className="col-12 text-black">
                  <thead>
                    <tr>
                      <th colSpan='14' className="blue-head py-2">
                        <Row>
                          <Col lg="6" md="6" sm="12">
                            <div className="pl-2  float-left">
                              <span className="font-12">WEEKLY TIME SHEET</span>
                              <span className="small-font pl-2">
                                {`${this.formatDate(this.state.startWeekDate)} - ${this.formatDate(this.state.weekEndDate)}`}
                              </span>
                            </div>
                          </Col>
                          <Col lg="6" md="6" sm="12">
                            <div className="pr-2 float-right">
                              <span className="pr-2 font-12">{GeneralHelper.timesheet_status_codes[`${get(this.state.timesheetdetails, 'status', '')}`]}</span>
                              <span className="font-small">{`Due on : ${this.formatDate(moment.utc(new Date(this.state.weekEndDate)).subtract(1, 'day'))}`}</span>
                              <span className="px-1">|</span>
                              <i className="fa fa-print px-1"></i>
                              <i className="fa fa-file-pdf-o px-1"></i>
                            </div>
                          </Col>
                        </Row>
                      </th>
                    </tr>
                  </thead>
                  <tbody className="text-center">
                    <tr>
                      <td colSpan='2' className="font-weight-bold text-right pr-1">NAME:</td>
                      <td colSpan='12' className="pl-1 text-left">
                        {get(this.state.timesheetdetails, 'userFirstname', '')}, {get(this.state.timesheetdetails, 'userLastname', '')}
                      </td>
                    </tr>
                    <tr>
                      <td colSpan='2' className="font-weight-bold text-right pr-1">GROUP:</td>
                      <td colSpan='12' className="pl-1 text-left">{'-'}</td>
                    </tr>
                    <tr className="text-center font-small p-1 bg-lite-gray">
                      <th colSpan='2'></th>
                      {get(this.state, 'daysOfWeek', []).map((day, index) => (
                        <th key={`${day.day}${index}`}>{day.day}<br />{day.date}</th>
                      ))}
                      <th>Total<br />Hours</th>
                      <th>Initial</th>
                    </tr>
                    {
                      get(this.state.timesheetdetails, 'activityTime', []).map((activity) => (
                        <React.Fragment>
                          {get(activity, 'clockinouts', []).map((clock, index) => (
                            <tr key={activity.id}>
                              {index === 0 && (<td colSpan='1' rowSpan={get(activity, 'clockinouts').length}>{activity.activityName.toUpperCase()}</td>)}
                              <td colSpan='1'>{GeneralHelper.ClockInOuts[clock.type]}</td>
                              {
                                get(this.state, 'daysOfWeek', []).map((day, index) => (
                                  <td colSpan='1' key={`${day}${index}`}>
                                    {isEqual(day.day, GeneralHelper.DAYS_OF_WEEK[moment.utc(clock.clockAt).day()]) ? moment.utc(clock.clockAt).format('h:mm A') : ''}
                                  </td>
                                ))
                              }
                              <td colSpan='1'></td>
                              {index === 0 && (
                                <td colSpan='1' rowSpan={get(activity, 'clockinouts').length}></td>
                              )}
                            </tr>
                          ))}
                          <tr className="time-td blue-text bg-lite-gray">
                            <td colSpan='2'>{`${activity.activityName.toUpperCase()} HOURS`}</td>
                            {
                              Object.values(GeneralHelper.DAYS_OF_WEEK).map((day, index) => (
                                <td colSpan='1' key={`${day}${index}`} className={`text-blue ${activity[`${day.toLowerCase()}Hour`] > 0 ? 'cursor-pointer' : ''}`}>
                                  <OverlayTrigger trigger="click" key='top' placement='top' rootClose={true} overlay={popoverComponent}>
                                    <span variant="secondary">{activity[`${day.toLowerCase()}Hour`] > 0 ? activity[`${day.toLowerCase()}Hour`] : ''}</span>
                                  </OverlayTrigger>
                                </td>
                              ))
                            }
                            <td colSpan='1'>{`${Object.values(GeneralHelper.DAYS_OF_WEEK).map((day) => activity[`${day.toLowerCase()}Hour`]).reduce((a, b) => a + b, 0)}`}</td>
                            <td colSpan='1' className="vertical-align-bottom">
                              {activity.approvedBy === 0 && (<div className="float-right">
                                <div className="guideList" onClick={this.handleActivityApprovalAction}>
                                  <div className="active cursor-pointer">
                                    <span className="activePointer"></span>
                                    <span className="pl-4">SIGN</span>
                                  </div>
                                </div>
                              </div>)}
                            </td>
                          </tr>
                        </React.Fragment>
                      ))
                    }
                    <tr className="time-td blue-text bg-lite-gray">
                      <td colSpan='2'>TOTAL</td>
                      <td></td>
                      <td></td>
                      <td></td>
                      <td></td>
                      <td></td>
                      <td></td>
                      <td></td>
                      <td className="text-blue">
                        <OverlayTrigger trigger="click" key='top' placement='top' rootClose={true} overlay={popoverComponent}>
                          <span variant="secondary">
                            {
                              get(this.state.timesheetdetails, 'activityTime', []).map((activity) => (
                                Object.values(GeneralHelper.DAYS_OF_WEEK).map((day) => activity[`${day.toLowerCase()}Hour`]).reduce((a, b) => a + b, 0)
                              )).reduce((a, b) => a + b, 0)
                            }
                          </span>
                        </OverlayTrigger>
                      </td>
                      <td></td>
                    </tr>
                  </tbody>
                  <thead>
                    <tr>
                      <th colSpan='14' className="blue-head text-center py-2">
                        Timesheet Changes
                        </th>
                    </tr>
                  </thead>
                  <tr>
                    <th colSpan='14' className="py-2">
                      {
                        get(this.state.timesheetdetails, 'activityTime', []).map((activity) => {
                          if (!isEmpty(activity.changes) && !activity.changes.includes(null)) {
                            return activity.changes.map((timesheetChanges) => (
                              <span key={timesheetChanges.activityID} className="pl-1">
                                {timesheetChanges.reason}
                              </span>)
                            )
                          }
                        })
                      }
                    </th>
                  </tr>
                  <tr>
                    <th colSpan='14' className="py-2"></th>
                  </tr>
                  <tr>
                    <th colSpan='4' className="pt-5">
                      <Row>
                        <Col lg="6" md="6" sm="6" className="mt-3">
                          <span className="pl-1 font-9">Employee Signature:</span>
                        </Col>
                        <Col lg="6" md="6" sm="6">
                          <div className="float-right">
                            <div className="guideList">
                              <div className="active"><span className="activePointer"></span>
                                <span className="pl-4">SIGN</span></div>
                            </div>
                          </div>
                        </Col>
                      </Row>
                    </th>
                    <th colSpan='2' className="pt-5">
                      <Row>
                        <Col lg="6" md="6" sm="6" className="mt-3">
                          <span className="pl-1 font-9">Date:</span>
                        </Col>
                        <Col lg="6" md="6" sm="6">
                        </Col>
                      </Row>
                    </th>
                    <th colSpan='4' className="pt-5">
                      {this.state.timesheetdetails && this.state.timesheetdetails.status < 500 ? <Row>
                        <Col lg="6" md="6" sm="6" className="mt-3">
                          <span className="pl-1 font-9">Approval Signature:</span>
                          {this.state.timesheetdetails && this.state.timesheetdetails.status >= 500 ?
                            <span>{this.state.timesheetdetails.userFirstname} {this.state.timesheetdetails.userLastname}</span> : null}
                        </Col>
                        {this.state.timesheetdetails && this.state.timesheetdetails.status < 500 ? <Col lg="6" md="6" sm="6">
                          <div className="float-right">
                            <div className="guideList" onClick={this.handleTimesheetApprovalAction}>
                              <div className="active cursor-pointer">
                                <span className="activePointer"></span>
                                <span className="pl-4">
                                  SIGN
                                  </span>
                              </div>
                            </div>
                          </div>
                        </Col> : null}
                      </Row> : <Row>
                        <Col lg="12" md="12" sm="12" className="mt-3">
                          <span className="pl-1 pr-2 font-9">Approval Signature:</span>
                          <span className="font-weight-bold">{this.state.timesheetdetails.approvedBy}</span>
                        </Col>
                      </Row>}
                    </th>
                    <th colSpan='3' className="pt-5">
                      <Row>
                        <Col lg="6" md="6" sm="6" className="mt-3">
                          <span className="pl-1 font-9">Date:</span>
                        </Col>
                        <Col lg="6" md="6" sm="6">
                        </Col>
                      </Row>
                    </th>
                  </tr>
                </table>
              </div>
            </div>
          </div>
        </Container>
        <Modal
          scrollable={true}
          size="md"
          onHide={() => this.setState({ displayConfirmationPopup: false })}
          show={this.state.displayConfirmationPopup}
        >
          <Modal.Header closeButton className="h6 background-green1">
            <Modal.Title className="h6 text-white small_font" id="contained-modal-title-vcenter">
              {`${isEqual(this.state.selectedUserActivity, UserActivity.activityApproval) ? 'Activity' : 'Timesheet'} Approval Confirmation`}
            </Modal.Title>
          </Modal.Header>
          <Modal.Body className="show-grid small_font px-5">
            <p className="xs_font text-dark text-center">Please add comment to electronically sign and approve this timesheet. </p>
            <p className="small_font font-weight-bold text-center">
              {`${this.formatDate(this.state.startWeekDate)} - ${this.formatDate(this.state.weekEndDate)}`}
            </p>
            <div className="form-group row">
              <div class="col-lg-12 col-md-12 col-xl-12 col-sm-12 text-center">
                <label for="exampleInputEmail1">Comment :</label>
                <textarea
                  className="form-control"
                  value={this.state.userApprovalComments}
                  onChange={this.setUserApprovalComments}
                />
                {isEmpty(this.state.userApprovalComments) && (<p style={{ color: 'red' }}>This is required</p>)}
              </div>
            </div>
            <p className="small_font text-center">
              {/* <b>Allen, Joe - Total Hours 40.00</b> */}
              <b>{`${get(this.state.timesheetdetails, 'userFirstname', '')}, ${get(this.state.timesheetdetails, 'userLastname', '')} - Total Hours`}</b>
            </p>
            <p className="xs_font text-center">I Certify that all the information in this timesheet is accurate and true.</p>
          </Modal.Body>
          <Modal.Footer>
            <div class="col-12 row mt-2">
              <div className="col-6">
                <button
                  onClick={() => this.setState({ displayConfirmationPopup: false })}
                  className="button resend-btn background-red px-2 float-left"
                >
                  No, Cancel
                </button>
              </div>
              <div className="col-6">
                <button
                  disabled={isEmpty(this.state.userApprovalComments)}
                  onClick={this.handleUserAction}
                  className="button resend-btn float-right px-4"
                >
                  Yes, Confirm
                </button>
              </div>
            </div>
          </Modal.Footer>
        </Modal>
      </div>
    );
  }
}

export default TimesheetChart;
