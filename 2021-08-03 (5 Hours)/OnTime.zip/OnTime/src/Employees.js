import React, { useState } from 'react';
import { Container, Tab, Tabs } from 'react-bootstrap';
import './App.css';
import LoadEmployeesTable from './components/LoadEmployeesTable.js';
import LoadEmployeesGroupTable from './components/LoadEmployeesGroupTable.js';


const Employees = () => {
  const [activeTab, setActiveTab] = useState('employees');
  return (
    <div className="App">
      <Container>
        <div className="contentwrapper pt-1 pb-5 mb-5">
          <Tabs defaultActiveKey="employees" activeKey={activeTab} className="customTabs" onSelect={(tab) => setActiveTab(tab)}>
            <Tab eventKey="employees" title={<span className="customTabsTitle">Manage Employees</span>}>
              {activeTab === 'employees' && <LoadEmployeesTable />}
            </Tab>
            <Tab eventKey="groups" title={<span className="customTabsTitle">Manage Groups</span>}>
              {activeTab === 'groups' && <LoadEmployeesGroupTable />}
            </Tab>
          </Tabs>
        </div>
      </Container>
    </div>
  );
}

export default Employees;
