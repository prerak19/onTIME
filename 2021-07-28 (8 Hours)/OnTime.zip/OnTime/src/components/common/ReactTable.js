import React, { useEffect, useState } from 'react';
import BootstrapTable from 'react-bootstrap-table-next';

const ReactTable = (props) => {
	const { data, columns, isSelection, onRowSelect, className } = props;
	const [selectedIds, setIds] = useState([]);
	const handleOnSelect = (row, isSelect) => {
		if (isSelect) {
			setIds([...selectedIds, row]);
		} else {
			const filteredSelections = selectedIds.filter((x) => x.tid !== row.tid);
			setIds(filteredSelections);
		}
	}

	useEffect(() => {
		onRowSelect(selectedIds);
	}, [selectedIds])

	const handleOnSelectAll = (isSelect, rows) => {
		isSelect ? setIds(rows) : setIds([]);
	}

	const selectRow = {
		mode: 'checkbox',
		hideSelectColumn: !isSelection,
		onSelect: handleOnSelect,
		onSelectAll: handleOnSelectAll
	};
	return (
		<BootstrapTable
			classes={className}
			keyField="tid"
			data={data}
			striped
			hover
			condensed
			columns={columns}
			selectRow={selectRow}
		/>
	);
}

ReactTable.defaultProps = {
	data: [],
	className: '',
	columns: [],
	isSelection: false,
	onRowSelect: () => { },
}

export default ReactTable;