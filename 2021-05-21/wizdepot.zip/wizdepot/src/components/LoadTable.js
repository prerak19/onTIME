import React from 'react';
import moment from 'moment';
import { MDBTable, MDBTableBody, MDBTableHead, MDBTooltip } from 'mdbreact';
import DatePicker from "react-datepicker";
import "react-datepicker/dist/react-datepicker.css";
import { Modal, Row } from "react-bootstrap";
import { apiPost, apiGet, apiPut, apiDelete } from '../Api.js';
import { confirmAlert } from 'react-confirm-alert';
import 'react-confirm-alert/src/react-confirm-alert.css';
import * as GeneralHelper from '../helpers/GeneralHelper'
import { find, isEmpty } from 'lodash';

class LoadTable extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      show: false,
      editshow: false,
      startDate: '',
      startDate1: '',
      startDate2: '',
      timedisabled: true,
      startdisabled: true,
      enddisabled: true,
      isChecked: false,
      holidaypolicy: true,
      rounding: false,
      rowresult: [],
      editdetails: {},
      fields: {},
      errors: {},
      error_message: '',
      activityTypes: GeneralHelper.activity_types,
      adminusers: [], roundingpolicies: [], holidaypolicies: []
    };
  }
  async componentDidMount() {
    await this.getFunction();
    this.getAdminUsers();
    this.getRoundingPolicies();
    this.getHolidayPolicies();
  }
  getRoundingPolicies = (e) => {
    let requestDetails = {
      method: 'policies/roundingpolicies/all/' + localStorage.orgid,
      params: {}
    };
    apiGet(requestDetails, true).then((response) => {
      this.setState({
        roundingpolicies: response.data
      })
    }).catch(error => {
      console.log(error)
    });
  }
  getHolidayPolicies = (e) => {
    let requestDetails = {
      method: 'policies/holidaypolicies/all/' + localStorage.orgid,
      params: {}
    };
    apiGet(requestDetails, true).then((response) => {
      this.setState({
        holidaypolicies: response.data
      })
    }).catch(error => {
      console.log(error)
    });
  }
  getAdminUsers = (e) => {
    let requestDetails = {
      method: 'adminusers/all/' + localStorage.orgid,
      params: {}
    };
    apiGet(requestDetails, true).then((response) => {
      this.setState({ adminusers: response.data });
    }).catch(error => {
      console.log(error)
    });
  }
  handleFormChange = (e) => {
    if (e.target.name == 'type') {
      this.toggleChangePolicy(e.target.value);
    }
    let editdetails = this.state.editdetails;
    let errors = this.state.errors;
    editdetails[e.target.name] = e.target.value;
    errors[e.target.name] = "form-control is-valid";
    this.setState({
      editdetails
    });
  }
  validateForm() {
    let editdetails = this.state.editdetails;
    let errors = {};
    let formIsValid = true;

    if (!editdetails["name"]) {
      formIsValid = false;
      errors["name"] = "form-control is-invalid";
    }
    if (!formIsValid) {
      this.setState({
        error_message: 'Please fill all * Required Fields!'
      });
    } else {
      this.setState({
        error_message: ''
      });
    }

    this.setState({
      errors: errors
    });
    return formIsValid;
  }
  addRecord = (e) => {
    const { editdetails } = this.state;
    if (this.validateForm()) {
      let requestDetails = {
        method: 'activities',
        params: {
          orgID: Number(localStorage.orgid),
          name: editdetails.name,
          code: Number(editdetails.code),
          description: editdetails.description,
          type: Number(editdetails.type),  //Duty
          status: Number(editdetails.status),  //Active
          timingMethod: editdetails.timingMethod === 0 ? 2 : Number(editdetails.timingMethod),
          roundingPolicyID: Number(editdetails.roundingPolicyID),
          holidayPolicyID: Number(editdetails.holidayPolicyID),
          activityApprover: { userID: editdetails.approverID },
          createdBy: Number(localStorage.userid)
        }
      };
      if ([10, 20, 30].includes(Number(editdetails.type))) {
        requestDetails.params = {
          ...requestDetails.params,
          allowExtra: editdetails.allowExtra,
          allowStart: moment(this.state.startDate).format('YYYY-MM-DD'),
          allowEnd: moment(this.state.startDate1).format('YYYY-MM-DD'),
          allowMax: editdetails.allowMax
        }
      }
      apiPost(requestDetails, true).then((response) => {
        this.setState({ show: false });
        this.getFunction();
      }).catch(error => {
        console.log(error)
      });
    }
  }
  editProcess = (d) => {
    this.setState({ editshow: true, holidaypolicy: true, rounding: false });
    this.setState({ editdetails: {} });
    let requestDetails = {
      method: 'activities/' + d.currentTarget.dataset.tag,
      params: {}
    };
    apiGet(requestDetails, true).then((response) => {
      let arrs = response.data;
      arrs.approverID = response.data.activityApprover.userID;
      if (response.data.allowExtra === 1) {
        this.setState({
          timedisabled: false,
          startdisabled: false,
          enddisabled: false, isChecked: true
        });
      } else {
        this.setState({
          timedisabled: true,
          startdisabled: true,
          enddisabled: true, isChecked: false
        });
      }
      this.setState({ editdetails: arrs });
      this.toggleChangePolicy(arrs.type)
    }
    ).catch(error => {
      console.log(error)
    });
  }
  editRecord = (e) => {
    const { editdetails } = this.state;
    if (this.validateForm()) {
      let requestDetails = {
        method: 'activities/' + e.currentTarget.dataset.tag,
        params: {
          actID: Number(e.currentTarget.dataset.tag),
          orgID: Number(localStorage.orgid),
          name: editdetails.name,
          code: Number(editdetails.code),
          description: editdetails.description,
          type: Number(editdetails.type),  //Duty
          status: Number(editdetails.status),  //Active
          timingMethod: editdetails.timingMethod === 0 ? 2 : Number(editdetails.timingMethod),
          roundingPolicyID: Number(editdetails.roundingPolicyID),
          holidayPolicyID: Number(editdetails.holidayPolicyID),
          activityApprover: { userID: editdetails.approverID },
          createdBy: Number(localStorage.userid),
        }
      };
      if ([10, 20, 30].includes(Number(editdetails.type))) {
        requestDetails.params = {
          ...requestDetails.params,
          allowExtra: editdetails.allowExtra,
          allowStart: moment(this.state.startDate).format('YYYY-MM-DD'),
          allowEnd: moment(this.state.startDate1).format('YYYY-MM-DD'),
          allowMax: editdetails.allowMax
        }
      }
      apiPut(requestDetails, true).then((response) => {
        this.setState({ editshow: false });
        this.getFunction();
      }).catch(error => {
        console.log(error)
      });
    }
  }
  deleteProcess = (e) => {
    var dv = e.currentTarget.dataset.tag;
    confirmAlert({
      customUI: ({ onClose }) => {
        return (
          <div className='custom-ui'>
            <h3>Are you sure?</h3>
            <p>You want to delete this?</p>
            <button data-tag={dv} onClick={() => {
              this.deleteRecord({ dv });
              onClose();
            }}>Yes, Delete it</button>
            <button onClick={onClose}>No, Cancel</button>
          </div>
        );
      }
    });
  }
  deleteRecord = (e) => {
    let requestDetails = {
      method: 'activities/' + e.dv,
      params: {}
    };
    apiDelete(requestDetails, true).then((response) => {
      this.getFunction();
    }).catch(error => {
      console.log(error)
    });
  }
  getFunction = (e) => {
    let requestDetails = {
      method: 'activities/all/' + localStorage.orgid,
      params: {}
    };
    apiGet(requestDetails, true).then((response) => {
      let result = response.data;
      this.setState({
        rowresult: result
      })
    }).catch(error => {
      console.log(error)
    });
  }

  handleChange = (date) => {
    this.setState({
      startDate: date
    })
  }
  handleChange1 = (date) => {
    this.setState({
      startDate1: date
    })
  }
  handleChange2 = (date) => {
    this.setState({
      startDate2: date
    })
  }
  toggleChange = (e) => {
    if (e.target.checked === true) {
      this.setState({
        timedisabled: false,
        startdisabled: false,
        enddisabled: false, isChecked: true
      });
    } else {
      this.setState({
        timedisabled: true,
        startdisabled: true,
        enddisabled: true, isChecked: false
      });
    }
  }
  toggleChangePolicy = (e) => {
    if (e === '50' || e === 50) {
      this.setState({
        holidaypolicy: false,
        rounding: true,
      });
    } else {
      this.setState({
        holidaypolicy: true,
        rounding: false,
      });
    }
  }
  isWeekday = (date) => {
    const day = date.getDay()
    return day === 0
  }
  ExampleCustomInput = ({ value, onClick }) => (
    <div className="inner-addon right-addon">
      <i className="fa fa-calendar"></i>
      <input disabled={this.state.startdisabled} onClick={onClick} value={value} type="text" className="example-custom-input form-control" placeholder="Select Date" name="date" />
    </div>
  );
  isWeekday1 = (date) => {
    const day = date.getDay()
    return day === 6
  }
  ExampleCustomInput1 = ({ value, onClick }) => (
    <div className="inner-addon right-addon">
      <i className="fa fa-calendar"></i>
      <input disabled={this.state.enddisabled} onClick={onClick} value={value} type="text" className="example-custom-input form-control" placeholder="Select Date" name="date" />
    </div>
  );
  ExampleCustomInput2 = ({ value, onClick }) => (
    <div className="inner-addon right-addon">
      <i className="fa fa-calendar"></i>
      <input disabled={this.state.timedisabled} onClick={onClick} value={value} type="text" className="example-custom-input form-control" placeholder="Select Date" name="date" />
    </div>
  );


  render() {
    const { editdetails } = this.state;
    return (
      <div>
        <div className="p-0 mb-3">
          <h6 className="col-12 text-left pl-0">List of Activities</h6>
          <Row className="m-0 width-100">
            <p className="small_font float-left col-lg-10 col-md-10 col-xl-10 col-sm-12 pl-0 text-muted">Total number of activities: {this.state.rowresult.length}</p>
            <button onClick={() => this.setState({
              editdetails: { type: '10', timingMethod: 2 }, show: true, holidaypolicy: true,
              rounding: false, timedisabled: true,
              startdisabled: true,
              enddisabled: true, isChecked: false
            })} className="button resend-btn py-2 px-4 col-lg-2 col-xl-2 col-md-2 col-sm-12 m-0"><i className="fa fa-plus pr-2"></i>Add Activity</button>
          </Row>
        </div>
        <MDBTable responsive bordered className="activityloadtable timesheets overflow">
          <MDBTableHead>
            <tr>
              <th rowSpan='2' className="sorting">Name</th>
              <th rowSpan='2'>Description</th>
              <th rowSpan='2'>Status</th>
              <th rowSpan='2'>ID</th>
              <th rowSpan='2'>Type</th>
              <th rowSpan='2'>Timing Method</th>
              <th rowSpan='2'>Approver</th>
              <th colSpan='4' className='text-center'>Allowance For Extra Hours</th>
              <th rowSpan='2'>Clock Round</th>
              <th rowSpan='2'>Edit</th>
              <th rowSpan='2'>Delete</th>
            </tr>
            <tr>
              <th>Extra Hours</th>
              <th>Start Date</th>
              <th>End Date</th>
              <th>Max Hours</th>
            </tr>
          </MDBTableHead>
          <MDBTableBody>
            {Array.isArray(this.state.rowresult) && this.state.rowresult.map((item, i) => {
              const rPolicy = !isEmpty(this.state.roundingpolicies) ? find(this.state.roundingpolicies, { pid: item.roundingPolicyID }) : {};
              return <tr key={i}>
                <td>{item.name}</td>
                <td>{item.description}</td>
                <td>{GeneralHelper.activity_status_codes[item.status]}</td>
                <td>{item.code}</td>
                <td>{GeneralHelper.activity_types_codes[item.type]}</td>
                <td>{GeneralHelper.timingMethod[item.timingMethod] || '-'}</td>
                <td>{item.activityApprover.firstName + ' ' + item.activityApprover.lastName}</td>
                <td>{(item.allowExtra == 1) ? "Allowed" : "Not Allowed"}</td>
                <td>{(item.allowExtra == 1) ? item.allowStart : "-"}</td>
                <td>{(item.allowExtra == 1) ? item.allowEnd : "-"}</td>
                <td>{(item.allowExtra == 1) ? item.allowMax + ' hrs' : "-"}</td>
                <td>{rPolicy ? rPolicy.name : 'N/A'}</td>
                <td><i className="fa fa-edit" data-tag={item.actID} onClick={this.editProcess} ></i></td>
                <td><i className="fa fa-trash" data-tag={item.actID} onClick={this.deleteProcess}></i></td>
              </tr>
            })
            }

          </MDBTableBody>
        </MDBTable>

        <Modal scrollable={true} size="lg" onHide={() => this.setState({ show: false })}
          show={this.state.show}>
          <Modal.Header closeButton>
            <Modal.Title className="h6" id="contained-modal-title-vcenter">
              Add Activity
        </Modal.Title>
          </Modal.Header>
          <Modal.Body className="show-grid small_font px-5">
            <div className="text-danger col-12 text-center">{this.state.error_message}</div>
            <div className="form-group">
              <label for="exampleInputEmail1">Activity Name*</label>
              <input type="text" value={editdetails.name} name="name" onChange={this.handleFormChange} className="form-control" placeholder="Activity Name" />
            </div>
            <div className="form-group">
              <label for="exampleInputEmail1">Activity Description</label>
              <textarea type="text" value={editdetails.description} name="description" onChange={this.handleFormChange} className="form-control" placeholder="Enter Activity Description"></textarea>
            </div>
            <div className="form-group row">
              <div className="col-xl-4 col-lg-4 col-md-4 col-sm-12">
                <label>Activity ID*</label>
                <input type="text" value={editdetails.code} name="code" onChange={this.handleFormChange} className="form-control" placeholder="Enter Activity ID" />
              </div>
              <div className="col-xl-4 col-lg-4 col-md-4 col-sm-12">
                <label>Activity Type*</label>
                <select value={editdetails.type} name="type" onChange={this.handleFormChange} placeholder="Select" className="form-control">
                  {Array.isArray(this.state.activityTypes) && this.state.activityTypes.map((item, i) => {
                    return <option value={item.code} key={i}>{item.name}</option>
                  })
                  }
                </select>
              </div>
              <div className="col-xl-4 col-lg-4 col-md-4 col-sm-12">
                <label>Timing Method</label>
                <select placeholder="Select" value={editdetails.timingMethod} defaultValue={2} name="timingMethod" onChange={this.handleFormChange} className="form-control">
                  <option value='1'>Punch In/Out</option>
                  <option value='2'>Manually Enter</option>
                </select>
              </div>
            </div>
            <div className="form-group row">
              <div className="col-xl-4 col-lg-4 col-md-4 col-sm-12">
                <label>Activity Status*</label>
                <select placeholder="Select" value={editdetails.status} name="status" onChange={this.handleFormChange} className="form-control">
                  <option value='200'>Inactive</option>
                  <option value='100'>Active</option>
                </select>
              </div>
              <div className="col-xl-4 col-lg-4 col-md-4 col-sm-12">
                <label className="mr-2">Activity Time Approver
                <MDBTooltip domElement tag="span" placement="top">
                    <span className="ml-2">
                      <i className="fa fa-question-circle" aria-hidden="true"></i></span>
                    <span>Not seeing your activity time approver? Go to Employees to set up the approver</span></MDBTooltip></label>
                <select placeholder="Select" value={editdetails.approverID} name="approverID" onChange={this.handleFormChange} className="form-control">
                  <option value='0'>Select</option>
                  {Array.isArray(this.state.adminusers) && this.state.adminusers.map((item, i) => {
                    return <option key={i} value={item.userID}>{item.firstName + ' ' + item.lastName}</option>
                  })
                  }
                </select>
              </div>
              <div className="col-xl-4 col-lg-4 col-md-4 col-sm-12" style={this.state.rounding === false ? {} : { display: 'none' }}>
                <label>TimeClock Rounding Policy</label>
                <select disabled={this.state.rounding} value={editdetails.roundingPolicyID} name="roundingPolicyID" onChange={this.handleFormChange} placeholder="Select" className="form-control">
                  {Array.isArray(this.state.roundingpolicies) && this.state.roundingpolicies.map((item, i) => {
                    return <option value={item.pid} key={i}>{item.name}</option>
                  })
                  }
                </select>
              </div>
              <div className="col-xl-4 col-lg-4 col-md-4 col-sm-12" style={this.state.holidaypolicy === false ? {} : { display: 'none' }}>
                <label>Holiday Policy</label>
                <select disabled={this.state.holidaypolicy} value={editdetails.holidayPolicyID} name="holidayPolicyID" onChange={this.handleFormChange} placeholder="Select" className="form-control">
                  {Array.isArray(this.state.holidaypolicies) && this.state.holidaypolicies.map((item, i) => {
                    return <option value={item.pid} key={i}>{item.name}</option>
                  })
                  }
                </select>
              </div>
            </div>
            {editdetails.type && [20, 10, 30].includes(Number(editdetails.type)) && <>
              <div className="form-group" style={this.state.holidaypolicy === true ? {} : { display: 'none' }}>
                <label>Setup for Allowance of Extra Hours</label>
              </div>
              <div className="form-group row" style={this.state.holidaypolicy === true ? {} : { display: 'none' }}>
                <label className="pr-2 float-left col-2" style={{ marginTop: '-4px' }}>Allowed</label>
                <input type="checkbox" defaultChecked={this.state.isChecked}
                  onChange={this.toggleChange} value="1" className="form-control" style={{ width: '3%' }} name="country" />
              </div>
              <div className="form-group row" style={this.state.holidaypolicy === true ? {} : { display: 'none' }}>
                <div className="col-xl-4 col-lg-4 col-md-4 col-sm-12">
                  <label className="pr-2">Start Week</label>
                  <DatePicker selected={this.state.startDate}
                    name="startDate" className="form-control" customInput={<this.ExampleCustomInput />}
                    filterDate={this.isWeekday} onChange={this.handleChange}
                    dateFormat="yyyy-MM-dd" />
                </div>
                <div className="col-xl-4 col-lg-4 col-md-4 col-sm-12">
                  <label className="pr-2">End Week</label>
                  <DatePicker selected={this.state.startDate1}
                    name="startDate" className="form-control" customInput={<this.ExampleCustomInput1 />}
                    filterDate={this.isWeekday1} onChange={this.handleChange1}
                    dateFormat="yyyy-MM-dd" />
                </div>
                <div className="col-xl-4 col-lg-4 col-md-4 col-sm-12">
                  <label className="pr-2">Max Hours</label>
                  <input type='number' value={editdetails.allowMax} name="allowMax" min='1' step='0.5' class='form-control' disabled={this.state.startdisabled} />
                </div>
              </div>
            </>}
          </Modal.Body>
          <Modal.Footer>
            <ul className="row form-group mr-0 mt-4 pr-0 list-inline pull-right">
              <li><button onClick={() => this.setState({ show: false })} className="button cancel-btn py-2 px-4 m-0 mr-2">Cancel</button></li>
              <li><button onClick={this.addRecord} className="button resend-btn py-2 px-4 m-0">Save Changes</button></li>
            </ul>
          </Modal.Footer>
        </Modal>
        <Modal scrollable={true} size="lg" onHide={() => this.setState({ editshow: false })}
          show={this.state.editshow}>
          <Modal.Header closeButton>
            <Modal.Title className="h6" id="contained-modal-title-vcenter">
              Edit Activity
        </Modal.Title>
          </Modal.Header>
          <Modal.Body className="show-grid small_font px-5">
            <div className="text-danger col-12 text-center">{this.state.error_message}</div>
            <div className="form-group">
              <label for="exampleInputEmail1">Activity Name*</label>
              <input type="text" value={editdetails.name} name="name" onChange={this.handleFormChange} className="form-control" placeholder="Activity Name" />
            </div>
            <div className="form-group">
              <label for="exampleInputEmail1">Activity Description</label>
              <textarea type="text" value={editdetails.description} name="description" onChange={this.handleFormChange} className="form-control" placeholder="Enter Activity Description"></textarea>
            </div>
            <div className="form-group row">
              <div className="col-xl-4 col-lg-4 col-md-4 col-sm-12">
                <label>Activity ID*</label>
                <input type="text" value={editdetails.code} name="code" onChange={this.handleFormChange} className="form-control" placeholder="Enter Activity ID" />
              </div>
              <div className="col-xl-4 col-lg-4 col-md-4 col-sm-12">
                <label>Activity Type*</label>
                <select value={editdetails.type} name="type" onChange={this.handleFormChange} placeholder="Select" className="form-control">
                  {Array.isArray(this.state.activityTypes) && this.state.activityTypes.map((item, i) => {
                    return <option value={item.code} key={i}>{item.name}</option>
                  })
                  }
                </select>
              </div>
              <div className="col-xl-4 col-lg-4 col-md-4 col-sm-12">
                <label>Timing Method</label>
                <select placeholder="Select" value={editdetails.timingMethod} defaultValue={2} name="timingMethod" onChange={this.handleFormChange} className="form-control">
                  <option value='1'>Punch In/Out</option>
                  <option value='2'>Manually Enter</option>
                </select>
              </div>
            </div>
            <div className="form-group row">
              <div className="col-xl-4 col-lg-4 col-md-4 col-sm-12">
                <label>Activity Status*</label>
                <select placeholder="Select" value={editdetails.status} name="status" onChange={this.handleFormChange} className="form-control">
                  <option value='200'>Inactive</option>
                  <option value='100'>Active</option>
                </select>
              </div>
              <div className="col-xl-4 col-lg-4 col-md-4 col-sm-12">
                <label className="mr-2">Activity Time Approver
                <MDBTooltip domElement tag="span" placement="top">
                    <span className="ml-2">
                      <i className="fa fa-question-circle" aria-hidden="true"></i></span>
                    <span>Not seeing your activity time approver? Go to Employees to set up the approver</span></MDBTooltip></label>
                <select placeholder="Select" value={editdetails.approverID} name="approverID" onChange={this.handleFormChange} className="form-control">
                  <option value='0'>Select</option>
                  {Array.isArray(this.state.adminusers) && this.state.adminusers.map((item, i) => {
                    return <option key={i} value={item.userID}>{item.firstName + ' ' + item.lastName}</option>
                  })
                  }
                </select>
              </div>
              <div className="col-xl-4 col-lg-4 col-md-4 col-sm-12" style={this.state.rounding === false ? {} : { display: 'none' }}>
                <label>TimeClock Rounding Policy</label>
                <select disabled={this.state.rounding} value={editdetails.roundingPolicyID} name="roundingPolicyID" onChange={this.handleFormChange} placeholder="Select" className="form-control">
                  {Array.isArray(this.state.roundingpolicies) && this.state.roundingpolicies.map((item, i) => {
                    return <option value={item.pid} key={i}>{item.name}</option>
                  })
                  }
                </select>
              </div>
              <div className="col-xl-4 col-lg-4 col-md-4 col-sm-12" style={this.state.holidaypolicy === false ? {} : { display: 'none' }}>
                <label>Holiday Policy</label>
                <select disabled={this.state.holidaypolicy} value={editdetails.holidayPolicyID} name="holidayPolicyID" onChange={this.handleFormChange} placeholder="Select" className="form-control">
                  {Array.isArray(this.state.holidaypolicies) && this.state.holidaypolicies.map((item, i) => {
                    return <option value={item.pid} key={i}>{item.name}</option>
                  })
                  }
                </select>
              </div>
            </div>
            {editdetails.type && [20, 10, 30].includes(Number(editdetails.type)) && <>
              <div className="form-group" style={this.state.holidaypolicy === true ? {} : { display: 'none' }}>
                <label>Setup for Allowance of Extra Hours</label>
              </div>
              <div className="form-group row" style={this.state.holidaypolicy === true ? {} : { display: 'none' }}>
                <label className="pr-2 float-left col-2" style={{ marginTop: '-4px' }}>Allowed</label>
                <input type="checkbox" checked={this.state.isChecked}
                  onChange={this.toggleChange} value="1" className="form-control" style={{ width: '3%' }} name="country" />
              </div>
              <div className="form-group row" style={this.state.holidaypolicy === true ? {} : { display: 'none' }}>
                <div className="col-xl-4 col-lg-4 col-md-4 col-sm-12">
                  <label className="pr-2">Start Week</label>
                  <DatePicker selected={this.state.startDate}
                    name="startDate" className="form-control" customInput={<this.ExampleCustomInput />}
                    filterDate={this.isWeekday} onChange={this.handleChange}
                    dateFormat="yyyy-MM-dd" value={editdetails.allowStart} />
                </div>
                <div className="col-xl-4 col-lg-4 col-md-4 col-sm-12">
                  <label className="pr-2">End Week</label>
                  <DatePicker selected={this.state.startDate1}
                    name="startDate1" className="form-control" customInput={<this.ExampleCustomInput1 />}
                    filterDate={this.isWeekday1} onChange={this.handleChange1}
                    dateFormat="yyyy-MM-dd" value={editdetails.allowEnd} />
                </div>
                <div className="col-xl-4 col-lg-4 col-md-4 col-sm-12">
                  <label className="pr-2">Max Hours</label>
                  <input type='number' value={editdetails.allowMax} name="allowMax" min='1' step='0.5' class='form-control' disabled={this.state.startdisabled} />
                </div>
              </div>
            </>}
          </Modal.Body>
          <Modal.Footer>
            <ul className="row form-group mr-0 mt-4 pr-0 list-inline pull-right">
              <li><button onClick={() => this.setState({ editshow: false })} className="button cancel-btn py-2 px-4 m-0 mr-2">Cancel</button></li>
              <li><button data-tag={editdetails.actID} onClick={this.editRecord} className="button resend-btn py-2 px-4 m-0">Save Changes</button></li>
            </ul>
          </Modal.Footer>
        </Modal>
      </div>
    );
  }
}
export default LoadTable;