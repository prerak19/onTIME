export const activity_types = [{'code':'10','name':'Duty'},{'code':'20','name':'G&A'},{'code':'30','name':'OH'},{'code':'40','name':'PTO'},{'code':'50','name':'Holiday'},{'code':'60','name':'LWOP'},{'code':'70','name':'Extra Mile'},{'code':'80','name':'Other'}];
export const activity_types_codes = {'10':'Duty','20':'G&A','30':'OH','40':'PTO','50':'Holiday','60':'LWOP','70':'Extra Mile','80':'Other'};

export const activity_status = [{'code':'100','name':'Active'},{'code':'200','name':'Inactive'},{'code':'300','name':'Deleted'}];
export const activity_status_codes = {'100':'Active','200':'Inactive','300':'Deleted'};

export const user_status = [{'code':'100','name':'Active'},{'code':'200','name':'Inactive'},{'code':'300','name':'Terminated'},{'code':'500','name':'Archived'},{'code':'900','name':'Email-Verifying'}];
export const user_status_codes = {'100':'Active','200':'Inactive','300':'Terminated','500':'Archived','900':'Email-Verifying'};

export const timesheet_status = [{'code':'100','name':'Active'}, {'code':'200','name':'Inactive'}, {'code':'300','name':'Submitted'}, {'code':'400','name':'Approvable'}, {'code':'500','name':'Approved'}, {'code':'600','name':'Archivable'}, {'code':'700','name':'Archived'}];
export const timesheet_status_codes = {'100':'Active', '200':'Inactive', '300':'Submitted', '400':'Approvable', '500':'Approved', '600':'Archivable', '700':'Archived'};

export const punchTypes = {'1':'Punch In','2':'Punch Out','3':'All'};

export const roundTypes = {'1':'Round Up','2':'Round Down','3':'Split Round'}; 

export const userTypes = {'0':'Not Employee','1':'Normal Employee','2':'Manager'};

export const adminTypes = {'0':'Not Admin','50':'Normal Admin','80':'Super User','90':'Root Super User'};

export const employeeTypes = [{'code':'10','name':'Salaried'},{'code':'20','name':'Full-Time Hourly'},{'code':'30','name':'Part-Time Hourly'},{'code':'40','name':'Temporary'},{'code':'50','name':'Intern'},{'code':'60','name':'SubContractor'}];
export const employeeTypes_codes = {'0':'Not Employee','10':'Salaried','20':'Full-Time Hourly','30':'Part-Time Hourly','40':'Temporary','50':'Intern','60':'SubContractor'};

export const wageCategory = [{'code':'1','name':'Exempt'},{'code':'2','name':'Non-exempt'},{'code':'3','name':'Other'}];
export const wageCategory_codes = {'0':'N/A','1':'Exempt','2':'Non-exempt','3':'Other'};

export const timingMethod = {'1':'Punch','2':'Manually Enter'};

export const DAYS_OF_WEEK = { 0: 'Sun', 1: 'Mon', 2: 'Tue', 3: 'Wed', 4: 'Thu', 5: 'Fri', 6: 'Sat' };
export const ClockInOuts = { 1: 'IN', 2: 'OUT' }