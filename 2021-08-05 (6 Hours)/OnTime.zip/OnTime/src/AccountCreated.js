import React from 'react';
import {Container} from 'react-bootstrap';
import 'bootstrap/dist/css/bootstrap.min.css';
import './App.css';
import Header from './components/Header.js';
import {apiGet,apiPost} from './Api.js';

class AccountCreated extends React.Component {
  constructor(props) {
    super(props);
    this.state = { 
      userid : (this.props.location.state) ? this.props.location.state.id :'',
      userdetails : '',
      fields: {},
      errors: {},
      error_message: '',
      success_message:''
    };
  };
  async componentDidMount() {     
    if(this.state.userid !== ""){
      this.getAdminUsers();
    }else{
      this.props.history.push({
        pathname: '/home',
      });
    }     
  }
  getAdminUsers = (e) => {
    let requestDetails = { 
      method:'employees/'+this.state.userid,
      params:{}
    };
    apiGet(requestDetails).then((response)=> {
      this.setState({ userdetails: response.data });  
    }).catch(error => {
      console.log(error)
    });
  }
  handleChange = (e) => {
    let fields = this.state.fields;
    let errors = this.state.errors;
    fields[e.target.name] = e.target.value;
    errors[e.target.name] = "form-control is-valid";
    this.setState({
      fields
    });
  }
  validateForm() {

    let fields = this.state.fields;
    let errors = {};
    let formIsValid = true;

    if (!fields["email"]) {
      formIsValid = false;
      errors["email"] = "form-control is-invalid";
    }
    if (typeof fields["email"] !== "undefined") {
      //regular expression for email validation
      var pattern = new RegExp(/^(("[\w-\s]+")|([\w-]+(?:\.[\w-]+)*)|("[\w-\s]+")([\w-]+(?:\.[\w-]+)*))(@((?:[\w-]+\.)*\w[\w-]{0,66})\.([a-z]{2,6}(?:\.[a-z]{2})?)$)|(@\[?((25[0-5]\.|2[0-4][0-9]\.|1[0-9]{2}\.|[0-9]{1,2}\.))((25[0-5]|2[0-4][0-9]|1[0-9]{2}|[0-9]{1,2})\.){2}(25[0-5]|2[0-4][0-9]|1[0-9]{2}|[0-9]{1,2})\]?$)/i);
      if (!pattern.test(fields["email"])) {
        formIsValid = false;
        errors["email"] = "form-control is-invalid";
      }
    }
    
    if(!formIsValid){
      this.setState({
        error_message: 'Please Enter Email!'
      });
    }else{
      this.setState({
        error_message: ''
      });
    }
    
    this.setState({
      errors: errors
    });
    return formIsValid;
  }
  resendEmail = (e) => {
    e.preventDefault();
    if (this.validateForm()) {
      let requestDetails = { 
        method:'adminusers/email-resend',
        params:{
          email : this.state.fields.email
        }
      };
      apiPost(requestDetails).then((response)=> {
        this.setState({success_message : 'Email Re-sent Successfully!'})        
      }).catch((error) => {
        this.setState({error_message : error.response.data.msg})
        window.scroll({top: 0, left: 0, behavior: 'smooth' })
      });           
      
    }else{
      
    }
  }
	render() {
  return (
    <div className="App">
      <header className="App-header">
          <Header />
      </header>
      <Container>
        <div className="content mt-5">          
          <div className="account_success_message width-70">
            <h3 className="xl_font">{this.state.userdetails.firstName +' '+this.state.userdetails.lastName}, your account for Company will be created after activation process is completed.</h3>
            <h5 className="large_font mb-1">Please follow the instructions to verify your email.</h5>
          </div>
          <div className="account_success_message width-70 float-left">
          <div className="border border-blue py-3 px-2 row m-0 mt-3">
            <div className="col-1 float-left p-1"><img width="100%" src={require("./components/assets/img/tick.png").default} alt="" /></div>
            <div className="col-11 float-right pl-2">
            <p className="large_font mb-0">We just sent you and email</p>
            <p className="small_font mb-0">The next step is to verify your email address. Check your inbox for the confirmation email.</p>
            </div>
          </div>
          <div className="border border-blue py-3 px-2 row m-0 mt-3">
            <div className="col-1 float-left p-1"><img width="100%" src={require("./components/assets/img/warning.png").default} alt="" /></div>
            <div className="col-11 float-right pl-2">
            <p className="large_font mb-0">Cant find the confirmation email?</p>
            <p className="small_font mb-0">Check your spam folder. If you still can't find it please <a href="!#">contact our support team</a> or resend</p>
            <input type="email" name="email" value={this.state.fields.email} onChange={this.handleChange} className={`form-control col-lg-8 col-md-8 col-sm-12 col-xl-8 mt-3 float-left ${this.state.errors["email"] ? this.state.errors["email"] : ''}` }  placeholder="Enter email address" />
            <input type="button" onClick={this.resendEmail} className="button col-lg-3 col-md-3 col-sm-12 col-xl-3 resend-btn"  value="Resend"/>
            <p className="text-danger">{this.state.error_message}</p>
            <p className="text-success">{this.state.success_message}</p>
            </div>
            
          </div>
          </div>
          <div className="width-30 float-right right-sidebar mt-2 mb-5">
                <p>Stay up to date with the latest WizDepot news.</p>
                <img className="mr-2 mt-1" src={require("./components/assets/img/fb.png").default} width="22%" alt="Logo"/>
                <img className="mr-2 mt-1" src={require("./components/assets/img/twitter.png").default} width="22%" alt="Logo"/>
                <img className="mr-2 mt-1" src={require("./components/assets/img/linkedin.png").default} width="22%" alt="Logo"/>
                <img className="mt-1" src={require("./components/assets/img/youtube.png").default} width="22%" alt="Logo"/>
          </div>
        </div>
      </Container>
    </div>
  );
  }
}

export default AccountCreated;
