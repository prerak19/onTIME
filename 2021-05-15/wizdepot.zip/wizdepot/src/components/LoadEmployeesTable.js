import React from 'react';
import { MDBDataTable } from 'mdbreact';
import DatePicker from "react-datepicker";
import "react-datepicker/dist/react-datepicker.css";
/* import "mdbreact/dist/css/mdb.css";
import "@fortawesome/fontawesome-free/css/all.min.css"; */
import '../App.css';
import {Modal,Row,Col} from "react-bootstrap";
import DualListBox from 'react-dual-listbox';
import 'react-dual-listbox/lib/react-dual-listbox.css';
import {apiPost,apiGet,apiPut,apiDelete} from '../Api.js';
import { confirmAlert } from 'react-confirm-alert'; 
import 'react-confirm-alert/src/react-confirm-alert.css'; 
import * as GeneralHelper from '../helpers/GeneralHelper'

class LoadEmployeesTable extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      show: false,
      editshow: false,
      startDate: '',
      startDate1: '',
      startDate2: '',
      timedisabled:true,
      startdisabled:true,
      enddisabled:true,
      isChecked: false,
      holidaypolicy:true,
      rounding:false,
      selected: [],
      options : [],
      rowresult: [],
      editdetails:[],
      fields: {},
      errors: {},
      error_message: '',
      groups:[],
      activities:[],
      empcount: 0,
      activity_id: 0,
      group_id: 0,
      status_id: 0,
      adminusers:[],
      activityList: [],
    };
  } 

  async componentDidMount() {  
    await this.getFunction();
    this.getGroups();
    this.getActivity();
    this.getAdminUsers(); 
  }
  getAdminUsers = (e) => {
    let requestDetails = { 
      method:'adminusers/all/'+localStorage.orgid,
      params:{}
    };
    apiGet(requestDetails, true).then((response)=> {
      this.setState({ adminusers: response.data });   
      console.log(this.state.adminusers);         
    }).catch(error => {
      console.log(error)
    });
  }
  getGroupName = (gid) =>{
    let gname = '';
    { Array.isArray(this.state.groups) &&  this.state.groups.map((item,i) =>{
      if(item.id == gid){
        gname = item.code;
      }      
    })
    }
    return gname;
  }
  getGroups = (e) => {
    let requestDetails = { 
      method:'groups/all/'+localStorage.orgid,
      params:{}
    };
    apiGet(requestDetails, true).then((response)=> { 
      this.setState({
        groups: response.data
      })     
      console.log(this.state.groups)                          
    }).catch(error => {
      console.log(error)
    });
  }
  groupChange = (e) => {
    let gid = e.target.value;
    this.getFunction(gid); 
    this.setState({group_id: gid}); 
  }
  getActivity = (e) => { 
    this.setState({ selected: [] });
    this.setState({ options: [] });
    this.setState({ activityList: [] });
    let requestDetails = { 
      method:'activities/all/'+localStorage.orgid,
      params:{}
    };
    apiGet(requestDetails, true).then((response)=> { 
      this.setState({
        activities: response.data
      })   
      let arr1 = this.state.options;
      { Array.isArray(response.data) &&  response.data.map((item) =>(  
        arr1.push({ value: item.actID , label: item.name, labeltype: item.type, labelallowExtra: item.allowExtra })
      ))
      }
      this.setState({ options: arr1 });             
    }).catch(error => {
      console.log(error)
    });
  }
  activityChange = (e) => {
    let aid = e.target.value;
    this.getFunction(this.state.group_id,aid); 
    this.setState({activity_id: aid});
  }
  statusChange = (e) => {
    let sid = e.target.value;
    this.getFunction(this.state.group_id,this.state.activity_id,sid); 
    this.setState({status_id: sid}); 
  }
  handleFormChange = (e) => {
    let editdetails = this.state.editdetails;
    let errors = this.state.errors;
    editdetails[e.target.name] = e.target.value;
    errors[e.target.name] = "form-control is-valid";
    this.setState({
      editdetails
    });
  }
  validateForm() {
    let editdetails = this.state.editdetails;
    let errors = {};
    let formIsValid = true;

    if (!editdetails["firstName"]) {
      formIsValid = false;
      console.log('test');
      errors["firstName"] = "form-control is-invalid";
    }
    if (!editdetails["lastName"]) {
      formIsValid = false;console.log('test1');
      errors["lastName"] = "form-control is-invalid";
    }
    if (!editdetails["userName"]) {
      formIsValid = false;console.log('test2');
      errors["userName"] = "form-control is-invalid";
    }
    if (!editdetails["password"]) {
      formIsValid = false;console.log('test3');
      errors["password"] = "form-control is-invalid";
    }
    if (!editdetails["cpassword"]) {
      formIsValid = false;console.log('test4');
      errors["cpassword"] = "form-control is-invalid";
    }
    if (!editdetails["approver"]) {
      formIsValid = false;console.log('test5');
      errors["approver"] = "form-control is-invalid";
    }
    if(!formIsValid){
      this.setState({
        error_message: 'Please fill all * Required Fields!'
      });
    }else{
      this.setState({
        error_message: ''
      });
    }
    
    this.setState({
      errors: errors
    });
    return formIsValid;
  }
  addProcess = (d) => {
    this.setState({ show: true }); 
    this.setState({ editdetails: [] });
  }
  addRecord = (e) => {
    if (this.validateForm()) {
      let requestDetails = { 
        method:'employees',
        params:{
          type : "user",
          org_id : localStorage.orgid,
          userName : this.state.editdetails.userName,
          password : this.state.editdetails.password,
          firstName : this.state.editdetails.firstName,
          lastName : this.state.editdetails.lastName,
          employeeType : this.state.editdetails.employeeType,//ft-hourly
          userType : this.state.editdetails.userType,//employee
          status : this.state.editdetails.status,//inactive
          email : this.state.editdetails.email,
          wage_category : this.state.editdetails.wage_category,//non-exempt
          timingMethod : this.state.editdetails.timingMethod,//punch
          timeApprover : { userID : this.state.editdetails.approver},
          group : { id : this.state.editdetails.group},
          userProfile : {
            employeeNumber : this.state.editdetails.employeeNumber,
              hireDate : this.state.editdetails.hireDate,
              anniversaryDate : this.state.editdetails.anniversaryDate,
              cEmail : this.state.editdetails.cEmail,
              cPhone : this.state.editdetails.cPhone,
              hPhone : this.state.editdetails.hPhone,
              mPhone : this.state.editdetails.mPhone,
              address1 : this.state.editdetails.address1,
              address2 : this.state.editdetails.address2,
              city : this.state.editdetails.city,
              state : this.state.editdetails.state,
              country : this.state.editdetails.country,
              zipcode : this.state.editdetails.zipcode,
              notifyTime : this.state.editdetails.notifyTime		    	
          },
          userActivities : this.state.activityList		    
        }
      };
      console.log(requestDetails);
      apiPost(requestDetails, true).then((response)=> { 
        this.setState({ show: false });
        this.getFunction();
      }).catch(error => {
        console.log(error)
      });    
    }
  } 
  editProcess = (d) => {
    this.setState({ editshow: true }); 
    this.setState({ editdetails: [] });
    this.getActivity();
    let requestDetails = { 
      method:'employees/'+d.currentTarget.dataset.tag,
      params:{}
    };
    apiGet(requestDetails, true).then((response)=> {
      let arrs = [];
      arrs.userName = response.data.userName;
      arrs.password = response.data.password;
      arrs.cpassword = response.data.password;
      arrs.firstName = response.data.firstName;
      arrs.lastName = response.data.lastName;
      arrs.employeeType = response.data.employeeType;
      arrs.status = response.data.status;
      arrs.email = response.data.email;
      arrs.wage_category = response.data.wage_category;
      arrs.timingMethod = response.data.timingMethod;
      arrs.approver = response.data.timeApprover.userID;
      arrs.group = response.data.group.id;
      arrs.employeeNumber = response.data.userProfile.employeeNumber;
      arrs.hireDate = response.data.userProfile.hireDate;
      arrs.anniversaryDate = response.data.userProfile.anniversaryDate;
      arrs.cEmail = response.data.userProfile.cEmail;
      arrs.cPhone = response.data.userProfile.cPhone;
      arrs.address1 = response.data.userProfile.address1;
      arrs.address2 = response.data.userProfile.address2;
      arrs.city = response.data.userProfile.city;
      arrs.state = response.data.userProfile.state;
      arrs.country = response.data.userProfile.country;
      arrs.zipcode = response.data.userProfile.zipcode;
      arrs.notifyTime	 = response.data.userProfile.notifyTime;	
      arrs.userID = response.data.userID;
      arrs.userType = response.data.userType
      this.setState({ editdetails: arrs });
      
      console.log(this.state.editdetails);

      let arr = this.state.selected;
      let arr2 = this.state.activityList;
      { Array.isArray(response.data.userActivities) &&  response.data.userActivities.map((item1) =>(  
        arr.push(item1.actID),
        arr2.push({ actID: item1.actID })
      ))
      }
      this.setState({ selected: arr });
      this.setState({ activityList: arr2 }); 
      }
    ).catch(error => {
      console.log(error)
    }); 
  }
  editRecord = (e) => {
    if (this.validateForm()) {
      let requestDetails = { 
        method:'employees/'+ e.currentTarget.dataset.tag,
        params:{
          type : "user",
          org_id : localStorage.orgid,
          userID : this.state.editdetails.userID,
          userName : this.state.editdetails.userName,
          password : this.state.editdetails.password,
          firstName : this.state.editdetails.firstName,
          lastName : this.state.editdetails.lastName,
          employeeType : this.state.editdetails.employeeType,//ft-hourly
          userType : this.state.editdetails.userType,//employee
          status : this.state.editdetails.status,//inactive
          email : this.state.editdetails.email,
          wage_category : this.state.editdetails.wage_category,//non-exempt
          timingMethod : this.state.editdetails.timingMethod,//punch
          timeApprover : { userID : this.state.editdetails.approver},
          group : { id : this.state.editdetails.group},
          userProfile : {
            employeeNumber : this.state.editdetails.employeeNumber,
              hireDate : this.state.editdetails.hireDate,
              anniversaryDate : this.state.editdetails.anniversaryDate,
              cEmail : this.state.editdetails.cEmail,
              cPhone : this.state.editdetails.cPhone,
              hPhone : '',
              mPhone : '',
              address1 : this.state.editdetails.address1,
              address2 : this.state.editdetails.address2,
              city : this.state.editdetails.city,
              state : this.state.editdetails.state,
              country : this.state.editdetails.country,
              zipcode : this.state.editdetails.zipcode,
              notifyTime : this.state.editdetails.notifyTime		    	
          },
          userActivities : this.state.activityList
        }
      };
      apiPut(requestDetails, true).then((response)=> { 
        this.setState({ editshow: false });
        this.getFunction();
      }).catch(error => {
        console.log(error)
      });    
    }else{
      return false;
    }
  }
  deleteProcess = (e) => {
    var dv = e.currentTarget.dataset.tag;
    confirmAlert({
      customUI: ({ onClose }) => {
        return (
          <div className='custom-ui'>
            <h3>Are you sure?</h3>
            <p>You want to delete this?</p>            
            <button data-tag={dv} onClick={() => {
            this.deleteRecord({dv});
            onClose();
          }}>Yes, Delete it</button>
            <button onClick={onClose}>No, Cancel</button>
          </div>
        );
      }
    });
  }
  deleteRecord = (e) => {
    let requestDetails = { 
      method:'employees/'+e.dv,
      params:{}
    };
    apiDelete(requestDetails, true).then((response)=> {
      this.getFunction();
    }).catch(error => {
      console.log(error)
    });  
  }
  getFunction = (gid='0',aid='0',sid='0') => {
    let requestDetails = { 
      method:'employees/all/'+localStorage.orgid,
      params:{
        group_id: gid,
        act_id : aid,
        status: sid
      }
    };
    apiPost(requestDetails, true).then((response)=> {             
      let result = response.data.users;
      let arr = [];
      { Array.isArray(result) &&  result.map((item) =>{
        let activitiesname = [];
        { Array.isArray(item.userActivities) &&  item.userActivities.map((item1) =>{
          activitiesname.push(item1.name);
        })
        }
                 
        arr.push({
          name: item.firstName +' '+item.lastName,
          status: GeneralHelper.user_status_codes[item.status],
          category: GeneralHelper.wageCategory_codes[item.wage_category],
          type: GeneralHelper.employeeTypes_codes[item.employeeType],
          date: item.userProfile.hireDate,
          method: GeneralHelper.timingMethod[item.timingMethod],
          activities: activitiesname.toString(),
          groupid: this.getGroupName(item.group.id),
          edit: <i class="fa fa-edit" data-tag={item.userID} onClick={this.editProcess}></i>,
          delete: <i class="fa fa-trash" data-tag={item.userID} onClick={this.deleteProcess}></i>,
        })
      })
        this.setState({
          rowresult: arr,
          empcount:response.data.count
        })
      }                  
    }).catch(error => {
      console.log(error)
    });
  }
  onChange = (selected) => {
    let data = this.state.options;
    this.setState({ activityList: [] });
    let arr1 = [];
    selected.map((item) => {
      let obj = data.find(o => o.value === item);
      arr1.push({ actID: obj.value })
    })

    this.setState({ activityList: arr1 });
    this.setState({ selected });
  };
  onAdd = (options) => {
    this.setState({ options });
  };
  handleChange = (date) => {
    this.setState({
      startDate: date
    })
  }
  handleChange1 = (date) => {
    this.setState({
      startDate1: date
    })
  }
  handleChange2 = (date) => {
    this.setState({
      startDate2: date
    })
  }
  toggleChange = (e) => {
    if(e.target.checked === true){      
      this.setState({
        timedisabled:false,
        startdisabled:false,
        enddisabled:false,
      });
    }else{
      this.setState({
        timedisabled:true,
        startdisabled:true,
        enddisabled:true,
      });
    }
  }
  toggleChangePolicy = (e) => {
    if(e.target.value === 'Holiday'){      
      this.setState({
        holidaypolicy:false,
        rounding:true,
      });
    }else{
      this.setState({
        holidaypolicy:true,
        rounding:false,
      });
    }
  }
  isWeekday = (date) => {
    const day = date.getDay()
    return day === 0
  }
  ExampleCustomInput = ({ value, onClick }) => (
    <button disabled={this.state.startdisabled} className="example-custom-input form-control" style={{
      minWidth: '100px',minHeight:'32px'
    }} onClick={onClick}>
      {value}
    </button>
  );
  isWeekday1 = (date) => {
    const day = date.getDay()
    return day === 6
  }
  ExampleCustomInput2 = ({ value, onClick }) => (
    <button  className="example-custom-input form-control" style={{
      minWidth: '100px',minHeight:'32px'
    }} onClick={onClick}>
      {value}
    </button>
  );

  render() {
  
  let datatable = {
    columns: [
      {
        label: 'Name',
        field: 'name',
        attributes: {
          'aria-controls': 'DataTable',
          'aria-label': 'Name',
        },
      },
      {
        label: 'Status',
        field: 'status',
      },
      {
        label: 'Wage Category',
        field: 'category',
      },
      {
        label: 'Employee Type',
        field: 'type',
      },
      {
        label: 'Hire Date',
        field: 'date',
      },
      {
        label: 'Timing Method',
        field: 'method',
      },
      {
        label: 'Activities',
        field: 'activities',
      },
      {
        label: 'Group ID',
        field: 'groupid',
      },
      {
        label: 'Edit',
        field: 'edit',
        sort: 'disabled',
      },
      {
        label: 'Delete',
        field: 'delete',
        sort: 'disabled',
      },
    ],
    rows: this.state.rowresult,
  }
  return (
    <div>
      
      <div className="form-group row small_font">      
        <div className="col-xl-2 col-lg-2 col-md-2 col-sm-12">
          <label>Group</label>
          <select className="form-control" onChange={this.groupChange}>
            <option value='0'>All Group</option>
            { Array.isArray(this.state.groups) &&  this.state.groups.map((item,i) =>{
              return <option value={item.id} key={i}>{item.name}</option>              
            })
            }            
          </select>
        </div>
        <div className="col-xl-2 col-lg-2 col-md-2 col-sm-12">
          <label>Activity</label>
          <select className="form-control" onChange={this.activityChange}>
            <option value='0'>All Activity</option>
            { Array.isArray(this.state.activities) &&  this.state.activities.map((item,i) =>{
              return <option value={item.actID} key={i}>{item.name}</option>              
            })
            } 
          </select>
        </div>
        <div className="col-xl-2 col-lg-2 col-md-2 col-sm-12" onChange={this.statusChange}>
          <label>Status</label>
          <select className="form-control">
            <option value='0'>All Employees</option>
            { Array.isArray(GeneralHelper.user_status) &&  GeneralHelper.user_status.map((item,i) =>{
              return <option value={item.code} key={i}>{item.name}</option>              
            })
            }
          </select>
        </div>
      </div>
      <div class="col-12 row mr-0 pr-0 pl-0 ml-0 mb-3">
        <h6 class="text-left float-left col-lg-10 col-md-10 col-xl-10 col-sm-12 pl-0">The Number of Total Employees : ({this.state.empcount})</h6>
        <button onClick={this.addProcess} class="button resend-btn py-2 px-4 col-lg-2 col-xl-2 col-md-2 col-sm-12 m-0"><i class="fa fa-plus pr-2"></i>Add Employees</button>
      </div>
      <MDBDataTable bordered hover info={false}  responsive={true} displayEntries={false} noBottomColumns entries={10} data={datatable} searching={false} />
      <Modal  scrollable={true} size="lg"  onHide={() => this.setState({ show: false })} 
          show={this.state.show}>
      <Modal.Header closeButton>
        <Modal.Title className="h6" id="contained-modal-title-vcenter">
        Add Employee Profile
        </Modal.Title>
      </Modal.Header>
      <Modal.Body className="show-grid small_font px-5">
      <div className="text-danger col-12 text-center">{this.state.error_message}</div>
            <div className="form-group row">
              <div className="col-xl-4 col-lg-4 col-md-4 col-sm-12">
                <label>First Name*</label>
                <input type="text" value={this.state.editdetails.firstName}  name="firstName" onChange={this.handleFormChange} className="form-control" placeholder="First Name" />
              </div>
              <div className="col-xl-4 col-lg-4 col-md-4 col-sm-12">
                <label>Last Name*</label>
                <input type="text" value={this.state.editdetails.lastName}  name="lastName" onChange={this.handleFormChange} className="form-control" placeholder="Last Name" />
              </div>
              <div className="col-xl-4 col-lg-4 col-md-4 col-sm-12">
                <label>Status*</label>
                <select value={this.state.editdetails.status}  name="status" onChange={this.handleFormChange} className="form-control">
                  { Array.isArray(GeneralHelper.user_status) &&  GeneralHelper.user_status.map((item,i) =>{
                    return <option value={item.code} key={i}>{item.name}</option>              
                  })
                  }
                </select>
              </div>
            </div>
            <div className="form-group row">
              <div className="col-xl-4 col-lg-4 col-md-4 col-sm-12">
                <label>Username*</label>
                <input type="text" value={this.state.editdetails.userName}  name="userName" onChange={this.handleFormChange} className="form-control" placeholder="Enter Username" />
              </div>
              <div className="col-xl-4 col-lg-4 col-md-4 col-sm-12">
                <label>Password*</label>
                <input type="password" value={this.state.editdetails.password}  name="password" onChange={this.handleFormChange} className="form-control" placeholder="Password" />
              </div>
              <div className="col-xl-4 col-lg-4 col-md-4 col-sm-12">
                <label>Confirm Password*</label>
                <input type="password" value={this.state.editdetails.cpassword}  name="cpassword" onChange={this.handleFormChange} className="form-control" placeholder="Confirm Password" />
              </div>
            </div>
            <div className="form-group row border-bottom pb-3">
                <div className="col-xl-4 col-lg-4 col-md-4 col-sm-12">
                <label className="pr-2">Notification Time</label>
                <select value={this.state.editdetails.notifyTime}  name="notifyTime" onChange={this.handleFormChange} className="form-control">
                  <option value='5'>5 Min</option>
                  <option value='10'>10 Min</option>
                  <option value='15'>15 Min</option>
                  <option value='20'>20 Min</option>
                  <option value='25'>25 Min</option>
                  <option value='30' selected='selected'>30 Min</option>
                  <option value='35'>35 Min</option>
                  <option value='40'>40 Min</option>
                  <option value='45'>45 Min</option>
                  <option value='50'>50 Min</option>
                  <option value='55'>55 Min</option>
                  <option value='60'>60 Min</option>
                </select>
                </div>
            </div>
            <div className="form-group row">
              <div className="col-xl-4 col-lg-4 col-md-4 col-sm-12">
                <label>Employee Number</label>
                <input type="text" value={this.state.editdetails.employeeNumber}  name="employeeNumber" onChange={this.handleFormChange} className="form-control" placeholder="Employee Number" />
              </div>
              <div className="col-xl-4 col-lg-4 col-md-4 col-sm-12">
                    <label>Timing Method*</label>
                    <select value={this.state.editdetails.timingMethod}  name="timingMethod" onChange={this.handleFormChange} disabled={this.state.rounding} placeholder="Select" className="form-control">
                        <option value='2'>Manually Enter</option>
                        <option value='1'>Punch</option>
                    </select>
              </div>
              <div className="col-xl-4 col-lg-4 col-md-4 col-sm-12">
                <label>Employee Type*</label>
                <select value={this.state.editdetails.employeeType}  name="employeeType" onChange={ (e) => {this.handleFormChange(e);this.toggleChangePolicy(e)}} placeholder="Select" className="form-control">
                  { Array.isArray(GeneralHelper.employeeTypes) &&  GeneralHelper.employeeTypes.map((item,i) =>{
                    return <option value={item.code} key={i}>{item.name}</option>              
                  })
                  }
                </select>
              </div>
            </div>
            <div className="form-group row">
                <div className="col-xl-4 col-lg-4 col-md-4 col-sm-12">
                  <label>Wage Category*</label>
                  <select value={this.state.editdetails.wage_category}  name="wage_category" onChange={this.handleFormChange} disabled={this.state.rounding} placeholder="Select" className="form-control">
                  { Array.isArray(GeneralHelper.wageCategory) &&  GeneralHelper.wageCategory.map((item,i) =>{
                    return <option value={item.code} key={i}>{item.name}</option>              
                  })
                  }
                  </select>
                </div>
                <div className="col-xl-4 col-lg-4 col-md-4 col-sm-12">
                    <label>Hire Date</label>
                    <input type="date" value={this.state.editdetails.hireDate}  name="hireDate" onChange={this.handleFormChange} className="form-control" placeholder="Enter Date" />
                </div>
                <div className="col-xl-4 col-lg-4 col-md-4 col-sm-12">
                    <label>Termination Date</label>
                    <input type="date" value={this.state.editdetails.terminationDate}  name="terminationDate" onChange={this.handleFormChange} className="form-control" placeholder="Enter Date" />
                </div>
            </div> 
            <div className="form-group row border-bottom pb-3">
                <div className="col-xl-4 col-lg-4 col-md-4 col-sm-12">
                    <label>Anniversary Date</label>
                    <input type="date" value={this.state.editdetails.anniversaryDate}  name="anniversaryDate" onChange={this.handleFormChange} className="form-control" placeholder="Enter Date" />
                </div>
            </div>
            <div className="form-group row">
                <div className="col-xl-4 col-lg-4 col-md-4 col-sm-12">
                    <label>Personal Email*</label>
                    <input type="email" value={this.state.editdetails.email}  name="email" onChange={this.handleFormChange} className="form-control" placeholder="Enter Email ID" />
                </div>
                <div className="col-xl-4 col-lg-4 col-md-4 col-sm-12">
                    <label>Work Email</label>
                    <input type="text" value={this.state.editdetails.cEmail}  name="cEmail" onChange={this.handleFormChange} className="form-control" placeholder="Enter Email ID" />
                </div>
                <div className="col-xl-4 col-lg-4 col-md-4 col-sm-12">
                    <label>Cell Phone</label>
                    <input type="number" value={this.state.editdetails.cPhone}  name="cPhone" onChange={this.handleFormChange} className="form-control" placeholder="Enter Phone Number" />
                </div>
            </div>
            <div className="form-group">
              <label for="exampleInputEmail1">Address</label>
              <input type="text" value={this.state.editdetails.address1}  name="address1" onChange={this.handleFormChange} className="form-control" placeholder="Enter Address" />
            </div>
            <div className="form-group">
              <label for="exampleInputEmail1">Address 2</label>
              <input type="text" value={this.state.editdetails.address2}  name="address2" onChange={this.handleFormChange} className="form-control" placeholder="Enter Address" />
            </div>
            <div className="form-group row border-bottom pb-3">
                <div className="col-xl-4 col-lg-4 col-md-4 col-sm-12">
                    <label>City</label>
                    <input type="text" value={this.state.editdetails.city}  name="city" onChange={this.handleFormChange} className="form-control" placeholder="Enter City" />
                </div>
                <div className="col-xl-4 col-lg-4 col-md-4 col-sm-12">
                    <label>State</label>
                    <select placeholder="State" value={this.state.editdetails.state}  name="state" onChange={this.handleFormChange} disabled={this.state.editable} className="form-control">
                          <option>State</option>
                          <option value='AL'>Alabama - AL</option>
                          <option value='AK'>Alaska - AK</option>
                          <option value='AL'>Alabama - AL</option>
                          <option value='AZ'>Arizona - AZ</option>
                          <option value='AR'>Arkansas - AR</option>
                          <option value='CA'>California - CA</option>
                          <option value='CO'>Colorado - CO</option>
                          <option value='CT'>Connecticut - CT</option>
                          <option value='DE'>Delaware - DE</option>
                          <option value='DC'>District of Columbia - DC</option>
                          <option value='FL'>Florida - FL</option>
                          <option value='GA'>Georgia - GA</option>
                          <option value='HI'>Hawaii - HI</option>
                          <option value='ID'>Idaho - ID</option>
                          <option value='IL'>Illinois - IL</option>
                          <option value='IN'>Indiana - IN</option>
                          <option value='IA'>Iowa - IA</option>
                          <option value='KS'>Kansas - KS</option>
                          <option value='KY'>Kentucky - KY</option>
                          <option value='LA'>Louisiana - LA</option>
                          <option value='ME'>Maine - ME</option>
                          <option value='MD'>Maryland - MD</option>
                          <option value='MA'>Massachusetts - MA</option>
                          <option value='MI'>Michigan - MI</option>
                          <option value='MN'>Minnesota - MN</option>
                          <option value='MS'>Mississippi - MS</option>
                          <option value='MO'>Missouri - MO</option>
                          <option value='MT'>Montana - MT</option>
                          <option value='NE'>Nebraska - NE</option>
                          <option value='NV'>Nevada - NV</option>
                          <option value='NH'>New Hampshire - NH</option>
                          <option value='NJ'>New Jersey - NJ</option>
                          <option value='NM'>New Mexico - NM</option>
                          <option value='NY'>New York - NY</option>
                          <option value='NC'>North Carolina - NC</option>
                          <option value='ND'>North Dakota - ND</option>
                          <option value='OH'>Ohio - OH</option>
                          <option value='OK'>Oklahoma - OK</option>
                          <option value='OR'>Oregon - OR</option>
                          <option value='PA'>Pennsylvania - PA</option>
                          <option value='PR'>Puerto Rico - PR</option>
                          <option value='RI'>Rhode Island - RI</option>
                          <option value='SC'>South Carolina - SC</option>
                          <option value='SD'>South Dakota - SD</option>
                          <option value='TN'>Tennessee - TN</option>
                          <option value='TX'>Texas - TX</option>
                          <option value='UT'>Utah - UT</option>
                          <option value='VT'>Vermont - VT</option>
                          <option value='VA'>Virginia - VA</option>
                          <option value='WA'>Washington - WA</option>
                          <option value='WV'>West Virginia - WV</option>
                          <option value='WI'>Wisconsin - WI</option>
                          <option value='WY'>Wyoming - WY</option>
                      </select>
                </div>
                <div className="col-xl-4 col-lg-4 col-md-4 col-sm-12">
                    <label>Zip Code</label>
                    <input type="number" value={this.state.editdetails.zipcode}  name="zipcode" onChange={this.handleFormChange} className="form-control" placeholder="Enter Zip Code" />
                </div>
                <div className="col-xl-4 col-lg-4 col-md-4 col-sm-12">
                    <label>Country</label>
                    <input type="text" value={this.state.editdetails.country}  name="country" onChange={this.handleFormChange} className="form-control" placeholder="Enter Country" />
                </div>
            </div>
            <div className="form-group row">
                <div className="col-xl-8 col-lg-8 col-md-8 col-sm-12">
                    <label className="mr-2">Activities</label>
                    <DualListBox lang ={{selectedHeader:'Selected Activities',
                    availableHeader: 'Available Activities'}}
                    showHeaderLabels={true}
                        options={this.state.options}
                        selected={this.state.selected}
                        onChange={this.onChange} className="mt-2" icons={{
                          moveLeft: '<',
                          moveAllLeft: '<<',
                          moveRight: '>',
                          moveAllRight: '>>'
                      }}
                    />
                </div>
                <div className="col-xl-4 col-lg-4 col-md-4 col-sm-12 m-auto">
                </div>
            </div>
            <div className="form-group row border-bottom pb-3">
                <div className="col-xl-4 col-lg-4 col-md-4 col-sm-12">
                    <label className="mr-2">Assigned Group</label>
                    <select value={this.state.editdetails.group}  name="group" onChange={this.handleFormChange} className="form-control">
                    <option value='0'>None</option>
                      { Array.isArray(this.state.groups) &&  this.state.groups.map((item,i) =>{
                        return <option value={item.id} key={i}>{item.name}</option>              
                      })
                      } 
                    </select>
                </div>
              <div className="col-xl-4 col-lg-4 col-md-4 col-sm-12">
                <label>Is Manager?</label>
                <select value={this.state.editdetails.userType}  name="userType" onChange={this.handleFormChange} className="form-control">
                    <option value='1'>NO</option>
                    <option value='2'>YES</option>
                </select>
              </div>
              <div className="col-xl-4 col-lg-4 col-md-4 col-sm-12">
                <label>Timesheet Approver*</label>
                <select value={this.state.editdetails.approver}  name="approver" onChange={this.handleFormChange} className="form-control">
                  <option value='0'>Select</option>
                  { Array.isArray(this.state.adminusers) &&  this.state.adminusers.map((item,i) =>{
                    return <option key={i} value={item.userID}>{item.firstName+' '+item.lastName}</option>
                    })
                  } 
                </select>
              </div>
            </div>
            <div className="form-group row">
              <div className="col-xl-6 col-lg-6 col-md-6 col-sm-12">
                <label for="exampleInputEmail1">Upload Signature File*</label>
                <Row className="">
                    <Col lg="12" md="12" sm="12" className="mt-3">
                        <button className="button resend-btn py-2 px-4 m-0">Choose File</button>
                        <p className="mt-1">File size limit: 1 MB</p>
                    </Col>
                </Row>
              </div>
              <div className="col-xl-6 col-lg-6 col-md-6 col-sm-12">
                <label for="exampleInputEmail1">Upload Initials File*</label>
                <Row className="">
                    <Col lg="12" md="12" sm="12" className="mt-3">
                        <button className="button resend-btn py-2 px-4 m-0">Choose File</button>
                        <p className="mt-1">File size limit: 1 MB</p>
                    </Col>
                </Row>
              </div>
            </div>
      </Modal.Body>
      <Modal.Footer>
      <ul class="row form-group mr-0 mt-4 pr-0 list-inline pull-right">
        <li><button onClick={() => this.setState({ show: false })} class="button cancel-btn py-2 px-4 m-0 mr-2">Cancel</button></li>
        <li><button onClick={this.addRecord} class="button resend-btn py-2 px-4 m-0">Save</button></li>
      </ul>
      </Modal.Footer>
    </Modal>
    <Modal  scrollable={true} size="lg" onHide={() => this.setState({ editshow: false })} 
          show={this.state.editshow}>
      <Modal.Header closeButton>
        <Modal.Title className="h6" id="contained-modal-title-vcenter">
        Edit Employee Profile
        </Modal.Title>
      </Modal.Header>
      <Modal.Body className="show-grid small_font px-5">
      <div className="text-danger col-12 text-center">{this.state.error_message}</div>
            <div className="form-group row">
              <div className="col-xl-4 col-lg-4 col-md-4 col-sm-12">
                <label>First Name*</label>
                <input type="text" value={this.state.editdetails.firstName}  name="firstName" onChange={this.handleFormChange} className="form-control" placeholder="First Name" />
              </div>
              <div className="col-xl-4 col-lg-4 col-md-4 col-sm-12">
                <label>Last Name*</label>
                <input type="text" value={this.state.editdetails.lastName}  name="lastName" onChange={this.handleFormChange} className="form-control" placeholder="Last Name" />
              </div>
              <div className="col-xl-4 col-lg-4 col-md-4 col-sm-12">
                <label>Status*</label>
                <select value={this.state.editdetails.status}  name="status" onChange={this.handleFormChange} className="form-control">
                  { Array.isArray(GeneralHelper.user_status) &&  GeneralHelper.user_status.map((item,i) =>{
                    return <option value={item.code} key={i}>{item.name}</option>              
                  })
                  }
                </select>
              </div>
            </div>
            <div className="form-group row">
              <div className="col-xl-4 col-lg-4 col-md-4 col-sm-12">
                <label>Username*</label>
                <input type="text" value={this.state.editdetails.userName}  name="userName" onChange={this.handleFormChange} className="form-control" placeholder="Enter Username" />
              </div>
              <div className="col-xl-4 col-lg-4 col-md-4 col-sm-12">
                <label>Password*</label>
                <input type="password" value={this.state.editdetails.password}  name="password" onChange={this.handleFormChange} className="form-control" placeholder="Password" />
              </div>
              <div className="col-xl-4 col-lg-4 col-md-4 col-sm-12">
                <label>Confirm Password*</label>
                <input type="password" value={this.state.editdetails.cpassword}  name="cpassword" onChange={this.handleFormChange} className="form-control" placeholder="Confirm Password" />
              </div>
            </div>
            <div className="form-group row border-bottom pb-3">
                <div className="col-xl-4 col-lg-4 col-md-4 col-sm-12">
                <label className="pr-2">Notification Time</label>
                <select value={this.state.editdetails.notifyTime}  name="notifyTime" onChange={this.handleFormChange} className="form-control">
                  <option value='5'>5 Min</option>
                  <option value='10'>10 Min</option>
                  <option value='15'>15 Min</option>
                  <option value='20'>20 Min</option>
                  <option value='25'>25 Min</option>
                  <option value='30' selected='selected'>30 Min</option>
                  <option value='35'>35 Min</option>
                  <option value='40'>40 Min</option>
                  <option value='45'>45 Min</option>
                  <option value='50'>50 Min</option>
                  <option value='55'>55 Min</option>
                  <option value='60'>60 Min</option>
                </select>
                </div>
            </div>
            <div className="form-group row">
              <div className="col-xl-4 col-lg-4 col-md-4 col-sm-12">
                <label>Employee Number</label>
                <input type="text" value={this.state.editdetails.employeeNumber}  name="employeeNumber" onChange={this.handleFormChange} className="form-control" placeholder="Employee Number" />
              </div>
              <div className="col-xl-4 col-lg-4 col-md-4 col-sm-12">
                    <label>Timing Method*</label>
                    <select value={this.state.editdetails.timingMethod}  name="timingMethod" onChange={this.handleFormChange} disabled={this.state.rounding} placeholder="Select" className="form-control">
                        <option value='2'>Manually Enter</option>
                        <option value='1'>Punch</option>
                    </select>
              </div>
              <div className="col-xl-4 col-lg-4 col-md-4 col-sm-12">
                <label>Employee Type*</label>
                <select value={this.state.editdetails.employeeType}  name="employeeType" onChange={ (e) => {this.handleFormChange(e);this.toggleChangePolicy(e)}} placeholder="Select" className="form-control">
                  { Array.isArray(GeneralHelper.employeeTypes) &&  GeneralHelper.employeeTypes.map((item,i) =>{
                    return <option value={item.code} key={i}>{item.name}</option>              
                  })
                  }
                </select>
              </div>
            </div>
            <div className="form-group row">
                <div className="col-xl-4 col-lg-4 col-md-4 col-sm-12">
                  <label>Wage Category*</label>
                  <select value={this.state.editdetails.wage_category}  name="wage_category" onChange={this.handleFormChange} disabled={this.state.rounding} placeholder="Select" className="form-control">
                  { Array.isArray(GeneralHelper.wageCategory) &&  GeneralHelper.wageCategory.map((item,i) =>{
                    return <option value={item.code} key={i}>{item.name}</option>              
                  })
                  }
                  </select>
                </div>
                <div className="col-xl-4 col-lg-4 col-md-4 col-sm-12">
                    <label>Hire Date</label>
                    <input type="date" value={this.state.editdetails.hireDate}  name="hireDate" onChange={this.handleFormChange} className="form-control" placeholder="Enter Date" />
                </div>
                <div className="col-xl-4 col-lg-4 col-md-4 col-sm-12">
                    <label>Termination Date</label>
                    <input type="date" value={this.state.editdetails.terminationDate}  name="terminationDate" onChange={this.handleFormChange} className="form-control" placeholder="Enter Date" />
                </div>
            </div> 
            <div className="form-group row border-bottom pb-3">
                <div className="col-xl-4 col-lg-4 col-md-4 col-sm-12">
                    <label>Anniversary Date</label>
                    <input type="date" value={this.state.editdetails.anniversaryDate}  name="anniversaryDate" onChange={this.handleFormChange} className="form-control" placeholder="Enter Date" />
                </div>
            </div>
            <div className="form-group row">
                <div className="col-xl-4 col-lg-4 col-md-4 col-sm-12">
                    <label>Personal Email*</label>
                    <input type="email" value={this.state.editdetails.email}  name="email" onChange={this.handleFormChange} className="form-control" placeholder="Enter Email ID" />
                </div>
                <div className="col-xl-4 col-lg-4 col-md-4 col-sm-12">
                    <label>Work Email</label>
                    <input type="text" value={this.state.editdetails.cEmail}  name="cEmail" onChange={this.handleFormChange} className="form-control" placeholder="Enter Email ID" />
                </div>
                <div className="col-xl-4 col-lg-4 col-md-4 col-sm-12">
                    <label>Cell Phone</label>
                    <input type="number" value={this.state.editdetails.cPhone}  name="cPhone" onChange={this.handleFormChange} className="form-control" placeholder="Enter Phone Number" />
                </div>
            </div>
            <div className="form-group">
              <label for="exampleInputEmail1">Address</label>
              <input type="text" value={this.state.editdetails.address1}  name="address1" onChange={this.handleFormChange} className="form-control" placeholder="Enter Address" />
            </div>
            <div className="form-group">
              <label for="exampleInputEmail1">Address 2</label>
              <input type="text" value={this.state.editdetails.address2}  name="address2" onChange={this.handleFormChange} className="form-control" placeholder="Enter Address" />
            </div>
            <div className="form-group row border-bottom pb-3">
                <div className="col-xl-4 col-lg-4 col-md-4 col-sm-12">
                    <label>City</label>
                    <input type="text" value={this.state.editdetails.city}  name="city" onChange={this.handleFormChange} className="form-control" placeholder="Enter City" />
                </div>
                <div className="col-xl-4 col-lg-4 col-md-4 col-sm-12">
                    <label>State</label>
                    <select placeholder="State" value={this.state.editdetails.state}  name="state" onChange={this.handleFormChange} disabled={this.state.editable} className="form-control">
                          <option>State</option>
                          <option value='AL'>Alabama - AL</option>
                          <option value='AK'>Alaska - AK</option>
                          <option value='AL'>Alabama - AL</option>
                          <option value='AZ'>Arizona - AZ</option>
                          <option value='AR'>Arkansas - AR</option>
                          <option value='CA'>California - CA</option>
                          <option value='CO'>Colorado - CO</option>
                          <option value='CT'>Connecticut - CT</option>
                          <option value='DE'>Delaware - DE</option>
                          <option value='DC'>District of Columbia - DC</option>
                          <option value='FL'>Florida - FL</option>
                          <option value='GA'>Georgia - GA</option>
                          <option value='HI'>Hawaii - HI</option>
                          <option value='ID'>Idaho - ID</option>
                          <option value='IL'>Illinois - IL</option>
                          <option value='IN'>Indiana - IN</option>
                          <option value='IA'>Iowa - IA</option>
                          <option value='KS'>Kansas - KS</option>
                          <option value='KY'>Kentucky - KY</option>
                          <option value='LA'>Louisiana - LA</option>
                          <option value='ME'>Maine - ME</option>
                          <option value='MD'>Maryland - MD</option>
                          <option value='MA'>Massachusetts - MA</option>
                          <option value='MI'>Michigan - MI</option>
                          <option value='MN'>Minnesota - MN</option>
                          <option value='MS'>Mississippi - MS</option>
                          <option value='MO'>Missouri - MO</option>
                          <option value='MT'>Montana - MT</option>
                          <option value='NE'>Nebraska - NE</option>
                          <option value='NV'>Nevada - NV</option>
                          <option value='NH'>New Hampshire - NH</option>
                          <option value='NJ'>New Jersey - NJ</option>
                          <option value='NM'>New Mexico - NM</option>
                          <option value='NY'>New York - NY</option>
                          <option value='NC'>North Carolina - NC</option>
                          <option value='ND'>North Dakota - ND</option>
                          <option value='OH'>Ohio - OH</option>
                          <option value='OK'>Oklahoma - OK</option>
                          <option value='OR'>Oregon - OR</option>
                          <option value='PA'>Pennsylvania - PA</option>
                          <option value='PR'>Puerto Rico - PR</option>
                          <option value='RI'>Rhode Island - RI</option>
                          <option value='SC'>South Carolina - SC</option>
                          <option value='SD'>South Dakota - SD</option>
                          <option value='TN'>Tennessee - TN</option>
                          <option value='TX'>Texas - TX</option>
                          <option value='UT'>Utah - UT</option>
                          <option value='VT'>Vermont - VT</option>
                          <option value='VA'>Virginia - VA</option>
                          <option value='WA'>Washington - WA</option>
                          <option value='WV'>West Virginia - WV</option>
                          <option value='WI'>Wisconsin - WI</option>
                          <option value='WY'>Wyoming - WY</option>
                      </select>
                </div>
                <div className="col-xl-4 col-lg-4 col-md-4 col-sm-12">
                    <label>Zip Code</label>
                    <input type="number" value={this.state.editdetails.zipcode}  name="zipcode" onChange={this.handleFormChange} className="form-control" placeholder="Enter Zip Code" />
                </div>
                <div className="col-xl-4 col-lg-4 col-md-4 col-sm-12">
                    <label>Country</label>
                    <input type="text" value={this.state.editdetails.country}  name="country" onChange={this.handleFormChange} className="form-control" placeholder="Enter Country" />
                </div>
            </div>
            <div className="form-group row">
                <div className="col-xl-8 col-lg-8 col-md-8 col-sm-12">
                    <label className="mr-2">Activities</label>
                    <DualListBox lang ={{selectedHeader:'Selected Activities',
                    availableHeader: 'Available Activities'}}
                    showHeaderLabels={true}
                        options={this.state.options}
                        selected={this.state.selected}
                        onChange={this.onChange} className="mt-2" icons={{
                          moveLeft: '<',
                          moveAllLeft: '<<',
                          moveRight: '>',
                          moveAllRight: '>>'
                      }}
                    />
                </div>
                <div className="col-xl-4 col-lg-4 col-md-4 col-sm-12 m-auto">
                </div>
            </div>
            <div className="form-group row border-bottom pb-3">
                <div className="col-xl-4 col-lg-4 col-md-4 col-sm-12">
                    <label className="mr-2">Assigned Group</label>
                    <select value={this.state.editdetails.group}  name="group" onChange={this.handleFormChange} className="form-control">
                    <option value='0'>None</option>
                      { Array.isArray(this.state.groups) &&  this.state.groups.map((item,i) =>{
                        return <option value={item.id} key={i}>{item.name}</option>              
                      })
                      } 
                    </select>
                </div>
              <div className="col-xl-4 col-lg-4 col-md-4 col-sm-12">
                <label>Is Manager?</label>
                <select value={this.state.editdetails.userType}  name="userType" onChange={this.handleFormChange} className="form-control">
                    <option value='1'>NO</option>
                    <option value='2'>YES</option>
                </select>
              </div>
              <div className="col-xl-4 col-lg-4 col-md-4 col-sm-12">
                <label>Timesheet Approver*</label>
                <select value={this.state.editdetails.approver}  name="approver" onChange={this.handleFormChange} className="form-control">
                  <option value='0'>Select</option>
                  { Array.isArray(this.state.adminusers) &&  this.state.adminusers.map((item,i) =>{
                    return <option key={i} value={item.userID}>{item.firstName+' '+item.lastName}</option>
                    })
                  } 
                </select>
              </div>
            </div>
            <div className="form-group row">
              <div className="col-xl-6 col-lg-6 col-md-6 col-sm-12">
                <label for="exampleInputEmail1">Upload Signature File*</label>
                <Row className="">
                    <Col lg="12" md="12" sm="12" className="mt-3">
                        <button className="button resend-btn py-2 px-4 m-0">Choose File</button>
                        <p className="mt-1">File size limit: 1 MB</p>
                    </Col>
                </Row>
              </div>
              <div className="col-xl-6 col-lg-6 col-md-6 col-sm-12">
                <label for="exampleInputEmail1">Upload Initials File*</label>
                <Row className="">
                    <Col lg="12" md="12" sm="12" className="mt-3">
                        <button className="button resend-btn py-2 px-4 m-0">Choose File</button>
                        <p className="mt-1">File size limit: 1 MB</p>
                    </Col>
                </Row>
              </div>
            </div>
      </Modal.Body>
      <Modal.Footer>
      <ul class="row form-group mr-0 mt-4 pr-0 list-inline pull-right">
        <li><button onClick={() => this.setState({ editshow: false })} class="button cancel-btn py-2 px-4 m-0 mr-2">Cancel</button></li>
        <li><button data-tag={this.state.editdetails.userID} onClick={this.editRecord} class="button resend-btn py-2 px-4 m-0">Save Changes</button></li>
      </ul>
      </Modal.Footer>
    </Modal>
    </div>
  );
}
}
export default LoadEmployeesTable;