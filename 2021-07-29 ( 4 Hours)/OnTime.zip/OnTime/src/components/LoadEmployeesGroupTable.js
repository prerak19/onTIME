import React from 'react';
import '../App.css';
import { Modal, } from "react-bootstrap";
import DualListBox from 'react-dual-listbox';
import 'react-dual-listbox/lib/react-dual-listbox.css';
import { apiPost, apiGet, apiPut, apiDelete } from '../Api.js';
import { cloneDeep, isEqual } from 'lodash';
import { confirmPopup } from '../helpers/Helpers';
import { confirmAlert } from 'react-confirm-alert';
import 'react-confirm-alert/src/react-confirm-alert.css';
import ReactTable from './common/ReactTable';

class LoadEmployeesGroupTable extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      show: false,
      editshow: false,
      selected: [],
      options: [],
      empselected: [],
      empoptions: [],
      rowresult: [],
      editdetails: [],
      fields: {},
      errors: {},
      error_message: '',
      employeesList: [],
      activityList: [],
      allEmployees: [],
      adminusers: [],
    };
  }
  componentDidMount() {
    this.getFunction();
    this.getAdminUsers();
    this.getActivities();
  }
  getAdminUsers = (e) => {
    let requestDetails = {
      method: 'employees/approvers/' + localStorage.orgid,
      params: {}
    };
    apiGet(requestDetails).then((response) => {
      this.setState({ adminusers: response.data });
    }).catch(error => {
      console.log(error)
    });
  }
  handleFormChange = (e) => {
    let editdetails = this.state.editdetails;
    let errors = this.state.errors;
    editdetails[e.target.name] = e.target.value;
    errors[e.target.name] = "form-control is-valid";
    this.setState({
      editdetails
    });
  }
  validateForm() {
    let editdetails = this.state.editdetails;
    let errors = {};
    let formIsValid = true;

    if (!editdetails["code"]) {
      formIsValid = false;
      errors["code"] = "form-control is-invalid";
    }
    if (!editdetails["name"]) {
      formIsValid = false;
      errors["name"] = "form-control is-invalid";
    }
    if (!formIsValid) {
      this.setState({
        error_message: 'Please fill all * Required Fields!'
      });
    } else {
      this.setState({
        error_message: ''
      });
    }

    this.setState({
      errors: errors
    });
    return formIsValid;
  }
  getActivities = (e) => {
    this.setState({ editdetails: [], selected: [], activityList: [], options: [] });
    let requestDetails1 = {
      method: `activities/all/${localStorage.orgid}?status=100`,
      params: {}
    };
    apiGet(requestDetails1, false).then((response) => {
      let arr1 = this.state.options;
      Array.isArray(response.data) && response.data.map((item) => (
        arr1.push({ value: item.actID, label: item.name, labeltype: item.type, labelallowExtra: item.allowExtra })
      ))
      this.setState({ options: arr1 });
    }).catch(error => {
      console.log(error)
    });
  }
  getEmployees = (e) => {
    let requestDetails1 = {
      method: `employees/all/${localStorage.orgid}`,
      params: {
        status: 100,
      }
    };
    apiPost(requestDetails1).then((response) => {
      let arr1 = [];
      Array.isArray(response.data.users) && response.data.users.map((item) => (
        item.group.id === 0 && arr1.push({ value: item.userID, label: item.firstName + ' ' + item.lastName })
      ))
      this.setState({ empoptions: arr1, allEmployees: arr1 });
    }).catch(error => {
      console.log(error)
    });
  }


  addRecord = (sameName = false) => {
    const { editshow, editdetails } = this.state;
    if (this.validateForm()) {
      let apiKey = null;
      let requestDetails = {
        method: `groups?uid=${localStorage.userid}/samenameok${sameName ? 1 : 0}`,
        params: {
          orgId: localStorage.orgid,
          name: this.state.editdetails.name,
          code: this.state.editdetails.code,
          desc: this.state.editdetails.desc,
          approver: {
            userID: this.state.editdetails.userID
          },
          "groupUsers": this.state.employeesList,
          "groupActivities": this.state.activityList
        }
      }
      if (editshow) {
        requestDetails = {
          method: `groups/${editdetails.id}?samenameok=${sameName ? 1 : 0}`,
          params: { ...requestDetails.params, id: editdetails.id }
        }
        apiKey = apiPut(requestDetails)
      } else {
        apiKey = apiPost(requestDetails)
      }
      apiKey.then((res) => {
        const obj = JSON.parse(res.request.response);
        if (res && isEqual(res.status, 200) && res.data) {
          window.alert(obj.msg);
          this.clearData();
          this.getFunction();
        }
        if (res.request.response && res.request.status !== 200) {
          if (obj.code === -10) {
            this.sameApprover();
          } else {
            obj.msg ? window.alert(obj.msg) : window.alert('Something Went Wrong!');
            return;
          }
        }
      }).catch(error => {
        console.log(error)
      });
    }
  }

  sameApprover = () => {
    confirmAlert({
      customUI: ({ onClose }) => {
        return (
          <div className='custom-ui'>
            <p>The selected Group Timesheet Approver has same name as one of the group members, are they the same person?
              (If yes, please select a different Group Timesheet Approver or make change to the group members.)</p>
            <button onClick={onClose}>Yes, Let me change it</button>
            <button onClick={async () => {
              await this.addRecord(true);
              onClose();
            }}>No, continue</button>
          </div>
        );
      },
    });
  }

  editProcess = (d) => {
    const { allEmployees } = this.state;
    this.clearData(false, true);
    let requestDetails = {
      method: 'groups/' + d.currentTarget.dataset.tag,
      params: {}
    };
    apiGet(requestDetails).then((response) => {
      if (response && response.data) {
        const arrs = { ...response.data, userID: response.data.approver.userID };
        let emOpt = cloneDeep(allEmployees);
        let arr = [];
        let arr2 = [];
        let arr3 = [];
        let arr4 = [];
        Array.isArray(response.data.groupActivities) && response.data.groupActivities.map((item1) => {
          arr.push(item1.actID);
          arr2.push({ actID: item1.actID, type: item1.type, allowExtra: item1.allowExtra });
          return null;
        })
        Array.isArray(response.data.groupUsers) && response.data.groupUsers.map((item2) => {
          arr3.push(item2.userID);
          arr4.push({ userID: item2.userID });
          if (!emOpt.find((x) => x.value === item2.userID)) {
            emOpt.push({ value: item2.userID, label: item2.firstName + ' ' + item2.lastName });
          }
          return null;
        })
        this.setState({ editdetails: arrs, selected: arr, empoptions: emOpt, activityList: arr2, empselected: arr3, employeesList: arr4 });
      }
    }
    ).catch(error => {
      console.log(error)
    });
  }
  deleteProcess = (e) => {
    var dv = e.currentTarget.dataset.tag;
    confirmPopup(() => this.deleteRecord(dv));
  }
  deleteRecord = (id) => {
    let requestDetails = {
      method: `groups/${id}`,
      params: {}
    };
    apiDelete(requestDetails).then((res) => {
      if (res && isEqual(res.status, 200) && res.data) {
        this.getFunction();
      }
      if (res.request.response && res.request.status !== 200) {
        let obj = JSON.parse(res.request.response);
        obj.msg ? window.alert(obj.msg) : window.alert('Something Went Wrong!');
        return;
      }
    }).catch(error => {
      console.log(error)
    });
  }
  getFunction = (e) => {
    this.getEmployees();
    let requestDetails = {
      method: 'groups/all/' + localStorage.orgid,
      params: {}
    };
    apiGet(requestDetails).then((res) => {
      if (res && res.status === 200 && res.data) {
        let result = res.data;
        let arr = [];
        Array.isArray(result) && result.map((item) => (
          arr.push({
            id: item.code,
            name: item.name,
            desc: item.desc,
            approver: item.approver ? item.approver.firstName + ' ' + item.approver.lastName : '',
            edit: <i className="fa fa-edit" data-tag={item.id} onClick={this.editProcess}></i>,
            delete: <i className="fa fa-trash" data-tag={item.id} onClick={this.deleteProcess}></i>,
          })
        ));
        this.setState({ rowresult: arr });
      }
    }).catch(error => {
      console.log(error)
    });
  }

  onChange = (selected) => {
    let data = this.state.options;
    let arr1 = [];
    selected.map((item) => {
      let obj = data.find(o => o.value === item);
      obj && arr1.push({ actID: obj.value, type: obj.labeltype, allowExtra: obj.labelallowExtra });
      return null;
    })

    this.setState({ activityList: arr1, selected });
  };
  onChangeEmp = (empselected) => {
    let data = this.state.empoptions;
    let arr1 = [];
    empselected.map((item) => {
      let obj = data.find(o => o.value === item);
      if (obj) {
        arr1.push({ userID: obj.value })
      }
      return null;
    })
    this.setState({ employeesList: arr1, empselected });
  };

  clearData = (addModal = false, editModal = false) => {
    this.setState({
      show: addModal, editshow: editModal, editdetails: {}, selected: [],
      empoptions: cloneDeep(this.state.allEmployees), empselected: [], error_message: '', employeesList: [], activityList: [],
    });
  }

  render() {
    const defaultColumns = [
      {
        text: 'Group ID',
        dataField: 'id',
      },
      {
        text: 'Group Name',
        dataField: 'name',
      },
      {
        text: 'Description',
        dataField: 'desc',
      },
      {
        text: 'Approver',
        dataField: 'approver',
      },
      {
        text: 'Edit',
        dataField: 'edit',
      },
      {
        text: 'Delete',
        dataField: 'delete',
      },
    ];
    return (
      <div>
        <div className="col-12 row mr-0 pr-0 pl-0 ml-0 mb-3">
          <h6 className="text-left float-left col-lg-9 col-md-9 col-xl-9 col-sm-12 pl-0">Employee Group List</h6>
          <button onClick={() => this.clearData(true, false)} className="button resend-btn py-2 px-4 col-lg-3 col-xl-3 col-md-3 col-sm-12 m-0"><i className="fa fa-plus pr-2"></i>Add Employee Group</button>
        </div>
        <ReactTable
          className="timesheets mb-0"
          columns={defaultColumns}
          showPagination={true}
          data={this.state.rowresult}
        />
        <Modal scrollable={true} size="lg" onHide={() => this.clearData()}
          show={this.state.show}>
          <Modal.Header closeButton>
            <Modal.Title className="h6" >
              Add Employee Group
        </Modal.Title>
          </Modal.Header>
          <Modal.Body className="show-grid small_font px-5">
            <div className="text-danger col-12 text-center">{this.state.error_message}</div>
            <div className="form-group row">
              <div className="col-xl-6 col-lg-6 col-md-6 col-sm-12">
                <label>Group ID*</label>
                <input type="text" value={this.state.editdetails.code} name="code" onChange={this.handleFormChange} className="form-control" placeholder="Enter Group ID" />
              </div>
              <div className="col-xl-6 col-lg-6 col-md-6 col-sm-12">
                <label>Group Name*</label>
                <input type="text" value={this.state.editdetails.name} name="name" onChange={this.handleFormChange} className="form-control" placeholder="Enter Group Name" />
              </div>
            </div>
            <div className="form-group row">
              <div className="col-xl-6 col-lg-6 col-md-6 col-sm-12">
                <label>Group Description</label>
                <textarea name="desc" onChange={this.handleFormChange} className="form-control" placeholder="Enter Description">
                  {this.state.editdetails.desc}
                </textarea>
              </div>
              <div className="col-xl-6 col-lg-6 col-md-6 col-sm-12">
                <label>Group Timesheet Approver</label>
                <select value={this.state.editdetails.userID} name="userID" onChange={this.handleFormChange} className="form-control">
                  <option value='0'>Select</option>
                  {Array.isArray(this.state.adminusers) && this.state.adminusers.map((item, i) => {
                    return <option key={i} value={item.userID}>{item.firstName + ' ' + item.lastName}</option>
                  })
                  }
                </select>
              </div>
            </div>
            <div className="form-group row">
              <div className="col-xl-12 col-lg-12 col-md-12 col-sm-12">
                <label className="mr-2">Employees</label>
                <DualListBox lang={{
                  selectedHeader: 'Selected Employees',
                  availableHeader: 'Available Employees'
                }}
                  showHeaderLabels={true}
                  options={this.state.empoptions}
                  selected={this.state.empselected}
                  onChange={this.onChangeEmp} className="mt-2" icons={{
                    moveLeft: '<',
                    moveAllLeft: '<<',
                    moveRight: '>',
                    moveAllRight: '>>'
                  }}
                />
              </div>
            </div>
            <div className="form-group row">
              <div className="col-xl-12 col-lg-12 col-md-12 col-sm-12">
                <label className="mr-2">Activities</label>
                <DualListBox lang={{
                  selectedHeader: 'Selected Activities',
                  availableHeader: 'Available Activities'
                }} showHeaderLabels={true}
                  options={this.state.options}
                  selected={this.state.selected}
                  onChange={this.onChange} className="mt-2" icons={{
                    moveLeft: '<',
                    moveAllLeft: '<<',
                    moveRight: '>',
                    moveAllRight: '>>'
                  }}
                />
              </div>
            </div>
          </Modal.Body>
          <Modal.Footer>
            <ul className="row form-group mr-0 mt-4 pr-0 list-inline pull-right">
              <li><button onClick={() => this.clearData()} className="button cancel-btn py-2 px-4 m-0 mr-2">Cancel</button></li>
              <li><button onClick={() => this.addRecord()} className="button resend-btn py-2 px-4 m-0">Save</button></li>
            </ul>
          </Modal.Footer>
        </Modal>
        <Modal scrollable={true} size="lg" onHide={() => this.clearData()}
          show={this.state.editshow}>
          <Modal.Header closeButton>
            <Modal.Title className="h6" >
              Edit Group
        </Modal.Title>
          </Modal.Header>
          <Modal.Body className="show-grid small_font px-5">
            <div className="text-danger col-12 text-center">{this.state.error_message}</div>
            <div className="form-group row">
              <div className="col-xl-6 col-lg-6 col-md-6 col-sm-12">
                <label>Group ID*</label>
                <input type="text" value={this.state.editdetails.code} name="code" onChange={this.handleFormChange} className="form-control" placeholder="Enter Group ID" />
              </div>
              <div className="col-xl-6 col-lg-6 col-md-6 col-sm-12">
                <label>Group Name*</label>
                <input type="text" value={this.state.editdetails.name} name="name" onChange={this.handleFormChange} className="form-control" placeholder="Enter Group Name" />
              </div>
            </div>
            <div className="form-group row">
              <div className="col-xl-6 col-lg-6 col-md-6 col-sm-12">
                <label>Group Description</label>
                <textarea name="desc" value={this.state.editdetails.desc} onChange={this.handleFormChange} className="form-control" placeholder="Enter Description">
                  {this.state.editdetails.desc}
                </textarea>
              </div>
              <div className="col-xl-6 col-lg-6 col-md-6 col-sm-12">
                <label>Group Timesheet Approver</label>
                <select value={this.state.editdetails.userID} name="userID" onChange={this.handleFormChange} className="form-control">
                  <option value='0'>Select</option>
                  {Array.isArray(this.state.adminusers) && this.state.adminusers.map((item, i) => {
                    return <option key={i} value={item.userID}>{item.firstName + ' ' + item.lastName}</option>
                  })
                  }
                </select>
              </div>
            </div>
            <div className="form-group row">
              <div className="col-xl-12 col-lg-12 col-md-12 col-sm-12">
                <label className="mr-2">Employees</label>
                <DualListBox lang={{
                  selectedHeader: 'Selected Employees',
                  availableHeader: 'Available Employees'
                }}
                  showHeaderLabels={true}
                  options={this.state.empoptions}
                  selected={this.state.empselected}
                  onChange={this.onChangeEmp} className="mt-2" icons={{
                    moveLeft: '<',
                    moveAllLeft: '<<',
                    moveRight: '>',
                    moveAllRight: '>>'
                  }}
                />
              </div>
            </div>
            <div className="form-group row">
              <div className="col-xl-12 col-lg-12 col-md-12 col-sm-12">
                <label className="mr-2">Activities</label>
                <DualListBox lang={{
                  selectedHeader: 'Selected Activities',
                  availableHeader: 'Available Activities'
                }} showHeaderLabels={true}
                  options={this.state.options}
                  selected={this.state.selected}
                  onChange={this.onChange} className="mt-2" icons={{
                    moveLeft: '<',
                    moveAllLeft: '<<',
                    moveRight: '>',
                    moveAllRight: '>>'
                  }}
                />
              </div>
            </div>
          </Modal.Body>
          <Modal.Footer>
            <ul className="row form-group mr-0 mt-4 pr-0 list-inline pull-right">
              <li><button onClick={() => this.clearData()} className="button cancel-btn py-2 px-4 m-0 mr-2">Cancel</button></li>
              <li><button onClick={() => this.addRecord()} className="button resend-btn py-2 px-4 m-0">Save Changes</button></li>
            </ul>
          </Modal.Footer>
        </Modal>
      </div>
    );
  }
}
export default LoadEmployeesGroupTable;