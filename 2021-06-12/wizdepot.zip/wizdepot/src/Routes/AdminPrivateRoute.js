import React from 'react';
import { Container } from 'react-bootstrap';
import { Route, Redirect } from "react-router-dom";
import AdminHeader from '../components/AdminHeader';

const AdminPrivateRoute = ({ component: Component, ...rest }) => {
  let userType = localStorage.getItem('usertype');
  return (
    <>
      <div className="App">
        <Container>
          <header className="admin-header">
            <AdminHeader />
          </header>
        </Container>
      </div>
      <Route
        {...rest}
        render={props =>
          userType === 'admin' ? (<Component {...props} />) :
            (<Redirect to={{ pathname: "/index", state: { from: props.location } }} />
            )
        }
      />
    </>
  );
}
export default AdminPrivateRoute;