import React from 'react';
import { MDBDataTable } from 'mdbreact';
import { Modal, Row, Col } from "react-bootstrap";
import DualListBox from 'react-dual-listbox';
import 'react-dual-listbox/lib/react-dual-listbox.css';
import { apiPost, apiGet, apiPut, apiDelete, getBlobImage, uploadImage } from '../Api.js';
import { confirmAlert } from 'react-confirm-alert';
import 'react-confirm-alert/src/react-confirm-alert.css';
import * as GeneralHelper from '../helpers/GeneralHelper'
import { find, isEqual } from 'lodash';

class LoadEmployeesTable extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      show: false,
      editMode: false,
      userSignature: null,
      userInitials: null,
      userInitial_file: null,
      userSignature_file: null,
      selected: [],
      options: [],
      rowresult: [],
      editdetails: [],
      errors: {},
      error_message: '',
      groups: [],
      activities: [],
      activity_id: 0,
      group_id: 0,
      status_id: 0,
      adminusers: [],
      activityList: [],
    };
  }

  componentDidMount() {
    this.getFunction();
    this.getGroups();
    this.getActivity();
    this.getAdminUsers();
  }
  getAdminUsers = (e) => {
    let requestDetails = {
      method: '/employees/approvers/' + localStorage.orgid,
      params: {}
    };
    apiGet(requestDetails, true).then((response) => {
      this.setState({ adminusers: response.data });
    }).catch(error => {
      console.log(error)
    });
  }

  getGroups = (e) => {
    let requestDetails = {
      method: 'groups/all/' + localStorage.orgid,
      params: {}
    };
    apiGet(requestDetails, true).then((response) => {
      this.setState({ groups: response.data });
    }).catch(error => {
      console.log(error)
    });
  }
  groupChange = (e) => {
    let gid = e.target.value;
    this.getFunction(gid);
    this.setState({ group_id: gid });
  }
  getActivity = (e) => {
    let requestDetails = {
      method: 'activities/all/' + localStorage.orgid,
      params: {}
    };
    apiGet(requestDetails, true).then((response) => {
      let arr1 = [];
      Array.isArray(response.data) && response.data.map((item) => (
        arr1.push({ value: item.actID, label: item.name, labeltype: item.type, labelallowExtra: item.allowExtra })
      ))
      this.setState({ activities: response.data, options: arr1 })
    }).catch(error => {
      console.log(error)
    });
  }
  activityChange = (e) => {
    let aid = e.target.value;
    this.getFunction(this.state.group_id, aid);
    this.setState({ activity_id: aid });
  }
  statusChange = (e) => {
    let sid = e.target.value;
    this.getFunction(this.state.group_id, this.state.activity_id, sid);
    this.setState({ status_id: sid });
  }
  handleFormChange = (e) => {
    let editdetails = this.state.editdetails;
    let errors = this.state.errors;
    editdetails[e.target.name] = e.target.value;
    errors[e.target.name] = "form-control is-valid";
    this.setState({
      editdetails
    });
  }
  validateForm() {
    const { editMode, editdetails, userSignature, userInitials } = this.state;
    let errors = {};
    let formIsValid = true;

    if (!editdetails["firstName"]) {
      formIsValid = false;
      errors["firstName"] = "form-control is-invalid";
    }
    if (!editdetails["lastName"]) {
      formIsValid = false;
      errors["lastName"] = "form-control is-invalid";
    }
    if (!editdetails["userName"]) {
      formIsValid = false;
      errors["userName"] = "form-control is-invalid";
    }
    if (!editMode && !editdetails["password"]) {
      formIsValid = false;
      errors["password"] = "form-control is-invalid";
    }
    if (!editMode && !editdetails["cpassword"]) {
      formIsValid = false;
      errors["cpassword"] = "form-control is-invalid";
    }
    if (!editdetails["approver"]) {
      formIsValid = false;
      errors["approver"] = "form-control is-invalid";
    }
    if (!userSignature) {
      formIsValid = false;
      errors["userSignature"] = "form-control is-invalid";
    }
    if (!userInitials) {
      formIsValid = false;
      errors["userInitials"] = "form-control is-invalid";
    }
    if (!formIsValid) {
      this.setState({
        error_message: 'Please fill all * Required Fields!'
      });
    } else {
      this.setState({
        error_message: ''
      });
    }

    this.setState({
      errors: errors
    });
    return formIsValid;
  }

  addRecord = (e) => {
    if (this.validateForm()) {
      let requestDetails = {
        method: 'employees',
        params: this.getParams()
      };
      apiPost(requestDetails, true).then((res) => {
        if (res && isEqual(res.status, 200) && res.data) {
          this.uploadImgDB(res.data.returnValue);
        }
        if (res.request.response && res.request.status !== 200) {
          let obj = JSON.parse(res.request.response);
          this.setState({ error_message: obj.msg });
          return;
        }
      }).catch(error => {
        console.log(error)
      });
    }
  }

  clearData = (openModal = false, editMode = false) => {
    this.setState({
      show: openModal,
      editMode,
      editdetails: {},
      userSignature_file: null,
      userInitial_file: null,
      userInitials: null,
      userSignature: null,
      selected: [], activityList: [],
    });
  }

  editProcess = async (d) => {
    this.clearData(true, true);
    let userID = d.currentTarget.dataset.tag;
    const emplDetails = { method: `employees/${userID}`, params: {} };
    const userSign = { method: `employees/images?id=${userID}&itemtype=user_signature`, params: {} };
    const userInitial = { method: `employees/images?id=${userID}&itemtype=user_initial`, params: {} };

    const empAPI = apiGet(emplDetails, true, false);
    const userSignApi = getBlobImage(userSign);
    const userInitialApi = getBlobImage(userInitial);

    await Promise.all([empAPI, userSignApi, userInitialApi]).then(([empRes, userSignRes, userInitialRes]) => {

      if (isEqual(empRes.status, 200) && empRes.data) {
        const { data } = empRes;
        let arrs = {
          userName: data.userName,
          password: data.password,
          cpassword: data.password,
          firstName: data.firstName,
          lastName: data.lastName,
          employeeType: data.employeeType,
          status: data.status,
          email: data.email,
          wage_category: data.wage_category,
          timingMethod: data.timingMethod,
          approver: data.timeApprover.userID,
          group: data.group.id,
          employeeNumber: data.userProfile.employeeNumber,
          hireDate: data.userProfile.hireDate,
          anniversaryDate: data.userProfile.anniversaryDate,
          cEmail: data.userProfile.cEmail,
          cPhone: data.userProfile.cPhone,
          address1: data.userProfile.address1,
          address2: data.userProfile.address2,
          city: data.userProfile.city,
          state: data.userProfile.state,
          country: data.userProfile.country,
          zipcode: data.userProfile.zipcode,
          notifyTime: data.userProfile.notifyTime,
          userID: data.userID,
          userType: data.userType
        };
        let arr = [];
        let arr2 = [];
        if (data.userActivities && data.userActivities.length > 0) {
          Array.isArray(data.userActivities) && data.userActivities.map((item1) => {
            arr.push(item1.actID);
            arr2.push({ actID: item1.actID });
            return null;
          })
        }
        this.setState({ selected: arr, editdetails: arrs, activityList: arr2 });
      }
      if (userSignRes.data && userSignRes.data.size) {
        let imageSrc = URL.createObjectURL(userSignRes.data);
        this.setState({ userSignature: imageSrc, userSignature_file: new File([userSignRes.data], "image.jpeg") })
      }
      if (userInitialRes.data && userInitialRes.data.size) {
        let imageSrc = URL.createObjectURL(userInitialRes.data);
        this.setState({ userInitials: imageSrc, userInitial_file: new File([userInitialRes.data], "image.jpeg") })
      }
    }).catch(error => {
      this.clearData(false, false);
      console.log(`Error in promises ${error}`)
    });
  }

  getParams = () => {
    const { editdetails, activityList } = this.state;
    let obj = {
      type: "user",
      org_id: localStorage.orgid,
      userName: editdetails.userName,
      password: editdetails.password,
      firstName: editdetails.firstName,
      lastName: editdetails.lastName,
      employeeType: editdetails.employeeType,//ft-hourly
      userType: editdetails.userType,//employee
      status: editdetails.status,//inactive
      email: editdetails.email,
      wage_category: editdetails.wage_category,//non-exempt
      timingMethod: editdetails.timingMethod,//punch
      timeApprover: { userID: editdetails.approver },
      group: { id: editdetails.group },
      userProfile: {
        employeeNumber: editdetails.employeeNumber,
        hireDate: editdetails.hireDate,
        anniversaryDate: editdetails.anniversaryDate,
        cEmail: editdetails.cEmail,
        cPhone: editdetails.cPhone,
        hPhone: editdetails.hPhone,
        mPhone: editdetails.mPhone,
        address1: editdetails.address1,
        address2: editdetails.address2,
        city: editdetails.city,
        state: editdetails.state,
        country: editdetails.country,
        zipcode: editdetails.zipcode,
        notifyTime: editdetails.notifyTime
      },
      userActivities: activityList
    }
    return obj;
  }
  editRecord = async (e) => {
    const { editdetails } = this.state;
    const { userID } = editdetails;
    if (this.validateForm()) {
      const empSubmit = { method: 'employees/' + userID, params: { userID, ...this.getParams() } };
      await apiPut(empSubmit, true).then((res) => {
        if (res && isEqual(res.status, 200) && res.data) {
          this.uploadImgDB();
        }
        if (res.request.response && res.request.status !== 200) {
          let obj = JSON.parse(res.request.response);
          this.setState({ error_message: obj.msg });
          return;
        }
      }).catch(error => {
        console.log(error)
      });
    } else {
      return false;
    }
  }

  uploadImgDB = async (id = null) => {
    const { editdetails, userInitial_file, userSignature_file } = this.state;
    const { userID } = editdetails;
    let userid = id ? id : userID;
    if (this.validateForm()) {
      const empUserInitial = { method: `employees/images?id=${userid}&itemtype=user_initial` };
      const empUserSignature = { method: `employees/images?id=${userid}&itemtype=user_signature` };
      let userInitialData = new FormData();
      let userSignData = new FormData();
      userInitialData.append("file", userInitial_file);
      userSignData.append("file", userSignature_file);
      const userInitialApi = uploadImage(empUserInitial, userInitialData);
      const userSignApi = uploadImage(empUserSignature, userSignData);

      await Promise.all([userInitialApi, userSignApi]).then((response) => {
        if (response && isEqual(response[0].status, 200) && response[0].data) {
          this.clearData(false, false);
          this.getFunction();
        } else {
          window.alert('Something Went Wrong!');
        }
      }).catch(error => {
        console.log(error)
      });
    } else {
      return false;
    }
  }
  deleteProcess = (e) => {
    var dv = e.currentTarget.dataset.tag;
    confirmAlert({
      customUI: ({ onClose }) => {
        return (
          <div className='custom-ui'>
            <h3>Are you sure?</h3>
            <p>You want to delete this?</p>
            <button data-tag={dv} onClick={() => {
              this.deleteRecord({ dv });
              onClose();
            }}>Yes, Delete it</button>
            <button onClick={onClose}>No, Cancel</button>
          </div>
        );
      }
    });
  }
  deleteRecord = (e) => {
    let requestDetails = {
      method: 'employees/' + e.dv,
      params: {}
    };
    apiDelete(requestDetails, true).then((response) => {
      this.getFunction();
    }).catch(error => {
      console.log(error)
    });
  }

  getFunction = (gid = '0', aid = '0', sid = '0') => {
    let requestDetails = {
      method: 'employees/all/' + localStorage.orgid,
      params: {
        group_id: gid,
        act_id: aid,
        status: sid
      }
    };
    apiPost(requestDetails, true).then((response) => {
      let result = response.data.users;
      let arr = [];
      Array.isArray(result) && result.map((item) => {
        let activitiesname = [];
        Array.isArray(item.userActivities) && item.userActivities.map((item1) => {
          activitiesname.push(item1.name);
        })
        arr.push({
          name: item.firstName + ' ' + item.lastName,
          status: GeneralHelper.user_status_codes[item.status],
          category: GeneralHelper.wageCategory_codes[item.wage_category],
          type: GeneralHelper.employeeTypes_codes[item.employeeType],
          date: item.userProfile.hireDate,
          method: GeneralHelper.timingMethod[item.timingMethod],
          activities: activitiesname.toString(),
          groupid: find(this.state.groups, { id: item.group.id }) ? find(this.state.groups, { id: item.group.id }).code : '',
          edit: <i className="fa fa-edit" data-tag={item.userID} onClick={this.editProcess}></i>,
          delete: <i className="fa fa-trash" data-tag={item.userID} onClick={this.deleteProcess}></i>,
        })
      })
      this.setState({ rowresult: arr })
    }).catch(error => {
      console.log(error)
    });
  }
  onChange = (selected) => {
    let data = this.state.options;
    let arr1 = [];
    selected.map((item) => {
      let obj = data.find(o => o.value === item);
      arr1.push({ actID: obj.value })
    })
    this.setState({ activityList: arr1, selected });
  };

  onAdd = (options) => {
    this.setState({ options });
  };

  userInitialChange = event => {
    const fileUploaded = event.target.files[0];
    this.setState({ userInitials: URL.createObjectURL(fileUploaded), userInitial_file: fileUploaded });
  };

  userSignatureChange = event => {
    const fileUploaded = event.target.files[0];
    this.setState({ userSignature: URL.createObjectURL(fileUploaded), userSignature_file: fileUploaded });
  };


  render() {
    const { editMode, groups, editdetails, rowresult, userSignature, userInitials } = this.state;
    let datatable = {
      columns: [
        {
          label: 'Name',
          field: 'name',
          attributes: {
            'aria-controls': 'DataTable',
            'aria-label': 'Name',
          },
        },
        {
          label: 'Status',
          field: 'status',
        },
        {
          label: 'Wage Category',
          field: 'category',
        },
        {
          label: 'Employee Type',
          field: 'type',
        },
        {
          label: 'Hire Date',
          field: 'date',
        },
        {
          label: 'Activities',
          field: 'activities',
        },
        {
          label: 'Group ID',
          field: 'groupid',
        },
        {
          label: 'Edit',
          field: 'edit',
          sort: 'disabled',
        },
        {
          label: 'Delete',
          field: 'delete',
          sort: 'disabled',
        },
      ],
      rows: rowresult,
    }
    return (
      <div>
        <div className="form-group row small_font">
          <div className="col-xl-2 col-lg-2 col-md-2 col-sm-12">
            <label>Group</label>
            <select className="form-control" onChange={this.groupChange}>
              <option value='0'>All Group</option>
              {Array.isArray(groups) && groups.map((item, i) => {
                return <option value={item.id} key={i}>{item.name}</option>
              })
              }
            </select>
          </div>
          <div className="col-xl-2 col-lg-2 col-md-2 col-sm-12">
            <label>Activity</label>
            <select className="form-control" onChange={this.activityChange}>
              <option value='0'>All Activity</option>
              {Array.isArray(this.state.activities) && this.state.activities.map((item, i) => {
                return <option value={item.actID} key={i}>{item.name}</option>
              })
              }
            </select>
          </div>
          <div className="col-xl-2 col-lg-2 col-md-2 col-sm-12" onChange={this.statusChange}>
            <label>Status</label>
            <select className="form-control">
              <option value='0'>All Employees</option>
              {Array.isArray(GeneralHelper.user_status) && GeneralHelper.user_status.map((item, i) => {
                return <option value={item.code} key={i}>{item.name}</option>
              })
              }
            </select>
          </div>
        </div>
        <div className="col-12 row mr-0 pr-0 pl-0 ml-0 mb-3">
          <h6 className="text-left float-left col-lg-10 col-md-10 col-xl-10 col-sm-12 pl-0">The Number of Total Employees : ({rowresult.length})</h6>
          <button onClick={() => this.clearData(true, false)} className="button resend-btn py-2 px-4 col-lg-2 col-xl-2 col-md-2 col-sm-12 m-0"><i className="fa fa-plus pr-2"></i>Add Employees</button>
        </div>
        <MDBDataTable
          className="timesheets"
          bordered hover info={false} responsive={true} displayEntries={false} noBottomColumns entries={10} data={datatable} searching={false} />
        <Modal scrollable={true} size="lg" onHide={() => this.setState({ show: false })}
          show={this.state.show}>
          <Modal.Header closeButton>
            <Modal.Title className="h6" id="contained-modal-title-vcenter">
              {editMode ? 'Edit' : 'Add'} Employee Profile
        </Modal.Title>
          </Modal.Header>
          <Modal.Body className="show-grid small_font px-5">
            <div className="text-danger col-12 text-center">{this.state.error_message}</div>
            <div className="form-group row">
              <div className="col-xl-4 col-lg-4 col-md-4 col-sm-12">
                <label>First Name*</label>
                <input type="text" value={editdetails.firstName} name="firstName" onChange={this.handleFormChange} className="form-control" placeholder="First Name" />
              </div>
              <div className="col-xl-4 col-lg-4 col-md-4 col-sm-12">
                <label>Last Name*</label>
                <input type="text" value={editdetails.lastName} name="lastName" onChange={this.handleFormChange} className="form-control" placeholder="Last Name" />
              </div>
              <div className="col-xl-4 col-lg-4 col-md-4 col-sm-12">
                <label>Status*</label>
                <select value={editdetails.status} name="status" onChange={this.handleFormChange} className="form-control">
                  {Array.isArray(GeneralHelper.user_status) && GeneralHelper.user_status.map((item, i) => {
                    return <option value={item.code} key={i}>{item.name}</option>
                  })
                  }
                </select>
              </div>
            </div>
            <div className="form-group row">
              <div className="col-xl-4 col-lg-4 col-md-4 col-sm-12">
                <label>Username*</label>
                <input type="text" value={editdetails.userName} name="userName" onChange={this.handleFormChange} className="form-control" placeholder="Enter Username" />
              </div>
              {!editMode && <div className="col-xl-4 col-lg-4 col-md-4 col-sm-12">
                <label>Password*</label>
                <input type="password" value={editdetails.password} name="password" onChange={this.handleFormChange} className="form-control" placeholder="Password" />
              </div>}
              {!editMode && <div className="col-xl-4 col-lg-4 col-md-4 col-sm-12">
                <label>Confirm Password*</label>
                <input type="password" value={editdetails.cpassword} name="cpassword" onChange={this.handleFormChange} className="form-control" placeholder="Confirm Password" />
              </div>}
              {editMode &&
                <div className="col-xl-4 col-lg-4 col-md-4 col-sm-12">
                  <label className="pr-2">Notification Time</label>
                  <select value={editdetails.notifyTime} name="notifyTime" onChange={this.handleFormChange} className="form-control">
                    <option value='5'>5 Min</option>
                    <option value='10'>10 Min</option>
                    <option value='15'>15 Min</option>
                    <option value='20'>20 Min</option>
                    <option value='25'>25 Min</option>
                    <option value='30' selected='selected'>30 Min</option>
                    <option value='35'>35 Min</option>
                    <option value='40'>40 Min</option>
                    <option value='45'>45 Min</option>
                    <option value='50'>50 Min</option>
                    <option value='55'>55 Min</option>
                    <option value='60'>60 Min</option>
                  </select>
                </div>
              }
            </div>
            {!editMode && <div className="form-group row border-bottom pb-3">
              <div className="col-xl-4 col-lg-4 col-md-4 col-sm-12">
                <label className="pr-2">Notification Time</label>
                <select value={editdetails.notifyTime} name="notifyTime" onChange={this.handleFormChange} className="form-control">
                  <option value='5'>5 Min</option>
                  <option value='10'>10 Min</option>
                  <option value='15'>15 Min</option>
                  <option value='20'>20 Min</option>
                  <option value='25'>25 Min</option>
                  <option value='30' selected='selected'>30 Min</option>
                  <option value='35'>35 Min</option>
                  <option value='40'>40 Min</option>
                  <option value='45'>45 Min</option>
                  <option value='50'>50 Min</option>
                  <option value='55'>55 Min</option>
                  <option value='60'>60 Min</option>
                </select>
              </div>
            </div>}
            <div className="form-group row">
              <div className="col-xl-4 col-lg-4 col-md-4 col-sm-12">
                <label>Employee Number</label>
                <input type="text" value={editdetails.employeeNumber} name="employeeNumber" onChange={this.handleFormChange} className="form-control" placeholder="Employee Number" />
              </div>
              <div className="col-xl-4 col-lg-4 col-md-4 col-sm-12">
                <label>Employee Type*</label>
                <select value={editdetails.employeeType} name="employeeType" onChange={(e) => { this.handleFormChange(e); }} placeholder="Select" className="form-control">
                  {Array.isArray(GeneralHelper.employeeTypes) && GeneralHelper.employeeTypes.map((item, i) => {
                    return <option value={item.code} key={i}>{item.name}</option>
                  })
                  }
                </select>
              </div>
              <div className="col-xl-4 col-lg-4 col-md-4 col-sm-12">
                <label>Wage Category*</label>
                <select value={editdetails.wage_category} name="wage_category" onChange={this.handleFormChange} placeholder="Select" className="form-control">
                  {Array.isArray(GeneralHelper.wageCategory) && GeneralHelper.wageCategory.map((item, i) => {
                    return <option value={item.code} key={i}>{item.name}</option>
                  })
                  }
                </select>
              </div>
            </div>
            <div className="form-group row border-bottom pb-3">
              <div className="col-xl-4 col-lg-4 col-md-4 col-sm-12">
                <label>Hire Date</label>
                <input type="date" value={editdetails.hireDate} name="hireDate" onChange={this.handleFormChange} className="form-control" placeholder="Enter Date" />
              </div>
              <div className="col-xl-4 col-lg-4 col-md-4 col-sm-12">
                <label>Termination Date</label>
                <input type="date" value={editdetails.terminationDate} name="terminationDate" onChange={this.handleFormChange} className="form-control" placeholder="Enter Date" />
              </div>
              <div className="col-xl-4 col-lg-4 col-md-4 col-sm-12">
                <label>Anniversary Date</label>
                <input type="date" value={editdetails.anniversaryDate} name="anniversaryDate" onChange={this.handleFormChange} className="form-control" placeholder="Enter Date" />
              </div>
            </div>
            <div className="form-group row">
              <div className="col-xl-4 col-lg-4 col-md-4 col-sm-12">
                <label>Personal Email*</label>
                <input type="email" value={editdetails.email} name="email" onChange={this.handleFormChange} className="form-control" placeholder="Enter Email ID" />
              </div>
              <div className="col-xl-4 col-lg-4 col-md-4 col-sm-12">
                <label>Work Email</label>
                <input type="text" value={editdetails.cEmail} name="cEmail" onChange={this.handleFormChange} className="form-control" placeholder="Enter Email ID" />
              </div>
              <div className="col-xl-4 col-lg-4 col-md-4 col-sm-12">
                <label>Cell Phone</label>
                <input value={editdetails.cPhone} name="cPhone" onChange={this.handleFormChange} className="form-control" placeholder="Enter Phone Number" />
              </div>
            </div>
            <div className="form-group">
              <label>Address</label>
              <input type="text" value={editdetails.address1} name="address1" onChange={this.handleFormChange} className="form-control" placeholder="Enter Address" />
            </div>
            <div className="form-group">
              <label>Address 2</label>
              <input type="text" value={editdetails.address2} name="address2" onChange={this.handleFormChange} className="form-control" placeholder="Enter Address" />
            </div>
            <div className="form-group row border-bottom pb-3">
              <div className="col-xl-4 col-lg-4 col-md-4 col-sm-12">
                <label>City</label>
                <input type="text" value={editdetails.city} name="city" onChange={this.handleFormChange} className="form-control" placeholder="Enter City" />
              </div>
              <div className="col-xl-4 col-lg-4 col-md-4 col-sm-12">
                <label>State</label>
                <select placeholder="State" value={editdetails.state} name="state" onChange={this.handleFormChange} className="form-control">
                  {GeneralHelper.stateDetails.map((x, key) => (
                    <option value={x.value} key={key}>{x.label}</option>
                  ))}
                </select>
              </div>
              <div className="col-xl-4 col-lg-4 col-md-4 col-sm-12">
                <label>Zip Code</label>
                <input value={editdetails.zipcode} name="zipcode" onChange={this.handleFormChange} className="form-control" placeholder="Enter Zip Code" />
              </div>
              <div className="col-xl-4 col-lg-4 col-md-4 col-sm-12">
                <label>Country</label>
                <input type="text" value={editdetails.country} name="country" onChange={this.handleFormChange} className="form-control" placeholder="Enter Country" />
              </div>
            </div>
            <div className="form-group row">
              <div className="col-xl-8 col-lg-8 col-md-8 col-sm-12">
                <label className="mr-2">Activities</label>
                <DualListBox lang={{
                  selectedHeader: 'Selected Activities',
                  availableHeader: 'Available Activities'
                }}
                  showHeaderLabels={true}
                  options={this.state.options}
                  selected={this.state.selected}
                  onChange={this.onChange} className="mt-2" icons={{
                    moveLeft: '<',
                    moveAllLeft: '<<',
                    moveRight: '>',
                    moveAllRight: '>>'
                  }}
                />
              </div>
            </div>
            <div className="form-group row border-bottom pb-3">
              <div className="col-xl-4 col-lg-4 col-md-4 col-sm-12">
                <label className="mr-2">Assigned Group</label>
                <select value={editdetails.group} name="group" onChange={this.handleFormChange} className="form-control">
                  <option value='0'>None</option>
                  {Array.isArray(this.state.groups) && this.state.groups.map((item, i) => {
                    return <option value={item.id} key={i}>{item.name}</option>
                  })
                  }
                </select>
              </div>
              <div className="col-xl-4 col-lg-4 col-md-4 col-sm-12">
                <label>Is Manager?</label>
                <select value={editdetails.userType} name="userType" onChange={this.handleFormChange} className="form-control">
                  <option value='1'>NO</option>
                  <option value='2'>YES</option>
                </select>
              </div>
              <div className="col-xl-4 col-lg-4 col-md-4 col-sm-12">
                <label>Timesheet Approver*</label>
                <select value={editdetails.approver} name="approver" onChange={this.handleFormChange} className="form-control">
                  <option value='0'>Select</option>
                  {Array.isArray(this.state.adminusers) && this.state.adminusers.map((item, i) => {
                    return <option key={i} value={item.userID}>{item.firstName + ' ' + item.lastName}</option>
                  })
                  }
                </select>
              </div>
            </div>
            <div className="form-group row">
              <div className="col-xl-6 col-lg-6 col-md-6 col-sm-12">
                <label>Upload Signature File*</label>
                <Row className="">
                  <Col lg="12" md="12" sm="12">
                    {userSignature && <img src={userSignature} height={40} className="mb-1" alt="user_signature" />}
                    <br />
                    <label className="button resend-btn py-2 px-4 m-0 cursor-pointer">
                      <input id="userSignature" type="file" onChange={this.userSignatureChange} accept=".png, .jpg, .jpeg" style={{ display: 'none' }} />
                      Choose File
                      </label>
                    <p className="mt-1">File size limit: 1 MB</p>
                  </Col>
                </Row>
              </div>
              <div className="col-xl-6 col-lg-6 col-md-6 col-sm-12">
                <label>Upload Initials File*</label>
                <Row className="">
                  <Col lg="12" md="12" sm="12">
                    {userInitials && <img src={userInitials || ''} height={40} className="mb-1" alt="user_initial" />}
                    <br />
                    <label className="button resend-btn py-2 px-4 m-0 cursor-pointer">
                      <input id="userInitials" type="file" onChange={this.userInitialChange} accept=".png, .jpg, .jpeg" style={{ display: 'none' }} />
                      Choose File
                      </label>
                    <p className="mt-1">File size limit: 1 MB</p>
                  </Col>
                </Row>
              </div>
            </div>
          </Modal.Body>
          <Modal.Footer>
            <ul className="row form-group mr-0 mt-4 pr-0 list-inline pull-right">
              <li><button onClick={() => this.clearData()} className="button cancel-btn py-2 px-4 m-0 mr-2">Cancel</button></li>
              <li><button onClick={() => editMode ? this.editRecord() : this.addRecord()} className="button resend-btn py-2 px-4 m-0">Save</button></li>
            </ul>
          </Modal.Footer>
        </Modal>
      </div>
    );
  }
}
export default LoadEmployeesTable;