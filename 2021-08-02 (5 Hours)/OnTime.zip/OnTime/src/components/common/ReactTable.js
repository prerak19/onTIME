import React, { useEffect, useState } from 'react';
import BootstrapTable from 'react-bootstrap-table-next';
import paginationFactory from 'react-bootstrap-table2-paginator';

const ReactTable = (props) => {
	const { data, columns, isSelection, onRowSelect, className, showPagination, striped } = props;
	const [selectedIds, setIds] = useState([]);
	const options = {
		sizePerPage: 10,
		hideSizePerPage: true,
		prePageText: 'Previous',
		nextPageText: 'Next',
		withFirstAndLast: false,
	};
	const handleOnSelect = (row, isSelect) => {
		if (isSelect) {
			setIds([...selectedIds, row]);
		} else {
			const filteredSelections = selectedIds.filter((x) => x.tid !== row.tid);
			setIds(filteredSelections);
		}
	}

	useEffect(() => {
		onRowSelect(selectedIds);
	}, [selectedIds])

	useEffect(() => {
		setIds([]);
	}, [data]);

	const handleOnSelectAll = (isSelect, rows) => {
		isSelect ? setIds(rows) : setIds([]);
	}

	const selectRow = {
		mode: 'checkbox',
		hideSelectColumn: !isSelection,
		onSelect: handleOnSelect,
		onSelectAll: handleOnSelectAll
	};
	return (
		<BootstrapTable
			classes={`${className} mb-0`}
			keyField="tid"
			data={data}
			striped={striped}
			hover
			condensed
			columns={columns}
			selectRow={selectRow}
			pagination={(showPagination && data.length > 10) && paginationFactory(options)}
		/>
	);
}

ReactTable.defaultProps = {
	data: [],
	className: '',
	columns: [],
	striped: false,
	isSelection: false,
	onRowSelect: () => { },
	showPagination: false,
}

export default ReactTable;