import React from 'react';
import DatePicker from "react-datepicker";
import {
  Modal,
  Row,
  Col
} from "react-bootstrap";
import { MDBBtn } from 'mdbreact';
import Timer from 'react-compound-timer';
import { find, get, isEmpty, isEqual, sortBy, sum } from 'lodash';
import moment from 'moment';
import { apiGet, apiPost, apiPut, getBlobImage } from './Api.js';
import { DAYS_OF_WEEK, timesheet_status_codes, ClockInOuts, toNumber, BY_WEEKLY_DAYS_OF_WEEK, getWeek } from './helpers/GeneralHelper';
import "react-datepicker/dist/react-datepicker.css";

class MyOwnTimesheet extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      tempObj: null,
      finalTimesheets: [],
      weekDays: [],
      weekRange: '',
      weekCount: 1,
      overallTotals: [],
      approvedImage: [],
      personalDetails: {},
      startTime: null,
      stopTime: null,
      weeklyDate: null,
      clockin: true,
      signshow: false,
      companyDetails: {},
      startWeekDate: '',
      weekEndDate: '',
      activityID: '',
      totalHours: 0.0,
      subLoading: false,
      employeeApprovalImg: [],
      userName: '',
      passWord: '',
      timesheetLoading: false,
      currentClockInTimesheet: {},
    };
  }

  componentDidMount() {
    const startWeekDate = moment().day(0);
    const weekEndDate = moment().day(6);
    const weeklyDate = new Date(moment());
    this.setState({
      weeklyDate,
      startWeekDate,
      weekEndDate,
    }, () => {
      this.getTimesheetRecord(startWeekDate.format('YYYY-MM-DD'), true, true);
    })
  }

  getTimesheetRecord = async (startDate, sheetLoading = true, lastClockIn = false) => {
    this.setState({ timesheetLoading: sheetLoading });
    const requestDetails = {
      method: `timesheets/${get(localStorage, 'userid', '')}/${startDate}`,
      params: {}
    };
    await apiGet(requestDetails, true, false).then(async (res) => {
      if (isEqual(res.status, 200) && res.data) {
        this.updateBiWeeklyData(res.data, lastClockIn);
      }
      if (res.request && res.request.status !== 200) {
        window.alert('No Timesheet is available for selected Week');
        this.setState({ timesheetLoading: false });
      }
    }).catch(error => {
      this.setState({ timesheetLoading: false });
    });
  }

  updateBiWeeklyData = async (data, lastClockIn) => {
    let tempObj = {}
    const finalTimesheets = data.timsheets;
    let currentClockInTimesheet = {};
    const weeklyCount = data.count === 2 ? true : false;
    let weekDays = [];
    const personalDetails = {
      userFirstname: finalTimesheets[0].userFirstname || (weeklyCount && finalTimesheets[1].userFirstname) || null,
      userLastname: finalTimesheets[0].userLastname || (weeklyCount && finalTimesheets[1].userLastname) || null,
      groupCode: finalTimesheets[0].groupCode || (weeklyCount && finalTimesheets[1].groupCode) || null,
      groupName: finalTimesheets[0].groupName || (weeklyCount && finalTimesheets[1].groupName) || null,
      status: finalTimesheets[0].status || (weeklyCount && finalTimesheets[1].status) || null,
      uid: finalTimesheets[0].uid || (weeklyCount && finalTimesheets[1].uid) || null
    };
    let overallTotals = [];
    let employeeApprovalImg = [];
    let approvedImage = [];
    finalTimesheets.map((xdt) => {
      if (xdt.activityTime && xdt.activityTime.length > 0) {
        xdt.activityTime.map((act) => {
          if (tempObj[act.activityName]) {
            tempObj[act.activityName] = { ...tempObj[act.activityName], week2: { ...act, timesheetID: xdt.tid } }
          } else {
            tempObj[act.activityName] = { week1: { ...act, timesheetID: xdt.tid } }
          }
        })
      }
      if (xdt.dailyTotals && xdt.dailyTotals.length > 0) {
        xdt.dailyTotals.map(async (dt) => {
          weekDays.push({
            day: moment(dt.date).format('ddd'),
            date: moment(dt.date).format('MMM D'),
            fullDate: moment(dt.date).format('YYYY-MM-DD'),
          })
          if (moment().format('YYYY-MM-DD') === dt.date) {
            currentClockInTimesheet = xdt;
            if (lastClockIn) {
              this.getClockInData(xdt.uid);
            }
          }
          overallTotals.push(dt);
        })
      }
      if (xdt.status >= 300) {
        if (!find(employeeApprovalImg, { uid: xdt.uid })) {
          const imgsrc = this.getApprovalImage('user_signature', xdt.uid);
          employeeApprovalImg.push({ uid: xdt.uid, imgsrc });
        }
        if (xdt.status >= 500) {
          if (!find(approvedImage, { approvedBy: xdt.approvedBy })) {
            const imgAppsrc = this.getApprovalImage('user_signature', xdt.approvedBy);
            approvedImage.push({ approvedBy: xdt.approvedBy, imgAppsrc });
          }
        }
      }
    })
    await Promise.all(employeeApprovalImg.map((x) => x.imgsrc)).then((body) => {
      employeeApprovalImg = employeeApprovalImg.map((img, key) => {
        return { ...img, src: body[key] }
      })
    })

    await Promise.all(approvedImage.map((x) => x.imgAppsrc)).then((body) => {
      approvedImage = approvedImage.map((img, key) => {
        return { ...img, src: body[key] }
      })
    })
    const sunday = new Date(moment(get(finalTimesheets[0], 'startDate')).day(0));
    const nextSunday = new Date(moment(get(finalTimesheets[1] || finalTimesheets[0], 'startDate')).day(6));
    this.setState({
      weekCount: data.count,
      tempObj,
      currentClockInTimesheet,
      weekDays,
      overallTotals,
      totalHours: sum(overallTotals.map((x) => x.hours)),
      finalTimesheets,
      personalDetails,
      weeklyDate: sunday,
      startWeekDate: moment(sunday).format('YYYY-MM-DD'),
      weekEndDate: moment(nextSunday).format('YYYY-MM-DD'),
      employeeApprovalImg,
      approvedImage,
      subLoading: false,
      timesheetLoading: false,
      signshow: false,
      clockinLoading: false,
      stopTime: null,
      startTime: null
    });
    document.body.click();
  }

  getApprovalImage = async (type = 'user_signature', uid = '') => {
    let userId = get(localStorage, 'userid', '');
    if (uid) { userId = uid; }
    let imageSrc = '';
    const getRequest = {
      method: `employees/images?id=${userId}&itemtype=${type}`
    };
    await getBlobImage(getRequest).then((response) => {
      if (response.data && response.data.size) {
        imageSrc = URL.createObjectURL(response.data);
      }
    }).catch(error => {
      console.log(error);
    });
    return imageSrc;
  }

  formatDate = (date) => moment(date).format("MMMM D, YYYY")

  handleWeekChange = (date) => {
    const formatDate = moment(date).format('YYYY-MM-DD');
    const request = {
      method: `timesheets/${get(localStorage, 'userid', '')}/${formatDate}`
    };
    this.setState({ timesheetLoading: true });
    apiGet(request, true, false).then((res) => {
      if (isEqual(res.status, 200) && res.data) {
        this.updateBiWeeklyData(res.data);
      }
      if (res.request && res.request.status !== 200) {
        window.alert('No Timesheet is available for selected Week');
        this.setState({ timesheetLoading: false });
      }
    }).catch((err) => {
      console.log(err);
    })
  }

  updateHourForDay = (activeHour = 0, activityProps, actIndex) => {
    this.setState({ subLoading: true });
    const request = {
      method: 'timesheets/hour',
      params: {
        timesheetID: activityProps.timesheetID,
        activityID: activityProps.activityID,
        day: actIndex,
        hours: Number(activeHour),
        madeBy: Number(get(localStorage, 'userid', '')),
      }
    }
    apiPut(request, true).then(async (res) => {
      if (isEqual(res.status, 200) && res.data) {
        await this.getTimesheetRecord(this.state.startWeekDate, false);
      }
      if (res.request && res.request.response && res.request.status !== 200) {
        this.setState({ subLoading: false });
        document.body.click();
        let obj = JSON.parse(res.request.response);
        obj.msg ? window.alert(obj.msg) : window.alert('Something Went Wrong!');
        return;
      }
    }).catch((err) => {
      console.log(err)
      this.setState({ subLoading: false });
    })
  }

  getClockInData = (uid) => {
    const request = {
      method: `activities/last-clockin?uid=${uid}`
    };
    apiGet(request, true, false).then((response) => {
      if (isEqual(response.status, 200) && response.data) {
        if (response.data.activityID) {
          this.setState({
            activityID: response.data.activityID,
            startTime: response.data.clockAt,
            clockin: false
          })
        }
      }
    }).catch((err) => {
      console.log(err);
    })
  }
  submitTimeSheet = () => {
    const { timesheetID, userName, passWord } = this.state;
    this.setState({ subLoading: true });
    const request = {
      method: `timesheets/submit?tid=${timesheetID}`,
      params: {
        userName, passWord
      }
    }
    apiPost(request, true).then((res) => {
      if (isEqual(res.status, 200) && res.data) {
        this.getTimesheetRecord(this.state.startWeekDate);
      }
      if (res.request && res.request.response && res.request.status !== 200) {
        this.setState({ subLoading: false });
        let obj = JSON.parse(res.request.response);
        obj.msg ? window.alert(obj.msg) : window.alert('Something Went Wrong!');
        return;
      }
    }).catch((err) => {
      this.setState({ subLoading: false });
    })
  }

  isWeekday = (date) => date.getDay() === 0;

  handlePressStartButton = () => {
    this.setState({ clockin: false });
  }

  startClockin = () => {
    const { currentClockInTimesheet, activityID, clockin } = this.state;
    const now = new Date();
    const request = {
      method: 'timesheets/punches',
      params: {
        timesheetID: currentClockInTimesheet.tid,
        activityID: activityID,
        day: now.getDay(),
        userID: Number(get(localStorage, 'userid', '')),
        type: !clockin ? 1 : 2,
        duration: '20',
        madeBy: currentClockInTimesheet.uid
      }
    }
    this.setState({ clockinLoading: true })
    apiPost(request, true).then(async (res) => {
      if (isEqual(res.status, 200) && res.data) {
        await this.getTimesheetRecord(this.state.startWeekDate, false);
        if (!this.state.clockin) {
          this.setState({
            startTime: moment().format('hh:mm:ss A MMM DD, YYYY'),
            clockinLoading: false
          })
        } else {
          let data = await this.getClockOutData(this.state.activityID);
          if (data.activityID) {
            this.setState({ stopTime: data.clockAt });
          } else {
            this.setState({ stopTime: null });
          }
        }
      }
      if (res.request && res.request.response && res.request.status !== 200) {
        this.setState({ startTime: null, clockinLoading: false });
        let obj = JSON.parse(res.request.response);
        obj.msg ? window.alert(obj.msg) : window.alert('Something Went Wrong!');
        return;
      }
    }).catch((err) => {
      this.setState({
        startTime: null,
        clockinLoading: false
      })
    })
  }

  renderOptions = () => {
    return get(this.state.currentClockInTimesheet, 'activityTime', []).map((activity) => (
      activity.timingMethod === 1 && <option value={activity.activityID} key={activity.activityID}>{activity.activityName.toUpperCase()} ({activity.activityCode})</option>
    ))
  }

  getClockOutData = async (activityId) => {
    const { currentClockInTimesheet } = this.state;
    let data = null;
    const request = {
      method: `activities/last-clockout?uid=${currentClockInTimesheet.uid}&aid=${activityId}`
    };
    await apiGet(request, true, false).then((response) => {
      if (isEqual(response.status, 200) && response.data) {
        data = response.data;
      }
    }).catch((err) => {
      console.log(err);
      this.setState({ stopTime: null });
    })
    return data;
  }

  changeDropdown = async (event) => {
    let activityId = event.target.value;
    this.setState({ clockinLoading: true })
    let response = await this.getClockOutData(activityId);
    if (response.activityID) {
      this.setState({
        stopTime: response.clockAt,
        activityID: response.activityID,
        clockin: true,
        startTime: null,
        clockinLoading: false
      });
    } else {
      this.setState({
        stopTime: null,
        activityID: activityId,
        clockin: true,
        startTime: null,
        clockinLoading: false
      });
    }
  }

  getCompanyDetails = (tdetails = {}) => {
    const { tid, startDate } = tdetails;
    let requestDetails = {
      method: 'organizations/' + localStorage.orgid,
      params: { user_id: localStorage.userid }
    };
    apiGet(requestDetails, true).then((response) => {
      if (response && response.data && response.status === 200) {
        this.setState({ companyDetails: response.data, signshow: true, weekRange: getWeek(startDate, startDate), timesheetID: tid, userName: '', passWord: '' })
      } else {
        window.alert('Something Went Wrong!');
      }
    }).catch(error => {
      console.log(error)
    });
  }

  returnImage = (id, key, imgArr, altText, width, height = 50) => {
    const obj = find(imgArr, { [key]: id });
    return obj ? < img src={obj.src} width={width || 'auto'} height={height} alt={altText} /> : null
  }

  ExampleCustomInput = ({ value, onClick }) => (
    <div className="inner-addon right-addon">
      <i className="fa fa-calendar" onClick={onClick}></i>
      <input onClick={onClick} value={value} onChange={() => { }} type="text" className="form-control" placeholder="Select Date" name="date" />
    </div>
  );

  render() {
    const { personalDetails, totalHours, clockin, clockinLoading, userName, passWord,
      timesheetLoading, startWeekDate, weekEndDate, subLoading, weeklyDate, weekRange, weekCount, tempObj, finalTimesheets,
      weekDays, currentClockInTimesheet, overallTotals, approvedImage, employeeApprovalImg, activityID, companyDetails } = this.state;
    const biweekly = weekCount === 2 ? true : false;
    let week1Total = [];
    let week2Total = [];
    if (overallTotals.length > 0) {
      week1Total = overallTotals.slice(0, 7).map((dTotal) => dTotal.hours);
      week2Total = overallTotals.slice(7, 14).map((d1Total) => d1Total.hours);
    }

    return (
      <div className="App">
        <div className="content">
          <div className="contentwrapper pb-5 mb-5">
            <div className="p-3 mb-3 small_font bg-amber border-0">
              <Row>
                <Col lg="5" md="5" sm="12">
                  <div className="">
                    <span className="pr-3 font-weight-bold font-16">
                      {personalDetails.userLastname ? personalDetails.userLastname + ',' : null} {personalDetails.userFirstname}
                    </span>
                  </div>
                </Col>
                <Col lg="3" md="3" className="text-right" />
                <Col lg="2" md="2" className="text-right">
                  <label className="act-text">Week Started</label>
                </Col>
                <Col lg="2" md="2" sm="12">
                  <div className="form-group row mb-0 mr-2">
                    <DatePicker
                      selected={weeklyDate}
                      value={moment(startWeekDate).format('YYYY-MM-DD')}
                      name="startDate"
                      className="form-control"
                      customInput={<this.ExampleCustomInput />}
                      showMonthDropdown
                      showYearDropdown
                      dropdownMode="select"
                      filterDate={this.isWeekday}
                      onChange={this.handleWeekChange}
                      dateFormat="yyyy-MM-dd"
                      placeholderText="yyyy-MM-dd"
                    />
                  </div>
                </Col>
              </Row>
            </div>
            {timesheetLoading ? 'Please Wait...' :
              <>
                <Row>
                  <Col lg="8" md="8" sm="12">
                    <table border='1' className="col-12 text-center text-black w-50">
                      <thead>
                        <tr>
                          <th colSpan='3' className="blue-head">
                            {`${get(personalDetails, 'userFirstname', '')} ${get(personalDetails, 'userLastname', '')}'s Accumulated Time`}
                          </th>
                        </tr>
                      </thead>
                      <tbody>
                        <tr>
                          <th style={{ width: '50%' }}>{`Week (${this.formatDate(startWeekDate)} - ${this.formatDate(weekEndDate)})`}</th>
                        </tr>
                        <tr className="blue-num">
                          <td className="font-weight-bold">{toNumber(totalHours) || '0.00'} Hrs</td>
                        </tr>
                      </tbody>
                    </table>
                  </Col>
                  <Col lg="4" md="4" sm="12" className="row my-auto mx-0 pr-0">
                    <select
                      disabled={!clockin || isEmpty(currentClockInTimesheet)}
                      onChange={(event) => this.changeDropdown(event)}
                      value={this.state.activityID}
                      placeholder="Select"
                      className="col-lg-7 col-md-7 col-sm-6 form-control float-left"
                      name="state"
                    >
                      <option value="0">Select Activity</option>
                      {this.renderOptions()}
                    </select>
                    <Timer
                      className="col-12"
                      initialTime={0}
                      startImmediately={false}
                    >
                      {({ start, resume, pause, stop, reset, timerState }) => (
                        <React.Fragment>
                          {clockin && <MDBBtn
                            size="md"
                            className="col-lg-4 col-md-4 col-sm-6 ml-2 btn-success float-right"
                            disabled={currentClockInTimesheet.status >= 300 || Number(activityID) === 0 || clockinLoading || isEmpty(currentClockInTimesheet)}
                            onClick={() => {
                              start();
                              this.setState({ clockin: false, startTime: null, stopTime: null }, () => this.startClockin());
                            }}
                          >
                            Clock In
                  </MDBBtn>}
                          {!clockin && <MDBBtn
                            size="md"
                            className="col-lg-4 col-md-4 col-sm-6 ml-2 btn-danger float-right"
                            onClick={() => this.setState({ clockin: true, startTime: null, stopTime: null }, () => this.startClockin())}
                            disabled={currentClockInTimesheet.status >= 300 || Number(activityID) === 0 || clockinLoading || isEmpty(currentClockInTimesheet)}
                          >
                            Clock Out
                  </MDBBtn>}
                          {!clockin && <div
                            className="small_font text-success col-12 pl-0 mt-2"
                          >
                            {/* <Timer.Hours /> : <Timer.Minutes /> : <Timer.Seconds />  */}
                            {this.state.startTime && <span className="text-right float-right">Start Time : {moment(this.state.startTime).format('hh:mm:ss A MMM DD, YYYY')}</span>}
                          </div>}
                          { clockin && <div className=" text-danger small_font col-12 pl-0 mt-2" >
                            {this.state.stopTime && <span className="text-right float-right">Stop Time : {moment(this.state.stopTime).format('hh:mm:ss A MMM DD, YYYY')}</span>}
                          </div>}
                        </React.Fragment>
                      )}
                    </Timer>
                  </Col>
                </Row>

                <div className="mt-3">
                  <table border='1' className="col-12 text-black">
                    <thead>
                      <tr>
                        <th colSpan='18' className="blue-head py-2">
                          <Row>
                            <Col lg="6" md="6" sm="12">
                              <div className="pl-2  float-left">
                                <span className="font-12">{biweekly ? 'BI' : ''} WEEKLY TIME SHEET</span>
                                <span className="small-font pl-2">
                                  {`${this.formatDate(startWeekDate)} - ${this.formatDate(weekEndDate)}`}
                                </span>
                              </div>
                            </Col>
                            <Col lg="6" md="6" sm="12">
                              <div className="pr-2 float-right">
                                <span className="pr-2 font-12">{timesheet_status_codes[`${get(personalDetails, 'status', '')}`]}</span>
                                <span className="font-small">{`Due on : ${this.formatDate(moment(weekEndDate).subtract(1, 'day'))}`}</span>
                                <span className="px-1">|</span>
                                <i className="fa fa-print px-1"></i>
                                <i className="fa fa-file-pdf-o px-1"></i>
                              </div>
                            </Col>
                          </Row>
                        </th>
                      </tr>
                    </thead>
                    <tbody className="text-center">
                      <tr>
                        <td colSpan='2' className="font-weight-bold text-right pr-1">NAME:</td>
                        <td colSpan='16' className="pl-1 text-left">
                          {get(personalDetails, 'userLastname', '')}, {get(personalDetails, 'userFirstname', '')}
                        </td>
                      </tr>
                      <tr>
                        <td colSpan='2' className="font-weight-bold text-right pr-1">GROUP:</td>
                        <td colSpan='16' className="pl-1 text-left">{personalDetails.groupCode ? `${personalDetails.groupName} (${personalDetails.groupCode})` : 'N/A'}</td>
                      </tr>
                      <tr className="text-center font-small p-1 bg-lite-gray">
                        <th colSpan='2' width="10%"></th>
                        {weekDays.slice(0, 7).map((day, index) => (
                          <th key={`${day.day}${index}`} width="5%">{day.day}<br />{day.date}</th>
                        ))}
                        <th width="7%">Total<br />Hours</th>
                        {biweekly && <>
                          {weekDays.slice(7, 14).map((day, index) => (
                            <th key={`${day.day}${index}`} width="5%">{day.day}<br />{day.date}</th>
                          ))}
                          <th width="7%">Total<br />Hours</th>
                        </>}
                      </tr>
                      {tempObj && Object.values(tempObj).map((x, i) => {
                        let activityName = x.week1.activityName;
                        let w1finalClockIns = {}, w1UniqueHours = {}, w2finalClockIns = {}, w2UniqueHours = {};
                        const w1activityTotal = x.week1 && Object.values(DAYS_OF_WEEK).map((day) => x.week1[`${day.toLowerCase()}Hour`]).reduce((a, b) => Number(Number(a) + Number(b)).toFixed(2), 0);
                        const w2activityTotal = x.week2 && Object.values(DAYS_OF_WEEK).map((day) => x.week2[`${day.toLowerCase()}Hour`]).reduce((a, b) => Number(Number(a) + Number(b)).toFixed(2), 0);
                        if (x.week1 && x.week1.clockinouts && x.week1.clockinouts.length > 0) {
                          x.week1.clockinouts.map((x, i) => {
                            let objVal = `${ClockInOuts[x.type]}`;
                            if (w1UniqueHours[objVal]) {
                              if (w1UniqueHours[objVal].length > 0 && find(w1UniqueHours[objVal], { day: x.day, type: x.type })) {
                                w1UniqueHours[`${objVal}_${i}`] = [x];
                              } else {
                                w1UniqueHours[objVal].push(x);
                              }
                            } else {
                              w1UniqueHours[objVal] = [x];
                            }
                            return null;
                          })
                          Object.keys(DAYS_OF_WEEK).map((y) => {
                            Object.entries(w1UniqueHours).map((xdata) => {
                              w1finalClockIns[xdata[0]] = xdata[1];
                              const uniqueDays = xdata[1].map(x => x.day);
                              if (!uniqueDays.includes(Number(y))) {
                                if (xdata[0].includes('IN')) {
                                  w1finalClockIns[xdata[0]].push({ day: Number(y), type: 1, clockAt: null });
                                } else {
                                  w1finalClockIns[xdata[0]].push({ day: Number(y), type: 2, clockAt: null });
                                }
                              } else {
                                return null;
                              }
                              return null;
                            });
                            return null;
                          })
                        }
                        if (x.week2 && x.week2.clockinouts && x.week2.clockinouts.length > 0) {
                          x.week2.clockinouts.map((x, i) => {
                            let objVal = `${ClockInOuts[x.type]}`;
                            let tempDay = Number(x.day) + 7;
                            if (w2UniqueHours[objVal]) {
                              if (w2UniqueHours[objVal].length > 0 && find(w2UniqueHours[objVal], { day: tempDay, type: x.type })) {
                                w2UniqueHours[`${objVal}_${i}`] = [{ ...x, day: tempDay }];
                              } else {
                                w2UniqueHours[objVal].push({ ...x, day: tempDay });
                              }
                            } else {
                              w2UniqueHours[objVal] = [{ ...x, day: tempDay }];
                            }
                            return null;
                          })
                          Object.keys(BY_WEEKLY_DAYS_OF_WEEK).map((y) => {
                            Object.entries(w2UniqueHours).map((xdata) => {
                              w2finalClockIns[xdata[0]] = xdata[1]
                              const uniqueDays = xdata[1].map(x => x.day);
                              if (!uniqueDays.includes(Number(y))) {
                                if (xdata[0].includes('IN')) {
                                  w2finalClockIns[xdata[0]].push({ day: Number(y), type: 1, clockAt: null });
                                } else {
                                  w2finalClockIns[xdata[0]].push({ day: Number(y), type: 2, clockAt: null });
                                }
                              } else {
                                return null;
                              }
                              return null;
                            });
                            return null;
                          })
                        }
                        let finalData = {};
                        if (!isEmpty(w1finalClockIns)) {
                          Object.entries(w1finalClockIns).map((x) => {
                            if (!isEmpty(w2finalClockIns) && w2finalClockIns[x[0]]) {
                              finalData[x[0]] = [...x[1], ...w2finalClockIns[x[0]]]
                            }
                            else {
                              finalData[x[0]] = [...x[1], ...new Array(7)]
                            }
                          })
                        } else if (!isEmpty(w2finalClockIns)) {
                          Object.entries(w2finalClockIns).map((x) => {
                            if (!isEmpty(w1finalClockIns) && w1finalClockIns[x[0]]) {
                              finalData[x[0]] = [...w1finalClockIns[x[0]], ...x[1]]
                            }
                            else {
                              finalData[x[0]] = [...new Array(7), ...x[1]]
                            }
                          })
                        }
                        return <React.Fragment key={i}>
                          {!isEmpty(finalData) && Object.values(finalData).map((x, k) => {
                            const timeType = Object.keys(finalData)[k];
                            let w1 = x.slice(0, 7);
                            let w2 = x.slice(7, 14);
                            return <tr key={k}>
                              {k === 0 && (<td rowSpan={Object.values(finalData).length}>{activityName.toUpperCase()}</td>)}
                              <td >{timeType.split('_')[0]}</td>
                              {sortBy(w1, 'day').map((dt, i) => <td key={i}>{(dt && dt.clockAt) ? moment(dt.clockAt).format('h:mm A') : ''}</td>)}
                              {biweekly && <>
                                {k === 0 && (<td rowSpan={Object.values(finalData).length}></td>)}
                                {sortBy(w2, 'day').map((dt, i) => <td key={i}>{(dt && dt.clockAt) ? moment(dt.clockAt).format('h:mm A') : ''}</td>)}
                              </>}
                              {k === 0 && (<td rowSpan={Object.values(finalData).length}></td>)}
                            </tr>
                          })}
                          <tr className="time-td blue-text bg-lite-gray">
                            <td colSpan='2'>{`${x.week1.activityName.toUpperCase() || x.week2.activityName.toUpperCase()} HOURS`}</td>
                            {
                              Object.values(DAYS_OF_WEEK).map((day, index) => {
                                let indexVal = null;
                                if (finalTimesheets[0].changeNotes.length > 0) {
                                  finalTimesheets[0].changeNotes.map((ch) => {
                                    if ((ch.activityID === x.week1.activityID) && DAYS_OF_WEEK[ch.day] === day) {
                                      indexVal = ch.index;
                                    };
                                    return null;
                                  })
                                }
                                const hourValue = x.week1[`${day.toLowerCase()}Hour`] > 0 ? toNumber(x.week1[`${day.toLowerCase()}Hour`]) : '';
                                return <td key={`${day}${index}`} className='text-blue'>
                                  {indexVal && <span className="ptoCircle mr-1 text-center">{indexVal}</span>}
                                  <span contentEditable={(x.week1.id !== 0 && x.week1.timingMethod === 2) ? true : false}
                                    onBlur={(e) => {
                                      const textContent = e.currentTarget.textContent;
                                      if (textContent && toNumber(textContent) !== hourValue) {
                                        this.updateHourForDay(textContent, x.week1, index)
                                      }
                                    }}>{hourValue}</span>
                                </td>
                              })
                            }
                            <td >{w1activityTotal}</td>


                            {/* for 2nd Week */}
                            {biweekly && <>
                              {
                                Object.values(DAYS_OF_WEEK).map((day, index) => {
                                  let indexVal = null;
                                  if (finalTimesheets[1].changeNotes.length > 0) {
                                    finalTimesheets[1].changeNotes.map((ch) => {
                                      if ((ch.activityID === x.week2.activityID) && DAYS_OF_WEEK[ch.day] === day) {
                                        indexVal = ch.index;
                                      };
                                      return null;
                                    })
                                  }
                                  const hour2Value = x.week2[`${day.toLowerCase()}Hour`] > 0 ? toNumber(x.week2[`${day.toLowerCase()}Hour`]) : '';
                                  return <td key={`${day}${index}`} className='text-blue'>
                                    {indexVal && <span className="ptoCircle mr-1 text-center">{indexVal}</span>}
                                    <span contentEditable={(x.week2.id !== 0 && x.week2.timingMethod === 2) ? true : false}
                                      onBlur={(e) => {
                                        const textContent = e.currentTarget.textContent;
                                        if (textContent && toNumber(textContent) !== hour2Value) {
                                          this.updateHourForDay(textContent, x.week2, index)
                                        }
                                      }}>{hour2Value}</span>
                                  </td>
                                })
                              }
                              <td >{w2activityTotal}</td>
                            </>}
                          </tr>
                        </React.Fragment>
                      })}
                      <tr className="time-td blue-text bg-lite-gray">
                        <td colSpan='2'>TOTAL</td>
                        {week1Total.map((hour, rkey) => <td key={rkey}>{toNumber(hour) || 0.00}</td>)}
                        <td className="text-blue">{toNumber(sum(week1Total)) || 0.00}</td>
                        {biweekly && <>
                          {week2Total.map((hour2, rkey) => <td key={rkey}>{toNumber(hour2) || 0.00}</td>)}
                          <td className="text-blue">{toNumber(sum(week2Total)) || 0.00}</td>
                        </>}
                      </tr>
                    </tbody>
                    <tr>
                      <th colSpan='10' className="blue-head text-center py-2">
                        Timesheet Changes
                        </th>
                      {biweekly && <th colSpan='8' className="blue-head text-center py-2">
                        Timesheet Changes
                        </th>}
                    </tr>
                    <tr>
                      <td colSpan='10' className="py-2 text-left align-baseline">
                        {
                          get(finalTimesheets[0], 'changeNotes', []).map((timesheetChanges, timIndex) => {
                            let actualDay = DAYS_OF_WEEK[timesheetChanges.day];
                            let dateObject = find(weekDays, { day: actualDay });
                            return <p key={timIndex} className="pl-1 mb-1 small_font">
                              <span className="ptoCircleChg mr-2 text-center"><span className="d-block mt-1">{timesheetChanges.index}</span></span>
                              {timesheetChanges.activityName || ''} {moment(dateObject.fullDate).format('dddd (MMM DD, YYYY)')} : {timesheetChanges.reason} - Change made by {timesheetChanges.madeByFirstname} {timesheetChanges.madeByLastname}
                                &nbsp; on {moment(timesheetChanges.madeAt).format("hh:mm A MMM DD, YYYY")}.
                              </p>
                          })
                        }
                      </td>
                      {biweekly &&
                        <td colSpan='8' className="py-2 text-left align-baseline">
                          {
                            get(finalTimesheets[1], 'changeNotes', []).map((timesheetChanges, timIndex) => {
                              let actualDay = DAYS_OF_WEEK[timesheetChanges.day];
                              const biweekDays = weekDays.slice(7, 14);
                              const dateObject = find(biweekDays, { day: actualDay });
                              return <p key={timIndex} className="pl-1 mb-1 small_font">
                                <span className="ptoCircleChg mr-2 text-center"><span className="d-block mt-1">{timesheetChanges.index}</span></span>
                                {timesheetChanges.activityName || ''} {moment(dateObject.fullDate).format('dddd (MMM DD, YYYY)')} : {timesheetChanges.reason} - Change made by {timesheetChanges.madeByFirstname} {timesheetChanges.madeByLastname}
                                &nbsp; on {moment(timesheetChanges.madeAt).format("hh:mm A MMM DD, YYYY")}.
                              </p>
                            })
                          }
                        </td>}
                    </tr>
                    <tr>
                      <td colSpan={biweekly ? '18' : '10'} className="py-2"></td>
                    </tr>
                    {!isEmpty(finalTimesheets) && <tr>
                      {/* 1st week data */}
                      <td colSpan='2' className="pt-5 text-left">
                      </td>
                      <td colSpan='4' className="pt-5 text-left">
                        <p className="mb-0">
                          <span className="pl-1 pr-2 font-9">Employee Signature:</span>
                          {finalTimesheets[0] && finalTimesheets[0].status >= 300 ?
                            this.returnImage(finalTimesheets[0].uid, 'uid', employeeApprovalImg, 'employeeApprovalImg', 80, 30) :
                            <div className="float-right">
                              <div className="guideList" onClick={() => finalTimesheets[0].tid !== 0 && this.getCompanyDetails(finalTimesheets[0])}>
                                <div className="active cursor-pointer">
                                  <span className="activePointer timesheetSign"></span>
                                  <span className="pl-4">
                                    SIGN
                              </span>
                                </div>
                              </div>
                            </div>}
                        </p>
                        <p className="mb-0">
                          <span className="pl-1 font-9">Date: </span>
                          <span className="pl-1 font-9">{finalTimesheets[0].submitDate || ''}</span>
                        </p>
                      </td>

                      <td colSpan='4' className="pt-5 text-left">
                        <p className="mb-0">
                          <span className="pl-1 pr-2 font-9">Approval Signature:</span>
                          {finalTimesheets[0] && finalTimesheets[0].status < 500 ? null :
                            this.returnImage(finalTimesheets[0].approvedBy, 'approvedBy', approvedImage, 'approvalImage', 80, 30)}
                        </p>
                        <p className="mb-0">
                          <span className="pl-1 font-9">Date: </span>
                          <span className="pl-1 font-9">{finalTimesheets[0].approvalDate || ''}</span>
                        </p>
                      </td>
                      {/* 2nd week data */}
                      {biweekly && <>
                        <td colSpan='4' className="pt-5 text-left">
                          <p className="mb-0">
                            <span className="pl-1 pr-2 font-9">Employee Signature:</span>
                            {finalTimesheets[1] && finalTimesheets[1].status >= 300 ?
                              this.returnImage(finalTimesheets[1].uid, 'uid', employeeApprovalImg, 'employeeApprovalImg', 80, 30) :
                              <div className="float-right">
                                <div className="guideList" onClick={() => finalTimesheets[1].tid !== 0 && this.getCompanyDetails(finalTimesheets[1])}>
                                  <div className="active cursor-pointer">
                                    <span className="activePointer timesheetSign"></span>
                                    <span className="pl-4">
                                      SIGN
                                  </span>
                                  </div>
                                </div>
                              </div>}
                          </p>
                          <p className="mb-0">
                            <span className="pl-1 font-9">Date: </span>
                            <span className="pl-1 font-9">{finalTimesheets[1].submitDate || ''}</span>
                          </p>
                        </td>
                        <td colSpan='4' className="pt-5 text-left">
                          <p className="mb-0">
                            <span className="pl-1 pr-2 font-9">Approval Signature:</span>
                            {finalTimesheets[1] && finalTimesheets[1].status < 500 ? null :
                              this.returnImage(finalTimesheets[1].approvedBy, 'approvedBy', approvedImage, 'approvalImage', 80, 30)}
                          </p>
                          <p className="mb-0">
                            <span className="pl-1 font-9">Date: </span>
                            <span className="pl-1 font-9">{finalTimesheets[1].approvalDate || ''}</span>
                          </p>
                        </td>
                      </>}
                    </tr>}
                  </table>
                </div>
              </>}
          </div>
        </div>

        {/** Modal to submit timesheet */}
        <Modal
          scrollable={true}
          size="md"
          onHide={() => this.setState({ signshow: false })}
          show={this.state.signshow}
        >
          <Modal.Header closeButton className="h6 background-green1">
            <Modal.Title className="h6 text-white small_font" id="contained-modal-title-vcenter">
              Timesheet Submission Confirmation by {personalDetails.userLastname} {personalDetails.userFirstname} ({this.formatDate(moment())}).
          </Modal.Title>
          </Modal.Header>
          <Modal.Body className="show-grid small_font px-5">
            <p className="xs_font text-dark text-center">
              Please enter your name and password to electronically sign and submit your timesheet. {companyDetails.name} requires that you certify your timesheet by submitting using this your electronic signature.
          </p>
            <p className="small_font font-weight-bold text-center">
              {weekRange}
            </p>
            <div className="form-group row">
              <div className="col-lg-3 col-md-3 col-xl-3 col-sm-12 px-0 text-right">
                <label className="mt-2">Login Name :</label>
              </div>
              <div className="col-lg-6 col-md-6 col-xl-6 col-sm-12">
                <input type="text" className="form-control" placeholder=""
                  value={userName}
                  onChange={(evt) => this.setState({ userName: evt.target.value })} />
              </div>
            </div>
            <div className="form-group row">
              <div className="col-lg-3 col-md-3 col-xl-3 col-sm-12 px-0 text-right">
                <label className="mt-2">Password :</label>
              </div>
              <div className="col-lg-6 col-md-6 col-xl-6 col-sm-12">
                <input type="password" className="form-control" placeholder=""
                  value={passWord}
                  onChange={(evt) => this.setState({ passWord: evt.target.value })} />
              </div>
            </div>
            <p className="small_font text-center">
              <b>{personalDetails.userLastname}, {personalDetails.userFirstname} - Total Hours {totalHours}</b>
            </p>
            <p className="xs_font text-center">
              I Certify that all the information in my timesheet is accurate and true.
          </p>
          </Modal.Body>
          <Modal.Footer>
            <div className="col-12 row mt-2">
              <div className="col-6">
                <button
                  onClick={() => this.setState({ signshow: false })}
                  className="button resend-btn background-red px-4 float-left"
                >
                  No Cancel
              </button>
              </div>
              <div className="col-6">
                <button
                  className="button resend-btn float-right px-4"
                  disabled={isEmpty(userName) || isEmpty(passWord) || subLoading}
                  onClick={() => this.submitTimeSheet()}
                >
                  Yes, Sign & Submit
                </button>
              </div>
            </div>
          </Modal.Footer>
        </Modal>
      </div>
    )
  }
}

export default MyOwnTimesheet;
