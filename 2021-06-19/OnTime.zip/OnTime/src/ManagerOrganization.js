import React from 'react';
import { Container } from 'react-bootstrap';
import 'bootstrap/dist/css/bootstrap.min.css';
import './App.css';
import MyOwnTimesheet from './MyOwnTimesheet.js';

class ManagerOrganization extends React.Component {
  render() {
    return (
      <div className="App">
        <Container>
          <div className="contentwrapper pt-3 pb-5">
            <MyOwnTimesheet />
          </div>
        </Container>
      </div>
    );
  }
}

export default ManagerOrganization;
