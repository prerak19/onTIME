import React from 'react';
import { Route, Redirect } from "react-router-dom";

const ManagerPrivateRoute = ({ component: Component, ...rest }) => {
  let userType = localStorage.getItem('usertype');
  return (
    <Route
      {...rest}
      render={props =>
        userType === 'manager' ? (<Component {...props} />) :
          (<Redirect to={{ pathname: "/index", state: { from: props.location } }}
          />)
      }
    />
  );
}

export default ManagerPrivateRoute;