import React from 'react';
import { Route, Redirect } from "react-router-dom";

const EmployeePrivateRoute = ({ component: Component, ...rest }) => {
  let userType = localStorage.getItem('usertype');
  return (
    <Route
      {...rest}
      render={props =>
        userType === 'employee' ? (<Component {...props} />) :
          (<Redirect to={{ pathname: "/index", state: { from: props.location } }}
          />)
      }
    />
  );
}

export default EmployeePrivateRoute;