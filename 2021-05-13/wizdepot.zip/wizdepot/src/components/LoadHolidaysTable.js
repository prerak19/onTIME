import React from 'react';
import { MDBDataTable, MDBTable, MDBTableBody, MDBTableHead,MDBTooltip  } from 'mdbreact';
import "react-datepicker/dist/react-datepicker.css";
/* import "mdbreact/dist/css/mdb.css";
import "@fortawesome/fontawesome-free/css/all.min.css"; */
import '../App.css';
import {Modal,Container} from "react-bootstrap";
import {apiPost,apiGet,apiPut,apiDelete} from '../Api.js';
import DualListBox from 'react-dual-listbox';
import 'react-dual-listbox/lib/react-dual-listbox.css';
import { confirmAlert } from 'react-confirm-alert'; 
import 'react-confirm-alert/src/react-confirm-alert.css'; 

class LoadHolidaysTable extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      show: false,
      editshow: false,
      startDate: '',
      startDate1: '',
      startDate2: '',
      timedisabled:true,
      startdisabled:true,
      enddisabled:true,
      isChecked: false,
      holidaypolicy:true,
      rounding:false,
      holidayshow:false,
      rowresult: [],
      editdetails:[],
      options :[],
      selected: [],
      holidayList: [],
      fields: {},
      errors: {},
      error_message: '',
      extraholidays :[],
      ehfields: [],
      editbtn:false,
      ehfieldsedit:[]
    };
  } 
  handleFormChange = (e) => {
    let editdetails = this.state.editdetails;
    let errors = this.state.errors;
    editdetails[e.target.name] = e.target.value;
    errors[e.target.name] = "form-control is-valid";
    this.setState({
      editdetails
    });
  }
  handleHFormChange = (e) => {
    let ehfields = this.state.ehfields;
    let errors = this.state.errors;
    ehfields[e.target.name] = e.target.value;
    errors[e.target.name] = "form-control is-valid";
    this.setState({
      ehfields
    });
  }
  validateForm() {

    let editdetails = this.state.editdetails;
    let errors = {};
    let formIsValid = true;

    if (!editdetails["name"]) {
      formIsValid = false;
      errors["name"] = "form-control is-invalid";
    }
    if(!formIsValid){
      this.setState({
        error_message: 'Please fill all * Required Fields!'
      });
    }else{
      this.setState({
        error_message: ''
      });
    }
    
    this.setState({
      errors: errors
    });
    return formIsValid;
  }
  onChange = (selected) => {
    let data = this.state.options;
    this.setState({ holidayList: [] });
    let arr1 = [];
    selected.map((item) => {
      let obj = data.find(o => o.value === item);
      arr1.push({ hid: obj.labelid , desc: obj.value, hDate: obj.labeldate  })
    })

    this.setState({ holidayList: arr1 });
    this.setState({ selected });       
  };
  onAdd = (options) => {
    this.setState({ options });
  };
  handleChange = (date) => {
    this.setState({
      startDate: date
    })
  }
  handleChange1 = (date) => {
    this.setState({
      startDate1: date
    })
  }
  handleChange2 = (date) => {
    this.setState({
      startDate2: date
    })
  }
  toggleChange = (e) => {
    if(e.target.checked === true){      
      this.setState({
        timedisabled:false,
        startdisabled:false,
        enddisabled:false,
      });
    }else{
      this.setState({
        timedisabled:true,
        startdisabled:true,
        enddisabled:true,
      });
    }
  }
  toggleChangePolicy = (e) => {
    console.log(e.target.value);
    if(e.target.value === 'Holiday'){      
      this.setState({
        holidaypolicy:false,
        rounding:true,
      });
    }else{
      this.setState({
        holidaypolicy:true,
        rounding:false,
      });
    }
  }
  isWeekday = (date) => {
    const day = date.getDay()
    return day === 0
  }
  ExampleCustomInput = ({ value, onClick }) => (
    <button disabled={this.state.startdisabled} className="example-custom-input form-control" style={{
      minWidth: '100px',minHeight:'32px'
    }} onClick={onClick}>
      {value}
    </button>
  );
  isWeekday1 = (date) => {
    const day = date.getDay()
    return day === 6
  }
  ExampleCustomInput1 = ({ value, onClick }) => (
    <button disabled={this.state.enddisabled} className="example-custom-input form-control" style={{
      minWidth: '100px',minHeight:'32px'
    }} onClick={onClick}>
      {value}
    </button>
  );
  ExampleCustomInput2 = ({ value, onClick }) => (
    <button disabled={this.state.timedisabled} className="example-custom-input form-control" style={{
      minWidth: '100px',minHeight:'32px'
    }} onClick={onClick}>
      {value}
    </button>
  );
  deleteProcess = (e) => {
    var dv = e.currentTarget.dataset.tag;
    confirmAlert({
      customUI: ({ onClose }) => {
        return (
          <div className='custom-ui'>
            <h3>Are you sure?</h3>
            <p>You want to delete this?</p>            
            <button data-tag={dv} onClick={() => {
            this.deleteRecord({dv});
            onClose();
          }}>Yes, Delete it</button>
            <button onClick={onClose}>No, Cancel</button>
          </div>
        );
      }
    });
  }
  deleteRecord = (e) => {
    console.log(e.dv); 
    let requestDetails = { 
      method:'policies/holidaypolicies/'+e.dv,
      params:{}
    };
    apiDelete(requestDetails, true).then((response)=> {
      let requestDetails = { 
      method:'policies/holidaypolicies/all/'+localStorage.orgid,
      params:{ 
      }};
      apiGet(requestDetails, true).then((response)=> {             
        let result = response.data;
        let arr = [];
        { Array.isArray(result) &&  result.map((item) =>(          
          arr.push({
            name: item.name,
            description: item.description,
            paid: 'Paid',
            edit: <i class="fa fa-edit" data-tag={item.pid} onClick={this.editProcess}></i>,
            delete: <i class="fa fa-trash" data-tag={item.pid} onClick={this.deleteProcess}></i>,
          })
          ))
          this.setState({
            rowresult: arr
          })
        }
        console.log(this.state.rowresult);                  
      }).catch(error => {
        console.log(error)
      });
    }).catch(error => {
      console.log(error)
    });  
  }
  editRecord = (e) => {
    if (this.validateForm()) {
      let requestDetails = { 
        method:'policies/holidaypolicies/'+ e.currentTarget.dataset.tag,
        params:{
          pid : e.currentTarget.dataset.tag,
          name : this.state.editdetails.name,
          description : this.state.editdetails.description,
          holidayList : this.state.holidayList
        }
      };
      apiPut(requestDetails, true).then((response)=> { 
        this.setState({ editshow: false });
        let requestDetails = { 
          method:'policies/holidaypolicies/all/'+localStorage.orgid,
          params:{ 
          }};
          apiGet(requestDetails, true).then((response)=> {             
            let result = response.data;
            let arr = [];
            { Array.isArray(result) &&  result.map((item) =>(          
              arr.push({
                name: item.name,
                description: item.description,
                paid: 'Paid',
                edit: <i class="fa fa-edit" data-tag={item.pid} onClick={this.editProcess}></i>,
                delete: <i class="fa fa-trash" data-tag={item.pid} onClick={this.deleteProcess}></i>,
              })
              ))
              this.setState({
                rowresult: arr
              })
            }
            console.log(this.state.rowresult);                  
          }).catch(error => {
            console.log(error)
          });
      }).catch(error => {
        console.log(error)
      });    
    }else{
      
    }
  }
  addRecord = (e) => {
    if (this.validateForm()) {
      let requestDetails = { 
        method:'policies/holidaypolicies',
        params:{
          orgID : localStorage.orgid,
          name : this.state.editdetails.name,
          description : this.state.editdetails.description,
          holidayList : this.state.holidayList
        }
      };
      apiPost(requestDetails, true).then((response)=> { 
        this.setState({ show: false });
        let requestDetails = { 
          method:'policies/holidaypolicies/all/'+localStorage.orgid,
          params:{ 
          }};
          apiGet(requestDetails, true).then((response)=> {             
            let result = response.data;
            let arr = [];
            { Array.isArray(result) &&  result.map((item) =>(          
              arr.push({
                name: item.name,
                description: item.description,
                paid: 'Paid',
                edit: <i class="fa fa-edit" data-tag={item.pid} onClick={this.editProcess}></i>,
                delete: <i class="fa fa-trash" data-tag={item.pid} onClick={this.deleteProcess}></i>,
              })
              ))
              this.setState({
                rowresult: arr
              })
            }
            console.log(this.state.rowresult);                  
          }).catch(error => {
            console.log(error)
          });
      }).catch(error => {
        console.log(error)
      });    
    }else{
      
    }
  }
  addProcess = (d) => {
    this.setState({ show: true });
    this.setState({ editdetails: [] });  
    this.setState({ selected: [] });
    this.setState({ holidayList: [] });
    this.setState({ options: [] });
    let requestDetails1 = { 
      method:'policies/stdholidays',
      params:{}
    };
    apiGet(requestDetails1, true).then((response)=> { 
      let arr1 = this.state.options;
      { Array.isArray(response.data) &&  response.data.map((item) =>(  
        arr1.push({ value: item.desc , label: item.desc+'('+item.hDate+')', labelid: item.hid, labeldate: item.hDate })
      ))
      }
      this.setState({ options: arr1 });
    }).catch(error => {
      console.log(error)
    });
  }
  editProcess = (d) => {
    this.setState({ editshow: true });
    this.setState({ editdetails: [] });  
    this.setState({ selected: [] });
    this.setState({ holidayList: [] });
    this.setState({ options: [] });
    this.setState({ extraholidays: [] });
    let requestDetails1 = { 
      method:'policies/stdholidays',
      params:{}
    };
    apiGet(requestDetails1, true).then((response)=> { 
      let arr1 = this.state.options;
      { Array.isArray(response.data) &&  response.data.map((item) =>(  
        arr1.push({ value: item.desc , label: item.desc+'('+item.hDate+')', labelid: item.hid, labeldate: item.hDate })
      ))
      }
      this.setState({ options: arr1 });
      console.log(this.state.options);
    }).catch(error => {
      console.log(error)
    });
    let requestDetails = { 
      method:'policies/holidaypolicies/'+d.currentTarget.dataset.tag,
      params:{}
    };
    apiGet(requestDetails, true).then((response)=> { 
      this.setState({ editdetails: response.data }); 
      
      let arr = this.state.selected;
      let arr1 = this.state.options;
      let arr2 = this.state.holidayList;
      let arr3 = this.state.extraholidays;
      let arr4 = [];
      { Array.isArray(arr1) &&  arr1.map((item2) =>{        
        if(arr4.indexOf(item2.value) == -1 ){
          arr4.push(item2.value);
        }
      })}
      console.log(arr4);
      { Array.isArray(response.data.holidayList) &&  response.data.holidayList.map((item1) =>{ 
        if(arr4.indexOf(item1.desc) == -1 ){
          arr3.push({ hDate : item1.hDate, desc : item1.desc }); 
        }  
        if(arr.indexOf(item1.desc) == -1 ){
          arr.push(item1.desc); 
        }             
               
        arr2.push({ hid : item1.hid ,hDate : item1.hDate, desc : item1.desc });
        arr1.push({ value: item1.desc , label: item1.desc+'('+item1.hDate+')', labelid: item1.hid, labeldate: item1.hDate })
      })
      }
      console.log(arr3);
      this.setState({ extraholidays: arr3 });
      this.setState({ selected: arr });
      this.setState({ holidayList: arr2 });      
      this.setState({ options: this.getUnique(arr1,'value') });
      
      
    }).catch(error => {
      console.log(error)
    }); 
  }
  getUnique(arr, index) {

    const unique = arr
         .map(e => e[index])
  
         // store the keys of the unique objects
         .map((e, i, final) => final.indexOf(e) === i && i)
  
         // eliminate the dead keys & store unique objects
        .filter(e => arr[e]).map(e => arr[e]);      
  
     return unique;
  }
  addextraholidays = (e) => {
    let arr = this.state.extraholidays;
    arr.push({ hDate : this.state.ehfields.ehDate, desc : this.state.ehfields.ehDesc });
    this.setState({ extraholidays: arr });
    let arr1 = this.state.options;
    { Array.isArray(this.state.extraholidays) &&  this.state.extraholidays.map((item) =>(  
      arr1.push({ value: item.desc , label: item.desc+'('+item.hDate+')', labelid: '', labeldate: item.hDate })
    ))
    }
    this.setState({ options: this.getUnique(arr1,'value') });   
    let ehfields = this.state.ehfields;
    ehfields['ehDate'] = '';
    ehfields['ehDesc'] = '';
    this.setState({ ehfields });
  }
  editEHProcess = (e) => {
    this.setState({ editbtn: true });
    let ehfields = this.state.ehfields;
    let ehfieldsedit = this.state.ehfieldsedit;
    ehfieldsedit['ehDate'] = this.state.ehfields.date;
    ehfieldsedit['ehDesc'] = e.currentTarget.dataset.desc;
    ehfields['ehDate'] = e.currentTarget.dataset.date;
    ehfields['ehDesc'] = e.currentTarget.dataset.desc;
    this.setState({ ehfields });
    this.setState({ ehfieldsedit });
  }
  deleteEHProcess = (f) => {
    let editdesc = f.currentTarget.dataset.desc;
    let exarr = this.state.extraholidays;
    this.setState({ extraholidays: [] });
    let arr = [];
    { Array.isArray(exarr) &&  exarr.map((item) =>{ 
      if(item.desc == editdesc) {
        
      }else{
        arr.push({ hDate : item.hDate, desc : item.desc })
      }      
    })
    }
    this.setState({ extraholidays: arr });
    console.log(this.state.options)
    let exarro = this.state.options;
    this.setState({ options: [] });
    let arro = [];
    { Array.isArray(exarro) &&  exarro.map((item) =>{       
      if(item.value == editdesc) {
        arro.push({ labeldate : this.state.ehfields.ehDate, label: item.value+'('+item.labeldate+')', labelid: item.labelid, value : this.state.ehfields.ehDesc })
      }else{
        arro.push({ value: item.value , label: item.value+'('+item.labeldate+')', labelid: item.labelid, labeldate: item.labeldate })
      }      
    })
    }
    this.setState({ options: arro });

    let exarrs = this.state.selected;
    this.setState({ selected: [] });
    let arrs = [];
    { Array.isArray(exarrs) &&  exarrs.map((item) =>{       
      if(item == editdesc) {        
      }else{
        arrs.push(item)
      }      
    })
    }
    this.setState({ selected: arrs });

    this.onChange(this.state.selected);

    let ehfields = this.state.ehfields;
    ehfields['ehDate'] = '';
    ehfields['ehDesc'] = '';
    this.setState({ ehfields });
  }
  handleEditRec = (e) => {
    this.setState({ holidayshow: true})
    //this.editProcess();
  }
  editEHRecord = (f) => {
    let editdesc = f.currentTarget.dataset.desc;
    this.setState({ editbtn: false });    
    let exarr = this.state.extraholidays;
    this.setState({ extraholidays: [] });
    let arr = [];
    { Array.isArray(exarr) &&  exarr.map((item) =>{ 
      if(item.desc == editdesc) {
        arr.push({ hDate : this.state.ehfields.ehDate, desc : this.state.ehfields.ehDesc })
      }else{
        arr.push({ hDate : item.hDate, desc : item.desc })
      }      
    })
    }
    this.setState({ extraholidays: arr });
    console.log(this.state.options)
    let exarro = this.state.options;
    this.setState({ options: [] });
    let arro = [];
    { Array.isArray(exarro) &&  exarro.map((item) =>{       
      if(item.value == editdesc) {
        arro.push({ labeldate : this.state.ehfields.ehDate, label: item.value+'('+item.labeldate+')', labelid: item.labelid, value : this.state.ehfields.ehDesc })
      }else{
        arro.push({ value: item.value , label: item.value+'('+item.labeldate+')', labelid: item.labelid, labeldate: item.labeldate })
      }      
    })
    }
    this.setState({ options: arro });
    this.onChange(this.state.selected);
    let ehfields = this.state.ehfields;
    ehfields['ehDate'] = '';
    ehfields['ehDesc'] = '';
    this.setState({ ehfields });
    /*let arr1 = this.state.options;
    { Array.isArray(this.state.extraholidays) &&  this.state.extraholidays.map((item) =>(  
      arr1.push({ value: item.desc , label: item.desc+'('+item.hDate+')', labelid: '', labeldate: item.hDate })
    ))
    }
    this.setState({ options: arr1 });  */
  }
  async componentDidMount() {   
    
    let requestDetails = { 
    method:'policies/holidaypolicies/all/'+localStorage.orgid,
    params:{ 
    }};
    await apiGet(requestDetails, true).then((response)=> {             
      let result = response.data;
      let arr = this.state.rowresult;
      { Array.isArray(result) &&  result.map((item) =>(          
        arr.push({
          name: item.name,
          description: item.description,
          paid: 'Paid',
          edit: <i class="fa fa-edit" data-tag={item.pid} onClick={this.editProcess}></i>,
          delete: <i class="fa fa-trash" data-tag={item.pid} onClick={this.deleteProcess}></i>,
        })
        ))
        this.setState({
          rowresult: arr
        })
      }
      console.log(this.state.rowresult);                  
    }).catch(error => {
      console.log(error)
    });  
  }  
  render() {
  let datatable = {
    columns: [
      {
        label: 'Policy Name',
        field: 'name',
        attributes: {
          'aria-controls': 'DataTable',
          'aria-label': 'Name',
        },
      },
      {
        label: 'Policy Description',
        field: 'description',
      },
      {
        label: 'Reoccuring Paid Holidays',
        field: 'paid',
      },
      {
        label: 'Edit',
        field: 'edit',
        sort: 'disabled',
      },
      {
        label: 'Delete',
        field: 'delete',
        sort: 'disabled',
      },
    ],
    rows: this.state.rowresult,
  }
  return (
    <div>
      <div class="col-12 row mr-0 pr-0 pl-0 ml-0 mb-3">
      <div className="text-left float-left col-lg-9 col-md-9 col-xl-9 col-sm-12 pl-0">
            <h6 class="">Holiday Policies</h6>
            <span className="text-muted">These Policies affect how Holidays are handled in the timekeeping system </span>
          </div>
        <button  onClick={this.addProcess} class="button resend-btn py-2 px-4 col-lg-3 col-xl-3 col-md-3 col-sm-12 m-0"><i class="fa fa-plus pr-2"></i>Add New Holiday Policy</button>
      </div>
      <MDBDataTable hover info={false}  responsive={true} displayEntries={false} noBottomColumns entries={10} data={datatable} searching={false}/>
     
    <Modal  scrollable={true} size="lg"
          show={this.state.holidayshow}
           aria-labelledby="contained-modal-title-vcenter">
      <Modal.Header>
        <Modal.Title className="m-auto h6" id="contained-modal-title-vcenter">
        Manage Extra Holiday
        </Modal.Title>
      </Modal.Header>
      <Modal.Body className="show-grid small_font">
        <div className="row">   
          <div className="col-xl-4 col-lg-4 col-md-4 col-sm-12">
            <div className="form-group">
              <label for="exampleInputEmail1">Holiday Title*</label>
              <input type="text" name='ehDesc' value={this.state.ehfields.ehDesc} onChange={this.handleHFormChange} className="form-control" placeholder="Enter Holiday Title" />
            </div>
            <div className="form-group">
              <label for="exampleInputEmail1">Date*</label>
              <input type="date" name='ehDate' value={this.state.ehfields.ehDate} onChange={this.handleHFormChange} className="form-control" placeholder="Enter Date"/>
            </div>
            <button onClick={this.addextraholidays} style={this.state.editbtn === false ? {} : { display: 'none' }} class="button resend-btn py-2 px-4 m-0">Save</button>
            <button onClick={this.editEHRecord} data-desc={this.state.ehfieldsedit.ehDesc} style={this.state.editbtn === true ? {} : { display: 'none' }} class="button resend-btn py-2 px-4 m-0">Update</button>
          </div>       
          <div className="col-xl-8 col-lg-8 col-md-8 col-sm-12">
            <MDBTable responsive bordered className="activityloadtable overflow"> 
              <MDBTableHead>
                <tr>
                  <th>Title</th>
                  <th>Date</th>
                  <th>Edit</th>
                  <th>Delete</th>
                </tr>
              </MDBTableHead>
              <MDBTableBody>
              { Array.isArray(this.state.extraholidays) &&  this.state.extraholidays.map((item,i) =>{
                return <tr key={i}>
                  <td>{item.desc}</td>
                  <td>{item.hDate}</td>
                  <td><i class="fa fa-edit" data-desc={item.desc} data-date={item.hDate} onClick={this.editEHProcess}></i></td>
                  <td><i class="fa fa-trash" data-desc={item.desc} data-date={item.hDate} onClick={this.deleteEHProcess}></i></td>
                </tr>
              })}
              </MDBTableBody>
            </MDBTable>
          </div>          
        </div>    
      </Modal.Body>
      <Modal.Footer>
      <ul class="row form-group mr-0 mt-4 pr-0 list-inline pull-right">
        <li><button onClick={() => this.setState({ holidayshow: false })} class="button cancel-btn py-2 px-4 m-0 mr-2">Close</button></li>
      </ul>
      </Modal.Footer>
    </Modal>
      <Modal  scrollable={true} size="lg"  onHide={() => this.setState({ show: false })} 
          show={this.state.show}>
      <Modal.Header closeButton>
        <Modal.Title className="h6" id="contained-modal-title-vcenter">
        Add Holiday Policy
        </Modal.Title>
      </Modal.Header>
      <Modal.Body className="show-grid small_font px-5">
      <div className="text-danger col-12 text-center">{this.state.error_message}</div>
      <div className="form-group">
              <label for="exampleInputEmail1">Policy Name*</label>
              <input type="text" value={this.state.editdetails.name}  name="name" onChange={this.handleFormChange} className={ (this.state.errors["name"] ? this.state.errors["name"] : '')} className="form-control" placeholder="Policy Name" />
            </div>
            <div className="form-group">
              <label for="exampleInputEmail1">Policy Description</label>
              <textarea type="email" value={this.state.editdetails.description}  name="description" onChange={this.handleFormChange} className={ (this.state.errors["description"] ? this.state.errors["description"] : '')} className="form-control" placeholder="Policy Description"></textarea>
            </div>
            <div className="form-group row">
                <div className="col-xl-12 col-lg-12 col-md-12 col-sm-12">
                 <label className="mr-2">Reoccuring Paid Holidays</label>
                    <button class="button resend-btn py-2 px-4 m-0 text-center" onClick={() => this.setState({ holidayshow: true, extraholidays:[] })}>Add/Edit/Delete Extra Holiday</button>
                
                    <DualListBox lang ={{selectedHeader:'Selected Holidays',
                    availableHeader: 'Available Holidays'}}
                    showHeaderLabels={true}
                        options={this.state.options}
                        selected={this.state.selected}
                        onChange={this.onChange} className="mt-2" icons={{
                          moveLeft: '<',
                          moveAllLeft: '<<',
                          moveRight: '>',
                          moveAllRight: '>>'
                      }}
                    />
                    
                </div>
            </div> 
      </Modal.Body>
      <Modal.Footer>
      <ul class="row form-group mr-0 mt-4 pr-0 list-inline pull-right">
        <li><button onClick={() => this.setState({ show: false })} class="button cancel-btn py-2 px-4 m-0 mr-2">Cancel</button></li>
        <li><button onClick={this.addRecord} class="button resend-btn py-2 px-4 m-0">Save</button></li>
      </ul>
      </Modal.Footer>
    </Modal>
    <Modal  scrollable={true} size="lg" onHide={() => this.setState({ editshow: false })} 
          show={this.state.editshow}>
      <Modal.Header closeButton>
        <Modal.Title className="h6" id="contained-modal-title-vcenter">
        Edit Holiday Policy
        </Modal.Title>
      </Modal.Header>
      <Modal.Body className="show-grid small_font px-5">
      <div className="text-danger col-12 text-center">{this.state.error_message}</div>
      <div className="form-group">
              <label for="exampleInputEmail1">Policy Name*</label>
              <input type="text" value={this.state.editdetails.name}  name="name" onChange={this.handleFormChange} className={ (this.state.errors["name"] ? this.state.errors["name"] : '')} className="form-control" placeholder="Policy Name" />
            </div>
            <div className="form-group">
              <label for="exampleInputEmail1">Policy Description</label>
              <textarea type="email" value={this.state.editdetails.description}  name="description" onChange={this.handleFormChange} className={ (this.state.errors["description"] ? this.state.errors["description"] : '')} className="form-control" placeholder="Policy Description"></textarea>
            </div>
            <div className="form-group row">
                <div className="col-xl-12 col-lg-12 col-md-12 col-sm-12">
                 <label className="mr-2">Reoccuring Paid Holidays</label>
                    <button class="button resend-btn py-2 px-4 m-0 text-center" onClick={this.handleEditRec}>Add/Edit/Delete Extra Holiday</button>
                
                    <DualListBox lang ={{selectedHeader:'Selected Holidays',
                    availableHeader: 'Available Holidays'}}
                    showHeaderLabels={true} allowDuplicates={false}
                        options={this.state.options}
                        selected={this.state.selected}
                        onChange={this.onChange} className="mt-2" icons={{
                          moveLeft: '<',
                          moveAllLeft: '<<',
                          moveRight: '>',
                          moveAllRight: '>>'
                      }}
                    />
                    
                </div>
            </div> 
      </Modal.Body>
      <Modal.Footer>
      <ul class="row form-group mr-0 mt-4 pr-0 list-inline pull-right">
        <li><button onClick={() => this.setState({ editshow: false })} class="button cancel-btn py-2 px-4 m-0 mr-2">Cancel</button></li>
        <li><button  data-tag={this.state.editdetails.pid} onClick={this.editRecord} class="button resend-btn py-2 px-4 m-0">Save Changes</button></li>
      </ul>
      </Modal.Footer>
    </Modal>
    </div>
  );
}
}
export default LoadHolidaysTable;