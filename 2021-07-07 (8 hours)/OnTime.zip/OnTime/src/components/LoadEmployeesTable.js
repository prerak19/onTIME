import React from 'react';
import { MDBDataTable } from 'mdbreact';
import { Modal, Row, Col } from "react-bootstrap";
import DatePicker from "react-datepicker";
import "react-datepicker/dist/react-datepicker.css";
import DualListBox from 'react-dual-listbox';
import 'react-dual-listbox/lib/react-dual-listbox.css';
import { apiPost, apiGet, apiPut, apiDelete } from '../Api.js';
import { confirmAlert } from 'react-confirm-alert';
import 'react-confirm-alert/src/react-confirm-alert.css';
import { user_status, employeeTypes, wageCategory, stateDetails, user_status_codes, wageCategory_codes, employeeTypes_codes, momentDate } from '../helpers/GeneralHelper';
import { cloneDeep, find, isEqual } from 'lodash';
import moment from 'moment';

const empForm = {
  employeeType: 10,
  group: 0,
  status: 200,
  wage_category: 1,
}

class LoadEmployeesTable extends React.Component {
  constructor(props) {
    super(props);
    this.componentRef = React.createRef();
    this.state = {
      show: false,
      editMode: false,
      newPassword: null,
      confirmNewPassword: null,
      editPsw: false,
      currentEmp: null,
      selected: [],
      options: [],
      rowresult: [],
      editdetails: cloneDeep(empForm),
      errors: {},
      error_message: '',
      groups: [],
      activities: [],
      activity_id: 0,
      group_id: 0,
      status_id: 0,
      adminusers: [],
      activityList: [],
    };
  }

  componentDidMount() {
    this.getFunction();
    this.getGroups();
    this.getActivity();
    this.getAdminUsers();
  }
  getAdminUsers = (e) => {
    let requestDetails = {
      method: '/employees/approvers/' + localStorage.orgid,
      params: {}
    };
    apiGet(requestDetails, true).then((response) => {
      this.setState({ adminusers: response.data });
    }).catch(error => {
      console.log(error)
    });
  }

  getGroups = (e) => {
    let requestDetails = {
      method: 'groups/all/' + localStorage.orgid,
      params: {}
    };
    apiGet(requestDetails, true).then((response) => {
      this.setState({ groups: response.data });
    }).catch(error => {
      console.log(error)
    });
  }
  groupChange = (e) => {
    let gid = e.target.value;
    this.getFunction(gid);
    this.setState({ group_id: gid });
  }
  getActivity = (e) => {
    let requestDetails = {
      method: `activities/all/${localStorage.orgid}`,
      params: {}
    };
    apiGet(requestDetails, true, false).then((response) => {
      let arr1 = [];
      Array.isArray(response.data) && response.data.map((item) => (
        item.status === 100 && arr1.push({ value: item.actID, label: item.name, labeltype: item.type, labelallowExtra: item.allowExtra })
      ))
      this.setState({ activities: response.data, options: arr1 })
    }).catch(error => {
      console.log(error)
    });
  }
  activityChange = (e) => {
    let aid = e.target.value;
    this.getFunction(this.state.group_id, aid);
    this.setState({ activity_id: aid });
  }
  statusChange = (e) => {
    let sid = e.target.value;
    this.getFunction(this.state.group_id, this.state.activity_id, sid);
    this.setState({ status_id: sid });
  }
  handleFormChange = (name, value) => {
    const { groups, editdetails, selected } = this.state;
    let edetails = cloneDeep(editdetails);
    edetails[name] = value;
    let errors = this.state.errors;
    if (!value) {
      errors[name] = 'form-control is-invalid';
    } else {
      errors[name] = 'form-control is-valid';
    }
    if (name === 'group') {
      const group2Arr = groups.find((x) => x.id === Number(value));
      let act2Arr = group2Arr && group2Arr.groupActivities && group2Arr.groupActivities.length > 0 ? group2Arr.groupActivities.map(act => act.actID) : [];
      let groupArr = [];
      if (selected && selected.length > 0 && editdetails.group) {
        groupArr = groups.find((x) => x.id === Number(editdetails.group));
        if (groupArr && groupArr.groupActivities && groupArr.groupActivities.length > 0) {
          selected.map((x) => {
            if (!find(groupArr.groupActivities, { actID: x })) {
              if (!act2Arr.includes(x)) {
                act2Arr.push(x);
              }
            }
            return null;
          });
        } else {
          selected.map((g) => !act2Arr.includes(g) && act2Arr.push(g));
        }
      } else {
        selected.map((g) => !act2Arr.includes(g) && act2Arr.push(g));
      };
      this.onChange(act2Arr);
    }
    if (name === 'status') {
      if (this.validateForm()) {
        this.setState({ editdetails: edetails, errors });
      }
    } else {
      this.setState({ editdetails: edetails, errors });
    }
  }
  validateForm() {
    const { editMode, editdetails } = this.state;
    let errors = {};
    let formIsValid = true;

    if (!editdetails["firstName"]) {
      formIsValid = false;
      errors["firstName"] = "form-control is-invalid";
    }
    if (!editdetails["lastName"]) {
      formIsValid = false;
      errors["lastName"] = "form-control is-invalid";
    }
    if (!editdetails["email"]) {
      formIsValid = false;
      errors["email"] = "form-control is-invalid";
    }
    if (!editdetails["userName"]) {
      formIsValid = false;
      errors["userName"] = "form-control is-invalid";
    }
    if (!editMode && !editdetails["password"]) {
      formIsValid = false;
      errors["password"] = "form-control is-invalid";
    }
    if (!editMode && !editdetails["cpassword"]) {
      formIsValid = false;
      errors["cpassword"] = "form-control is-invalid";
    }
    if (!editMode && editdetails["cpassword"] !== editdetails["password"]) {
      formIsValid = false;
      errors["password"] = "form-control is-invalid";
      errors["cpassword"] = "form-control is-invalid";
    }
    if (!editdetails["approver"]) {
      formIsValid = false;
      errors["approver"] = "form-control is-invalid";
    }
    if (!editdetails["hireDate"]) {
      formIsValid = false;
      errors["hireDate"] = "form-control is-invalid";
    }
    if (!formIsValid) {
      this.setState({ error_message: 'Please fill all * Required Fields!' });
      this.componentRef.current.scrollTop = 0;
    } else {
      this.setState({
        error_message: ''
      });
    }

    this.setState({
      errors: errors
    });
    return formIsValid;
  }

  addRecord = (e) => {
    if (this.validateForm()) {
      let requestDetails = {
        method: 'employees',
        params: this.getParams()
      };
      apiPost(requestDetails, true).then((res) => {
        if (res && isEqual(res.status, 200) && res.data) {
          window.alert('Employee Created Successfully.');
          this.clearData();
          this.getFunction();
        }
        if (res.request.response && res.request.status !== 200) {
          let obj = JSON.parse(res.request.response);
          this.setState({ error_message: obj.msg });
          return;
        }
      }).catch(error => {
        console.log(error)
      });
    }
  }

  clearData = (openModal = false, editMode = false) => {
    this.setState({
      show: openModal,
      editMode,
      editdetails: cloneDeep(empForm),
      error_message: null,
      errors: {},
      selected: [], activityList: [],
    });
  }

  editProcess = async (d) => {
    this.clearData(true, true);
    let userID = d.currentTarget.dataset.tag;
    const emplDetails = { method: `employees/${userID}`, params: {} };

    await apiGet(emplDetails, true, false).then((empRes) => {
      if (isEqual(empRes.status, 200) && empRes.data) {
        const { data } = empRes;
        let arrs = {
          userName: data.userName,
          password: data.password,
          cpassword: data.password,
          firstName: data.firstName,
          lastName: data.lastName,
          employeeType: data.employeeType,
          status: data.status,
          email: data.email,
          wage_category: data.wage_category,
          approver: data.timeApprover.userID,
          group: data.group.id,
          employeeNumber: data.userProfile.employeeNumber,
          hireDate: data.userProfile.hireDate,
          anniversaryDate: data.userProfile.anniversaryDate,
          cEmail: data.userProfile.cEmail,
          cPhone: data.userProfile.cPhone,
          address1: data.userProfile.address1,
          address2: data.userProfile.address2,
          city: data.userProfile.city,
          state: data.userProfile.state,
          country: data.userProfile.country,
          zipcode: data.userProfile.zipcode,
          userID: data.userID,
        };
        let arr = [];
        let arr2 = [];
        if (data.userActivities && data.userActivities.length > 0) {
          Array.isArray(data.userActivities) && data.userActivities.map((item1) => {
            arr.push(item1.actID);
            arr2.push({ actID: item1.actID });
            return null;
          })
        }
        this.setState({ selected: arr, editdetails: arrs, activityList: arr2 });
      }
    }).catch(error => {
      this.clearData(false, false);
      console.log(`Error in promises ${error}`)
    });
  }

  getParams = () => {
    const { editdetails, activityList } = this.state;
    let obj = {
      type: "user",
      org_id: localStorage.orgid,
      userName: editdetails.userName,
      password: editdetails.password,
      firstName: editdetails.firstName,
      lastName: editdetails.lastName,
      employeeType: editdetails.employeeType,//ft-hourly
      status: editdetails.status,//inactive
      email: editdetails.email,
      wage_category: editdetails.wage_category,//non-exempt
      timeApprover: { userID: editdetails.approver },
      group: { id: editdetails.group },
      userProfile: {
        employeeNumber: editdetails.employeeNumber,
        hireDate: moment(editdetails.hireDate).format('YYYY-MM-DD'),
        anniversaryDate: editdetails.anniversaryDate,
        cEmail: editdetails.cEmail,
        cPhone: editdetails.cPhone,
        hPhone: editdetails.hPhone,
        mPhone: editdetails.mPhone,
        address1: editdetails.address1,
        address2: editdetails.address2,
        city: editdetails.city,
        state: editdetails.state,
        country: editdetails.country,
        zipcode: editdetails.zipcode,
      },
      userActivities: activityList
    }
    return obj;
  }
  editRecord = async (e) => {
    const { editdetails } = this.state;
    const { userID } = editdetails;
    if (this.validateForm()) {
      const empSubmit = { method: 'employees/' + userID, params: { userID, ...this.getParams() } };
      await apiPut(empSubmit, true).then((res) => {
        if (res && isEqual(res.status, 200) && res.data) {
          window.alert('Employee Updated Successfully.');
          this.clearData();
          this.getFunction();
        }
        if (res.request.response && res.request.status !== 200) {
          let obj = JSON.parse(res.request.response);
          this.setState({ error_message: obj.msg });
          return;
        }
      }).catch(error => {
        console.log(error)
      });
    } else {
      return false;
    }
  }

  resetEmpPassword = () => {
    const { currentEmp, confirmNewPassword, newPassword } = this.state;
    if (confirmNewPassword !== newPassword) {
      this.setState({ error_message: 'Password and Conifrm Password Does not Match!' });
      return;
    } else {
      this.setState({ error_message: '' });
    }
    let requestDetails = {
      method: 'employees/password-reset',
      params: {
        userID: currentEmp.userID,
        newPassword: newPassword,
        managerID: localStorage.userid
      }
    };
    apiPost(requestDetails, true).then((res) => {
      if (isEqual(res.status, 200) && res.data) {
        window.alert('Password Reset Successfully.');
        this.setState({ editPsw: false, currentEmp: null });
      } else if (res.request.response && res.request.status !== 200) {
        let obj = JSON.parse(res.request.response);
        obj.msg ? window.alert(obj.msg) : window.alert('Something Went Wrong!');
        return;
      } else {
        window.alert('Something Went Wrong!')
      }
    }).catch(error => {
      console.log(error);
      window.alert('Something Went Wrong!');
      this.setState({ editPsw: false, currentEmp: null });
    });
  }

  deleteProcess = (e) => {
    var dv = e.currentTarget.dataset.tag;
    confirmAlert({
      customUI: ({ onClose }) => {
        return (
          <div className='custom-ui'>
            <h3>Are you sure?</h3>
            <p>You want to delete this?</p>
            <button data-tag={dv} onClick={() => {
              this.deleteRecord({ dv });
              onClose();
            }}>Yes, Delete it</button>
            <button onClick={onClose}>No, Cancel</button>
          </div>
        );
      }
    });
  }
  deleteRecord = (e) => {
    let requestDetails = {
      method: 'employees/' + e.dv,
      params: {}
    };
    apiDelete(requestDetails, true).then((res) => {
      if (res && res.status === 200) {
        this.getFunction();
      } else {
        let obj = JSON.parse(res.request.response);
        window.alert(obj.msg);
        return null;
      }
    }).catch(error => {
      console.log(error)
    });
  }

  getFunction = (gid = '0', aid = '0', sid = '0') => {
    let requestDetails = {
      method: 'employees/all/' + localStorage.orgid,
      params: {
        group_id: gid,
        act_id: aid,
        status: sid
      }
    };
    apiPost(requestDetails, true).then((response) => {
      let result = response.data.users;
      let arr = [];
      Array.isArray(result) && result.map((item) => {
        let activitiesname = [];
        Array.isArray(item.userActivities) && item.userActivities.map((item1) => activitiesname.push(item1.name))
        arr.push({
          name: item.firstName + ' ' + item.lastName,
          status: user_status_codes[item.status],
          category: wageCategory_codes[item.wage_category],
          type: employeeTypes_codes[item.employeeType],
          date: (item.userProfile && item.userProfile.hireDate) ? item.userProfile.hireDate : null,
          activities: activitiesname.toString(),
          groupid: find(this.state.groups, { id: item.group.id }) ? find(this.state.groups, { id: item.group.id }).code : '',
          edit: <i className="fa fa-edit" data-tag={item.userID} onClick={this.editProcess}></i>,
          delete: <i className="fa fa-trash" data-tag={item.userID} onClick={this.deleteProcess}></i>,
          psw: <i className="fa fa-lock text-warning" onClick={() => this.setState({ editPsw: true, currentEmp: item, newPassword: null, confirmNewPassword: null })}></i>,
        })
        return null;
      })
      this.setState({ rowresult: arr })
    }).catch(error => {
      console.log(error)
    });
  };

  onChange = (selected) => {
    let data = this.state.options;
    let arr1 = [];
    selected.map((item) => {
      let obj = data.find(o => o.value === item);
      obj && arr1.push({ actID: obj.value });
      return null;
    })
    this.setState({ activityList: arr1, selected });
  };

  onAdd = (options) => {
    this.setState({ options });
  };

  ExampleCustomInput = ({ value, onClick, name }) => {
    const { errors } = this.state;
    return <div className="inner-addon right-addon">
      <i className="fa fa-calendar" onClick={onClick}></i>
      <input onClick={onClick} value={value} onChange={() => { }} type="text" className={((errors["hireDate"] && name === 'hireDate') ? errors["hireDate"] : 'form-control')} placeholder="Select Date" name="date" />
    </div>
  };

  render() {
    const { editMode, groups, errors, editPsw, currentEmp, newPassword, confirmNewPassword, editdetails, rowresult } = this.state;
    let datatable = {
      columns: [
        {
          label: 'Name',
          field: 'name',
        },
        {
          label: 'Status',
          field: 'status',
        },
        {
          label: 'Wage Category',
          field: 'category',
        },
        {
          label: 'Employee Type',
          field: 'type',
        },
        {
          label: 'Hire Date',
          field: 'date',
        },
        {
          label: 'Activities',
          field: 'activities',
        },
        {
          label: 'Group ID',
          field: 'groupid',
        },
        {
          label: 'Edit',
          field: 'edit',
        },
        {
          label: 'Delete',
          field: 'delete',
        },
        {
          label: '',
          field: 'psw',
        },
      ],
      rows: rowresult,
    }
    return (
      <div>
        <div className="form-group row small_font">
          <div className="col-xl-2 col-lg-2 col-md-2 col-sm-12">
            <label>Group</label>
            <select className="form-control" onChange={this.groupChange}>
              <option value='0'>All Group</option>
              {Array.isArray(groups) && groups.map((item, i) => {
                return <option value={item.id} key={i}>{item.name}</option>
              })
              }
            </select>
          </div>
          <div className="col-xl-2 col-lg-2 col-md-2 col-sm-12">
            <label>Activity</label>
            <select className="form-control" onChange={this.activityChange}>
              <option value='0'>All Activity</option>
              {Array.isArray(this.state.activities) && this.state.activities.map((item, i) => {
                return <option value={item.actID} key={i}>{item.name}</option>
              })
              }
            </select>
          </div>
          <div className="col-xl-2 col-lg-2 col-md-2 col-sm-12" onChange={this.statusChange}>
            <label>Status</label>
            <select className="form-control">
              <option value='0'>All Employees</option>
              {Array.isArray(user_status) && user_status.map((item, i) => {
                return <option value={item.code} key={i}>{item.name}</option>
              })
              }
            </select>
          </div>
        </div>
        <div className="col-12 row mr-0 pr-0 pl-0 ml-0 mb-3">
          <h6 className="text-left float-left col-lg-10 col-md-10 col-xl-10 col-sm-12 pl-0">The Number of Total Employees : ({rowresult.length})</h6>
          <button onClick={() => this.clearData(true, false)} className="button resend-btn py-2 px-4 col-lg-2 col-xl-2 col-md-2 col-sm-12 m-0"><i className="fa fa-plus pr-2"></i>Add Employees</button>
        </div>
        <MDBDataTable
          className="timesheets"
          bordered hover info={false}
          responsive={true}
          displayEntries={false}
          noBottomColumns
          entries={10}
          sortable={false}
          data={datatable}
          searching={false}
        />
        <Modal scrollable={true} size="lg" onHide={() => this.setState({ show: false })}
          show={this.state.show}>
          <Modal.Header closeButton>
            <Modal.Title className="h6" id="contained-modal-title-vcenter">
              {editMode ? 'Edit' : 'Add'} Employee Profile
        </Modal.Title>
          </Modal.Header>
          <Modal.Body className="show-grid small_font px-5" ref={this.componentRef}>
            <div className="text-danger col-12 text-center">{this.state.error_message}</div>
            <div className="form-group row">
              <div className="col-xl-4 col-lg-4 col-md-4 col-sm-12">
                <label>First Name*</label>
                <input type="text" value={editdetails.firstName} name="firstName" onChange={(e) => this.handleFormChange(e.target.name, e.target.value)}
                  className={(errors["firstName"] ? errors["firstName"] : 'form-control')} placeholder="First Name" />
              </div>
              <div className="col-xl-4 col-lg-4 col-md-4 col-sm-12">
                <label>Last Name*</label>
                <input type="text" value={editdetails.lastName} name="lastName" onChange={(e) => this.handleFormChange(e.target.name, e.target.value)} className={(errors["lastName"] ? errors["lastName"] : 'form-control')} placeholder="Last Name" />
              </div>
              <div className="col-xl-4 col-lg-4 col-md-4 col-sm-12">
                <label>Status*</label>
                <select value={editdetails.status} name="status" onChange={(e) => this.handleFormChange(e.target.name, e.target.value)} className={(errors["status"] ? errors["status"] : 'form-control')}>
                  {Array.isArray(user_status) && user_status.map((item, i) => {
                    return <option value={item.code} key={i}>{item.name}</option>
                  })
                  }
                </select>
              </div>
            </div>
            <div className="form-group row border-bottom pb-3">
              <div className="col-xl-4 col-lg-4 col-md-4 col-sm-12">
                <label>Username*</label>
                <input type="text" value={editdetails.userName} name="userName" onChange={(e) => this.handleFormChange(e.target.name, e.target.value)} className={(errors["userName"] ? errors["userName"] : 'form-control')} placeholder="Enter Username" />
              </div>
              {!editMode ? <div className="col-xl-4 col-lg-4 col-md-4 col-sm-12">
                <label>Password*</label>
                <input type="password" value={editdetails.password} name="password" onChange={(e) => this.handleFormChange(e.target.name, e.target.value)} className={(errors["password"] ? errors["password"] : 'form-control')} placeholder="Password" />
              </div> : null}
              {!editMode && <div className="col-xl-4 col-lg-4 col-md-4 col-sm-12">
                <label>Confirm Password*</label>
                <input type="password" value={editdetails.cpassword} name="cpassword" onChange={(e) => this.handleFormChange(e.target.name, e.target.value)} className={(errors["cpassword"] ? errors["cpassword"] : 'form-control')} placeholder="Confirm Password" />
              </div>}
            </div>
            <div className="form-group row">
              <div className="col-xl-4 col-lg-4 col-md-4 col-sm-12">
                <label>Employee Number</label>
                <input type="text" value={editdetails.employeeNumber} name="employeeNumber" onChange={(e) => this.handleFormChange(e.target.name, e.target.value)} className="form-control" placeholder="Employee Number" />
              </div>
              <div className="col-xl-4 col-lg-4 col-md-4 col-sm-12">
                <label>Employee Type*</label>
                <select value={editdetails.employeeType} name="employeeType" onChange={(e) => this.handleFormChange(e.target.name, e.target.value)} placeholder="Select" className={(errors["employeeType"] ? errors["employeeType"] : 'form-control')}>
                  {Array.isArray(employeeTypes) && employeeTypes.map((item, i) => {
                    return <option value={item.code} key={i}>{item.name}</option>
                  })
                  }
                </select>
              </div>
              <div className="col-xl-4 col-lg-4 col-md-4 col-sm-12">
                <label>Wage Category*</label>
                <select value={editdetails.wage_category} name="wage_category" onChange={(e) => this.handleFormChange(e.target.name, e.target.value)} placeholder="Select" className={(errors["wage_category"] ? errors["wage_category"] : 'form-control')}>
                  {Array.isArray(wageCategory) && wageCategory.map((item, i) => {
                    return <option value={item.code} key={i}>{item.name}</option>
                  })
                  }
                </select>
              </div>
            </div>
            <div className="form-group row border-bottom pb-3">
              <div className="col-xl-4 col-lg-4 col-md-4 col-sm-12">
                <label>Hire Date*</label>
                <DatePicker
                  selected={editdetails.hireDate ? momentDate(editdetails.hireDate) : null}
                  value={editdetails.hireDate}
                  name="hireDate"
                  showMonthDropdown
                  showYearDropdown
                  dropdownMode="select"
                  className={(errors["hireDate"] ? errors["hireDate"] : 'form-control')}
                  customInput={<this.ExampleCustomInput />}
                  onChange={(date) => this.handleFormChange('hireDate', date)}
                  dateFormat="yyyy-MM-dd"
                  placeholderText="yyyy-MM-dd"
                />
              </div>
              <div className="col-xl-4 col-lg-4 col-md-4 col-sm-12">
                <label>Termination Date</label>
                <DatePicker
                  selected={editdetails.terminationDate ? momentDate(editdetails.terminationDate) : null}
                  value={editdetails.terminationDate}
                  showMonthDropdown
                  showYearDropdown
                  dropdownMode="select"
                  name="terminationDate"
                  className='form-control'
                  customInput={<this.ExampleCustomInput />}
                  onChange={(date) => this.handleFormChange('terminationDate', date)}
                  dateFormat="yyyy-MM-dd"
                  placeholderText="yyyy-MM-dd"
                />
              </div>
              <div className="col-xl-4 col-lg-4 col-md-4 col-sm-12">
                <label>Anniversary Date</label>
                <DatePicker
                  selected={editdetails.anniversaryDate ? momentDate(editdetails.anniversaryDate) : null}
                  value={editdetails.anniversaryDate}
                  name="anniversaryDate"
                  className='form-control'
                  showMonthDropdown
                  showYearDropdown
                  dropdownMode="select"
                  customInput={<this.ExampleCustomInput />}
                  onChange={(date) => this.handleFormChange('anniversaryDate', date)}
                  dateFormat="yyyy-MM-dd"
                  placeholderText="yyyy-MM-dd"
                />
              </div>
            </div>
            <div className="form-group row">
              <div className="col-xl-4 col-lg-4 col-md-4 col-sm-12">
                <label>Personal Email*</label>
                <input type="email" value={editdetails.email} name="email" onChange={(e) => this.handleFormChange(e.target.name, e.target.value)} className={(errors["email"] ? errors["email"] : 'form-control')} placeholder="Enter Email ID" />
              </div>
              <div className="col-xl-4 col-lg-4 col-md-4 col-sm-12">
                <label>Work Email</label>
                <input type="text" value={editdetails.cEmail} name="cEmail" onChange={(e) => this.handleFormChange(e.target.name, e.target.value)} className="form-control" placeholder="Enter Email ID" />
              </div>
              <div className="col-xl-4 col-lg-4 col-md-4 col-sm-12">
                <label>Cell Phone</label>
                <input value={editdetails.cPhone} name="cPhone" onChange={(e) => this.handleFormChange(e.target.name, e.target.value)} className="form-control" placeholder="Enter Phone Number" />
              </div>
            </div>
            <div className="form-group">
              <label>Address</label>
              <input type="text" value={editdetails.address1} name="address1" onChange={(e) => this.handleFormChange(e.target.name, e.target.value)} className="form-control" placeholder="Enter Address" />
            </div>
            <div className="form-group">
              <label>Address 2</label>
              <input type="text" value={editdetails.address2} name="address2" onChange={(e) => this.handleFormChange(e.target.name, e.target.value)} className="form-control" placeholder="Enter Address" />
            </div>
            <div className="form-group row border-bottom pb-3">
              <div className="col-xl-4 col-lg-4 col-md-4 col-sm-12">
                <label>City</label>
                <input type="text" value={editdetails.city} name="city" onChange={(e) => this.handleFormChange(e.target.name, e.target.value)} className="form-control" placeholder="Enter City" />
              </div>
              <div className="col-xl-4 col-lg-4 col-md-4 col-sm-12">
                <label>State</label>
                <select placeholder="State" value={editdetails.state} name="state" onChange={(e) => this.handleFormChange(e.target.name, e.target.value)} className="form-control">
                  {stateDetails.map((x, key) => (
                    <option value={x.value} key={key}>{x.label}</option>
                  ))}
                </select>
              </div>
              <div className="col-xl-4 col-lg-4 col-md-4 col-sm-12">
                <label>Zip Code</label>
                <input value={editdetails.zipcode} name="zipcode" onChange={(e) => this.handleFormChange(e.target.name, e.target.value)} className="form-control" placeholder="Enter Zip Code" />
              </div>
              <div className="col-xl-4 col-lg-4 col-md-4 col-sm-12">
                <label>Country</label>
                <input type="text" value={editdetails.country} name="country" onChange={(e) => this.handleFormChange(e.target.name, e.target.value)} className="form-control" placeholder="Enter Country" />
              </div>
            </div>
            <div className="form-group row">
              <div className="col-xl-8 col-lg-8 col-md-8 col-sm-12">
                <label className="mr-2">Activities</label>
                <DualListBox lang={{
                  selectedHeader: 'Selected Activities',
                  availableHeader: 'Available Activities'
                }}
                  showHeaderLabels={true}
                  options={this.state.options}
                  selected={this.state.selected}
                  onChange={this.onChange} className="mt-2" icons={{
                    moveLeft: '<',
                    moveAllLeft: '<<',
                    moveRight: '>',
                    moveAllRight: '>>'
                  }}
                />
              </div>
            </div>
            <div className="form-group row">
              <div className="col-xl-4 col-lg-4 col-md-4 col-sm-12">
                <label className="mr-2">Assigned Group</label>
                <select value={editdetails.group} name="group" onChange={(e) => this.handleFormChange(e.target.name, e.target.value)} className="form-control">
                  <option value='0'>None</option>
                  {Array.isArray(this.state.groups) && this.state.groups.map((item, i) => {
                    return <option value={item.id} key={i}>{item.name}</option>
                  })
                  }
                </select>
              </div>
              <div className="col-xl-4 col-lg-4 col-md-4 col-sm-12">
                <label>Timesheet Approver*</label>
                <select value={editdetails.approver} name="approver" onChange={(e) => this.handleFormChange(e.target.name, e.target.value)} className={(errors["approver"] ? errors["approver"] : 'form-control')}>
                  <option value='0'>Select</option>
                  {Array.isArray(this.state.adminusers) && this.state.adminusers.map((item, i) => {
                    return <option key={i} value={item.userID}>{item.firstName + ' ' + item.lastName}</option>
                  })
                  }
                </select>
              </div>
            </div>
          </Modal.Body>
          <Modal.Footer>
            <ul className="row form-group mr-0 mt-4 pr-0 list-inline pull-right">
              <li><button onClick={() => this.clearData()} className="button cancel-btn py-2 px-4 m-0 mr-2">Cancel</button></li>
              <li><button onClick={() => editMode ? this.editRecord() : this.addRecord()} className="button resend-btn py-2 px-4 m-0">Save</button></li>
            </ul>
          </Modal.Footer>
        </Modal>
        {editPsw === true && <Modal scrollable={true} size="md" onHide={() => this.setState({ editPsw: false, currentEmp: null, error_message: '' })}
          show={this.state.editPsw}>
          <Modal.Header closeButton>
            <Modal.Title id="contained-modal-title-vcenter">
              <div className="h6"><i className="fa fa-lock text-warning mr-2"></i>{currentEmp.firstName}, {currentEmp.lastName} - Reset Password</div>
              <p className="small_font font-weight-normal">Please enter a new temporary password for {currentEmp.firstName} {currentEmp.lastName}. For security reason, password to be changed.</p>
            </Modal.Title>
          </Modal.Header>
          <Modal.Body className="show-grid small_font px-5">
            <div className="text-danger col-12 text-center">{this.state.error_message}</div>
            <Row>
              <Col lg="12" md="12" sm="12">
                <div className="form-group">
                  <label>Login Name</label>
                  <input type="text" value={currentEmp.userName} className="form-control" placeholder="Joe Smith" disabled />
                </div>
              </Col>
              <Col lg="6" md="12" sm="12">
                <div className="form-group">
                  <label>Reset Password</label>
                  <input type="password" value={newPassword} name='newPassword' onChange={(e) => this.setState({ [e.target.name]: e.target.value })} className="form-control" placeholder="Enter new password" Readonly />
                </div>
              </Col>
              <Col lg="6" md="12" sm="12">
                <div className="form-group">
                  <label></label>
                  <input type="password" value={confirmNewPassword} name='confirmNewPassword' onChange={(e) => this.setState({ [e.target.name]: e.target.value })} className="form-control mt-2" placeholder="Confirm new password" Readonly />
                </div>
              </Col>
            </Row>
            <p className="small_font">
              You are about to reset password for this employee.
              After user login with this new password,
              they will be able to update to their choice in their profile settings.
            </p>
          </Modal.Body>
          <Modal.Footer>
            <button onClick={() => this.setState({ editPsw: false, currentEmp: null, error_message: '' })} className="button cancel-btn py-2 px-4 m-0 mr-2">Cancel</button>
            <button
              disabled={!confirmNewPassword || !newPassword}
              onClick={() => this.resetEmpPassword()}
              className="button resend-btn py-2 px-4 m-0">Reset Password</button>
          </Modal.Footer>
        </Modal>}
      </div>
    );
  }
}
export default LoadEmployeesTable;