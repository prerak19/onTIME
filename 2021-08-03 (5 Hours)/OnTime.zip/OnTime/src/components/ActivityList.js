import React from 'react';
import { isEmpty, isEqual } from 'lodash';
import { apiGet } from '../Api';
import { punchTypes, roundTypes } from '../helpers/GeneralHelper';
import { Tab, Tabs } from 'react-bootstrap';

class ActivityList extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      holidayPolicyData: {},
      roundingPolicyData: {},
      loadPolicy: false,
      activeTab: "roundingPolicy"
    };
  }

  componentDidMount() {
    this.getData();
  }

  getData = async () => {
    const { activity } = this.props;
    this.setState({ loadPolicy: true });
    if (activity.roundingPolicyID > 0) {
      const getRequest = {
        method: `policies/roundingpolicies/${activity.roundingPolicyID}`,
        params: {}
      };
      await apiGet(getRequest, false).then((response) => {
        if (isEqual(response.status, 200) && response.data) {
          this.setState({ roundingPolicyData: response.data, loadPolicy: false });
        }
      }).catch(error => {
        this.setState({ roundingPolicyData: {}, loadPolicy: false });
      });
    }
    if (activity.holidayPolicyID > 0) {
      const getRequest = {
        method: `policies/holidaypolicies/${activity.holidayPolicyID}`,
        params: {}
      };
      await apiGet(getRequest, false).then((response) => {
        if (isEqual(response.status, 200) && response.data) {
          this.setState({ holidayPolicyData: response.data, loadPolicy: false });
        }
      }).catch(error => {
        this.setState({ holidayPolicyData: {}, loadPolicy: false });
      });
    }
    this.setState({ loadPolicy: false });
  }

  render() {
    const { activity } = this.props;
    const { holidayPolicyData, roundingPolicyData, loadPolicy, activeTab } = this.state;
    let holidaysArr = [];
    if (holidayPolicyData && holidayPolicyData.holidayList && holidayPolicyData.holidayList.length > 0) {
      holidaysArr = holidayPolicyData.holidayList.map((x) => x.desc);
    }
    return (
      <div>
        <div className="row mx-0">
          <p onClick={() => this.props.backToMenu()} className=" text-left float-left cursor-pointer font-weight-bolder blue-color"><i className="fa fa-angle-left pr-2"></i>Activities</p>
        </div>
        <div className="w-100 text-left float-left">
          <p className="text-muted mb-3">  View Policies for Activity : {activity && activity.name.toUpperCase()}</p>
          <h6 className="font-weight-bolder">{activity.name.toUpperCase()}({activity.code}) - Activity Policies</h6>
        </div>
        {loadPolicy === true ? 'Please Wait...' :
          (isEmpty(roundingPolicyData) && isEmpty(holidayPolicyData)) ? <div> No Policies Found </div>
            : <div className="payrollform">
              <Tabs defaultActiveKey="roundingPolicy" activeKey={activeTab} className="customTabs" onSelect={(tab) => this.setState({ activeTab: tab })}>
                <Tab eventKey="roundingPolicy" title={<span className="customTabsTitle">Rounding Policy</span>}>
                  {activeTab === 'roundingPolicy' &&
                    <div className="content small_font ml-4">
                      <p><b>Policy Name : </b>{roundingPolicyData.name}</p>
                      <p><b>Policy Description : </b>{roundingPolicyData.description} </p>
                      <p><b>Punch Type to Round : </b>{punchTypes[roundingPolicyData.punchType]}</p>
                      <p><b>How to Round : </b>{roundTypes[roundingPolicyData.roundType]}</p>
                      <p><b>Round Interval : </b>Nearest {roundingPolicyData.roundInterval} minutes</p>
                    </div>}
                </Tab>
                <Tab eventKey="holidayPolicy" title={<span className="customTabsTitle">Holiday Policy</span>}>
                  {activeTab === 'holidayPolicy' &&
                    <div className="content small_font ml-4">
                      <p><b>Policy Name : </b>{holidayPolicyData.name}</p>
                      <p><b>Policy Description : </b>{holidayPolicyData.description}</p>
                      <p><b>Reoccuring Holidays : </b>{holidaysArr.join(', ')}</p>
                    </div>}
                </Tab>
              </Tabs>
            </div>
        }
      </div>
    );
  }
}
export default ActivityList;