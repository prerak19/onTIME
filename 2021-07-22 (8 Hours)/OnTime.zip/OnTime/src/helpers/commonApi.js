import { apiGet, uploadImage } from "../Api";

export const toBase64 = file => new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.readAsDataURL(file);
    reader.onload = () => resolve(reader.result);
    reader.onerror = error => reject(error);
});

export const signImageUpload = async (imageData, savedFuture = true, type = "user_signature") => {
    let imageId = '';
    const signImageFile = new File([imageData], "image");
    const userid = localStorage.userid;
    let requestDetails3 = { method: `employees/images/sig-init?id=${userid}&itemtype=${type}&reuse=${savedFuture ? 1 : 0} ` };
    let signImage = new FormData();
    if (signImageFile) {
        signImage.append("file", signImageFile);
        signImage.append("type", 'png');
    }
    await uploadImage(requestDetails3, signImage).then((res) => {
        if (res.status === 200 && res.data && res.data.returnValue) {
            imageId = res.data.returnValue;
        }
        if (res.request && res.request.response && res.request.status !== 200) {
            let obj = JSON.parse(res.request.response);
            window.alert(obj.msg);
            return;
        }
    }).catch(error => {
        console.log(error)
    });
    return imageId;
}

export const getImageURLs = async (imageId) => {
    let signatureImage = '';
    const requestDetails = { method: `employees/images/${imageId}` };
    await apiGet(requestDetails, false, false).then(async (response) => {
        if (response.data) {
            signatureImage = response.data;
        }
    }).catch(error => {
        console.log(error);
    });
    return signatureImage;
}

export const getReuseSignInit = async (Init = false) => {
    let obj = {
        imageId: "",
        signatureImage: "",
    };
    const requestDetails = { method: `employees/images/reuse-${Init ? 'init' : 'sig'}?uid=${localStorage.userid}` };
    await apiGet(requestDetails, true, false).then(async (res) => {
        if (res.status === 200 && res.data && res.data.returnValue) {
            obj.imageId = Number(res.data.returnValue);
            obj.signatureImage = await getImageURLs(obj.imageId)
        }
    }).catch((err) => {
        console.log(err);
    })
    return obj;
}