import React from 'react';
import { MDBDataTable, } from 'mdbreact';
import { Modal, } from "react-bootstrap";
import { apiPost, apiGet, apiPut, apiDelete } from '../Api.js';
import { confirmAlert } from 'react-confirm-alert';
import 'react-confirm-alert/src/react-confirm-alert.css';
import * as GeneralHelper from '../helpers/GeneralHelper'

class LoadPoliciesTable extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      show: false,
      editshow: false,
      rowresult: [],
      editdetails: [],
      fields: {},
      errors: {},
      error_message: '',
      punchTypes: GeneralHelper.punchTypes,
      roundTypes: GeneralHelper.roundTypes
    };
  }

  componentDidMount() {
    this.getFunction();
  }
  handleFormChange = (e) => {
    let editdetails = this.state.editdetails;
    let errors = this.state.errors;
    editdetails[e.target.name] = e.target.value;
    errors[e.target.name] = "form-control is-valid";
    this.setState({
      editdetails
    });
  }
  validateForm() {
    let editdetails = this.state.editdetails;
    let errors = {};
    let formIsValid = true;

    if (!editdetails["name"]) {
      formIsValid = false;
      errors["name"] = "form-control is-invalid";
    }
    if (!formIsValid) {
      this.setState({
        error_message: 'Please fill all * Required Fields!'
      });
    } else {
      this.setState({
        error_message: ''
      });
    }

    this.setState({
      errors: errors
    });
    return formIsValid;
  }
  addRecord = (e) => {
    if (this.validateForm()) {
      let requestDetails = {
        method: 'policies/roundingpolicies',
        params: {
          userId: localStorage.userid,
          orgID: localStorage.orgid,
          name: this.state.editdetails.name,
          description: this.state.editdetails.description,
          punchType: this.state.editdetails.punchType ? this.state.editdetails.punchType : '3',
          roundType: this.state.editdetails.roundType ? this.state.editdetails.roundType : '3',
          roundInterval: this.state.editdetails.roundInterval ? this.state.editdetails.roundInterval : '15'
        }
      };
      apiPost(requestDetails, true).then((res) => {
        if (res && res.status === 200 && res.data) {
          this.setState({ show: false });
          this.getFunction();
        }
        if (res.request.response && res.request.status !== 200) {
          let obj = JSON.parse(res.request.response);
          obj.msg ? window.alert(obj.msg) : window.alert('Something Went Wrong!');
          return;
        }
      }).catch(error => {
        console.log(error)
      });
    }
  }
  editRecord = (e) => {
    if (this.validateForm()) {
      let requestDetails = {
        method: 'policies/roundingpolicies/' + e.currentTarget.dataset.tag,
        params: {
          pid: e.currentTarget.dataset.tag,
          userId: '7',
          orgID: localStorage.orgid,
          name: this.state.editdetails.name,
          description: this.state.editdetails.description,
          punchType: this.state.editdetails.punchType ? this.state.editdetails.punchType : '3',
          roundType: this.state.editdetails.roundType ? this.state.editdetails.roundType : '3',
          roundInterval: this.state.editdetails.roundInterval ? this.state.editdetails.roundInterval : '15'
        }
      };
      apiPut(requestDetails, true).then((res) => {
        if (res && res.status === 200 && res.data) {
          this.setState({ editshow: false });
          this.getFunction();
        }
        if (res.request.response && res.request.status !== 200) {
          let obj = JSON.parse(res.request.response);
          obj.msg ? window.alert(obj.msg) : window.alert('Something Went Wrong!');
          return;
        }
      }).catch(error => {
        console.log(error)
      });
    }
  }
  editProcess = (d) => {
    this.setState({ editshow: true });
    this.setState({ editdetails: [] });
    let requestDetails = {
      method: 'policies/roundingpolicies/' + d.currentTarget.dataset.tag,
      params: {}
    };
    apiGet(requestDetails, true).then((response) => {
      this.setState({ editdetails: response.data });
    }
    ).catch(error => {
      console.log(error)
    });
  }
  deleteProcess = (e) => {
    var dv = e.currentTarget.dataset.tag;
    confirmAlert({
      customUI: ({ onClose }) => {
        return (
          <div className='custom-ui'>
            <h3>Are you sure?</h3>
            <p>You want to delete this?</p>
            <button data-tag={dv} onClick={() => {
              this.deleteRecord({ dv });
              onClose();
            }}>Yes, Delete it</button>
            <button onClick={onClose}>No, Cancel</button>
          </div>
        );
      }
    });
  }
  deleteRecord = (e) => {
    let requestDetails = {
      method: 'policies/roundingpolicies/' + e.dv,
      params: {}
    };
    apiDelete(requestDetails, true).then((res) => {
      if (res && res.status === 200 && res.data) {
        this.getFunction();
      }
      if (res.request.response && res.request.status !== 200) {
        let obj = JSON.parse(res.request.response);
        obj.msg ? window.alert(obj.msg) : window.alert('Something Went Wrong!');
        return;
      }
    }).catch(error => {
      console.log(error)
    });
  }
  getFunction = (e) => {
    let requestDetails = {
      method: 'policies/roundingpolicies/all/' + localStorage.orgid,
      params: {}
    };
    apiGet(requestDetails, true).then((response) => {
      let result = response.data;
      let arr = [];
      Array.isArray(result) && result.map((item) => (
        arr.push({
          name: item.name,
          description: item.description,
          punch: this.state.punchTypes[item.punchType],
          round: this.state.roundTypes[item.roundType],
          interval: item.roundInterval + ' Min',
          edit: <i className="fa fa-edit" data-tag={item.pid} onClick={this.editProcess}></i>,
          delete: <i className="fa fa-trash" data-tag={item.pid} onClick={this.deleteProcess}></i>,
        })
      ))
      this.setState({
        rowresult: arr
      });
      console.log(this.state.rowresult);
    }).catch(error => {
      console.log(error)
    });
  }

  render() {
    let datatable = {
      columns: [
        {
          label: 'Policy Name',
          field: 'name',
          attributes: {
            'aria-controls': 'DataTable',
            'aria-label': 'Name',
          },
        },
        {
          label: 'Policy Description',
          field: 'description',
        },
        {
          label: 'Punch Type to Round',
          field: 'punch',
        },
        {
          label: 'How to Round',
          field: 'round',
        },
        {
          label: 'Round Interval',
          field: 'interval',
        },
        {
          label: 'Edit',
          field: 'edit',
          sort: 'disabled',
        },
        {
          label: 'Delete',
          field: 'delete',
          sort: 'disabled',
        },
      ],
      rows: this.state.rowresult,
    }
    return (
      <div>
        <div className="col-12 row mr-0 pr-0 pl-0 ml-0 mb-3">
          <div className="text-left float-left col-lg-9 col-md-9 col-xl-9 col-sm-12 pl-0">
            <h6 className="mb-0">Time Clock Rounding Policies</h6>
            <span className="text-muted">These Policies affect how time is rounded when punching in or out </span>
          </div>
          <button onClick={() => this.setState({ editdetails: [], show: true })} className="h-35 button resend-btn py-2 px-4 col-lg-3 col-xl-3 col-md-3 col-sm-4 m-0">
            <i className="fa fa-plus pr-2"></i>Add New Rounding Policy</button>
        </div>
        <MDBDataTable
          className="timesheets"
          bordered hover info={false} responsive={true} displayEntries={false} noBottomColumns entries={10} data={datatable} searching={false} />
        <Modal scrollable={true} size="lg" onHide={() => this.setState({ show: false })}
          show={this.state.show}>
          <Modal.Header closeButton>
            <Modal.Title className="h6" id="contained-modal-title-vcenter">
              Add Policies
        </Modal.Title>
          </Modal.Header>
          <Modal.Body className="show-grid small_font px-5">
            <div className="text-danger col-12 text-center">{this.state.error_message}</div>
            <div className="form-group">
              <label for="exampleInputEmail1">Policy Name*</label>
              <input type="text" value={this.state.editdetails.name} name="name" onChange={this.handleFormChange} className={(this.state.errors["name"] ? this.state.errors["name"] : 'form-control')} placeholder="Rounding Policy Name" />
            </div>
            <div className="form-group">
              <label for="exampleInputEmail1">Policy Description</label>
              <textarea value={this.state.editdetails.description} onChange={this.handleFormChange} name="description" className={(this.state.errors["description"] ? this.state.errors["description"] : 'form-control')} placeholder="Rounding Policy Description"></textarea>
            </div>
            <div className="form-group row">
              <div className="col-xl-4 col-lg-4 col-md-4 col-sm-12">
                <label>Punch type to Round</label>
                <select placeholder="Select" value={this.state.editdetails.punchType} onChange={this.handleFormChange} className="form-control" name="punchType">
                  {/* <option value='1'>Punch In</option>
                  <option value='2'>Punch Out</option> */}
                  <option value='3'>Both Punch In and Out</option>
                </select>
              </div>
              <div className="col-xl-4 col-lg-4 col-md-4 col-sm-12">
                <label>How to Round</label>
                <select placeholder="Select" value={this.state.editdetails.roundType} onChange={this.handleFormChange} className="form-control" name="roundType">
                  {/* <option value='1'>Round Up</option>
                  <option value='2'>Round Down</option> */}
                  <option value='3'>Split Round</option>
                </select>
              </div>
              <div className="col-xl-4 col-lg-4 col-md-4 col-sm-12">
                <label>Round Interval</label>
                <select placeholder="Select" value={this.state.editdetails.roundInterval} onChange={this.handleFormChange} className="form-control" name="roundInterval">
                  <option value='15'>To Nearest 15 Min</option>
                  <option value='6'>To Nearest 6 Min</option>
                </select>
              </div>
            </div>
          </Modal.Body>
          <Modal.Footer>
            <ul className="row form-group mr-0 mt-4 pr-0 list-inline pull-right">
              <li><button onClick={() => this.setState({ show: false })} className="button cancel-btn py-2 px-4 m-0 mr-2">Cancel</button></li>
              <li><button onClick={this.addRecord} className="button resend-btn py-2 px-4 m-0">Save</button></li>
            </ul>
          </Modal.Footer>
        </Modal>
        <Modal scrollable={true} size="lg" onHide={() => this.setState({ editshow: false })}
          show={this.state.editshow}>
          <Modal.Header closeButton>
            <Modal.Title className="h6" id="contained-modal-title-vcenter">
              Edit Rounding Policies
        </Modal.Title>
          </Modal.Header>
          <Modal.Body className="show-grid small_font px-5">
            <div className="text-danger col-12 text-center">{this.state.error_message}</div>
            <div className="form-group">
              <label for="exampleInputEmail1">Policy Name*</label>
              <input type="text" value={this.state.editdetails.name} name="name" onChange={this.handleFormChange} className={(this.state.errors["name"] ? this.state.errors["name"] : 'form-control')} placeholder="Rounding Policy Name" />
            </div>
            <div className="form-group">
              <label for="exampleInputEmail1">Policy Description</label>
              <textarea value={this.state.editdetails.description} name="description" onChange={this.handleFormChange} className={(this.state.errors["description"] ? this.state.errors["description"] : 'form-control')} placeholder="Rounding Policy Description"></textarea>
            </div>
            <div className="form-group row">
              <div className="col-xl-4 col-lg-4 col-md-4 col-sm-12">
                <label>Punch type to Round</label>
                <select placeholder="Select" value={this.state.editdetails.punchType} onChange={this.handleFormChange} className="form-control" name="punchType">
                  {/* <option value='1'>Punch In</option>
                  <option value='2'>Punch Out</option> */}
                  <option value='3'>Both Punch In and Out</option>
                </select>
              </div>
              <div className="col-xl-4 col-lg-4 col-md-4 col-sm-12">
                <label>How to Round</label>
                <select placeholder="Select" value={this.state.editdetails.roundType} onChange={this.handleFormChange} className="form-control" name="roundType">
                  {/* <option value='1'>Round Up</option>
                  <option value='2'>Round Down</option> */}
                  <option value='3'>Split Round</option>
                </select>
              </div>
              <div className="col-xl-4 col-lg-4 col-md-4 col-sm-12">
                <label>Round Interval</label>
                <select placeholder="Select" value={this.state.editdetails.roundInterval} onChange={this.handleFormChange} className="form-control" name="roundInterval">
                  <option value='15'>To Nearest 15 Min</option>
                  <option value='6'>To Nearest 6 Min</option>
                </select>
              </div>
            </div>
          </Modal.Body>
          <Modal.Footer>
            <ul className="row form-group mr-0 mt-4 pr-0 list-inline pull-right">
              <li><button onClick={() => this.setState({ editshow: false })} className="button cancel-btn py-2 px-4 m-0 mr-2">Cancel</button></li>
              <li><button data-tag={this.state.editdetails.pid} onClick={this.editRecord} className="button resend-btn py-2 px-4 m-0">Save Changes</button></li>
            </ul>
          </Modal.Footer>
        </Modal>
      </div>
    );
  }
}
export default LoadPoliciesTable;