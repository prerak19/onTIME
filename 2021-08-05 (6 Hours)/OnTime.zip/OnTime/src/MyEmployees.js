import React from 'react';
import { Container, Tab, Tabs } from 'react-bootstrap';
import 'bootstrap/dist/css/bootstrap.min.css';
import './App.css';
import TimesheetPreview from './components/TimesheetPreview';
import TimesheetReciept from './components/timesheetRecieptReport';
import moment from 'moment';
import LoadMyTeamTable from './components/LoadMyTeamTable';
import AboutEmployees from './components/AboutEmployees';
import ManagerReportingSection from './components/ManagerReportingSection';

class MyTeam extends React.Component {

  constructor(props) {
    super(props);
    this.state = {
      startDate: moment().day(0).format('YYYY-MM-DD'),
      endDate: moment().day(6).format('YYYY-MM-DD'),
      activityTimeArr: [],
      summaryArr: [],
      activeTab: 'employeeTime',
      disFilterArr: [],
      originalArr: [],
      showreport: null,
      companyDetails: {},
    };
  }

  setProps = (props) => {
    const { showreport, summaryArr, originalArr, detailsArr, orgImage, activityTimeArr, disFilterArr, startDate, endDate, companyDetails } = props;
    if (showreport === 'original') {
      this.setState({
        showreport, originalArr, startDate, endDate, companyDetails, orgImage
      });
    } else {
      this.setState({
        showreport, summaryArr, detailsArr, activityTimeArr,
        disFilterArr, startDate, endDate, companyDetails, orgImage
      });
    }

  }

  render() {
    const { showreport, startDate, activeTab, endDate, activityTimeArr, summaryArr, detailsArr, disFilterArr, orgImage, companyDetails, originalArr } = this.state;
    return (
      <div className="App">
        <Container>
          <div className="contentwrapper pt-1 pb-5">
            <Tabs defaultActiveKey="employeeTime" activeKey={activeTab} className="customTabs" onSelect={(tab) => this.setState({ activeTab: tab })}>
              <Tab eventKey="employeeTime" title={<span className="customTabsTitle">Manage Employee Time</span>}>
                {activeTab === 'employeeTime' && <LoadMyTeamTable />}
              </Tab>
              <Tab eventKey="runReports" title={<span className="customTabsTitle">Run Reports</span>}>
                {activeTab === 'runReports' && <ManagerReportingSection setProps={this.setProps} />}
              </Tab>
              <Tab eventKey="aboutEmp" title={<span className="customTabsTitle">About Employees</span>}>
                {activeTab === 'aboutEmp' && <AboutEmployees setProps={this.setProps} />}
              </Tab>
            </Tabs>
          </div>
        </Container>
        {showreport === 'timesheet' && <TimesheetPreview orgImage={orgImage} companyDetails={companyDetails} activityTimeArr={activityTimeArr} summaryArr={summaryArr} detailsArr={detailsArr} startDate={startDate} endDate={endDate} disFilterArr={disFilterArr} />}
        {showreport === 'original' && <TimesheetReciept orgImage={orgImage} companyDetails={companyDetails} startDate={startDate} endDate={endDate} originalArr={originalArr} />}
      </div>
    );
  }
}

export default MyTeam;
