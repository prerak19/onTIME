import React from 'react';
import DatePicker from "react-datepicker";
import {
  Modal,
  Nav,
  Row,
  Col,
  Popover,
  OverlayTrigger
} from "react-bootstrap";
import { MDBBtn } from 'mdbreact';
import { NavLink } from "react-router-dom";
import Timer from 'react-compound-timer';
import { get, isEmpty, isEqual, isNumber } from 'lodash';
import moment from 'moment';
import { apiGet, apiPut } from './Api.js';
import * as GeneralHelper from './helpers/GeneralHelper';

// Stylesheets
import 'bootstrap/dist/css/bootstrap.min.css';
import './App.css';
import "react-datepicker/dist/react-datepicker.css";

class MyOwnTimesheet extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      startTime: '',
      weeklyDate: null,
      clockin: true,
      curtime: '00:00:00 PM Apr 29, 2020',
      signshow: false,
      msignshow: false,
      weekStartDate: '',
      weekEndDate: '',
      timesheetdetails: {},
      daysOfWeek: [],
      punchOutComments: '',
      activityID: '',
    };
  }

  setPunchOutComments = (evt) => this.setState({ punchOutComments: evt.target.value })
  updateHourForDay = () => {
    const request = {
      method: 'timesheets/hour',
      params: {
        timesheetID: get(this.state.timesheetdetails, 'tid', null),
        activityID: this.state.activityID,
        day: '',
        hours: get(this.state, 'startTime', null),
        reason: get(this.state, 'punchOutComments', null),
        madeBy: get(this.state.timesheetdetails, 'uid', null)
      }
    }
    apiPut(request, true).then((response) => {
      console.log('update-hour', response.data);
    }).catch((err) => console.log(err))
  }

  componentDidMount() {
    const now = new Date();
    now.setDate(now.getDate() - (now.getDay() + 6) % 7);
    const sunday = new Date(now.getFullYear(), now.getMonth(), now.getDate() - 1);
    const today = new Date();
    today.setDate(today.getDate() + (0 - 1 - today.getDay() + 7) % 7 + 1);
    const nextSunday = new Date(today.getFullYear(), today.getMonth(), today.getDate());
    const weekStart = moment(sunday).format('YYYY-MM-DD');
    this.setState({
      weeklyDate: sunday,
      startWeekDate: weekStart,
      weekEndDate: moment(nextSunday).format('YYYY-MM-DD'),
    }, () => {
      this.getTimesheetRecord(weekStart);
    })
  }

  getTimesheetRecord = (startDate) => {
    const requestDetails = { 
      method: `timesheets/${get(localStorage, 'userid', '')}/${startDate}`,
      params: {}
    };
    apiGet(requestDetails, true).then((response) => {
      // const sunday = new Date(get(response.data, 'startDate'));
      const startDay = moment.utc(startDate);
      const today = new Date(startDay);
      today.setDate(today.getDate() + (0 - 1 - today.getDay() + 7) % 7 + 1);
      const nextSunday = new Date(today.getFullYear(), today.getMonth(), today.getDate());
      const daysOfWeekFromStart = [
        {
          day: GeneralHelper.DAYS_OF_WEEK[startDay.day()],
          date: startDay.format('MMM D')
        }
      ];
      for (let i = 1; i <= 6; ++i) {
        const newDay = startDay;
        newDay.add(1, 'day');
        daysOfWeekFromStart.push({
          day: GeneralHelper.DAYS_OF_WEEK[newDay.day()],
          date: newDay.format('MMM D')
        })
      }      
      this.setState({
        startWeekDate: moment.utc(new Date(get(response, 'data.startDate'))).format('YYYY-MM-DD'),
        weekEndDate: moment.utc(nextSunday).format('YYYY-MM-DD'),
        timesheetdetails: response.data,
        daysOfWeek: daysOfWeekFromStart
      }, () => {
        get(this.state.timesheetdetails, 'activityTime', []).map((activity, index) => {
          if (index === 0) {
            this.setState({
              activityID: get(activity, 'activityID', '')
            })
          }
        })
      });
    }).catch(error => {
      console.log(error);
    });
  }
  
  formatDate = (date) => moment.utc(new Date(date)).format("MMMM D, YYYY")

  handleChange = (date) => {
    this.setState({ startTime: date })
  }

  handleWeekChange = (date) => {
    const formatDate = moment(new Date(date)).format('YYYY-MM-DD')
    const request = {
      method: `timesheets/${get(this.state.timesheetdetails, 'uid')}/${formatDate}`,
      params: {}
    };
    const today = new Date(formatDate);
    today.setDate(today.getDate() + (0 - 1 - today.getDay() + 7) % 7 + 1);
    const nextSunday = new Date(today.getFullYear(), today.getMonth(), today.getDate());
    apiGet(request, true).then((response) => {
      if (isEqual(response.status, 200)) {
        this.setState({
          weeklyDate: date,
          startWeekDate: formatDate,
          weekEndDate: moment.utc(nextSunday).format('YYYY-MM-DD'),
          timesheetdetails: !isEmpty(response.data) ? response.data : {}
        });
      }
    }).catch((err) => {
      console.log(err);
    })
  }

  getTime = () => {
    var now = new Date();
    var hour = now.getHours();
    var minute = now.getMinutes();
    var second = now.getSeconds();
    var ap = "AM";
    if (hour > 11) { ap = "PM"; }
    if (hour > 12) { hour = hour - 12; }
    if (hour == 0) { hour = 12; }
    if (hour < 10) { hour = "0" + hour; }
    if (minute < 10) { minute = "0" + minute; }
    if (second < 10) { second = "0" + second; }
    var timeString = hour + ':' + minute + ':' + second + " " + ap;
    var strArray = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
    var d = now.getDate();
    var m = strArray[now.getMonth()];
    var y = now.getFullYear();
    var ts = m + '' + (d <= 9 ? '0' + d : d) + ', ' + y;
    if (!this.state.clockin) {
      this.setState({
        curtime: timeString + ' ' + ts
      })
    }
    this.startClockin(moment().format('YYYY-MM-DD HH:MM:ss'))
  }

  isWeekday = (date) => {
    const day = date.getDay()
    return day === 0
  }

  handlePressStartButton = () => {
    this.setState({ clockin: false });
    console.log('test');
  }

  startClockin = (timeStamp) => {
    const now = new Date();
    const request = {
      method: 'timesheets/punches',
      params: {
        timesheetID: get(this.state.timesheetdetails, 'tid', null),
        activityID: this.state.activityID,
        day:  now.getDay(),
        userID: get(localStorage, 'userid', ''),
        clockAt: timeStamp,
        type: !this.state.clockin ? '1' : '2',
        duration: '',
        madeBy: get(this.state.timesheetdetails, 'uid', null)
      }
    }
    apiPut(request, true).then((response) => {
      console.log('update-hour', response.data);
    }).catch((err) => console.log(err))
  }

  renderOptions = () => {
    const totalHours = (activity) => {
      const { monHour, tueHour, wedHour, thuHour, friHour, satHour, sunHour } = activity
      return monHour + tueHour + wedHour + thuHour + friHour + satHour + sunHour
    }
    return get(this.state.timesheetdetails, 'activityTime', []).map((activity) => (
        <option value={activity.activityID} key={activity.activityID}>{activity.activityName.toUpperCase()} ({totalHours(activity)})</option>
    ))
  }

  render() {
    const popoverComponent = (
      <Popover
        id={`popover-positioned-top`}
        className="timesheetpopover"
      >
        <Popover.Title as="h6" className="background-green1 text-white">
          <span className="small_font">
            {this.state.timesheetdetails.userFirstname}, {this.state.timesheetdetails.userLastname}
          </span>
          {/* <span className="small_font">Sun Apr 15, 2016</span> */}
          <span
            aria-label="Close"
            className="float-right icon-button cursor-pointer"
            onClick={() => document.body.click()}
          >
            x
        </span>
        </Popover.Title>
        <Popover.Content>
          <div className="row px-3">
            <label className="col-xl-3 col-lg-3 col-md-3 col-sm-10 p-0 permission-label">Type : </label>
            <label className="col-xl-6 col-lg-6 col-md-6 col-sm-10 p-0 permission-label">Punch Out</label>
          </div>
          <div className="row px-3">
            <label className="col-xl-3 col-lg-3 col-md-3 col-sm-10 p-0 permission-label">Time : </label>
            <div className="col-xl-7 col-lg-7 col-md-7 col-sm-10 p-0">
              <input
                onChange={(event) => this.handleChange(event.target.value)}
                className="form-control"
                type="number"
                max={24}
                min={1}
                step={0.1}
                inputMode="text"
              />
            </div>
            <i className="col-xl-1 col-lg-1 col-md-1 mt-auto mb-auto fa fa-clock-o text-danger"></i>
          </div>
          <div className="row px-3">
            <label className="col-xl-3 col-lg-3 col-md-3 col-sm-10 p-0 permission-label"></label>
          </div>
          <p className="xs_font mt-2 text-center">
            If there is support document, please<span className="link-style text-decoration-underline">upload</span>
          </p>
          <div class="row mt-2">
            <div className="col-6">
              {/* <button className="button resend-btn background-red px-2 float-left">
              Delete Punch
            </button> */}
            </div>
            <div className="col-6">
              <button
                className="button resend-btn float-right px-4"
                onClick={this.updateHourForDay}
              >
                Save
            </button>
            </div>
          </div>
        </Popover.Content>
      </Popover>
    );

    return (
      <div className="App">
        <div className="content">
          <div className="contentwrapper pb-5 mb-5">
            <div className="p-3 mb-3 small_font bg-amber border-0">
              <Row>
                <Col lg="8" md="8" sm="12">
                  <div className="">
                    <span className="pr-3 font-weight-bold font-16">
                      {get(this.state.timesheetdetails, 'userFirstname', '')}, {get(this.state.timesheetdetails, 'userLastname', '')}
                    </span>
                    {/* <span className="pr-3 chart-text">98.9%</span>
                  <span className="pr-3 small-font">Attendance Rate</span> */}
                  </div>
                </Col>

                <Col lg="2" md="2" sm="6" className="text-right">
                  <label className="act-text">Week Started</label>
                </Col>
                <Col lg="2" md="2" sm="12">
                  <div className="form-group row mb-0 inner-addon right-addon mr-2">
                    <i class="fa fa-calendar"></i>
                    <DatePicker
                      selected={this.state.weekStartDate}
                      onChange={this.handleWeekChange}
                      name="startDate"
                      className="form-control"
                      value={this.state.weekStartDate}
                      filterDate={this.isWeekday}
                      dateFormat="yyyy-MM-dd"
                      placeholderText="YYYY-MM-DD"
                    />
                  </div>
                </Col>
              </Row>
            </div>
            <Row>
              <Col lg="8" md="8" sm="12">
                <table border='1' className="col-12 text-center text-black">
                  <thead>
                    <tr>
                      <th colSpan='3' className="blue-head">
                        {`${get(this.state.timesheetdetails, 'userFirstname', '')} ${get(this.state.timesheetdetails, 'userLastname', '')}'s Accumulated Time`}
                      </th>
                    </tr>
                  </thead>
                  <tbody>
                    <tr>
                      <th style={{ width: '50%' }}>{`Week (${this.formatDate(this.state.startWeekDate)} - ${this.formatDate(this.state.weekEndDate)})`}</th>
                      <th style={{ width: '50%' }}>{`Current Bi-Week Period (${this.formatDate(moment.utc(new Date(this.state.startWeekDate)).subtract(7, 'days'))} - ${this.formatDate(this.state.weekEndDate)})`}</th>
                    </tr>
                    <tr className="blue-num">
                      <td className="font-weight-bold">{'-'}</td>
                      <td className="font-weight-bold">{'-'}</td>
                    </tr>
                  </tbody>
                </table>
              </Col>
              <Col lg="4" md="4" sm="12" className="row my-auto">
                <select
                  onChange={
                    (event) =>  this.setState({ activityID: event.target.value })
                  }
                  placeholder="Select"
                  className="col-lg-7 col-md-7 col-sm-6 form-control float-left"
                  name="state"
                >
                  {this.renderOptions()}
                </select>
                <Timer
                  className="col-12"
                  initialTime={0}
                  startImmediately={false}
                >
                  {({ start, resume, pause, stop, reset, timerState }) => (
                    <React.Fragment>
                      <MDBBtn
                        size="md"
                        className="col-lg-4 col-md-4 col-sm-6 ml-2 btn-success float-right"
                        onClick={() => {
                          start();
                          this.setState({ clockin: false }, () => this.getTime() );
                        }}
                        style={this.state.clockin === true ? {} : { display: 'none' }}
                      >
                        Clock In
                  </MDBBtn>
                      <MDBBtn
                        size="md"
                        className="col-lg-4 col-md-4 col-sm-6 ml-2 btn-danger float-right"
                        onClick={() => this.setState({ clockin: true }, () => this.getTime() )}
                        style={this.state.clockin === false ? {} : { display: 'none' }}
                      >
                        Clock Out
                  </MDBBtn>
                      <div
                        className="small_font text-success col-12 pl-0 mt-2"
                        style={this.state.clockin === false ? {} : { display: 'none' }}
                      >
                        <Timer.Hours /> : <Timer.Minutes /> : <Timer.Seconds /> <span className="text-right float-right">Start Time : {this.state.curtime}</span>
                      </div>
                    </React.Fragment>
                  )}
                </Timer>
              </Col>
            </Row>
            <div className="mt-3">
              <table border='1' className="col-12 text-black">
                <thead>
                  <tr>
                    <th colSpan='17' className="blue-head py-2">
                      <Row>
                        <Col lg="6" md="6" sm="12">
                          <div className="pl-2  float-left">
                            <span className="font-12">WEEKLY TIME SHEET</span>
                            <span className="small-font pl-2">
                              {`${this.formatDate(this.state.startWeekDate)} - ${this.formatDate(this.state.weekEndDate)}`}
                            </span>
                          </div>
                        </Col>
                        <Col lg="6" md="6" sm="12">
                          <div className="pr-2 float-right">
                            <span className="pr-2 font-12">
                              {GeneralHelper.timesheet_status_codes[`${get(this.state.timesheetdetails, 'status', '')}`]}
                            </span>
                            <span className="font-small">
                              {`Due on : ${this.formatDate(moment.utc(new Date(this.state.weekEndDate)).subtract(1, 'day'))}`}
                            </span>
                            <span className="px-1">|</span>
                            <i className="fa fa-print px-1"></i>
                            <i className="fa fa-file-pdf-o px-1"></i>
                          </div>
                        </Col>
                      </Row>
                    </th>
                  </tr>
                </thead>
                <tbody className="text-center">
                  <tr>
                    <td colSpan='2' className="font-weight-bold text-right pr-1">NAME:</td>
                    <td colSpan='12' className="pl-1 text-left">
                      {get(this.state.timesheetdetails, 'userFirstname', '')}, {get(this.state.timesheetdetails, 'userLastname', '')}
                    </td>
                  </tr>
                  <tr>
                    <td colSpan='2' className="font-weight-bold text-right pr-1">GROUP:</td>
                    <td colSpan='12' className="pl-1 text-left">{'-'}</td>
                  </tr>
                  <tr className="text-center font-small p-1 bg-lite-gray">
                    <th colSpan='2'></th>
                    {get(this.state, 'daysOfWeek', []).map((day, index) => (
                      <th key={`${day.day}${index}`}>{day.day}<br />{day.date}</th>
                    ))}
                    <th>Total<br />Hours</th>
                    <th>Initial</th>
                  </tr>
                  {
                    get(this.state.timesheetdetails, 'activityTime', []).map((activity) => (
                      <React.Fragment>
                        {get(activity, 'clockinouts', []).map((clock, index) => (
                          <tr key={activity.activityID}>
                            {index === 0 && (<td colSpan='1' rowSpan={get(activity, 'clockinouts').length}>{activity.activityName.toUpperCase()}</td>)}
                            <td colSpan='1'>{GeneralHelper.ClockInOuts[clock.type]}</td>
                            {
                              get(this.state, 'daysOfWeek', []).map((day, index) => (
                                <td colSpan='1' key={`${day}${index}`}>
                                  {isEqual(day.day, GeneralHelper.DAYS_OF_WEEK[moment.utc(clock.clockAt).day()]) ? moment.utc(clock.clockAt).format('h:mm A') : ''}
                                </td>
                              ))
                            }
                            <td colSpan='1'></td>
                            {index === 0 && (
                              <td colSpan='1' rowSpan={get(activity, 'clockinouts').length}></td>
                            )}
                          </tr>
                        ))}
                        <tr className="time-td blue-text bg-lite-gray">
                          <td colSpan='2'>{`${activity.activityName.toUpperCase()} HOURS`}</td>
                          {
                            Object.values(GeneralHelper.DAYS_OF_WEEK).map((day, index) => (
                              <td colSpan='1' key={`${day}${index}`} className={`text-blue ${activity[`${day.toLowerCase()}Hour`] > 0 && activity.enabled && activity.timingMethod === 2 ? 'cursor-pointer' : ''}`}>
                                {
                                  activity.enabled && activity.timingMethod === 2 ? (
                                    <OverlayTrigger trigger="click" key='top' placement='top' rootClose={true} overlay={popoverComponent}>
                                      <span variant="secondary">{activity[`${day.toLowerCase()}Hour`] > 0 ? activity[`${day.toLowerCase()}Hour`] : ''}</span>
                                    </OverlayTrigger>
                                  ) : (
                                      <span variant="secondary">{activity[`${day.toLowerCase()}Hour`] > 0 ? activity[`${day.toLowerCase()}Hour`] : ''}</span>
                                    )
                                }
                              </td>
                            ))
                          }
                          <td colSpan='1'>{`${Object.values(GeneralHelper.DAYS_OF_WEEK).map((day) => activity[`${day.toLowerCase()}Hour`]).reduce((a, b) => a + b, 0)}`}</td>
                          <td colSpan='1' className="vertical-align-bottom">
                            {activity.approvedBy === 0 && (<div className="float-right">
                              <div className="guideList" onClick={this.handleActivityApprovalAction}>
                                <div className="active cursor-pointer">
                                  <span className="activePointer"></span>
                                  <span className="pl-4">SIGN</span>
                                </div>
                              </div>
                            </div>)}
                          </td>
                        </tr>
                      </React.Fragment>
                    ))
                  }
                  <tr className="time-td blue-text bg-lite-gray">
                    <td colSpan='2'>TOTAL</td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td className="text-blue">
                      <OverlayTrigger trigger="click" key='top' placement='top' rootClose={true} overlay={popoverComponent}>
                        <span variant="secondary">
                          {
                            get(this.state.timesheetdetails, 'activityTime', []).map((activity) => (
                              Object.values(GeneralHelper.DAYS_OF_WEEK).map((day) => activity[`${day.toLowerCase()}Hour`]).reduce((a, b) => a + b, 0)
                            )).reduce((a, b) => a + b, 0)
                          }
                        </span>
                      </OverlayTrigger>
                    </td>
                    <td></td>
                  </tr>
                </tbody>
                <thead>
                  <tr>
                    <th colSpan='14' className="blue-head text-center py-2">
                      Timesheet Changes
                    </th>
                  </tr>
                </thead>
                <tr>
                  <th colSpan='14' className="py-2">
                    {
                      get(this.state.timesheetdetails, 'activityTime', []).map((activity) => {
                        if (!isEmpty(activity.changes)) {
                          return activity.changes.map((timesheetChanges) => (
                            <span key={timesheetChanges.activityID} className="pl-1">
                              {timesheetChanges.reason}
                            </span>)
                          )
                        }
                      })
                    }
                  </th>
                </tr>
                <tr>
                  <th colSpan='14' className="py-2"></th>
                </tr>
                <tr>
                  <th colSpan='4' className="pt-5">
                    <Row>
                      <Col lg="6" md="6" sm="6" className="mt-3">
                        <span className="pl-1 font-9">Employee Signature:</span>
                      </Col>
                      <Col lg="6" md="6" sm="6">
                        <div className="float-right">
                          <div className="guideList" onClick={date => this.setState({ signshow: true })}>
                            <div className="active"><span className="activePointer"></span>
                              <span className="pl-4">SIGN</span></div>
                          </div>
                        </div>
                      </Col>
                    </Row>
                  </th>
                  <th colSpan='2' className="pt-5">
                    <Row>
                      <Col lg="6" md="6" sm="6" className="mt-3">
                        <span className="pl-1 font-9">Date:</span>
                      </Col>
                      <Col lg="6" md="6" sm="6">
                      </Col>
                    </Row>
                  </th>
                  <th colSpan='4' className="pt-5">
                    <Row>
                      <Col lg="6" md="6" sm="6" className="mt-3">
                        <span className="pl-1 font-9">Approval Signature:</span>
                      </Col>
                      <Col lg="6" md="6" sm="6">

                      </Col>
                    </Row>
                  </th>
                  <th colSpan='3' className="pt-5">
                    <Row>
                      <Col lg="6" md="6" sm="6" className="mt-3">
                        <span className="pl-1 font-9">Date:</span>
                      </Col>
                      <Col lg="6" md="6" sm="6">
                      </Col>
                    </Row>
                  </th>
                </tr>
              </table>
            </div>
          </div>
        </div>

        {/** Modal to submit timesheet */}
        <Modal
          scrollable={true}
          size="md"
          onHide={() => this.setState({ signshow: false })}
          show={this.state.signshow}
        >
          <Modal.Header closeButton className="h6 background-green1">
            <Modal.Title className="h6 text-white small_font" id="contained-modal-title-vcenter">
              Timesheet Submission Confirmation by Joe Allen 4/29/2016
          </Modal.Title>
          </Modal.Header>
          <Modal.Body className="show-grid small_font px-5">
            <p className="xs_font text-dark text-center">
              Please enter your name and password to electronically sign and submit your timesheet. ABC, Inc. requires that you certify your timesheet by submitting using this your electronic signature.
          </p>
            <p className="small_font font-weight-bold text-center">
              Sun Apr 24, 2016 - Mon Apr 25, 2016
          </p>
            <div className="form-group row">
              <div class="col-lg-6 col-md-6 col-xl-6 col-sm-12">
                <label for="exampleInputEmail1">Login Name :</label>
              </div>
              <div class="col-lg-6 col-md-6 col-xl-6 col-sm-12">
                <input type="text" className="form-control" placeholder="" />
              </div>
            </div>
            <div className="form-group row">
              <div class="col-lg-6 col-md-6 col-xl-6 col-sm-12">
                <label for="exampleInputEmail1">Password :</label>
              </div>
              <div class="col-lg-6 col-md-6 col-xl-6 col-sm-12">
                <input type="password" className="form-control" placeholder="" />
              </div>
            </div>
            <p className="small_font text-center">
              Sun Apr 24, 2016 - Sat Apr 30, 2016
          </p>
            <p className="small_font text-center">
              <b>Allen, Joe - Total Hours 40.00</b>
            </p>
            <p className="xs_font text-center">
              I Certify that all the information in my timesheet is accurate and true.
          </p>
          </Modal.Body>
          <Modal.Footer>
            <div class="col-12 row mt-2">
              <div className="col-6">
                <button
                  onClick={() => this.setState({ signshow: false })}
                  className="button resend-btn background-red px-2 float-left"
                >
                  No Cancel
              </button>
              </div>
              <div className="col-6">
                <Nav.Link as={NavLink} to="/TimesheetSubmitPreview" className="p-0">
                  <button className="button resend-btn float-right px-4">
                    Yes, Sign & Submit
                </button>
                </Nav.Link>
              </div>
            </div>
          </Modal.Footer>
        </Modal>
        {/** Modal to display activity approval popup */}
        <Modal
          scrollable={true}
          size="md"
          onHide={() => this.setState({ msignshow: false })}
          show={this.state.msignshow}
        >
          <Modal.Header closeButton className="h6 background-green1">
            <Modal.Title className="h6 text-white small_font" id="contained-modal-title-vcenter">
              Timesheet Approval Confirmation
          </Modal.Title>
          </Modal.Header>
          <Modal.Body className="show-grid small_font px-5">
            <p className="xs_font text-dark text-center">
              Please add comment to electronically sign and approve this timesheet.
          </p>
            <p className="small_font font-weight-bold text-center">
              Sun Apr 24, 2016 - Mon Apr 25, 2016
          </p>
            <div className="form-group row">
              <div class="col-lg-12 col-md-12 col-xl-12 col-sm-12 text-center">
                <label for="exampleInputEmail1">Comment :</label>
                <textarea className="form-control" />
              </div>
            </div>
            <p className="small_font text-center">
              <b>Allen, Joe - Total Hours 40.00</b>
            </p>
            <p className="xs_font text-center">
              I Certify that all the information in this timesheet is accurate and true.
            </p>
          </Modal.Body>
          <Modal.Footer>
            <div class="col-12 row mt-2">
              <div className="col-6">
                <button
                  onClick={() => this.setState({ msignshow: false })}
                  className="button resend-btn background-red px-2 float-left"
                >
                  No, Cancel
              </button>
              </div>
              <div className="col-6">
                <button
                  onClick={() => this.setState({ msignshow: false })}
                  className="button resend-btn float-right px-4"
                >
                  Yes, Sign & Submit
              </button>
              </div>
            </div>
          </Modal.Footer>
        </Modal>
      </div>
    )
  }
}

export default MyOwnTimesheet;
