import React from 'react';
import { Row, Col, OverlayTrigger, Popover } from "react-bootstrap";
import { find, get, isEqual } from 'lodash';
import moment from 'moment';
import html2pdf from "html2pdf.js";
import { DAYS_OF_WEEK, timesheet_status_codes, ClockInOuts, toNumber } from '../helpers/GeneralHelper';

// Stylesheets
import 'bootstrap/dist/css/bootstrap.min.css';
import '../App.css';
import "react-datepicker/dist/react-datepicker.css";

class TimesheetReciept extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      printData: false,
      originalArr: this.props.originalArr,
      numIndex: '',
    };
  }

  formatDate = (date) => moment(date).format("MMMM D, YYYY")

  savePDF = async (e) => {
    e.preventDefault();
    this.setState({ printData: true });
    let obj = {
      unit: 'cm', format: 'ledger', orientation: 'landscape',
    }
    setTimeout(() => {
      var element = document.getElementById('originalReport');
      var opt = {
        margin: [0, 2, 1, 2],
        filename: 'timesheetReciepts.pdf',
        pagebreak: { before: '.beforeClass', after: ['#after1', '#after2'], avoid: 'img' },
        html2canvas: { y: 0, scrollY: 0, useCORS: true },
        jsPDF: obj
      };
      html2pdf().set(opt).from(element).save();
    }, 1000)
    setTimeout(() => { this.setState({ printData: false }) }, 2000);
  }

  changeReport = (event, name) => {
    const { originalArr } = this.props;
    let value = event.target && event.target.value;
    this.setState({ [name]: value }, () => {
      if (value !== 'All') {
        this.setState({
          originalArr: originalArr.filter((x) => {
            let val = `${x.userLastname} ${x.userFirstname} - (${this.formatDate(x.startDate)})`;
            return val === value;
          })
        });
      } else {
        this.setState({ originalArr });
      }
    });
  }

  render() {
    const { printData, originalArr, numIndex } = this.state;
    const { startDate, endDate, orgImage, companyDetails } = this.props;
    return (
      <div className="pb-5 mb-5 container">
        <div className="buttonLine">
          <h6 className="text-center">Report Preview</h6>
          <div className="form-group row mx-0">
            <label className="col-1 px-0 mt-2">Filter Report</label>
            <select className="col-3 form-control ml-0"
              onChange={(event) => this.changeReport(event, 'numIndex')}
              value={numIndex}>
              <option value="All">All</option>
              {this.props.originalArr && this.props.originalArr.map((act, actKey) => {
                let val = `${act.userLastname} ${act.userFirstname} - (${this.formatDate(act.startDate)})`;
                return <option value={val} key={actKey}>{val}</option>
              })}
            </select>
            <div className="col-8 px-0">
              <button onClick={(e) => this.savePDF(e)} className="mt-0 button resend-btn ml-2 float-right">Save As PDF</button>
            </div>
          </div>
        </div>
        <div id="originalReport" className={!printData ? "overflow-auto reportHeight w-100" : "w-100"} >
          {originalArr && originalArr.map((org, key) => {
            return <div key={key} className={`mr-3 mb-5 mt-3 ${key !== 0 && 'beforeClass'}`}>
              <table className="w-100 text-black">
                <thead>
                  {key === 0 && <>
                    <tr>
                      <th colSpan="2" rowSpan="3" className="border-0">
                        {orgImage && <img src={orgImage} height="100px" alt="orgImage" />}
                      </th>
                      <th className="border-white border-right-0 bg-white text-black" colSpan='6'>
                        <h6 className="mb-0">{companyDetails && companyDetails.name} ORIGINAL TIMESHEET RECEIPT</h6>
                      </th>
                      <th className="border-white border-right-0 bg-white text-black" colSpan='2'></th>
                    </tr>
                    <tr>
                      <th className="border border-white" colSpan={6}>
                        {companyDetails ? <h6 className="mb-0">
                          {companyDetails.address1 ? `${companyDetails.address1},` : ''}
                          {companyDetails.address2 ? ` ${companyDetails.address2},` : ''}
                          {companyDetails.city ? ` ${companyDetails.city},` : ''}
                          {companyDetails.zip ? ` ${companyDetails.zip},` : ''}
                          {companyDetails.state ? ` ${companyDetails.state},` : ''}
                        </h6> : <h6>&nbsp;</h6>}
                      </th>
                      <th className="border-white border-right-0 bg-white text-black" colSpan='2'></th>
                    </tr>
                    <tr><th className="border-white border-right-0 bg-white text-black" colSpan='6'>
                      <h6 className="mb-0">FROM {moment(startDate).format('MM/DD/YYYY')} TO {moment(endDate).format('MM/DD/YYYY')}</h6>
                    </th>
                      <th className="border-white border-right-0 bg-white text-black" colSpan='2'></th>
                    </tr>
                  </>}
                  <tr>
                    <th colSpan='16' className="blue-head py-2">
                      <Row className="mx-0">
                        <Col lg="6" md="6" sm="12">
                          <div className="pl-2  float-left">
                            <span className="font-12">WEEKLY TIME SHEET</span>
                            <span className="small-font pl-2">
                              {`${this.formatDate(org.startWeekDate)} - ${this.formatDate(org.weekEndDate)}`}
                            </span>
                          </div>
                        </Col>
                        <Col lg="6" md="6" sm="12">
                          <div className="pr-2 float-right">
                            <span className="pr-2 font-12">
                              {timesheet_status_codes[`${get(org, 'status', '')}`]}
                            </span>
                            <span className="font-small">{`Due on : ${this.formatDate(moment(org.weekEndDate).subtract(1, 'day'))}`}</span>
                          </div>
                        </Col>
                      </Row>
                    </th>
                  </tr>
                </thead>
                <tbody className="text-center">
                  <tr>
                    <td colSpan='2' className="font-weight-bold text-right pr-1">NAME: </td>
                    <td colSpan='8' className="pl-1 text-left">
                      {org.userLastname}, {org.userFirstname}
                    </td>
                  </tr>
                  <tr>
                    <td colSpan='2' className="font-weight-bold text-right pr-1">GROUP: </td>
                    <td colSpan='8' className="pl-1 text-left">{org.groupCode ? `${org.groupName} (${org.groupCode})` : '-'}</td>
                  </tr>
                  <tr className="text-center font-small p-1 bg-lite-gray">
                    <th colSpan='2' width="10%"></th>
                    {get(org, 'daysOfWeek', []).map((day, index) => (
                      <th key={`${day.day}${index}`}>{day.day}<br />{day.date}</th>
                    ))}
                    <th>Total<br />Hours</th>
                  </tr>
                  {
                    org && get(org, 'activityTime', []).map((activity, jk) => {
                      let activityTotal = Object.values(DAYS_OF_WEEK).map((day) => activity[`${day.toLowerCase()}Hour`]).reduce((a, b) => (a + b), 0);
                      const clockinouts = activity.clockinouts;
                      return <React.Fragment key={jk}>
                        {clockinouts.map((clock, index) => (
                          <tr key={activity.activityID + index}>
                            {index === 0 && (<td colSpan='1' rowSpan={clockinouts.length + 1}>{activity.activityName.toUpperCase()}</td>)}
                            <td colSpan='1'>{ClockInOuts[clock.type]}</td>
                            {
                              get(org, 'daysOfWeek', []).map((day, index) => (
                                <td colSpan='1' key={`${day}${index}${jk}`}>
                                  {isEqual(day.day, DAYS_OF_WEEK[moment(clock.clockAt).day()]) ? moment(clock.clockAt).format('h:mm A') : ''}
                                </td>
                              ))
                            }
                            <td colSpan='1'></td>
                          </tr>
                        ))}
                        <tr className="time-td blue-text bg-lite-gray">
                          {clockinouts.length > 0 ? <td>HOURS</td> : <td colSpan='2'>{`${activity.activityName.toUpperCase()} HOURS`}</td>}
                          {Object.values(DAYS_OF_WEEK).map((day, index) => {
                            let multiIndex1 = {};
                            let objDate1 = {};
                            if (org.changeNotes.length > 0) {
                              org.changeNotes.map((ch) => {
                                const keyName1 = `${ch.activityName}_${ch.day}`;
                                if (objDate1 && objDate1[keyName1]) {
                                  let obj = objDate1[keyName1];
                                  objDate1[keyName1] = { ...objDate1[keyName1], index: [...obj.index, ch.index] };
                                } else {
                                  objDate1[keyName1] = { index: [ch.index], day: ch.day, activityID: ch.activityID };
                                }
                                if ((ch.activityID === activity.activityID) && DAYS_OF_WEEK[ch.day] === day) {
                                  if (objDate1[keyName1] && (objDate1[keyName1].index).length > 0) {
                                    multiIndex1 = objDate1[keyName1];
                                  }
                                };
                                return null;
                              });
                            }
                            return <td key={`${day}${index}`} className="text-blue">
                              {(multiIndex1.index && multiIndex1.index.length > 1) ? <OverlayTrigger
                                key={index}
                                placement='top'
                                overlay={
                                  <Popover id={`popover-positioned-top`}>
                                    <Popover.Title as="h6" className="background-green1 text-white">Timesheet Changes</Popover.Title>
                                    <Popover.Content>
                                      <div>Timesheet Changes of Day: </div>
                                      <div>{multiIndex1.index.join(', ')}</div>
                                    </Popover.Content>
                                  </Popover>
                                }>
                                <span onClick={(e) => e.stopPropagation()} className="ptoCircleMultiple mr-2 ptoCircle xs_font">{multiIndex1.index[0]}</span>
                              </OverlayTrigger> :
                                multiIndex1.index && <span onClick={(e) => e.stopPropagation()} className="mr-1 ptoCircle xs_font">{multiIndex1.index[0]}</span>
                              }
                              {activity[`${day.toLowerCase()}Hour`] > 0 ? toNumber(activity[`${day.toLowerCase()}Hour`]) : multiIndex1.index ? '0.00' : null}
                            </td>
                          })}
                          <td colSpan='1'>{toNumber(activityTotal)}</td>
                        </tr>
                      </React.Fragment>
                    })
                  }
                  <tr className="time-td blue-text bg-lite-gray">
                    <td colSpan='2'>TOTAL</td>
                    <td colSpan='7' />
                    <td className="text-blue">
                      <span variant="secondary">{toNumber(org.totalHours) || '-'}</span>
                    </td>
                  </tr>
                  <tr>
                    <th colSpan='10' className="blue-head text-center py-2">
                      Timesheet Changes
                    </th>
                  </tr>
                  <tr>
                    <th colSpan='10' className="py-2">
                      {get(org, 'changeNotes', []).map((timesheetChanges, timIndex) => {
                        let actualDay = DAYS_OF_WEEK[timesheetChanges.day];
                        let dateObject = find(get(org, 'daysOfWeek', []), { day: actualDay });
                        return <p key={timIndex} className="pl-1 mb-1 small_font text-left">
                          <span className="ptoCircleChg mr-2 text-center">{timesheetChanges.index}</span>
                          {timesheetChanges.activityName || ''} {moment(dateObject.fullDate).format('dddd (MMM DD, YYYY)')} : {timesheetChanges.reason} - Change made by {timesheetChanges.madeByFirstname} {timesheetChanges.madeByLastname}
                                &nbsp; on {moment(timesheetChanges.madeAt).format("hh:mm A MMM DD, YYYY")}.
                          </p>
                      })}
                    </th>
                  </tr>
                  <tr>
                    <th colSpan='10' className="py-2"></th>
                  </tr>
                  <tr>
                    <th colSpan='3' className="pt-5 text-left">
                      <span className="pl-1 font-9">Employee Signature: &nbsp;</span>
                      {org.employeeApprovalImg ? <img src={org.employeeApprovalImg} height={30} alt="employeeApprovalImg" /> :
                        null}
                    </th>
                    <th colSpan='2' className="pt-5 text-left">
                      <span className="pl-1 font-9">Date:</span>
                      <span className="pl-1 font-9">{org.submitDate || ''}</span>
                    </th>
                    <th colSpan='3' className="pt-5 text-left">
                      <span className="pl-1 font-9">Approval Signature: &nbsp;</span>
                      {org.approvalImage ? <img src={org.approvalImage} alt="approvalImage" height={30} /> : null}
                    </th>
                    <th colSpan='2' className="pt-5 text-left">
                      <span className="pl-1 font-9">Date:  &nbsp;</span>
                      <span className="pl-1 font-9">{org.approvalDate || ''}</span>
                    </th>
                  </tr>
                </tbody>
              </table>
            </div>
          })}
        </div>
      </div>
    )
  }
}

export default TimesheetReciept;
