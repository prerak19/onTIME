import React from 'react';
import { Container } from 'react-bootstrap';
import { Route, Redirect } from "react-router-dom";
import AdminHeader from '../components/AdminHeader';
import { fontOptions } from '../helpers/GeneralHelper';

const AdminPrivateRoute = ({ component: Component, rights = '', ...rest }) => {
  const userType = localStorage.usertype;
  const userDetails = JSON.parse(localStorage.userdetails);
  return (
    <>
      <link rel="stylesheet" type='text/css' href={`https://fonts.googleapis.com/css?family=${fontOptions.map(x => x.value).join('|')}`} id="signature_text" />
      <div className="App">
        <Container>
          <header className="admin-header">
            <AdminHeader />
          </header>
        </Container>
      </div>
      <Route
        {...rest}
        render={props =>
          userType === 'admin' && (!rights || userDetails[`${rights}`] === 1) ? (<Component {...props} />) :
            (<Redirect to={{ pathname: "/index", state: { from: props.location } }} />
            )
        }
      />
    </>
  );
}
export default AdminPrivateRoute;