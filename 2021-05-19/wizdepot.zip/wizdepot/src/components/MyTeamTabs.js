import React, { Component } from 'react';
import 'bootstrap/dist/css/bootstrap.min.css';
import 'bs-stepper/dist/css/bs-stepper.min.css';
import Stepper from 'bs-stepper';
import LoadMyTeamTable from './LoadMyTeamTable.js';
import "react-datepicker/dist/react-datepicker.css";
import AboutEmployees from './AboutEmployees.js';
import ManagerReportingSection from './ManagerReportingSection.js';

class MyTeamTabs extends Component {
  constructor(props) {
    super(props);
    this.state = {};
  }
  componentDidMount() {
    this.stepper = new Stepper(document.querySelector('#stepper2'), {
      linear: false,
      animation: true
    })
  }

  setProps = (props) => {
    const { showreport, summaryArr, originalArr, detailsArr, activityTimeArr, disFilterArr, startDate, endDate, companyDetails } = props;
    if (showreport === 'original') {
      this.props.setPropsData({ showreport, originalArr, startDate, endDate })
    } else {
      this.props.setPropsData({
        showreport, summaryArr, detailsArr, activityTimeArr,
        disFilterArr, startDate, endDate, companyDetails
      })
    }
  }

  render() {
    return (
      <React.Fragment>
        <div id="stepper2" className="bs-stepper">
          <div className="bs-stepper-header">
            <div className="step" data-target="#tests-l-1">
              <button className="step-trigger">
                <span className="bs-stepper-label1">Manage Employee Time</span>
              </button>
            </div>
            <div className="step" data-target="#tests-l-2">
              <button className="step-trigger">
                <span className="bs-stepper-label1">Run Reports</span>
              </button>
            </div>
            <div className="step" data-target="#tests-l-3">
              <button className="step-trigger">
                <span className="bs-stepper-label1">About Employees</span>
              </button>

            </div>
          </div>
          <div className="stepper-content">
            <div id="tests-l-1" className="content small_font">
              <LoadMyTeamTable />
            </div>
            <div id="tests-l-2" className="content  pl-0  small_font">
              <ManagerReportingSection setProps={this.setProps} />
            </div>
            <div id="tests-l-3" className="content pl-2 small_font">
              <AboutEmployees />
            </div>
          </div>
        </div>
      </React.Fragment>
    );
  }
}

export default MyTeamTabs;
