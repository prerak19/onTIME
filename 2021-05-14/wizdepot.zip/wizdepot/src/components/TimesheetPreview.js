import React, { Component } from 'react';
import 'bootstrap/dist/css/bootstrap.min.css';
import 'bs-stepper/dist/css/bs-stepper.min.css';
import Stepper from 'bs-stepper';
import { toNumber } from '../helpers/GeneralHelper';
import { chunk, groupBy, sum } from 'lodash';
import { Row, Col } from "react-bootstrap";


class TimesheetPreview extends Component {
  constructor(props) {
    super(props);
    this.state = {
      show: false,
      close: false,
      viewshow: false,
      editshow: false,
      supershow: false,
      editsupershow: false,
      name: 'React',
      remove: false,
    };
  }
  componentDidMount() {
    this.stepper = new Stepper(document.querySelector('#stepper1'), {
      linear: false,
      animation: true
    });
    document.getElementById("tp1").click();
  }

  onSubmit(e) {
    e.preventDefault()
  }

  render() {
    return (
      <div className="mt-5">
        <h6 className="text-center">Report Preview</h6>
        <button onClick={() => this.setState({ showreport: true })} class="button resend-btn float-right mb-3">Save As Excel</button>
        <button onClick={() => this.setState({ showreport: true })} class="button resend-btn ml-2 float-right mb-3">Save As PDF</button>
        <div className="payrollform">
          <div className="col-12 mb-3 text-center">
            <h6>TIMESHEET SUMMARY REPORT</h6>
          </div>
          <div id="stepper1" className="bs-stepper">
            <div className="bs-stepper-header">
              <div className="step" ref="fileUploader" id="tp1" data-target="#test-l-1">
                <button className="step-trigger">
                  <span className="bs-stepper-label">Summary Page</span>
                </button>
              </div>
              <div className="step" data-target="#test-l-2">
                <button className="step-trigger">
                  <span className="bs-stepper-label">Detail Page</span>
                </button>
              </div>
            </div>
            <div className="bs-stepper-content">
              <div id="test-l-1" className="content  pl-2 small_font overflow-auto">
                <table border='1' className="col-12 text-center text-black">
                  <thead>
                    <tr>
                      <th colSpan='3'>Total Summary</th>
                      <th className="background-green" colSpan={this.props.activityTimeArr.length} />
                      <th className="background-green" colSpan={2} />
                    </tr>
                    <tr>
                      <th rowSpan='2'>FIRST NAME</th>
                      <th rowSpan='2'>LAST NAME</th>
                      <th rowSpan='2'>GROUP</th>
                      <th colSpan={this.props.activityTimeArr.length}>ACTIVITIES</th>
                      <th colSpan='2'>TOTAL</th>
                    </tr>
                    <tr>
                      {this.props.activityTimeArr.length > 0 ? this.props.activityTimeArr.map((x, i) => {
                        return <th key={i}>{x}</th>
                      }) : <th />}
                      <th>REGULAR</th>
                      <th>OVERTIME</th>
                    </tr>
                  </thead>
                  <tbody>
                    {this.props.summaryArr.map((x, key) => {
                      return <tr key={key}>
                        <td>{x.firstName}</td>
                        <td>{x.lastName}</td>
                        <td>{x.groupName}</td>
                        {Object.values(x.timeObj).map((act, j) => {
                          return <td key={j}>{toNumber(act)}</td>
                        })}
                        <td>{toNumber(x.regularHours)}</td>
                        <td>{toNumber(x.overtimeHours)}</td>
                      </tr>
                    })}
                  </tbody>
                </table>
              </div>
              <div id="test-l-2" className="content  pl-2 small_font">
                <Row >
                  <Col xs={2} className="pr-0">
                    <table border='1' className="col-12 text-center text-black ">
                      <tbody>
                        {this.props.detailsArr && this.props.detailsArr.map((x, i) => {
                          let finalFirstArr = [];
                          Object.entries(x).map((val) => {
                            if (typeof val[1] === 'object') {
                              let arr = chunk(Object.keys(val[1]), 31);
                              arr.map((dateData, i) => {
                                finalFirstArr.push({
                                  key: i,
                                  activityId: val[0].split('_')[1],
                                  activityName: val[0].split('_')[0]
                                })
                              })
                            }
                          });
                          return <React.Fragment key={i}>
                            <tr>
                              <td colSpan={2}>
                                &nbsp;
                            </td></tr>
                            {Object.values(groupBy(finalFirstArr, 'key')).map((v, l) => {
                              return <React.Fragment key={l}>
                                <tr>
                                  <td colSpan='2'>ACTIVITY</td>
                                </tr>
                                <tr>
                                  <td>ID</td>
                                  <td>Name</td>
                                </tr>
                                {v.map((valueData, dataKey) => {
                                  return <tr key={dataKey}>
                                    <td>{valueData.activityId}</td>
                                    <td>{valueData.activityName}</td>
                                  </tr>
                                })
                                }<tr>
                                  <td colSpan={2}>Summary</td>
                                </tr>
                              </React.Fragment>
                            })}
                          </React.Fragment>
                        })}
                      </tbody>
                    </table>
                  </Col>
                  <Col xs={10} className="overflow-auto pl-0">
                    <table border='1' className="col-12 text-center text-black ">
                      <tbody>
                        {this.props.detailsArr && this.props.detailsArr.map((x, i) => {
                          let finalFirstArr = [];
                          let sumArr = [];
                          Object.entries(x).map((val, key) => {
                            if (typeof val[1] === 'object') {
                              Object.entries(val[1]).map((s) => {
                                if (sumArr.find((x) => x.key === s[0])) {
                                  sumArr = sumArr.map((sn) => {
                                    let vale = sn.value;
                                    return (sn.key === s[0]) ? { ...sn, value: Number(vale) + Number(s[1]) } : sn;
                                  })
                                } else {
                                  sumArr.push({
                                    key: s[0],
                                    value: Number(s[1]),
                                  })
                                }
                              })
                              let arr = chunk(Object.keys(val[1]), 31);
                              arr.map((dateData, i) => {
                                finalFirstArr.push({
                                  value: val[1],
                                  key: i,
                                  activityId: val[0].split('_')[1],
                                  activityName: val[0].split('_')[0],
                                  data: dateData,
                                })
                              })
                            }
                          });
                          const emptyArr = (data) => Array(31 - Number(data.length)).fill('');
                          let regularLength = Object.values(groupBy(finalFirstArr, 'key')).length;
                          return <React.Fragment>
                            <tr>
                              <td colSpan='33'>[Group Name] [Group ID] EMPLOYEE NAME: {x.lastName}, {x.firstName}</td>
                            </tr>
                            {Object.values(groupBy(finalFirstArr, 'key')).map((v, l) => {
                              let obj = {};
                              v[0].data.map((head, k) => {
                                let val = head.split('_')[1];
                                let monthName = val.split('-')[0];
                                if (obj[monthName]) {
                                  obj[monthName].push(val);
                                } else {
                                  obj[monthName] = [val];
                                }
                              });
                              return <React.Fragment key={l}>
                                <tr>
                                  {Object.entries(obj).map((headMonth, k) => <td key={k} colSpan={headMonth[1].length}>{headMonth[0]}</td>)}
                                  {emptyArr(v[0].data).map((emp, k) => <td key={k}>&nbsp;</td>)}
                                  {l === 0 && <th colSpan='2'>TOTAL</th>}
                                </tr>
                                <tr>
                                  {v[0].data.map((hr, k) => {
                                    return <td key={k}>
                                      {hr.split('_')[0]}
                                    </td>
                                  })}
                                  {emptyArr(v[0].data).map((emp, k) => <td key={k}>&nbsp;</td>)}
                                  {l === 0 && <td>REGULAR</td>}
                                  {l === 0 && <td>OVERTIME</td>}
                                </tr>
                                {v.map((valueData, dataKey) => {
                                  return <tr key={dataKey}>
                                    {valueData.data.map((hr, k) => {
                                      return <td key={k}>
                                        {valueData.value[`${hr}`]}
                                      </td>
                                    })}
                                    {emptyArr(valueData.data).map((emp, k) => <td key={k}>&nbsp;</td>)}
                                    {l === 0 && dataKey === 0 && <>
                                      <td rowSpan={(regularLength * v.length) + ((regularLength * 3) - 2)}>{x.regularHours}</td>
                                      <td rowSpan={(regularLength * v.length) + ((regularLength * 3) - 2)}>{x.overtimeHours}</td>
                                    </>}
                                  </tr>
                                })}
                                <tr>
                                  {chunk(sumArr, 31)[l].map((hr, k) => {
                                    return <td key={k}>
                                      {hr.value}
                                    </td>
                                  })}
                                  {emptyArr(v[0].data).map((emp, k) => <td key={k}>&nbsp;</td>)}
                                </tr>
                              </React.Fragment>
                            })}
                          </React.Fragment>
                        })}
                      </tbody>
                    </table>
                  </Col>
                </Row>
              </div>
            </div>
          </div>
          <div aria-live="polite" aria-atomic="true" style={{ position: 'relative', }}>
          </div>
        </div>
      </div>
    );
  }
}

export default TimesheetPreview;
