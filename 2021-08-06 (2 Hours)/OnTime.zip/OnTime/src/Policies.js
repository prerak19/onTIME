import React, { useState } from 'react';
import './App.css';
import { Container, Tab, Tabs } from 'react-bootstrap';
import LoadPoliciesTable from './components/LoadPoliciesTable';
import LoadHolidaysTable from './components/LoadHolidaysTable';


const Policies = () => {
  const [activeTab, setActiveTab] = useState('policiesTab');
  return (
    <div className="App">
      <Container>
        <div className="contentwrapper pt-1 pb-5 mb-5">
          <Tabs defaultActiveKey="policiesTab" activeKey={activeTab} className="customTabs" onSelect={(tab) => setActiveTab(tab)}>
            <Tab eventKey="policiesTab" title={<span className="customTabsTitle">Time Clock Rounding</span>}>
              {activeTab === 'policiesTab' && <LoadPoliciesTable />}
            </Tab>
            <Tab eventKey="holidaysTab" title={<span className="customTabsTitle">Holiday Policies</span>}>
              {activeTab === 'holidaysTab' && <LoadHolidaysTable />}
            </Tab>
          </Tabs>
        </div>
      </Container>
    </div>
  );
}

export default Policies;
