import React from 'react';
import { Container } from 'react-bootstrap';
import { Route, Redirect } from "react-router-dom";
import AdminHeader from '../components/AdminHeader';
import { fontOptions } from '../helpers/GeneralHelper';

const EmployeePrivateRoute = ({ component: Component, ...rest }) => {
  let userType = localStorage.usertype;
  return (
    <>
      <link rel="stylesheet" type='text/css' href={`https://fonts.googleapis.com/css?family=${fontOptions.map(x => x.value).join('|')}`} id="signature_text" />
      <div className="App">
        <Container>
          <header className="admin-header">
            <AdminHeader />
          </header>
        </Container>
      </div>
      <Route
        {...rest}
        render={props =>
          userType === 'employee' ? (<Component {...props} />) :
            (<Redirect to={{ pathname: "/index", state: { from: props.location } }}
            />)
        }
      />
    </>
  );
}

export default EmployeePrivateRoute;