import React from 'react';
import { Container } from 'react-bootstrap';
import 'bootstrap/dist/css/bootstrap.min.css';
import './App.css';
import AdminHeader from './components/AdminHeader.js';
import ReportingSection from './ReportingSection.js';
import PayrollTable from './components/PayrollTable';
import TimesheetPreview from './components/TimesheetPreview';
import moment from 'moment';

class Reporting extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      startDate: new Date(moment().day(0).format('YYYY-MM-DD')),
      endDate: new Date(moment().day(6).format('YYYY-MM-DD')),
      activityTimeArr: [],
      summaryArr: [],
      payRollArr: [],
      dutyCodeArr: [],
      withourDutyCodeArr: [],
      finalTotalPayRoll: {},
      disFilterArr: [],
      showreport: '',
    };
  }
  loadPreview = (e) => {
    e.preventDefault();
    this.setState({
      showreport: this.state.preview,
      showreportcss: true,
    });
  }

  setProps = (props) => {
    const { showreport, summaryArr, detailsArr, activityTimeArr, disFilterArr, payRollArr,
      dutyCodeArr, finalTotalPayRoll, withourDutyCodeArr } = props;
    if (showreport === 'payroll') {
      this.setState({
        showreport,
        payRollArr, dutyCodeArr, finalTotalPayRoll,
        withourDutyCodeArr,
        disFilterArr
      })
    } else {
      this.setState({
        showreport,
        summaryArr,
        detailsArr,
        activityTimeArr,
        disFilterArr
      });
    }

  }
  render() {
    const { showreport, startDate, endDate, activityTimeArr, summaryArr, detailsArr, payRollArr,
      dutyCodeArr, withourDutyCodeArr, finalTotalPayRoll, disFilterArr } = this.state;
    return (
      <div className="App">
        <Container>
          <header className="admin-header">
            <AdminHeader />
          </header>
          <ReportingSection setProps={this.setProps} />
        </Container>
        { showreport === 'payroll' && <PayrollTable payRollArr={payRollArr} dutyCodeArr={dutyCodeArr} withourDutyCodeArr={withourDutyCodeArr} finalTotalPayRoll={finalTotalPayRoll} startDate={startDate} endDate={endDate} disFilterArr={disFilterArr} />}
        { showreport === 'timesheet' && <TimesheetPreview activityTimeArr={activityTimeArr} summaryArr={summaryArr} detailsArr={detailsArr} startDate={startDate} endDate={endDate} disFilterArr={disFilterArr} />}
      </div>
    );
  }
}

export default Reporting;
