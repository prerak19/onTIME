import React from 'react';
import Logo from './components/assets/img/login-logo.png';
import 'bootstrap/dist/css/bootstrap.min.css';
import './components/assets/css/login.css';
import 'font-awesome/css/font-awesome.css';
import { apiPost } from './Api.js';

class ForgotPassword extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      userid: (this.props.location.state) ? this.props.location.state.id : '',
      userdetails: '',
      fields: {},
      errors: {},
      error_message: '',
      success_message: ''
    };
  };
  onSubmit = (e) => {
    this.props.history.push("/Login");
  }
  handleChange = (e) => {
    let fields = this.state.fields;
    let errors = this.state.errors;
    fields[e.target.name] = e.target.value;
    errors[e.target.name] = "form-control is-valid";
    this.setState({
      fields
    });
  }
  validateForm() {
    let fields = this.state.fields;
    let errors = {};
    let formIsValid = true;
    if (!fields["userName"]) {
      formIsValid = false;
      errors["userName"] = "form-control is-invalid";
    }
    this.setState({ error_message: !formIsValid ? 'Please Enter User Name!' : '', errors });
    return formIsValid;
  }
  resendEmail = (e) => {
    e.preventDefault();
    if (this.validateForm()) {
      let requestDetails = {
        method: 'employees/reset-password-request',
        params: {
          userName: this.state.fields.userName
        }
      };
      apiPost(requestDetails).then((res) => {
        if (res && res.status === 200) {
          this.setState({ success_message: 'Email sent Successfully!' });
          this.props.history.push({
            pathname: "/login",
            state: { msg: 'Instructions to reset your password has been sent to your Email' }
          });
        }
        if (res.request && res.request.response && res.request.status !== 200) {
          const obj = JSON.parse(res.request.response);
          this.setState({ error_message: obj.msg || 'Something Went Wrong!' })
          return;
        }
      }).catch((error) => {
        this.setState({ error_message: error.response.data.msg })
        window.scroll({ top: 0, left: 0, behavior: 'smooth' })
      });
    }
  }
  render() {
    return (
      <div className="background min-h-100">
        <div className="container">
          <div className="row h-100 justify-content-center align-items-center m-0">
            <div className="col-12 forgot-margin">
              <div className="login-form text-center col-lg-4 col-md-5 col-sm-9">
                <img src={Logo} width="86%" alt="Logo" />
                <img alt="Banner" width="15%" src={require("./components/assets/img/time-icon.png").default} />
                <p className="font-weight-bold font-11 mb-2">Reset Password</p>
                <p className="font-10 mb-2">Enter Your User Name below to have instructions to reset your password</p>
                <p className="text-danger small_font">{this.state.error_message}</p>
                <p className="text-success small_font">{this.state.success_message}</p>
                <form>
                  <div className="input-group my-3">
                    <div className="input-group-prepend">
                      <span className="input-group-text"><i style={{ fontSize: '12px' }} className="fa fa-envelope" aria-hidden="true"></i></span>
                    </div>
                    <input type="text" name='userName' value={this.state.fields.userName} onChange={this.handleChange} className={`form-control ${this.state.errors["userName"] ? this.state.errors["userName"] : ''}`} placeholder="User Name" />
                  </div>
                  <input type="button" onClick={this.resendEmail} className="button w-100 py-2 mb-3" value="Send Instructions" />
                </form>
              </div>
            </div>
          </div>
        </div></div>
    );
  }
}

export default ForgotPassword;
