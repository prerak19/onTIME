import React from 'react';
import '../App.css';
import ManagerReportingSection from './ManagerReportingSection.js';
import TimesheetPreview from '../components/TimesheetPreview';
import moment from 'moment';
import TimesheetReciept from '../components/timesheetRecieptReport';

class ManagerReportsTab extends React.Component {
	constructor(props) {
		super(props);
		this.state = {
			startDate: new Date(moment().day(0).format('YYYY-MM-DD')),
			endDate: new Date(moment().day(6).format('YYYY-MM-DD')),
			activityTimeArr: [],
			summaryArr: [],
			disFilterArr: [],
			originalArr: [],
			showreport: '',
			companyDetails: {},
		};
	}

	setProps = (props) => {
		const { showreport, summaryArr, originalArr, detailsArr, activityTimeArr, disFilterArr,startDate, endDate, companyDetails } = props;
		if (showreport === 'original') {
			this.setState({
				showreport, originalArr, startDate, endDate
			});
		} else {
			this.setState({
				showreport, summaryArr, detailsArr, activityTimeArr,
				disFilterArr, startDate, endDate, companyDetails
			});
		}

	}
	render() {
		const { showreport, startDate, endDate, activityTimeArr, summaryArr, detailsArr, disFilterArr, companyDetails } = this.state;
		return (
			<div className="App">
				<ManagerReportingSection setProps={this.setProps} />
				{ showreport === 'timesheet' && <TimesheetPreview companyDetails={companyDetails} activityTimeArr={activityTimeArr} summaryArr={summaryArr} detailsArr={detailsArr} startDate={startDate} endDate={endDate} disFilterArr={disFilterArr} />}
				{ showreport === 'original' && <TimesheetReciept startDate={startDate} endDate={endDate} originalArr={originalArr} />}
			</div>
		);
	}
}

export default ManagerReportsTab;
