import React from 'react';
import 'bootstrap/dist/css/bootstrap.min.css';
import './App.css';
import DatePicker from "react-datepicker";
import "react-datepicker/dist/react-datepicker.css";
import {
  Modal,
  Row,
  Col,
  Popover,
  OverlayTrigger
} from "react-bootstrap";
import { apiGet, apiPut, apiPost, getBlobImage } from './Api.js';
import { get, isEqual, isEmpty, sum, find, sortBy } from 'lodash';
import { DAYS_OF_WEEK, timesheet_status_codes, ClockInOuts, toNumber, BY_WEEKLY_DAYS_OF_WEEK, getWeek } from './helpers/GeneralHelper';
import moment from 'moment';

const UserActivity = {
  timesheetApproval: 1,
  activityApproval: 2
}

class TimesheetChart extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      weeklyDate: new Date(moment().day(0)),
      actionLogs: [],
      tempObj: null,
      finalTimesheets: [],
      weekDays: [],
      weekCount: 1,
      overallTotals: [],
      approvedImage: [],
      currentTimesheet: {},
      personalDetails: {},
      displayConfirmationPopup: false,
      subLoading: false,
      timesheetid: props.id,
      currentActivityId: null,
      totalHours: 0.0,
      currentActivityTotalHours: 0,
      startWeekDate: moment().day(0),
      weekEndDate: moment().day(6),
      activityApprovalImg: [],
      employeeApprovalImg: [],
      punchOutTime: '',
      punchOutComments: '',
      userApprovalComments: '',
      selectedUserActivity: null,
      timesheetLoading: false,
    };
  }

  componentDidMount() {
    this.getTimesheetRecord();
  }

  getTimesheetRecord = () => {
    const requestDetails = {
      method: `timesheets/${this.state.timesheetid}`,
      params: {}
    };
    this.setState({ timesheetLoading: true });
    apiGet(requestDetails, true, false).then((res) => {
      if (isEqual(res.status, 200) && res.data) {
        this.updateBiWeeklyData(res.data);
      }
      if (res.request && res.request.status !== 200) {
        window.alert('No Timesheet is available for selected Week');
        this.setState({ timesheetLoading: false });
      }
    }).catch(error => {
      console.log(error);
    });
  }

  updateBiWeeklyData = async (data) => {
    let tempObj = {}
    const finalTimesheets = data.timsheets;
    const weeklyCount = data.count === 2 ? true : false;
    let weekDays = [];
    const personalDetails = {
      userFirstname: finalTimesheets[0].userFirstname || (weeklyCount && finalTimesheets[1].userFirstname) || null,
      userLastname: finalTimesheets[0].userLastname || (weeklyCount && finalTimesheets[1].userLastname) || null,
      groupCode: finalTimesheets[0].groupCode || (weeklyCount && finalTimesheets[1].groupCode) || null,
      groupName: finalTimesheets[0].groupName || (weeklyCount && finalTimesheets[1].groupName) || null,
      status: finalTimesheets[0].status || (weeklyCount && finalTimesheets[1].status) || null,
      uid: finalTimesheets[0].uid || (weeklyCount && finalTimesheets[1].uid) || null
    };
    let overallTotals = [];
    let employeeApprovalImg = [];
    let approvedImage = [];
    let activityApprovalImg = [];
    finalTimesheets.map((xdt) => {
      if (xdt.activityTime && xdt.activityTime.length > 0) {
        xdt.activityTime.map((act) => {
          if (tempObj[act.activityName]) {
            tempObj[act.activityName] = { ...tempObj[act.activityName], week2: { ...act, timesheetID: xdt.tid, startDate: xdt.startDate, status: xdt.status } }
          } else {
            tempObj[act.activityName] = { week1: { ...act, timesheetID: xdt.tid, startDate: xdt.startDate, status: xdt.status } }
          }
          return null;
        })

        let approvedImageArr = xdt.activityTime.filter(x => x.approvedBy !== 0);
        if (approvedImageArr.length > 0) {
          approvedImageArr = approvedImageArr.map((x, i) => {
            if (!find(activityApprovalImg, { approvedBy: x.approvedBy })) {
              const imgsrc = this.getApprovalImage('user_initial', x.approvedBy);
              activityApprovalImg.push({ index: i, approvedBy: x.approvedBy, imgsrc });
              return null;
            }
            return null;
          })
        }
      }
      if (xdt.dailyTotals && xdt.dailyTotals.length > 0) {
        xdt.dailyTotals.map((dt) => {
          weekDays.push({
            day: moment(dt.date).format('ddd'),
            date: moment(dt.date).format('MMM D'),
            fullDate: moment(dt.date).format('YYYY-MM-DD'),
          })
          overallTotals.push(dt);
          return null;
        })
      }
      if (xdt.status >= 300) {
        if (!find(employeeApprovalImg, { uid: xdt.uid })) {
          const imgsrc = this.getApprovalImage('user_signature', xdt.uid);
          employeeApprovalImg.push({ uid: xdt.uid, imgsrc });
        }
        if (xdt.status >= 500) {
          if (!find(approvedImage, { approvedBy: xdt.approvedBy })) {
            const imgAppsrc = this.getApprovalImage('user_signature', xdt.approvedBy);
            approvedImage.push({ approvedBy: xdt.approvedBy, imgAppsrc });
          }
        }
      }
      return null;
    })
    await Promise.all(employeeApprovalImg.map((x) => x.imgsrc)).then((body) => {
      employeeApprovalImg = employeeApprovalImg.map((img, key) => {
        return { ...img, src: body[key] }
      })
    })

    await Promise.all(approvedImage.map((x) => x.imgAppsrc)).then((body) => {
      approvedImage = approvedImage.map((img, key) => {
        return { ...img, src: body[key] }
      })
    })

    await Promise.all(activityApprovalImg.map((x) => x.imgsrc)).then((body) => {
      activityApprovalImg = activityApprovalImg.map((img, key) => {
        return { ...img, src: body[key] }
      })
    })
    const sunday = new Date(moment(get(finalTimesheets[0], 'startDate')).day(0));
    const nextSunday = new Date(moment(get(finalTimesheets[1] || finalTimesheets[0], 'startDate')).day(6));
    let actionLogs = await this.getActionLogs(data);
    this.setState({
      weekCount: data.count,
      tempObj,
      weekDays,
      overallTotals,
      totalHours: sum(overallTotals.map((x) => x.hours)),
      finalTimesheets,
      personalDetails,
      weeklyDate: sunday,
      startWeekDate: moment(sunday).format('YYYY-MM-DD'),
      weekEndDate: moment(nextSunday).format('YYYY-MM-DD'),
      actionLogs,
      employeeApprovalImg,
      approvedImage,
      currentActivityId: null,
      currentActivityTotalHours: 0.00,
      userApprovalComments: '',
      selectedUserActivity: null,
      activityApprovalImg,
      displayConfirmationPopup: false,
      subLoading: false,
      timesheetLoading: false
    });
    document.body.click();
  }

  cancelPopup = () => {
    this.setState({
      currentActivityId: null,
      currentActivityTotalHours: 0.00,
      userApprovalComments: '',
      selectedUserActivity: null,
      displayConfirmationPopup: false,
    })
  }

  getActionLogs = async (data) => {
    let arr = [];
    const getWeek1Request = { method: `timesheets/action-logs/${data.timsheets[0].tid}` };
    let apiArr = [apiGet(getWeek1Request, true, false)];
    if (data.count === 2) {
      const getWeek2Request = { method: `timesheets/action-logs/${data.timsheets[1].tid} ` };
      apiArr.push(apiGet(getWeek2Request, true, false));
    }
    await Promise.all(apiArr).then(([week1, week2]) => {
      if (week1 && week1.data && week1.data.length > 0) {
        arr.push(...week1.data);
      }
      if (week2 && week2.data && week2.data.length > 0) {
        arr.push(...week2.data);
      }
    }).catch(error => {
    });
    return arr;
  }

  getApprovalImage = async (type = 'user_signature', uid = '') => {
    let userId = get(localStorage, 'userid', '');
    if (uid) { userId = uid; }
    let imageSrc = '';
    const getRequest = {
      method: `employees/images?id=${userId}&itemtype=${type}`
    };
    await getBlobImage(getRequest).then((response) => {
      if (response.data && response.data.size) {
        imageSrc = URL.createObjectURL(response.data);
      }
    }).catch(error => {
      console.log(error);
    });
    return imageSrc;
  }

  formatDate = (date) => moment(date).format("MMMM D, YYYY");

  isWeekday = (date) => date.getDay() === 0;

  handleWeekChange = (date) => {
    const { personalDetails } = this.state;
    const formatDate = moment(date).format('YYYY-MM-DD');
    const request = {
      method: `timesheets/${get(personalDetails, 'uid')}/${formatDate}`
    };
    this.setState({ timesheetLoading: true });
    apiGet(request, true, false).then((res) => {
      if (isEqual(res.status, 200) && res.data) {
        this.updateBiWeeklyData(res.data);
      }
      if (res.request && res.request.status !== 200) {
        window.alert('No Timesheet is available for selected Week');
        this.setState({ timesheetLoading: false });
      }
    }).catch((err) => {
      console.log(err);
    })
  }

  setPunchOutComments = (evt) => this.setState({ punchOutComments: evt.target.value })

  setUserApprovalComments = (evt) => this.setState({ userApprovalComments: evt.target.value })

  updateHour = (activityProps, actIndex) => {
    this.setState({ subLoading: true });
    const request = {
      method: 'timesheets/hour',
      params: {
        timesheetID: Number(activityProps.timesheetID),
        activityID: activityProps.activityID,
        day: actIndex,
        hours: Number(this.state.punchOutTime),
        reason: this.state.punchOutComments,
        madeBy: Number(get(localStorage, 'userid', '')),
      }
    }
    apiPut(request, true).then((res) => {
      if (isEqual(res.status, 200) && res.data) {
        this.getTimesheetRecord();
      }
      if (res.request && res.request.response && res.request.status !== 200) {
        this.setState({ subLoading: false });
        document.body.click();
        let obj = JSON.parse(res.request.response);
        obj.msg ? window.alert(obj.msg) : window.alert('Something Went Wrong!');
        return;
      }
    }).catch((err) => {
      console.log(err)
      this.setState({ subLoading: false });
    })
  }

  handleActivityApprovalAction = (activity, activityHours) => {
    const { activityID, timesheetID } = activity;
    this.setState({
      selectedUserActivity: UserActivity.activityApproval,
      currentActivityId: activityID,
      currentTimesheet: activity,
      timesheetid: timesheetID,
      currentActivityTotalHours: toNumber(activityHours),
      displayConfirmationPopup: true
    })
  }

  handleTimesheetApprovalAction = (tDetails, total = 0.00) => {
    const { tid } = tDetails;
    this.setState({
      userApprovalComments: '',
      currentTimesheet: tDetails,
      timesheetid: tid,
      selectedUserActivity: UserActivity.timesheetApproval,
      currentActivityTotalHours: toNumber(total) || 0.00,
      displayConfirmationPopup: true
    })
  }

  handleUserAction = () => {
    const { currentActivityId, userApprovalComments, selectedUserActivity } = this.state;
    this.setState({ subLoading: true });
    let params = {
      timesheetID: this.state.timesheetid,
      madeBy: get(localStorage, 'userid', ''),
      reason: userApprovalComments
    }
    if (selectedUserActivity === UserActivity.activityApproval) {
      params.activityID = currentActivityId;
    }
    const request = {
      method: '',
      params
    }
    switch (selectedUserActivity) {
      case UserActivity.activityApproval:
        request.method = 'timesheets/activity-approve';
        break;
      case UserActivity.timesheetApproval:
        request.method = 'timesheets/approve';
        break;
      default:
        break;
    }
    apiPost(request, true).then((res) => {
      if (isEqual(res.status, 200) && res.data) {
        window.alert(`${selectedUserActivity === UserActivity.activityApproval ? 'Activity' : 'Timesheet'} has been approved.`);
        this.cancelPopup();
        this.getTimesheetRecord();
      }
      if (res.request && res.request.status !== 200) {
        let obj = JSON.parse(res.request.response);
        obj.msg ? window.alert(obj.msg) : window.alert('Something Went Wrong!');
        this.cancelPopup();
      }
    }).catch((err) => {
      this.setState({ subLoading: false });
    })
  }

  returnImage = (id, key, imgArr, altText, width, height = 50) => {
    const obj = find(imgArr, { [key]: id });
    return obj ? < img src={obj.src} width={width || 'auto'} height={height} alt={altText} /> : null
  }

  ExampleCustomInput = ({ value, onClick }) => (
    <div className="inner-addon right-addon">
      <i className="fa fa-calendar" onClick={onClick}></i>
      <input onClick={onClick} value={value} onChange={() => { }} type="text" className="form-control" placeholder="Select Date" name="date" />
    </div>
  );

  render() {
    const { totalHours, weekCount, tempObj, userApprovalComments, currentTimesheet,
      finalTimesheets, weekDays, overallTotals, personalDetails, actionLogs, selectedUserActivity, timesheetLoading, subLoading, approvedImage, activityApprovalImg, employeeApprovalImg, currentActivityTotalHours } = this.state;
    const biweekly = weekCount === 2 ? true : false;
    let week1Total = [];
    let week2Total = [];
    if (overallTotals.length > 0) {
      week1Total = overallTotals.slice(0, 7).map((dTotal) => dTotal.hours);
      week2Total = overallTotals.slice(7, 14).map((d1Total) => d1Total.hours);
    }
    const popoverComponent = (activityProps, activityDay) => (
      <Popover id={`popover-positioned-top`} className="timesheetpopover">
        <Popover.Title as="h6" className="background-green1 text-white">
          <span className="small_font">{personalDetails.userFirstname}, {personalDetails.userLastname}</span>
          <span
            aria-label="Close" className="float-right icon-button cursor-pointer"
            onClick={() => document.body.click()}
          >
            x
          </span>
        </Popover.Title>
        <Popover.Content>
          <div className="row p-3">
            <label className="col-xl-3 col-lg-3 col-md-3 col-sm-10 p-0 permission-label">Hour : </label>
            <div className="col-xl-7 col-lg-7 col-md-7 col-sm-10 p-0">
              <input
                type="text"
                className="form-control"
                placeholder=""
                value={this.state.punchOutTime}
                onChange={(evt) => this.setState({ punchOutTime: evt.target.value })}
              />
              {isEmpty(this.state.punchOutTime) && (<p className="text-danger mb-0">This is required</p>)}
            </div>
          </div>
          <div className="col-xl-12 col-lg-12 col-md-12 col-sm-12 p-0">
            <textarea
              className="form-control"
              placeholder="Reason for change (required)"
              value={this.state.punchOutComments}
              onChange={this.setPunchOutComments}
            />
            {isEmpty(this.state.punchOutComments) && (<p className="text-danger mb-0">This is required</p>)}
          </div>
          <div className="row mt-2 mx-0">
            <button
              disabled={(isEmpty(this.state.punchOutComments) && isEmpty(this.state.punchOutTime)) || this.state.subLoading}
              className="button resend-btn float-right px-4"
              onClick={() => this.updateHour(activityProps, activityDay)}
            >
              {this.state.subLoading ? 'Please Wait' : 'Save'}
            </button>
          </div>
        </Popover.Content>
      </Popover>
    );
    return (
      <React.Fragment>
        <ul className="pl-0 my-2">
          <button onClick={() => this.props.onBackClick()} className="p-0 cursor-pointer button resend-btn py-2 px-4 m-0 mr-2">Back</button>
        </ul>
        <div className="p-3 mb-3 small_font bg-amber border-0">
          <Row >
            <Col lg="5" md="5" sm="12">
              <span className="pr-3 font-weight-bold font-16">
                {personalDetails.userLastname ? personalDetails.userLastname + ',' : null} {personalDetails.userFirstname}
              </span>
            </Col>
            <Col lg="3" md="3" className="text-right" />
            <Col lg="2" md="2" className="text-right">
              <label className="act-text">Week Started</label>
            </Col>
            <Col lg="2" md="2" sm="12" className="pr-0">
              <div className="form-group row mb-0 mr-2">
                <DatePicker
                  selected={this.state.weeklyDate}
                  value={this.state.startWeekDate}
                  customInput={<this.ExampleCustomInput />}
                  showMonthDropdown
                  showYearDropdown
                  dropdownMode="select"
                  name="startDate"
                  className="form-control"
                  filterDate={this.isWeekday}
                  onChange={this.handleWeekChange}
                  dateFormat="yyyy-MM-dd"
                  placeholderText="yyyy-MM-dd"
                />
              </div>
            </Col>
          </Row>
        </div>
        {timesheetLoading ? 'Please Wait...' :
          <>
            <Row>
              <Col lg="12" md="12" sm="12">
                <table border='1' className="col-12 text-center text-black w-50">
                  <thead>
                    <tr>
                      <th colSpan='3' className="blue-head">
                        {`${get(personalDetails, 'userFirstname', '')} ${get(personalDetails, 'userLastname', '')}'s Accumulated Time`}
                      </th>
                    </tr>
                  </thead>
                  <tbody>
                    <tr>
                      <th style={{ width: '50%' }}>{`Week (${this.formatDate(this.state.startWeekDate)} - ${this.formatDate(this.state.weekEndDate)})`}</th>
                    </tr>
                    <tr className="blue-num">
                      <td className="font-weight-bold">{toNumber(totalHours) || '0.00'} Hrs</td>
                    </tr>
                  </tbody>
                </table>
              </Col>
            </Row>

            <div className="mt-3">
              <table border='1' className="w-100 text-black">
                <thead>
                  <tr>
                    <th colSpan='20' className="blue-head py-2">
                      <Row>
                        <Col lg="6" md="6" sm="12">
                          <div className="pl-2  float-left">
                            <span className="font-12">{biweekly ? 'BI' : ''} WEEKLY TIME SHEET</span>
                            <span className="small-font pl-2">
                              {`${this.formatDate(this.state.startWeekDate)} - ${this.formatDate(this.state.weekEndDate)}`}
                            </span>
                          </div>
                        </Col>
                        <Col lg="6" md="6" sm="12">
                          <div className="pr-2 float-right">
                            <span className="pr-2 font-12">{timesheet_status_codes[`${get(personalDetails, 'status', '')}`]}</span>
                            <span className="font-small">{`Due on : ${this.formatDate(moment(this.state.weekEndDate).subtract(1, 'day'))}`}</span>
                            <span className="px-1">|</span>
                            <i className="fa fa-print px-1"></i>
                            <i className="fa fa-file-pdf-o px-1"></i>
                          </div>
                        </Col>
                      </Row>
                    </th>
                  </tr>
                </thead>
                <tbody className="text-center">
                  <tr>
                    <td colSpan='2' className="font-weight-bold text-right pr-1">NAME:</td>
                    <td colSpan='18' className="pl-1 text-left">
                      {get(personalDetails, 'userLastname', '')}, {get(personalDetails, 'userFirstname', '')}
                    </td>
                  </tr>
                  <tr>
                    <td colSpan='2' className="font-weight-bold text-right pr-1">GROUP:</td>
                    <td colSpan='18' className="pl-1 text-left">{personalDetails.groupCode ? `${personalDetails.groupName} (${personalDetails.groupCode})` : 'N/A'}</td>
                  </tr>
                  <tr className="text-center font-small p-1 bg-lite-gray">
                    <th colSpan='2' width="10%"></th>
                    {weekDays.slice(0, 7).map((day, index) => (
                      <th key={`${day.day}${index}`} width="5%">{day.day}<br />{day.date}</th>
                    ))}
                    <th width="5%">Total<br />Hours</th>
                    <th width="5%">Initial</th>
                    {biweekly && <>
                      {weekDays.slice(7, 14).map((day, index) => (
                        <th key={`${day.day}${index}`} width="5%">{day.day}<br />{day.date}</th>
                      ))}
                      <th width="5%">Total<br />Hours</th>
                      <th width="5%">Initial</th>
                    </>}
                  </tr>
                  {tempObj && Object.values(tempObj).map((x, i) => {
                    let activityName = x.week1.activityName;
                    let w1finalClockIns = {}, w1UniqueHours = {}, w2finalClockIns = {}, w2UniqueHours = {};
                    const w1activityTotal = x.week1 && Object.values(DAYS_OF_WEEK).map((day) => x.week1[`${day.toLowerCase()}Hour`]).reduce((a, b) => Number(Number(a) + Number(b)).toFixed(2), 0);
                    const w2activityTotal = x.week2 && Object.values(DAYS_OF_WEEK).map((day) => x.week2[`${day.toLowerCase()}Hour`]).reduce((a, b) => Number(Number(a) + Number(b)).toFixed(2), 0);
                    if (x.week1 && x.week1.clockinouts && x.week1.clockinouts.length > 0) {
                      x.week1.clockinouts.map((x, i) => {
                        let objVal = `${ClockInOuts[x.type]}`;
                        if (w1UniqueHours[objVal]) {
                          if (w1UniqueHours[objVal].length > 0 && find(w1UniqueHours[objVal], { day: x.day, type: x.type })) {
                            w1UniqueHours[`${objVal}_${i}`] = [x];
                          } else {
                            w1UniqueHours[objVal].push(x);
                          }
                        } else {
                          w1UniqueHours[objVal] = [x];
                        }
                        return null;
                      })
                      Object.keys(DAYS_OF_WEEK).map((y) => {
                        Object.entries(w1UniqueHours).map((xdata) => {
                          w1finalClockIns[xdata[0]] = xdata[1];
                          const uniqueDays = xdata[1].map(x => x.day);
                          if (!uniqueDays.includes(Number(y))) {
                            if (xdata[0].includes('IN')) {
                              w1finalClockIns[xdata[0]].push({ day: Number(y), type: 1, clockAt: null });
                            } else {
                              w1finalClockIns[xdata[0]].push({ day: Number(y), type: 2, clockAt: null });
                            }
                          } else {
                            return null;
                          }
                          return null;
                        });
                        return null;
                      })
                    }
                    if (x.week2 && x.week2.clockinouts && x.week2.clockinouts.length > 0) {
                      x.week2.clockinouts.map((x, i) => {
                        let objVal = `${ClockInOuts[x.type]}`;
                        let tempDay = Number(x.day) + 7;
                        if (w2UniqueHours[objVal]) {
                          if (w2UniqueHours[objVal].length > 0 && find(w2UniqueHours[objVal], { day: tempDay, type: x.type })) {
                            w2UniqueHours[`${objVal}_${i}`] = [{ ...x, day: tempDay }];
                          } else {
                            w2UniqueHours[objVal].push({ ...x, day: tempDay });
                          }
                        } else {
                          w2UniqueHours[objVal] = [{ ...x, day: tempDay }];
                        }
                        return null;
                      })
                      Object.keys(BY_WEEKLY_DAYS_OF_WEEK).map((y) => {
                        Object.entries(w2UniqueHours).map((xdata) => {
                          w2finalClockIns[xdata[0]] = xdata[1]
                          const uniqueDays = xdata[1].map(x => x.day);
                          if (!uniqueDays.includes(Number(y))) {
                            if (xdata[0].includes('IN')) {
                              w2finalClockIns[xdata[0]].push({ day: Number(y), type: 1, clockAt: null });
                            } else {
                              w2finalClockIns[xdata[0]].push({ day: Number(y), type: 2, clockAt: null });
                            }
                          } else {
                            return null;
                          }
                          return null;
                        });
                        return null;
                      })
                    }
                    let finalData = {};
                    if (!isEmpty(w1finalClockIns)) {
                      Object.entries(w1finalClockIns).map((x) => {
                        if (!isEmpty(w2finalClockIns) && w2finalClockIns[x[0]]) {
                          finalData[x[0]] = [...x[1], ...w2finalClockIns[x[0]]]
                        }
                        else {
                          finalData[x[0]] = [...x[1], ...new Array(7)]
                        }
                        return null;
                      })
                    } else if (!isEmpty(w2finalClockIns)) {
                      Object.entries(w2finalClockIns).map((x) => {
                        if (!isEmpty(w1finalClockIns) && w1finalClockIns[x[0]]) {
                          finalData[x[0]] = [...w1finalClockIns[x[0]], ...x[1]]
                        }
                        else {
                          finalData[x[0]] = [...new Array(7), ...x[1]]
                        }
                        return null;
                      })
                    }
                    return <React.Fragment key={i}>
                      {!isEmpty(finalData) && Object.values(finalData).map((x, k) => {
                        const timeType = Object.keys(finalData)[k];
                        let w1 = x.slice(0, 7);
                        let w2 = x.slice(7, 14);
                        return <tr key={k}>
                          {k === 0 && (<td rowSpan={Object.values(finalData).length}>{activityName.toUpperCase()}</td>)}
                          <td >{timeType.split('_')[0]}</td>
                          {sortBy(w1, 'day').map((dt, i) => <td key={i}>{(dt && dt.clockAt) ? moment(dt.clockAt).format('h:mm A') : ''}</td>)}
                          <td ></td>
                          {biweekly && <>
                            {k === 0 && (<td rowSpan={Object.values(finalData).length}></td>)}
                            {sortBy(w2, 'day').map((dt, i) => <td key={i}>{(dt && dt.clockAt) ? moment(dt.clockAt).format('h:mm A') : ''}</td>)}
                            <td ></td>
                          </>}
                          {k === 0 && (<td rowSpan={Object.values(finalData).length}></td>)}
                        </tr>
                      })}
                      <tr className="time-td blue-text bg-lite-gray">
                        <td colSpan='2'>{`${x.week1.activityName.toUpperCase() || x.week2.activityName.toUpperCase()} HOURS`}</td>
                        {
                          Object.values(DAYS_OF_WEEK).map((day, index) => {
                            let multiIndex1 = {};
                            let objDate1 = {};
                            if (finalTimesheets[0].changeNotes.length > 0) {
                              finalTimesheets[0].changeNotes.map((ch) => {
                                const keyName1 = `${ch.activityName}_${ch.day}`;
                                if (objDate1 && objDate1[keyName1]) {
                                  let obj = objDate1[keyName1];
                                  objDate1[keyName1] = { ...objDate1[keyName1], index: [...obj.index, ch.index] };
                                } else {
                                  objDate1[keyName1] = { index: [ch.index], day: ch.day, activityID: ch.activityID };
                                }
                                if ((ch.activityID === x.week1.activityID) && DAYS_OF_WEEK[ch.day] === day) {
                                  if (objDate1[keyName1] && (objDate1[keyName1].index).length > 0) {
                                    multiIndex1 = objDate1[keyName1];
                                  }
                                };
                                return null;
                              });
                            }
                            return <OverlayTrigger trigger={x.week1.id !== 0 && "click"} key={index} placement='top' rootClose={true} overlay={popoverComponent(x.week1, index)}>
                              <td key={`${day}${index}`} className={`text-blue ${x.week1.id !== 0 && 'cursor-pointer'}`}>
                                {multiIndex1.index && <span title={multiIndex1.index.join(', ')} className={`${multiIndex1.index.length > 1 ? 'ptoCircleMultiple mr-2' : 'mr-1'} ptoCircle xs_font`}>{multiIndex1.index[0]}</span>}
                                <span className="cursor-pointer">
                                  {x.week1[`${day.toLowerCase()}Hour`] > 0 ? toNumber(x.week1[`${day.toLowerCase()}Hour`]) : null}&nbsp;
                                </span>
                              </td>
                            </OverlayTrigger>
                          })
                        }
                        <td >{w1activityTotal}</td>
                        <td className="vertical-align-bottom">
                          {x.week1.approvedBy === 0 ? (<div className="float-right">
                            <div className="guideList" onClick={() => x.week1.id !== 0 && this.handleActivityApprovalAction(x.week1, w1activityTotal)}>
                              <div className="active cursor-pointer">
                                <span className="activePointer"></span>
                                <span>SIGN</span>
                              </div>
                            </div>
                          </div>) : this.returnImage(x.week1.approvedBy, 'approvedBy', activityApprovalImg, 'approvalImage', 40, 30)}
                        </td>


                        {/* for 2nd Week */}
                        {biweekly && <>
                          {
                            Object.values(DAYS_OF_WEEK).map((day, index) => {
                              let multiIndex2 = {};
                              let objDate2 = {};
                              if (finalTimesheets[1].changeNotes.length > 0) {
                                finalTimesheets[1].changeNotes.map((ch) => {
                                  const keyName2 = `${ch.activityName}_${ch.day}`;
                                  if (objDate2 && objDate2[keyName2]) {
                                    let obj = objDate2[keyName2];
                                    objDate2[keyName2] = { ...objDate2[keyName2], index: [...obj.index, ch.index] };
                                  } else {
                                    objDate2[keyName2] = { index: [ch.index], day: ch.day, activityID: ch.activityID };
                                  }
                                  if ((ch.activityID === x.week2.activityID) && DAYS_OF_WEEK[ch.day] === day) {
                                    if (objDate2[keyName2] && (objDate2[keyName2].index).length > 0) {
                                      multiIndex2 = objDate2[keyName2];
                                    }
                                  };
                                  return null;
                                });
                              }
                              return <OverlayTrigger trigger={x.week2.id !== 0 && "click"} key={index} placement='top' rootClose={true} overlay={popoverComponent(x.week2, index)}>
                                <td key={`${day}${index}`} className={`text-blue ${x.week2.id !== 0 && 'cursor-pointer'}`}>
                                  {multiIndex2.index && <span title={multiIndex2.index.join(', ')} onClick={() => { }} className={`${multiIndex2.index.length > 1 ? 'ptoCircleMultiple mr-2' : 'mr-1'} ptoCircle xs_font`}>{multiIndex2.index[0]}</span>}
                                  <span className="cursor-pointer">
                                    {x.week2[`${day.toLowerCase()}Hour`] > 0 ? toNumber(x.week2[`${day.toLowerCase()}Hour`]) : null}
                                  </span>
                                </td>
                              </OverlayTrigger>
                            })
                          }
                          <td >{w2activityTotal}</td>
                          <td className="vertical-align-bottom">
                            {x.week2.approvedBy === 0 ? (<div className="float-right">
                              <div className="guideList" onClick={() => x.week2.id !== 0 && this.handleActivityApprovalAction(x.week2, w2activityTotal)}>
                                <div className="active cursor-pointer">
                                  <span className="activePointer"></span>
                                  <span>SIGN</span>
                                </div>
                              </div>
                            </div>) : this.returnImage(x.week2.approvedBy, 'approvedBy', activityApprovalImg, 'approvalImage', 40, 30)}
                          </td>
                        </>}
                      </tr>
                    </React.Fragment>
                  })}
                  <tr className="time-td blue-text bg-lite-gray">
                    <td colSpan='2'>TOTAL</td>
                    {week1Total.map((hour, rkey) => <td key={rkey}>{toNumber(hour) || 0.00}</td>)}
                    <td className="text-blue">{toNumber(sum(week1Total)) || 0.00}</td>
                    <td />
                    {biweekly && <>
                      {week2Total.map((hour2, rkey) => <td key={rkey}>{toNumber(hour2) || 0.00}</td>)}
                      <td className="text-blue">{toNumber(sum(week2Total)) || 0.00}</td>
                      <td />
                    </>}
                  </tr>
                  <tr>
                    <th colSpan='11' className="blue-head text-center py-2">
                      Timesheet Changes
                        </th>
                    {biweekly && <th colSpan='9' className="blue-head text-center py-2">
                      Timesheet Changes
                        </th>}
                  </tr>
                  <tr>
                    <td colSpan='11' className="py-2 text-left align-baseline">
                      {
                        get(finalTimesheets[0], 'changeNotes', []).map((timesheetChanges, timIndex) => {
                          let actualDay = DAYS_OF_WEEK[timesheetChanges.day];
                          let dateObject = find(weekDays, { day: actualDay });
                          return <p key={timIndex} className="pl-1 mb-1 small_font">
                            <span className="ptoCircleChg mr-2 text-center"><span className="d-block mt-1">{timesheetChanges.index}</span></span>
                            {timesheetChanges.activityName || ''} {moment(dateObject.fullDate).format('dddd (MMM DD, YYYY)')} : {timesheetChanges.reason} - Change made by {timesheetChanges.madeByFirstname} {timesheetChanges.madeByLastname}
                                &nbsp; on {moment(timesheetChanges.madeAt).format("hh:mm A MMM DD, YYYY")}.
                              </p>
                        })
                      }
                    </td>
                    {biweekly && <td colSpan='9' className="py-2 text-left align-baseline">
                      {
                        get(finalTimesheets[1], 'changeNotes', []).map((timesheetChanges, timIndex) => {
                          let actualDay = DAYS_OF_WEEK[timesheetChanges.day];
                          const biweekDays = weekDays.slice(7, 14);
                          const dateObject = find(biweekDays, { day: actualDay });
                          return <p key={timIndex} className="pl-1 mb-1 small_font">
                            <span className="ptoCircleChg mr-2 text-center"><span className="d-block mt-1">{timesheetChanges.index}</span></span>
                            {timesheetChanges.activityName || ''} {moment(dateObject.fullDate).format('dddd (MMM DD, YYYY)')} : {timesheetChanges.reason} - Change made by {timesheetChanges.madeByFirstname} {timesheetChanges.madeByLastname}
                                &nbsp; on {moment(timesheetChanges.madeAt).format("hh:mm A MMM DD, YYYY")}.
                              </p>
                        })
                      }
                    </td>}
                  </tr>
                  <tr>
                    <td colSpan={biweekly ? '20' : '11'} className="py-2"></td>
                  </tr>

                  {!isEmpty(finalTimesheets) && <tr>
                    {/* 1st week data */}
                    <td colSpan='2' className="pt-5 text-left">
                    </td>
                    <td colSpan='4' className="pt-5 text-left">
                      <p className="mb-0">
                        <span className="pl-1 pr-2 font-9">Employee Signature:</span>
                        {finalTimesheets[0] && finalTimesheets[0].status >= 300 ?
                          this.returnImage(finalTimesheets[0].uid, 'uid', employeeApprovalImg, 'employeeApprovalImg', 80, 30) : null}
                      </p>
                      <p className="mb-0">
                        <span className="pl-1 font-9">Date: </span>
                        <span className="pl-1 font-9">{finalTimesheets[0].submitDate || ''}</span>
                      </p>
                    </td>

                    <td colSpan='4' className="pt-5 text-left">
                      <p className="mb-0">
                        <span className="pl-1 pr-2 font-9">Approval Signature:</span>
                        {finalTimesheets[0] && finalTimesheets[0].status < 500 ? <div className="float-right">
                          <div className="guideList" onClick={() => finalTimesheets[0].tid !== 0 && this.handleTimesheetApprovalAction(finalTimesheets[0], sum(week1Total))}>
                            <div className="active cursor-pointer">
                              <span className="activePointer timesheetSign"></span>
                              <span className="pl-4">
                                SIGN
                                  </span>
                            </div>
                          </div>
                        </div> :
                          this.returnImage(finalTimesheets[0].approvedBy, 'approvedBy', approvedImage, 'approvalImage', 80, 30)}
                      </p>
                      <p className="mb-0">
                        <span className="pl-1 font-9">Date: </span>
                        <span className="pl-1 font-9">{finalTimesheets[0].approvalDate || ''}</span>
                      </p>
                    </td>
                    <td colspan="1" class="pt-5 text-left"></td>

                    {/* 2nd week data */}
                    {biweekly && <>
                      <td colSpan='4' className="pt-5 text-left">
                        <p className="mb-0">
                          <span className="pl-1 pr-2 font-9">Employee Signature:</span>
                          {finalTimesheets[1] && finalTimesheets[1].status >= 300 ?
                            this.returnImage(finalTimesheets[1].uid, 'uid', employeeApprovalImg, 'employeeApprovalImg', 80, 30) : null}
                        </p>
                        <p className="mb-0">
                          <span className="pl-1 font-9">Date: </span>
                          <span className="pl-1 font-9">{finalTimesheets[1].submitDate || ''}</span>
                        </p>
                      </td>
                      <td colSpan='4' className="pt-5 text-left">
                        <p className="mb-0">
                          <span className="pl-1 pr-2 font-9">Approval Signature:</span>
                          {finalTimesheets[1] && finalTimesheets[1].status < 500 ? <div className="float-right">
                            <div className="guideList" onClick={() => finalTimesheets[1].tid !== 0 && this.handleTimesheetApprovalAction(finalTimesheets[1], sum(week2Total))}>
                              <div className="active cursor-pointer">
                                <span className="activePointer timesheetSign"></span>
                                <span className="pl-4">
                                  SIGN
                                  </span>
                              </div>
                            </div>
                          </div> :
                            this.returnImage(finalTimesheets[1].approvedBy, 'approvedBy', approvedImage, 'approvalImage', 80, 30)}
                        </p>
                        <p className="mb-0">
                          <span className="pl-1 font-9">Date: </span>
                          <span className="pl-1 font-9">{finalTimesheets[1].approvalDate || ''}</span>
                        </p>
                      </td>
                      <td colspan="1" class="pt-5 text-left"></td>
                    </>}
                  </tr>}
                </tbody>
              </table>
              <table border='1' className="w-100 text-black">
                <thead>
                  <tr>
                    <th colSpan={biweekly ? '20' : '11'} className="blue-head text-center py-2">
                      Timesheet Action Tracking Log Report
                        </th>
                  </tr>
                </thead>
                <tbody>
                  <tr>
                    <td width="20%" className="text-left">Action By</td>
                    <td width="15%" className="text-left">Actor's IP</td>
                    <td width="20%" className="text-left">Date & Time</td>
                    <td width="45%" className="text-left">Action Taken</td>
                  </tr>
                  {actionLogs.length > 0 ? actionLogs.map((actionData, actionKey) => {
                    return <tr key={actionKey}>
                      <td width="20%" className="text-left">{actionData.userName}</td>
                      <td width="15%" className="text-left">{actionData.actionIp}</td>
                      <td width="20%" className="text-left">{moment(actionData.actionTime).format('MM/DD/YYYY HH:MM A')}</td>
                      <td width="45%" className="text-left">[ {actionData.actionType} ] {actionData.description}</td>
                    </tr>
                  }) : <tr><td colSpan={biweekly ? '20' : '11'}></td></tr>}
                  <tr>
                    <th colSpan={biweekly ? '20' : '11'} className="py-2 text-left">
                      Privacy Act Notification: "This information is subject to the Privacy Act of 1974, (Title 5, USC 522a)"
                        </th>
                  </tr>
                </tbody>
              </table>
            </div>
          </>
        }
        <Modal
          scrollable={true}
          size="md"
          onHide={() => this.cancelPopup()}
          show={this.state.displayConfirmationPopup}
        >
          <Modal.Header closeButton className="h6 background-green1">
            <Modal.Title className="h6 text-white small_font" id="contained-modal-title-vcenter">
              {`${isEqual(selectedUserActivity, UserActivity.activityApproval) ? 'Activity' : 'Timesheet'} Approval Confirmation`}
            </Modal.Title>
          </Modal.Header>
          <Modal.Body className="show-grid small_font px-5">
            {selectedUserActivity === UserActivity.activityApproval ?
              <p className="text-dark text-center">You are approving the {currentTimesheet.activityName} hours for the week of: </p>
              :
              <p className="text-dark text-center">You are approving the following timesheet for the week of: </p>
            }
            <p className="small_font font-weight-bold text-center">
              {getWeek(currentTimesheet.startDate, currentTimesheet.startDate, 'MMMM D, YYYY')}
            </p>
            {currentTimesheet.status !== 300 &&
              <div className="form-group row">
                <div className="col-lg-12 col-md-12 col-xl-12 col-sm-12 text-center">
                  <label htmlFor="exampleInputEmail1">Comment :</label>
                  <textarea
                    className="form-control"
                    value={userApprovalComments}
                    onChange={this.setUserApprovalComments}
                  />
                  {isEmpty(userApprovalComments) && (<p style={{ color: 'red' }}>This is required</p>)}
                </div>
              </div>}
            <p className="small_font text-center">
              <b>{`${get(personalDetails, 'userFirstname', '')}, ${get(personalDetails, 'userLastname', '')} - Total Hours ${currentActivityTotalHours}`}</b>
            </p>
          </Modal.Body>
          <Modal.Footer>
            <div className="col-12 row mt-2">
              <div className="col-6">
                <button
                  onClick={() => this.cancelPopup()}
                  className="button resend-btn background-red px-4 float-left"
                >
                  No, Cancel
                </button>
              </div>
              <div className="col-6">
                <button
                  disabled={(personalDetails.status !== 300 && isEmpty(userApprovalComments)) || subLoading}
                  onClick={this.handleUserAction}
                  className="button resend-btn float-right px-4"
                >
                  {subLoading ? 'Please Wait' : 'Yes, Confirm'}
                </button>
              </div>
            </div>
          </Modal.Footer>
        </Modal>
      </React.Fragment>
    );
  }
}

export default TimesheetChart;
