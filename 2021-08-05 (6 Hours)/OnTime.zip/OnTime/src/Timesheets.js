import React from 'react';
import { Container } from 'react-bootstrap';
import 'bootstrap/dist/css/bootstrap.min.css';
import './App.css';
import LoadTimesheetsTable from './components/LoadTimesheetsTable.js';

class Timesheets extends React.Component {
	render() {
		return (
			<div className="App">
				<Container>
					<div className="content">
						<div className="contentwrapper pt-3 pb-5">
							<LoadTimesheetsTable />
						</div>
					</div>
				</Container>
			</div>
		);
	}
}

export default Timesheets;
