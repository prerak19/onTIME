import React from 'react';

// Libs
import { get, find, isEmpty, isEqual, sortBy, every, sum, uniqBy } from 'lodash';
import moment from 'moment';
import { MDBDataTable, MDBBtn } from 'mdbreact';
import DatePicker from "react-datepicker";
import "react-datepicker/dist/react-datepicker.css";
import 'bootstrap/dist/css/bootstrap.min.css';
import '../App.css';
import { Modal, Row, Col, Popover, OverlayTrigger } from "react-bootstrap";
import { apiGet, apiPost } from '../Api.js';
import { timesheet_status, toNumber, timesheet_status_codes, isSmallScreenFunction, DAYS_OF_WEEK, employeeTypes, momentDate, fontOptions } from '../helpers/GeneralHelper';
import TimesheetChart from '../TimesheetChart';
import { getReuseSignInit, signImageUpload } from '../helpers/commonApi';

const TimesheetOperation = {
  approve: 1,
  reject: 2
};

const DashboardButtonFunctionality = {
  archivable: 1,
  archived: 2
};

class LoadTimesheetsTable extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      displayMassEntryForm: false,
      displayMassEntryDate: '',
      displayUserApprovalForm: false,
      approveTimesheet: false,
      selectedStartWeekDate: '',
      selectedEndWeekDate: '',
      finalData: null,
      approvedcount: false,
      archivedcount: false,
      approveCounter: 0,
      timesheetstatus: 'Submitted',
      timesheetStatusCode: 300,
      displayas: 'Weekly',
      startweeklyDate: '',
      endweeklyDate: '',
      summaryDetails: {},
      rowresult: [],
      activeTimeSheetId: null,
      currentRecordingPeriod: false,
      employeeType: '',
      employeeTypeCode: '',
      activityId: '',
      selectedTimesheets: [],
      isSelectAll: false,
      activityDropdownOptions: [
        {
          actID: 0,
          name: 'All'
        }
      ],
      massEntryActivitiesDD: [],
      activityColumns: [],
      approveBtnDisabled: true,
      rejectBtnDisabled: true,
      massEntryHour: '',
      massEntryComments: '',
      massEntryActivity: '',
      massEntryDate: '',
      massEntryFormSubmitBtn: false,
      uniqueActivityTableCols: [],
      selectedTimesheetOperation: null,
      validTimeSheetDataArr: [],
      isUserCommentRequired: false,
      userComments: '',
      displayWarningModal: false,
      selectedButtonFunctionality: null,
      isSmallScreen: false,

      savedFuture: true,
      savedSign: true,

      signatureOutput: '',
      signatureText: '',
      signatureFont: fontOptions[0].value,
      signType: 'type',
      currentSignId: "",
      signatureImage: '',

      initialOutput: '',
      initialText: '',
      initialFont: fontOptions[0].value,
      initialType: 'type',
      currentInitialId: '',
      initialImage: '',
    };
    this.onResize = this.onResize.bind(this);
  }

  componentDidMount = () => {
    this.setCurrentRecordingPeriod(false);
    this.getActivitiesInOrganisation();
    this.onResize();
    window.addEventListener('resize', (e) => {
      this.onResize();
    });
  }

  componentWillUnmount() {
    window.removeEventListener('resize', this.onResize);
  }

  onResize() {
    this.setState({
      isSmallScreen: isSmallScreenFunction()
    }, () => {
      if (this.state.finalData) {
        this.getTimesheetsData(this.state.finalData);
      }
    });
  }


  selectAllHandler = (evt) => {
    const isChecked = evt.target.checked;
    this.setState({
      isSelectAll: isChecked
    }, () => {
      this.setState({
        selectedTimesheets: isChecked ? this.state.rowresult.map(res => res.tid.toString()) : []
      }, () => {
        this.setState({
          rowresult: this.state.rowresult.map((x, i) => {
            return {
              ...x, check: (
                <input
                  key={`${x.tid}`}
                  type='checkbox'
                  id={`${x.tid}`}
                  value={`${x.tid}`}
                  checked={this.state.selectedTimesheets.includes(`${x.tid}`)}
                  onChange={(e) => this.checkboxHandler(e.target.value, e.target.checked)}
                />
              )
            }
          }),
          approveBtnDisabled: this.state.selectedTimesheets.length < 1,
          rejectBtnDisabled: this.state.selectedTimesheets.length < 1,
        })
      })
    })
  }

  handleStartWeekChange = (date) => {
    this.setState({
      selectedStartWeekDate: date,
      startweeklyDate: moment(date).format('YYYY-MM-DD'),
      currentRecordingPeriod: false
    }, () => {
      this.getSummary(date, this.state.endweeklyDate);
      this.getTimesheets(date, this.state.endweeklyDate);
    })
  }

  handleEndWeekChange = (date) => {
    this.setState({
      selectedEndWeekDate: date,
      endweeklyDate: moment(date).format('YYYY-MM-DD'),
      currentRecordingPeriod: false
    }, () => {
      this.getSummary(this.state.startweeklyDate, date);
      this.getTimesheets(this.state.startweeklyDate, date);
    })
  }

  changeStatus = (evt) => {
    const timeSheetFilterStatus = evt.target.value;
    const status = find(timesheet_status, { name: timeSheetFilterStatus });
    this.setState({
      timesheetstatus: timeSheetFilterStatus,
      timesheetStatusCode: isEqual(timeSheetFilterStatus, 'all') ? '' : parseInt(status.code),
    }, () => {
      this.getSummary(this.state.startweeklyDate, this.state.endweeklyDate);
      this.getTimesheets(this.state.startweeklyDate, this.state.endweeklyDate);
    });
  }

  isWeekday = (date) => {
    const day = date.getDay()
    return day === 0
  }

  ExampleCustomInput = ({ value, onClick }) => (
    <div className="inner-addon right-addon">
      <i className="fa fa-calendar" onClick={onClick}></i>
      <input onClick={onClick} value={value} onChange={() => { }} type="text" className="form-control" placeholder="Select Date" name="date" />
    </div>
  );

  getSummary = (sunday, nextSunday) => {
    const requestDetails = {
      method: `timesheets/summary/${localStorage.orgid}`,
      params: {
        from: !isEmpty(sunday.toString()) ? moment(sunday).format('YYYY-MM-DD') : '',
        to: !isEmpty(nextSunday.toString()) ? moment(nextSunday).format('YYYY-MM-DD') : ''
      }
    };

    apiGet(requestDetails, true).then((response) => {
      this.setState({
        summaryDetails: response.data,
        selectedTimesheets: [],
        validTimeSheetDataArr: [],
        approveCounter: 0,
        approveBtnDisabled: true,
        rejectBtnDisabled: true,
        empName: ''
      });
    }).catch(error => {
      console.log(error);
    });
  }


  getActivitiesInOrganisation = () => {
    const request = {
      method: `activities/all/${localStorage.orgid}`,
      params: {}
    }

    apiGet(request, true).then((res) => {
      if (!isEmpty(res.data)) {
        const activityInfo = []
        res.data.forEach((activity) => {
          activityInfo.push({
            actID: activity.actID,
            name: activity.name
          });
        })
        this.setState({
          activityDropdownOptions: [
            ...this.state.activityDropdownOptions,
            ...activityInfo
          ],
        })
      }
    }).catch(err => {
      console.log(err);
    })
  }

  checkboxHandler = (timesheetId, checked) => {
    const timesheet = this.state.selectedTimesheets.find(checkboxId => isEqual(checkboxId, timesheetId));
    if (isEmpty(timesheet)) {
      this.setState({
        selectedTimesheets: [
          ...this.state.selectedTimesheets,
          timesheetId
        ]
      }, () => {
        let timesheetStatusArr = [...this.state.validTimeSheetDataArr, find(this.state.rowresult, { tid: parseInt(timesheetId) })];
        if (checked === false) {
          timesheetStatusArr = timesheetStatusArr.filter((x) => x.tid !== Number(timesheetId));
        }
        this.setState({
          rowresult: this.state.rowresult.map((x, i) => {
            if (x.tid === Number(timesheetId)) {
              return {
                ...x,
                check: (
                  <input
                    key={`${x.tid}`}
                    type='checkbox'
                    id={`${x.tid}`}
                    value={`${x.tid}`}
                    checked={this.state.selectedTimesheets.includes(`${x.tid}`)}
                    onChange={(e) => this.checkboxHandler(e.target.value, e.target.checked)}
                  />
                ),
              }
            }
            else {
              return x;
            }
          }),
          isSelectAll: this.state.selectedTimesheets.length === this.state.rowresult.length,
          approveBtnDisabled: this.state.selectedTimesheets.length < 1,
          rejectBtnDisabled: this.state.selectedTimesheets.length < 1,
          validTimeSheetDataArr: timesheetStatusArr,
        })
      })
    } else {
      this.setState({
        selectedTimesheets: this.state.selectedTimesheets.filter(checkboxId => !isEqual(checkboxId, timesheetId))
      }, () => {
        let timesheetStatusArr = [...this.state.validTimeSheetDataArr, find(this.state.rowresult, { tid: parseInt(timesheetId) })];
        if (checked === false) {
          timesheetStatusArr = timesheetStatusArr.filter((x) => x.tid !== Number(timesheetId));
        }
        this.setState({
          rowresult: this.state.rowresult.map((x, i) => {
            if (x.tid === Number(timesheetId)) {
              return {
                ...x,
                check: (
                  <input
                    key={`${x.tid}`}
                    type='checkbox'
                    id={`${x.tid}`}
                    value={`${x.tid}`}
                    checked={this.state.selectedTimesheets.includes(`${x.tid}`)}
                    onChange={(e) => this.checkboxHandler(e.target.value, e.target.checked)}
                  />
                ),
              }
            }
            else {
              return x;
            }
          }),
          isSelectAll: this.state.selectedTimesheets.length === this.state.rowresult.length,
          approveBtnDisabled: this.state.selectedTimesheets.length < 1,
          rejectBtnDisabled: this.state.selectedTimesheets.length < 1,
          validTimeSheetDataArr: timesheetStatusArr,
        })
      })
    }
  }

  getTimesheets = (sunday, nextSunday) => {
    const requestDetails = {
      method: 'timesheets/management',
      params: {
        from: !isEmpty(sunday.toString()) ? moment(sunday).format('YYYY-MM-DD') : '',
        to: !isEmpty(nextSunday.toString()) ? moment(nextSunday).format('YYYY-MM-DD') : '',
        approver_id: localStorage.userid,
        org_id: localStorage.orgid,
        status: this.state.timesheetStatusCode,
        employee_type: this.state.employeeTypeCode,
        activity_id: this.state.activityId
      }
    };
    apiGet(requestDetails, true).then((response) => {
      const result = get(response.data, 'timsheets', []);
      this.getTimesheetsData(result);
    }).catch(error => {
      console.log(error);
    });
  }

  getTimesheetsData = (result) => {
    const { isSmallScreen } = this.state;
    const arr = [];
    const activityTimesheetInfo = [];
    const activityTableColumns = [];
    result.forEach((timesheet) => {
      const activityTypes = timesheet.activityTime;
      activityTypes.forEach((activity) => {
        activityTableColumns.push({
          id: activity.activityID,
          label: <div><span className="d-inline-flex align-items-center">{activity.activityName} {activity.allowExtra === 1 && <i className="fa fa-clock-o text-danger ml-2" title="Extra Hour Allowance"></i>}</span><br />Hours</div>,
          field: `${activity.activityName}`.toLowerCase(),
          width: 150
        })
        activityTimesheetInfo.push({
          timesheetId: activity.timesheetID,
          activityId: activity.activityID,
          label: <div><span className="d-inline-flex align-items-center">{activity.activityName} {activity.allowExtra === 1 && <i className="fa fa-clock-o text-danger ml-2" title="Extra Hour Allowance"></i>}</span><br />Hours</div>,
          width: 150,
          field: `${activity.activityName}`.toLowerCase(),
          totalHours: Object.values(DAYS_OF_WEEK).map((day) => activity[`${day.toLowerCase()}Hour`]).reduce((a, b) => Number(Number(a) + Number(b)).toFixed(2), 0)
        })
      })
    });
    const uniqueActivityTableCols = [];
    !isEmpty(activityTableColumns) && activityTableColumns.forEach((col) => {
      const record = uniqueActivityTableCols.filter((uniqueCol) => uniqueCol.id === col.id)
      if (isEmpty(record)) {
        uniqueActivityTableCols.push(col);
      }
    })
    const activityHours = (timesheetId) => {
      const rowValues = [];
      uniqueActivityTableCols.forEach((col) => {
        const record = find(activityTimesheetInfo, { timesheetId, activityId: col.id });
        rowValues.push({
          [col.field]: isEmpty(record) ? '0.00' : toNumber(record.totalHours),
        })
      })
      return Object.assign({}, ...rowValues);
    }
    Array.isArray(result) && result.map((item) => {
      const totalHours = item.regularHours + item.overtimeHours;
      const extraHour = item.activityTime.length > 0 && item.activityTime.find((x) => {
        const ttlHrs = sum(Object.values(DAYS_OF_WEEK).map((day) => x[`${day.toLowerCase()}Hour`]));
        return ttlHrs > 0 && x.allowExtra === 1
      });
      arr.push({
        ...item,
        check: (
          <input
            key={`${item.tid}`}
            type='checkbox'
            id={`${item.tid}`}
            value={`${item.tid}`}
            checked={false}
            onChange={(e) => this.checkboxHandler(e.target.value, e.target.checked)}
          />
        ),
        start: (<span>
          {!isEmpty(extraHour) ?
            <OverlayTrigger rootClose trigger="click" placement="top" overlay={<Popover>
              <Popover.Title className="bg-danger text-white">
                <span>Extra Hour Allowance</span>
                <i className="fa fa-close float-right" onClick={() => document.body.click()}></i>
              </Popover.Title>
              <Popover.Content>
                {item.userLastname} {item.userFirstname} is working on {extraHour.activityName} where extra hours are allowed for this week, and has currently used {toNumber(item.overtimeHours)} hours of the max {toNumber(extraHour.maxOT)} extra hours allowed.
              </Popover.Content>
            </Popover>}>
              <i className="fa fa-clock-o text-danger mr-2" />
            </OverlayTrigger>
            :
            (isEmpty(extraHour) && item.regularHours >= 39) ?
              <OverlayTrigger rootClose trigger="click" placement="top" overlay={<Popover>
                <Popover.Title className="bg-orange text-white">
                  <span>Extra Hours Warning</span>
                  <i className="fa fa-close float-right" onClick={() => document.body.click()}></i>
                </Popover.Title>
                <Popover.Content>
                  {item.userLastname} {item.userFirstname}
                  {item.regularHours >= 39 && item.regularHours < 40 ? ' is less than 1 hour away from reaching 40 hours for the week ' : ' has more than 40 hours for the week '}
                  and is not currently authorized to work over 40 hours.
              </Popover.Content>
              </Popover>}>
                <i className="fa fa-exclamation-triangle text-warning mr-2" />
              </OverlayTrigger>
              :
              <i className="mr-3" />}
          <a title={moment(item.startDate).format('YYYY-MM-DD')}
            // href="javascript:void(0);"
            onClick={() => this.setState({ activeTimeSheetId: item.tid })}
            className="text-decoration-underline blue-color p-0 cursor-pointer"
          >
            {isSmallScreen ? moment(item.startDate).format('MM-DD') : moment(item.startDate).format('YYYY-MM-DD')}
          </a></span>),
        timesheetStatus: item.status,
        status: timesheet_status_codes[`${item.status}`],
        last_name: item.userLastname,
        first_name: item.userFirstname,
        total: <div
          className={`${!isEmpty(extraHour) && totalHours > 40 ? 'bg-danger text-white' : ''}
          ${(isEmpty(extraHour) && item.regularHours >= 39) ? 'bg-orange etxt-white' : ''}`}>
          {toNumber(totalHours)}
        </div>,
        overtime: toNumber(item.overtimeHours),
        maxot: !isEmpty(extraHour) ? toNumber(extraHour.maxOT) : 0.00,
        regular: toNumber(item.regularHours),
        ...activityHours(item.tid)
      })
      return null;
    });
    this.setState({
      rowresult: arr,
      finalData: result,
      selectedTimesheets: [],
      validTimeSheetDataArr: [],
      approveCounter: 0,
      empName: '',
      approveBtnDisabled: true,
      rejectBtnDisabled: true,
      uniqueActivityTableCols,
      isSelectAll: false
    });
  }

  setCurrentRecordingPeriod = (checkboxState) => {
    this.setState({ currentRecordingPeriod: !checkboxState });
    const getRequest = {
      method: `timesheets/cur-rec-period/${localStorage.orgid}`,
      params: {}
    };
    apiGet(getRequest, true).then((response) => {
      if (isEqual(response.status, 200) && response.data) {
        const start = response.data.startDate;
        const end = response.data.endDate;
        this.setState({
          selectedStartWeekDate: momentDate(start),
          selectedEndWeekDate: momentDate(end),
          startweeklyDate: moment(start).format('YYYY-MM-DD'),
          endweeklyDate: moment(end).format('YYYY-MM-DD')
        }, () => {
          this.getSummary(start, end);
          this.getTimesheets(start, end);
        });
      }
    }).catch(error => {
      this.setState({
        selectedStartWeekDate: momentDate(),
        selectedEndWeekDate: momentDate(),
        startweeklyDate: moment().format('YYYY-MM-DD'),
        endweeklyDate: moment().format('YYYY-MM-DD')
      });
    });
  }

  filterByEmployeeType = (evt) => {
    const employeeType = evt.target.value;
    const status = find(employeeTypes, { name: employeeType });
    this.setState({
      employeeType,
      employeeTypeCode: isEqual(employeeType, 'all') ? '' : parseInt(status.code)
    }, () => {
      this.getSummary(this.state.startweeklyDate, this.state.endweeklyDate);
      this.getTimesheets(this.state.startweeklyDate, this.state.endweeklyDate);
    });
  }

  filterByActivity = (evt) => {
    const activityCode = evt.target.value;
    this.setState({
      activityId: isEqual(activityCode, '0') ? '' : parseInt(activityCode)
    }, () => {
      this.getSummary(this.state.startweeklyDate, this.state.endweeklyDate);
      this.getTimesheets(this.state.startweeklyDate, this.state.endweeklyDate);
    });
  }

  signatureChange = (name, value, fontValue) => {
    this.setState({ [`${name}Text`]: value, [`${name}Font`]: fontValue });
    if (value && fontValue) {
      var tCtx = document.createElement('canvas').getContext('2d');
      tCtx.canvas.width = (tCtx.measureText(value).width * 4) + 10;
      tCtx.canvas.height = 70;
      tCtx.font = `40px ${fontValue}`;
      tCtx.fillText(value, 0, 40);
      this.setState({ [`${name}Output`]: tCtx.canvas.toDataURL() });
    } else {
      this.setState({ [`${name}Output`]: '' });
    }
  }

  completeTimesheetOperation = async () => {
    const { currentSignId, currentInitialId, userComments, savedSign, signatureOutput, initialOutput, savedFuture,
      validTimeSheetDataArr, approveCounter, selectedTimesheetOperation } = this.state;
    const tId = validTimeSheetDataArr[approveCounter - 1].tid;
    let imgParams = {};
    if (selectedTimesheetOperation === 1) {
      if (savedSign) {
        imgParams.initID = currentInitialId;
        imgParams.sigID = currentSignId;
      }
      if (!savedSign && signatureOutput && initialOutput) {
        imgParams.sigID = await signImageUpload(signatureOutput, savedFuture);
        imgParams.initID = await signImageUpload(initialOutput, savedFuture, 'user_initial');
      }
    }
    if (imgParams.sigID && imgParams.initID) {
      this.setState({ approveTimesheet: true });
      const request = {
        method: selectedTimesheetOperation === 1 ? 'timesheets/approve' : 'timesheets/disapprove',
        params: {
          timesheetID: tId,
          madeBy: localStorage.userid,
          reason: userComments,
          ...imgParams
        }
      };
      await apiPost(request).then((res) => {
        if (res && res.data && res.status === 200) {
          if (validTimeSheetDataArr.length > 1 && approveCounter !== validTimeSheetDataArr.length) {
            let timeObj = validTimeSheetDataArr[approveCounter];
            const minDate = moment(timeObj.startDate);
            const sunday = moment(minDate).day(0).format('ddd MMM DD, YYYY');
            const nextSunday = moment(minDate).day(6).format('ddd MMM DD, YYYY');
            this.setState({
              approveCounter: approveCounter + 1,
              displayMassEntryDate: `${sunday} - ${nextSunday}`,
              isUserCommentRequired: timeObj.timesheetStatus < 300 ? true : false,
              userComments: '',
              empName: `${timeObj.userFirstname} ${timeObj.userLastname}`,
              approveTimesheet: false,
            });
          } else {
            if (approveCounter === validTimeSheetDataArr.length) {
              const message = `${approveCounter} out of ${this.state.selectedTimesheets.length} selected timesheet${approveCounter > 1 ? 's' : ''} successfully ${this.state.selectedTimesheetOperation === 1 ? 'approved' : 'rejected'}`
              window.alert(message);
              this.closeUserApprovalForm();
            }
          }
        } else {
          if (res.request && res.request.response && res.request.status !== 200) {
            const obj = JSON.parse(res.request.response);
            window.alert(obj.msg || 'Something Went Wrong');
            return;
          }
        }
      }).catch((err) => console.log(err));
    } else {
      window.alert('Please Type In Signature & Initial');
      return;
    }
  }

  openUserApprovalForm = async () => {
    const { validTimeSheetDataArr } = this.state;
    const minDate = Math.min(...validTimeSheetDataArr.map(e => moment(e.startDate)));
    const sunday = moment(minDate).day(0).format('ddd MMM DD, YYYY');
    const nextSunday = moment(minDate).day(6).format('ddd MMM DD, YYYY');
    const signObj = await getReuseSignInit();
    const initialObj = await getReuseSignInit(true);
    this.setState({
      displayUserApprovalForm: true,
      approveCounter: 1,
      displayMassEntryDate: `${sunday} - ${nextSunday}`,
      currentSignId: signObj.imageId,
      signatureImage: signObj.signatureImage,
      currentInitialId: initialObj.imageId,
      initialImage: initialObj.signatureImage,
      savedSign: signObj.imageId && initialObj.imageId ? true : false
    });
  }

  openWarningModal = (buttonNumber) => {
    const { validTimeSheetDataArr } = this.state;
    const minDate = Math.min(...validTimeSheetDataArr.map(e => moment(e.startDate)));
    const sunday = moment(minDate).day(0).format('ddd MMM DD, YYYY');
    const nextSunday = moment(minDate).day(6).format('ddd MMM DD, YYYY');
    this.setState({
      selectedButtonFunctionality: buttonNumber,
      displayMassEntryDate: `${sunday} - ${nextSunday}`,
      displayWarningModal: true,
    });
  }

  closeUserApprovalForm = () => {
    this.setState({
      displayUserApprovalForm: false,
      selectedTimesheetOperation: null,
      isUserCommentRequired: false,
      userComments: '',
      displayMassEntryDate: '',
      empName: '',
      savedFuture: true, savedSign: true,
      approveTimesheet: false,
      signatureText: '', signatureFont: fontOptions[0].value, signatureImage: '', currentSignId: '', signatureOutput: '', signType: 'type',
      initialText: '', initialFont: fontOptions[0].value, currentInitialId: '', initialImage: '', initialOutput: '', initialType: 'type',
    }, () => {
      this.getSummary(this.state.startweeklyDate, this.state.endweeklyDate);
      this.getTimesheets(this.state.startweeklyDate, this.state.endweeklyDate);
    })
  }

  approveOrRejectTimesheets = (operation) => {
    const { displayUserApprovalForm, selectedTimesheets, rowresult } = this.state;
    if (!displayUserApprovalForm) {
      const timesheetIds = selectedTimesheets;
      let timesheetStatusArr = [];
      timesheetIds.map((x, i) => (timesheetStatusArr = [...timesheetStatusArr, find(rowresult, { tid: parseInt(x) })]));
      timesheetStatusArr = sortBy(timesheetStatusArr, (value) => value.startDate);
      if (!isEmpty(timesheetStatusArr)) {
        switch (operation) {
          case 1:
            this.setState({
              validTimeSheetDataArr: timesheetStatusArr,
              isUserCommentRequired: timesheetStatusArr[0].timesheetStatus < 300 ? true : false,
              selectedTimesheetOperation: operation,
              empName: `${timesheetStatusArr[0].userFirstname} ${timesheetStatusArr[0].userLastname}`
            }, () => {
              return this.openUserApprovalForm()
            })
            break;
          case 2:
            this.setState({
              validTimeSheetDataArr: timesheetStatusArr,
              isUserCommentRequired: true,
              selectedTimesheetOperation: operation,
              empName: `${timesheetStatusArr[0].userFirstname} ${timesheetStatusArr[0].userLastname}`
            }, () => {
              return this.openUserApprovalForm()
            })
            break;
          default:
            break;
        }
      }
    }
  }

  updateTimesheetStatusToArchivedOrArchivable = () => {
    const { validTimeSheetDataArr } = this.state;
    const validTimesheets = [];
    const timesheetIds = this.state.selectedTimesheets;
    if (!isEmpty(timesheetIds)) {
      timesheetIds.forEach((timesheetId) => {
        switch (this.state.selectedButtonFunctionality) {
          case DashboardButtonFunctionality.archivable:
            const archivableSt = find(validTimeSheetDataArr.filter((x) => x.timesheetStatus === 500), { tid: parseInt(timesheetId) });
            if (archivableSt) {
              validTimesheets.push(parseInt(timesheetId));
            }
            break;
          case DashboardButtonFunctionality.archived:
            const archivedSt = find(validTimeSheetDataArr.filter((x) => x.timesheetStatus === 600), { tid: parseInt(timesheetId) });
            if (archivedSt) {
              validTimesheets.push(parseInt(timesheetId));
            }
            break;
          default:
            break;
        }
      })
    }

    if (!isEmpty(validTimesheets)) {
      const request = {
        method: this.state.selectedButtonFunctionality === DashboardButtonFunctionality.archivable
          ? 'timesheets/set-archivable' : 'timesheets/set-archived',
        params: {
          tidList: validTimesheets,
          madeBy: localStorage.userid
        }
      }
      apiPost(request, true).then((response) => {
        const message = `${validTimesheets} out of ${this.state.selectedTimesheets.length} selected timesheet's successfully ${this.state.selectedButtonFunctionality === 1 ? 'archivable' : 'archived'}.`
        window.alert(message);
        this.getSummary(this.state.startweeklyDate, this.state.endweeklyDate);
        this.getTimesheets(this.state.startweeklyDate, this.state.endweeklyDate);
        this.closeWarningModal();
      }).catch((error) => {
        console.log(error);
      });
    }
  }

  onSubmitMassTimeEntry = () => {
    const request = {
      method: 'timesheets/masshour',
      params: {
        tidList: this.state.selectedTimesheets.map((timesheetId) => parseInt(timesheetId)),
        activityID: parseInt(this.state.massEntryActivity),
        day: moment(this.state.massEntryDate).day(),
        hour: this.state.massEntryHour,
        reason: this.state.massEntryComments,
        madeBy: localStorage.userid
      }
    };
    apiPost(request, true).then((res) => {
      this.getSummary(this.state.startweeklyDate, this.state.endweeklyDate);
      this.getTimesheets(this.state.startweeklyDate, this.state.endweeklyDate);
      this.cancelMassEntry();
    }).catch((error) => {
      console.log(error);
    });
  }

  closeWarningModal = () => {
    this.setState({
      displayWarningModal: false,
      selectedButtonFunctionality: null,
      displayMassEntryDate: '',
    }, () => {
      this.getSummary(this.state.startweeklyDate, this.state.endweeklyDate);
      this.getTimesheets(this.state.startweeklyDate, this.state.endweeklyDate);
    })
  }

  openMassEntryForm = () => {
    const { rowresult, selectedTimesheets } = this.state;
    if (selectedTimesheets.length < 2) {
      window.alert('Please Select more then 1 timesheets with Same week for Mass Entry!');
      return;
    }
    const arr = rowresult.filter((x, i) => selectedTimesheets.includes(`${x.tid}`));
    let massEntryActivitiesDD = [];
    arr.map((x) => {
      if (x.activityTime && x.activityTime.length > 0) {
        x.activityTime.map((activity) => {
          massEntryActivitiesDD.push({
            actID: activity.activityID,
            name: activity.activityName
          });
          return null;
        })
      }
      return null;
    })

    const lookup = massEntryActivitiesDD.reduce((a, e) => {
      a[e.actID] = ++a[e.actID] || 0;
      return a;
    }, {});
    massEntryActivitiesDD = uniqBy(massEntryActivitiesDD.filter(e => lookup[e.actID]), 'actID');

    const maxDate = Math.max(...arr.map(e => moment(e.startDate)));
    const minDate = Math.min(...arr.map(e => moment(e.startDate)));
    if (moment(minDate).format('YYYY-MM-DD') === moment(maxDate).format('YYYY-MM-DD')) {
      const sunday = moment(minDate).day(0).format('ddd MMM DD, YYYY');
      const nextSunday = moment(minDate).day(6).format('ddd MMM DD, YYYY');
      this.setState({
        displayMassEntryForm: true,
        massEntryActivitiesDD,
        massEntryActivity: massEntryActivitiesDD.length > 0 ? massEntryActivitiesDD[0].actID : null,
        displayMassEntryDate: `${sunday} - ${nextSunday}`
      })
    } else {
      window.alert('Please Select Same week for Mass Entry!');
      return;
    }
  }

  cancelMassEntry = () => {
    this.setState({
      displayMassEntryForm: false,
      displayMassEntryDate: '',
      massEntryActivity: '',
      massEntryActivitiesDD: [],
      massEntryComments: '',
      massEntryDate: '',
      massEntryHour: ''
    });
  }

  render() {
    const { isSelectAll, uniqueActivityTableCols, rowresult, selectedButtonFunctionality, currentRecordingPeriod, selectedStartWeekDate, selectedEndWeekDate, startweeklyDate,
      endweeklyDate, timesheetstatus, activityDropdownOptions, summaryDetails, approveBtnDisabled, rejectBtnDisabled, selectedTimesheets, displayMassEntryForm,
      displayMassEntryDate, massEntryDate, massEntryActivity, massEntryActivitiesDD, massEntryHour, massEntryComments, displayUserApprovalForm, selectedTimesheetOperation, displayWarningModal,
      validTimeSheetDataArr, empName, userComments, isUserCommentRequired, activeTimeSheetId, isSmallScreen, savedSign, savedFuture, signatureImage, approveTimesheet,
      signType, signatureFont, signatureOutput, signatureText, initialType, initialFont, initialOutput, initialText, initialImage,
    } = this.state;
    if (activeTimeSheetId) {
      return <TimesheetChart
        id={activeTimeSheetId}
        onBackClick={() => {
          this.getTimesheets(startweeklyDate, endweeklyDate)
          this.setState({ activeTimeSheetId: null })
        }}
      />
    }

    const defaultColumns = [
      {
        label: 'Week Start',
        field: 'start',
      },
      {
        label: 'Status',
        field: 'status',
      },
      {
        label: 'Last Name',
        field: 'last_name',
      },
      {
        label: 'First Name',
        field: 'first_name',
      },
      {
        label: 'Ttl Hrs',
        field: 'total',
      },
      {
        label: (<span>Overtime<br /> Hours</span>),
        field: 'overtime',
      },
      {
        label: (<span>Max OT<br /> Allowed</span>),
        field: 'maxot',
      },
      {
        label: (isSmallScreen ? <span title="Regular Hours <=40">{'Regular Hours'} </span> : <span>{'Regular Hours'} <br />{' <= 40'}</span>),
        field: 'regular',
      },
    ];

    const datatable = {
      columns: [
        {
          label: (
            <input
              type="checkbox"
              id="colhead_checkbox"
              onChange={this.selectAllHandler}
              checked={isSelectAll}
            />
          ),
          field: 'check'
        },
        ...defaultColumns,
      ],
      rows: rowresult,
    }

    const activityDataTable = {
      columns: uniqueActivityTableCols,
      rows: rowresult,
    }
    return (
      <React.Fragment>
        <div className="p-3 mb-3 small_font bg-amber border-0">
          <Row>
            <Col lg="4" md="4" sm="12">
              <label className="pr-2 float-left">Date Range : </label>
              <input
                style={{ float: 'left', width: '25px', marginTop: '3px' }}
                type="checkbox"
                name="current-recording"
                className="form-control"
                onChange={() => this.setCurrentRecordingPeriod(currentRecordingPeriod)}
                checked={currentRecordingPeriod}
              />
              <label
                onClick={() => this.setCurrentRecordingPeriod(currentRecordingPeriod)}
                style={{ fontSize: '9pt' }}
              >
                Current Recording Period
              </label>
              <Row>
                <Col lg="6" md="6" sm="6">
                  <label className="pr-2">Start Week</label>
                  <DatePicker
                    selected={selectedStartWeekDate}
                    value={startweeklyDate}
                    showMonthDropdown
                    showYearDropdown
                    dropdownMode="select"
                    name="startDate"
                    className="form-control"
                    customInput={<this.ExampleCustomInput />}
                    filterDate={this.isWeekday}
                    onChange={this.handleStartWeekChange}
                    dateFormat="yyyy-MM-dd"
                    placeholderText="yyyy-MM-dd"
                  />
                </Col>
                <Col lg="6" md="6" sm="6">
                  <label className="pr-2">End Week</label>
                  <DatePicker
                    selected={selectedEndWeekDate}
                    value={endweeklyDate}
                    showMonthDropdown
                    showYearDropdown
                    dropdownMode="select"
                    name="startDate"
                    className="form-control"
                    customInput={<this.ExampleCustomInput />}
                    filterDate={this.isWeekday}
                    onChange={this.handleEndWeekChange}
                    dateFormat="yyyy-MM-dd"
                    placeholder="yyyy-MM-dd"
                  />
                </Col>
              </Row>
            </Col>
            <Col lg="2" md="2" sm="12" className="mb-0 mt-auto">
              <label>Timesheet Status</label>
              <select onChange={this.changeStatus} value={timesheetstatus} placeholder="Select" className="form-control dropdown-height" name="state">
                <option value="all">All</option>
                <option value="Active" >Active</option>
                <option value="Inactive">Inactive</option>
                <option value="Submitted">Submitted</option>
                <option value="Approvable">Approvable</option>
                <option value="Approved">Approved</option>
                <option value="Archivable">Archivable</option>
                <option value="Archived" >Archived</option>
              </select>
            </Col>
            <Col lg="2" md="2" sm="12" className="mb-0 mt-auto">
              <label>Activity</label>
              <select onChange={this.filterByActivity} value={this.state.activityId} placeholder="Select" className="form-control dropdown-height" name="state" >
                {activityDropdownOptions.map(activity => <option key={activity.actID} value={activity.actID}>{activity.name}</option>)}
              </select>
            </Col>
            <Col lg="2" md="2" sm="12" className="mb-0 mt-auto">
              <label>Employee Type</label>
              <select onChange={this.filterByEmployeeType} value={this.state.employeeType} placeholder="Select" className="form-control dropdown-height" name="state">
                <option value="all">All</option>
                <option value="Salaried">Salaried</option>
                <option value="Full-Time Hourly">Full Time Hourly</option>
                <option value="Part-Time Hourly">PT Hourly</option>
                <option value="Temporary">Temporary</option>
                <option value="SubContractor">SUB</option>
                <option value="Intern">Intern</option>
              </select>
            </Col>
          </Row>
        </div>
        <p className="small_font mb-2 mt-2 ">Summary on Number of Timesheets in this Period :
          <label className="label label-info"> Active : {get(summaryDetails, 'numOfActive', 0)}</label>
          <label className="label label-danger"> Inactive : {get(summaryDetails, 'numOfInactive', 0)}</label>
          <label className="label label-success2"> Submitted : {get(summaryDetails, 'numOfSubmitted', 0)}</label>
          <label className="label label-warning"> Approvable : {get(summaryDetails, 'numOfApprovable', 0)}</label>
          <label className="label label-success1"> Approved : {get(summaryDetails, 'numOfApproved', 0)}</label>
          <label className="label label-primary"> Archivable : {get(summaryDetails, 'numOfArchivable', 0)}</label>
          <label className="label label-default"> Archived : {get(summaryDetails, 'numOfArchived', 0)}</label>
        </p>
        <div className="row px-0 ml-0 mb-3">
          <div className="text-left float-left col-lg-7 col-md-7 col-xl-7 col-sm-12 pl-0">
            <MDBBtn
              disabled={approveBtnDisabled || validTimeSheetDataArr.some((e) => e.timesheetStatus > 400)}
              onClick={() => this.approveOrRejectTimesheets(TimesheetOperation.approve)}
              color="success"
              data-toggle="tooltip"
              title="Approve"
            >
              <i className="fa fa-thumbs-up text-white"></i>
            </MDBBtn>
            <MDBBtn
              disabled={rejectBtnDisabled || validTimeSheetDataArr.some((e) => e.timesheetStatus !== 300 && e.timesheetStatus !== 400)}
              onClick={() => this.approveOrRejectTimesheets(TimesheetOperation.reject)}
              className="ml-2"
              color="danger"
              data-toggle="tooltip"
              title="Reject"
            >
              <i className="fa fa-thumbs-down text-white"></i>
            </MDBBtn>
            <MDBBtn
              onClick={() => this.openWarningModal(DashboardButtonFunctionality.archivable)}
              style={(validTimeSheetDataArr.length > 0 && every(validTimeSheetDataArr, { 'timesheetStatus': 500 })) ? {} : { display: 'none' }}
              color="success"
              className="ml-2"
            >
              Set to Archivable
            </MDBBtn>
            <MDBBtn
              onClick={() => this.openWarningModal(DashboardButtonFunctionality.archived)}
              style={(validTimeSheetDataArr.length > 0 && every(validTimeSheetDataArr, { 'timesheetStatus': 600 })) ? {} : { display: 'none' }}
              color="success"
              className="ml-2"
            >
              Set to Archived
            </MDBBtn>
          </div>
          <div className="col-lg-3 col-xl-3 col-md-3 col-sm-12"></div>
          <div className="col-lg-2 col-xl-2 col-md-2 col-sm-12">
            <button
              onClick={() => this.openMassEntryForm()}
              className="button resend-btn py-2 px-3 m-0 float-right"
              disabled={isEmpty(selectedTimesheets)}
            >
              Mass Time Entry
              <i className="fa fa-book pl-2"></i>
            </button>
          </div>
        </div>
        <Row className="mr-0">
          <Col xs={uniqueActivityTableCols.length > 0 ? 9 : 12} className="pr-0">
            <MDBDataTable
              className="activitytable timesheets fieldTable"
              responsive={true}
              noBottomColumns
              sortable={false}
              striped
              info={false}
              bordered
              hover
              displayEntries={false}
              data={datatable}
              searching={false}
              paging={false}
            />
          </Col>
          {uniqueActivityTableCols.length > 0 && <Col xs={3} className="px-0">
            <MDBDataTable
              className="activitytable timesheets"
              responsive={true}
              noBottomColumns
              sortable={false}
              striped
              info={false}
              bordered
              hover
              displayEntries={false}
              data={activityDataTable}
              searching={false}
              paging={false}
            />
          </Col>}
        </Row>
        {/** Modal to perform mass entry form operation */}
        {displayMassEntryForm && <Modal
          scrollable={true}
          size="md"
          onHide={() => this.cancelMassEntry()}
          show={displayMassEntryForm}
        >
          <Modal.Header closeButton className="h6 background-blue1">
            <Modal.Title className="h6 text-white" id="contained-modal-title-vcenter">
              Mass Time Entry
            </Modal.Title>
          </Modal.Header>
          <Modal.Body className="show-grid small_font px-5">
            <p className="xs_font text-dark text-center">
              {`Add hours for the ${selectedTimesheets.length} selected employee${selectedTimesheets.length > 1 ? 's' : ''} for the week of:`}
            </p>
            <p className="small_font font-weight-bold text-center">
              {displayMassEntryDate}
            </p>
            <div className="form-group row">
              <div className="col-lg-6 col-md-6 col-xl-6 col-sm-12">
                <label>Date:</label>
                <DatePicker
                  selected={massEntryDate ? momentDate(massEntryDate) : null}
                  value={massEntryDate}
                  name="massEntryDate"
                  className="form-control"
                  showMonthDropdown
                  showYearDropdown
                  dropdownMode="select"
                  minDate={momentDate(displayMassEntryDate.split('-')[0])}
                  maxDate={momentDate(displayMassEntryDate.split('-')[1])}
                  customInput={<this.ExampleCustomInput />}
                  onChange={(date) => this.setState({ massEntryDate: date })}
                  dateFormat="yyyy-MM-dd"
                  placeholderText="yyyy-MM-dd"
                />
                {!massEntryDate && (<p style={{ color: 'red' }}>This is required</p>)}
              </div>
              <div className="col-lg-6 col-md-6 col-xl-6 col-sm-12">
                <label>Activity Name:</label>
                <select onChange={(evt) => this.setState({ massEntryActivity: evt.target.value })} defaultValue={massEntryActivity} placeholder="Select" className="form-control" name="state">
                  {massEntryActivitiesDD.map(activity => <option key={activity.actID} value={activity.actID}>{activity.name}</option>)}
                </select>
                {!massEntryActivity && (<p style={{ color: 'red' }}>This is required</p>)}
              </div>
            </div>
            <div className="form-group row">
              <div className="col-lg-6 col-md-6 col-xl-6 col-sm-12">
                <label>Hour:</label>
                <input
                  type="text"
                  className="form-control"
                  placeholder=""
                  value={massEntryHour}
                  onChange={(evt) => this.setState({ massEntryHour: evt.target.value })}
                />
                {!massEntryHour && (<p style={{ color: 'red' }}>This is required</p>)}
              </div>
              <div className="col-lg-6 col-md-6 col-xl-6 col-sm-12">
                <label>Comments*:</label>
                <textarea
                  onChange={(evt) => this.setState({ massEntryComments: evt.target.value })}
                  type="text"
                  className="form-control"
                  placeholder="Enter Activity Description"
                  value={massEntryComments}
                />
                {!massEntryComments && (<p style={{ color: 'red' }}>This is required</p>)}
              </div>
            </div>
          </Modal.Body>
          <Modal.Footer>
            <div className="col-12 row mt-2">
              <p className="small_font text-dark text-center mx-auto mb-2">Are you sure you would like to continue with this mass time entry?</p>
              <div className="col-6">
                <button
                  onClick={() => this.cancelMassEntry()}
                  className="button resend-btn background-red px-4 float-left"
                >
                  No, Cancel
                </button>
              </div>
              <div className="col-6">
                <button
                  disabled={!massEntryComments || !massEntryDate || !massEntryHour || !massEntryActivity}
                  className="button resend-btn float-right px-4"
                  onClick={() => this.onSubmitMassTimeEntry()}
                >
                  Yes, Continue
                </button>
              </div>
            </div>
          </Modal.Footer>
        </Modal>
        }
        {/** Modal for user approval to approve or reject a timesheet */}
        <Modal
          scrollable={true}
          size="md"
          onHide={this.closeUserApprovalForm}
          show={displayUserApprovalForm}
        >
          <Modal.Header closeButton className="h6 background-green1">
            <Modal.Title className="h6 text-white small_font" id="contained-modal-title-vcenter">
              Timesheet {isEqual(TimesheetOperation.approve, selectedTimesheetOperation) ? 'Approval' : 'Rejection'} Confirmation
            </Modal.Title>
          </Modal.Header>
          <Modal.Body className="show-grid small_font px-5">
            <p className="xs_font text-dark text-center">
              {`You are about to ${isEqual(TimesheetOperation.approve, selectedTimesheetOperation) ? 'approve' : 'reject'} ${empName}'s timesheet. Please confirm to continue`}
            </p>
            <p className="small_font font-weight-bold text-center">
              {displayMassEntryDate}
            </p>
            {isUserCommentRequired && <div className="form-group row">
              <div className="col-lg-3 col-md-3 col-xl-3 col-sm-3 text-right">
                <label>Comment :</label>
              </div>
              <div className="col-lg-9 col-md-9 col-xl-9 col-sm-9">
                <textarea className="form-control" value={userComments} onChange={(evt) => this.setState({ userComments: evt.target.value })}></textarea>
                {isEmpty(userComments) && (<p className="mb-0" style={{ color: 'red' }}>This is required</p>)}
              </div>
            </div>}
            {signatureImage && initialImage &&
              <div className="text-center mt-2">
                <input type="checkbox" id="savedSign" checked={savedSign} onChange={(e) => this.setState({ savedSign: e.target.checked })} className="mr-2" name="savedSign" />
                <label className="mb-0" htmlFor="savedSign">Use the saved signature & Initial</label>
              </div>}
            {(savedSign) ?
              <div className="text-center">
                {signatureImage && <img src={signatureImage} alt="signatureImage" className="mb-1" />}
                {initialImage && <img src={initialImage} alt="initialImage" className="mb-1 ml-2" />}
              </div> :
              <>
                <div className="border-bottom">
                  <h6 className="text-center mb-0 mt-2">Create Signature</h6>
                  <div className="row mt-2">
                    <div className="col-xl-2 col-lg-2 col-md-2 col-sm-12">
                    </div>
                    <div className="col-xl-3 col-lg-3 col-md-3 col-sm-12 pl-0">
                      <input type="radio" value="type" checked={signType === 'type'} onChange={() => this.setState({ signType: 'type' })} className="mr-2 align-middle" name="signType" />
                      <label>Type</label>
                    </div>
                    <div className="col-xl-3 col-lg-3 col-md-3 col-sm-12 pl-0">
                      <input type="radio" value="drawing" checked={signType === 'drawing'} disabled onChange={() => this.setState({ signType: 'drawing' })} className="mr-2 align-middle" name="signType" />
                      <label>Drawing</label>
                    </div>
                    <div className="col-xl-4 col-lg-4 col-md-4 col-sm-12">
                      <input type="radio" value="image" checked={signType === 'image'} disabled onChange={() => this.setState({ signType: 'image' })} className="mr-2 align-middle" name="signType" />
                      <label>Image</label>
                    </div>
                  </div>
                  {signType === 'type' &&
                    <>
                      <div className="row mt-2 mb-2">
                        <div className="col-lg-2 col-md-2 col-xl-2 col-sm-12 px-0">
                          <label className="mt-2">Type :</label>
                        </div>
                        <div className="col-lg-7 col-md-7 col-xl-7 col-sm-12 pl-0">
                          <input type="text" id="signatureText" style={{ fontFamily: signatureFont, fontSize: signatureText && '3em !important' }} className="form-control" placeholder="Please type here for signature..." value={signatureText} onChange={(evt) => this.signatureChange('signature', evt.target.value, signatureFont)} />
                        </div>
                        <div className="col-xl-3 col-lg-3 col-md-3 col-sm-12 px-0">
                          <select value={signatureFont} className="form-control p-2" style={{ fontFamily: signatureFont }} onChange={(e) => this.signatureChange('signature', signatureText, e.target.value)} name="signatureFont">
                            {fontOptions.map((x, fkey) =>
                              <option value={x.value} key={fkey} className="font-12" style={{ fontFamily: `${x.value}` }}>Style</option>
                            )}
                          </select>
                        </div>
                      </div>
                      {signatureOutput && <div className="row mt-2 align-items-center">
                        <div className="col-lg-2 col-md-2 col-xl-2 col-sm-12 px-0">
                          <label>Signature :</label>
                        </div>
                        <img src={signatureOutput} style={{ maxWidth: '340px', maxHeight: '60px' }} alt="signatureOutput" />
                      </div>}
                    </>}
                </div>
                <div>
                  <h6 className="text-center mb-0 mt-2">Create Initial</h6>
                  <div className="row mt-2">
                    <div className="col-xl-2 col-lg-2 col-md-2 col-sm-12">
                    </div>
                    <div className="col-xl-3 col-lg-3 col-md-3 col-sm-12 pl-0">
                      <input type="radio" value="type" checked={initialType === 'type'} onChange={() => this.setState({ initialType: 'type' })} className="mr-2 align-middle" name="initialType" />
                      <label>Type</label>
                    </div>
                    <div className="col-xl-3 col-lg-3 col-md-3 col-sm-12 pl-0">
                      <input type="radio" value="drawing" checked={initialType === 'drawing'} disabled onChange={() => this.setState({ initialType: 'drawing' })} className="mr-2 align-middle" name="initialType" />
                      <label>Drawing</label>
                    </div>
                    <div className="col-xl-4 col-lg-4 col-md-4 col-sm-12">
                      <input type="radio" value="image" checked={initialType === 'image'} disabled onChange={() => this.setState({ initialType: 'image' })} className="mr-2 align-middle" name="initialType" />
                      <label>Image</label>
                    </div>
                  </div>
                  {initialType === 'type' &&
                    <>
                      <div className="row mt-2 mb-2">
                        <div className="col-lg-2 col-md-2 col-xl-2 col-sm-12 px-0">
                          <label className="mt-2">Type :</label>
                        </div>
                        <div className="col-lg-7 col-md-7 col-xl-7 col-sm-12 pl-0">
                          <input type="text" id="initialText" style={{ fontFamily: initialFont, fontSize: initialText && '3em !important' }} className="form-control" placeholder="Please type here for signature..." value={initialText} onChange={(evt) => this.signatureChange('initial', evt.target.value, initialFont)} />
                        </div>
                        <div className="col-xl-3 col-lg-3 col-md-3 col-sm-12 px-0">
                          <select value={initialFont} className="form-control p-2" style={{ fontFamily: initialFont }} onChange={(e) => this.signatureChange('initial', initialText, e.target.value)} name="initialFont">
                            {fontOptions.map((x, fkey) =>
                              <option value={x.value} key={fkey} className="font-12" style={{ fontFamily: `${x.value}` }}>Style</option>
                            )}
                          </select>
                        </div>
                      </div>
                      {initialOutput && <div className="row align-items-center">
                        <div className="col-lg-2 col-md-2 col-xl-2 col-sm-12 px-0">
                          <label>Signature :</label>
                        </div>
                        <img src={initialOutput} style={{ maxWidth: '340px', maxHeight: '60px' }} alt="initialOutput" />
                      </div>}
                    </>}
                </div>
                <div className="text-center mb-2">
                  <input type="checkbox" id="savedFuture" checked={savedFuture} onChange={(e) => this.setState({ savedFuture: e.target.checked })} className="mr-2 mt-1" name="savedFuture" />
                  <label htmlFor="savedFuture" className="mb-0">Save Signature & Inital for future use</label>
                </div>
              </>
            }
          </Modal.Body>
          <Modal.Footer>
            <div className="col-12 row mt-2">
              <div className="col-6">
                <button
                  onClick={this.closeUserApprovalForm}
                  className="button resend-btn background-red px-4 float-left"
                >
                  No, Cancel
                </button>
              </div>
              <div className="col-6">
                <button
                  disabled={(isUserCommentRequired && isEmpty(userComments)) || approveTimesheet}
                  onClick={this.completeTimesheetOperation}
                  className="button resend-btn float-right px-4"
                >
                  Yes, Confirm
                </button>
              </div>
            </div>
          </Modal.Footer>
        </Modal>
        {/** Modal for archivable and archived feature */}
        <Modal
          scrollable={true}
          size="md"
          onHide={this.closeWarningModal}
          show={displayWarningModal}
        >
          <Modal.Header closeButton className="h6 background-green1">
            <Modal.Title className="h6 text-white small_font" id="contained-modal-title-vcenter">
              Set to {selectedButtonFunctionality === DashboardButtonFunctionality.archivable ? 'Archivable' : 'Archived'} Confirmation
            </Modal.Title>
          </Modal.Header>
          <Modal.Body className="show-grid small_font px-5">
            <p className="small_font text-dark text-center">
              You are setting {selectedTimesheets.length} timesheets to {selectedButtonFunctionality === DashboardButtonFunctionality.archivable ? 'Archivable' : 'Archived'}, please confirm to continue.
            </p>
            {/* <p className="small_font font-weight-bold text-center">
              {displayMassEntryDate}
            </p> */}
          </Modal.Body>
          <Modal.Footer>
            <div className="col-12 row mt-2">
              <div className="col-6">
                <button
                  onClick={this.closeWarningModal}
                  className="button resend-btn background-red px-4 float-left"
                >
                  No, Cancel
                </button>
              </div>
              <div className="col-6">
                <button
                  onClick={this.updateTimesheetStatusToArchivedOrArchivable}
                  className="button resend-btn float-right px-4"
                >
                  Yes, Confirm
                </button>
              </div>
            </div>
          </Modal.Footer>
        </Modal>
      </React.Fragment>
    )
  }
}

export default LoadTimesheetsTable;