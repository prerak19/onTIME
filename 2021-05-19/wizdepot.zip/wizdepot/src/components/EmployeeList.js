import React from 'react';
import { MDBDataTable } from 'mdbreact';
import "react-datepicker/dist/react-datepicker.css";
import { Modal, Row, Col } from "react-bootstrap";
import { apiGet, apiPost } from '../Api';
import { isEqual } from 'lodash';
import { ClockInOuts, employeeTypes_codes, user_status_codes, wageCategory_codes } from '../helpers/GeneralHelper';
import moment from 'moment';

class EmployeesList extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      loadEmp: false,
      employeeList: [],
      editshow: false,
      currentEmp: null,
      confirmNewPassword: '',
      newPassword: '',
    };
  }
  componentDidMount = () => {
    this.getActivityEmployees();
  }

  getActivityEmployees = () => {
    this.setState({ loadEmp: true });
    const { activity } = this.props;
    const getRequest = {
      method: `/employees?activity=${activity.actID}`,
      params: {}
    };
    apiGet(getRequest, true, false).then((response) => {
      if (isEqual(response.status, 200) && response.data) {
        if (response.data.users.length > 0) {
          let data = [];
          response.data.users.map((us) => {
            let userActs = us.userActivities.length > 0 ? us.userActivities.map((x) => x.name) : [];
            let lastActivity = '';
            if (us.lastClockType) {
              lastActivity = `Punch ${ClockInOuts[`${us.lastClockType}`]} ${moment(us.lastClockTime).format('MM/DD/YYYY HH:MM A')}`
            }else{
              lastActivity = `Manually Enter `
            }
            // lastActivity = `${lastActivity} ${moment(us.lastClockTime).format('MM/DD/YYYY HH:MM A')}`
            data.push({
              name: `${us.lastName} ${us.firstName}`,
              status: user_status_codes[`${us.status}`] || '',
              wage_category: wageCategory_codes[`${us.wage_category}`],
              emp_type: employeeTypes_codes[`${us.employeeType}`],
              hire_date: '2/05/2021',
              activities: userActs.length > 0 && userActs.join('/'),
              lastActivity,
              psw: <i class="fa fa-lock text-warning" onClick={() => this.setState({ editshow: true, currentEmp: us })}></i>,
            })
          })
          this.setState({
            employeeList: data,
            loadEmp: false
          })
        } else {
          this.setState({ employeeList: [], loadEmp: false })
        }
      } else {
        this.setState({ employeeList: [], loadEmp: false })
      }
    }).catch(error => {
      this.setState({ employeeList: [], loadEmp: false })
    });
  }

  resetEmpPassword = () => {
    const { currentEmp, newPassword } = this.state;
    let requestDetails = {
      method: 'employees/password-reset',
      params: {
        userID: currentEmp.userID,
        newPassword: newPassword,
        managerID: localStorage.userid
      }
    };
    apiPost(requestDetails, true).then((response) => {
      if (isEqual(response.status, 200) && response.data) {
        window.alert('Password Reset Successfully.');
      } else {
        window.alert('Something Went Wrong!');
      }
      this.setState({ editshow: false, currentEmp: null });
    }).catch(error => {
      console.log(error);
      window.alert('Something Went Wrong!');
      this.setState({ editshow: false, currentEmp: null });
    });
  }

  render() {
    const { employeeList, loadEmp, editshow, currentEmp, confirmNewPassword, newPassword } = this.state;
    const { activity } = this.props;
    let datatable = {
      columns: [
        {
          label: 'Name',
          field: 'name',
        },
        {
          label: 'Status',
          field: 'status',
        },
        {
          label: 'Wage Category',
          field: 'wage_category',
        },
        {
          label: 'Employee Type',
          field: 'emp_type',
        },
        {
          label: 'Hire Date',
          field: 'hire_date',
        },
        {
          label: 'Activities',
          field: 'activities',
        },
        {
          label: 'Last Activity',
          field: 'lastActivity',
        },
        {
          label: '',
          field: 'psw',
          sort: 'disabled',
        },
      ],
      rows: employeeList,
    }
    return (
      <div>
        <div class="row mx-0">
          <div className="text-left float-left">
            <p onClick={() => this.props.backToMenu()} class=" cursor-pointer font-weight-bolder blue-color"><i className="fa fa-angle-left pr-2"></i>Activities</p>
          </div>
        </div>
        {loadEmp === true ? 'Please Wait...' :
          <div>
            <div className="w-100 text-left float-left">
              <p className="text-muted mb-3"> Settings for Employees under Activity : {activity.name.toUpperCase()}</p>
              <h6 class="font-weight-bolder">Number of Total Employees ({employeeList.length})</h6>
            </div>
            <MDBDataTable
              hover
              info={false}
              responsive={true}
              displayEntries={false}
              noBottomColumns
              entriesOptions={[5, 20, 25]}
              entries={5}
              pagesAmount={4}
              data={datatable}
              searching={false}
            />
          </div>
        }
        {editshow === true && <Modal scrollable={true} size="md" onHide={() => this.setState({ editshow: false, currentEmp: null })}
          show={this.state.editshow}>
          <Modal.Header closeButton>
            <Modal.Title id="contained-modal-title-vcenter">
              <div className="h6"><i class="fa fa-lock text-warning mr-2"></i>{currentEmp.lastName}, {currentEmp.firstName} - Reset Password</div>
              <p className="small_font font-weight-normal">Please enter a new temporary password for {currentEmp.lastName} {currentEmp.firstName}. For security reason, password to be changed</p>
            </Modal.Title>
          </Modal.Header>
          <Modal.Body className="show-grid small_font px-5">
            <Row>
              <Col lg="12" md="12" sm="12">
                <div className="form-group">
                  <label for="exampleInputEmail1">Login Name</label>
                  <input type="text" value={`${currentEmp.lastName} ${currentEmp.firstName}`} className="form-control" placeholder="Joe Smith" disabled />
                </div>
              </Col>
              <Col lg="6" md="12" sm="12">
                <div className="form-group">
                  <label for="exampleInputEmail1">Reset Password</label>
                  <input type="password" value={newPassword} name='newPassword' onChange={(e) => this.setState({ [e.target.name]: e.target.value })} className="form-control" placeholder="Enter new password" Readonly />
                </div>
              </Col>
              <Col lg="6" md="12" sm="12">
                <div className="form-group">
                  <label for="exampleInputEmail1"></label>
                  <input type="password" value={confirmNewPassword} name='confirmNewPassword' onChange={(e) => this.setState({ [e.target.name]: e.target.value })} className="form-control mt-2" placeholder="Confirm new password" Readonly />
                </div>
              </Col>
            </Row>
            <p className="small_font">
              You are about to reset password for this team member.
              User login with this new password,
              They will be given the option to update to their choice
            </p>
          </Modal.Body>
          <Modal.Footer>
            <button onClick={() => this.setState({ editshow: false, currentEmp: null })} class="button cancel-btn py-2 px-4 m-0 mr-2">Cancel</button>
            <button
              disabled={!confirmNewPassword || !newPassword || confirmNewPassword !== newPassword}
              onClick={() => this.resetEmpPassword()}
              class="button resend-btn py-2 px-4 m-0">Reset Password</button>
          </Modal.Footer>
        </Modal>}
      </div>
    );
  }
}
export default EmployeesList;