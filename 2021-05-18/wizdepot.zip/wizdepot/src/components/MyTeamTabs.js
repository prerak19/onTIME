import React, { Component } from 'react';
import 'bootstrap/dist/css/bootstrap.min.css';
import 'bs-stepper/dist/css/bs-stepper.min.css';
import Stepper from 'bs-stepper';
import { Row, Col, Card } from "react-bootstrap";
import LoadMyTeamTable from './LoadMyTeamTable.js';
import EmployeeList from './EmployeeList.js';
import ActivityList from './ActivityList.js';
import { CardBody, CardFooter, CardHeader } from 'reactstrap';
import { MDBBtn } from 'mdbreact';
import "react-datepicker/dist/react-datepicker.css";
import ManagerReportsTab from './ManagerReportsTab.js';

class MyTeamTabs extends Component {
  constructor(props) {
    super(props);
    this.state = {
      edit: true,
      reset: false,
      startDate: null,
      endDate: null,
      semiMonthlyDate: null,
      MonthlyDate: null,
      weeklyDate: null,
      biWeeklyDate: null,
      TimePeriod: 'weekly',
      includesReport: 'allemployees',
      reportingHours: 'allhours',
      packEmployees: 'alphabet',
      preview: 'timesheet',
      showreport: '',
      showreportcss: false,
      abtemp: false,
      abtact: false,
      abtall: true
    };
  }
  componentDidMount() {
    this.stepper = new Stepper(document.querySelector('#stepper2'), {
      linear: false,
      animation: true
    })
  }

  onSubmit(e) {
    e.preventDefault()
  }

  loadPreview = (e) => {
    e.preventDefault();
    this.setState({
      showreport: this.state.preview,
      showreportcss: true,
    });
  }
  isWeekday = (date) => {
    const day = date.getDay()
    return day === 0
  }
  isMonthly = (date) => {
    const day = date.getDate()
    return day === 1
  }
  isSemiMonthly = (date) => {
    const day = date.getDate()
    return day === 1 || day === 16;
  }
  handleOnChange = (e) => {
    this.setState({
      preview: e.target.value
    })
  }
  handlemousedown = (e) => {
    console.log('text');
    e.target.selected = !e.target.selected;
    e.stopPropagation();
    return false;
  }

  render() {
    return (
      <div>
        <div id="stepper2" className="bs-stepper">
          <div className="bs-stepper-header">
            <div className="step" data-target="#tests-l-1">
              <button className="step-trigger">
                <span className="bs-stepper-label1">Manage Employee Time</span>
              </button>
            </div>
            <div className="step" data-target="#tests-l-2">
              <button className="step-trigger">
                <span className="bs-stepper-label1">Run Reports</span>
              </button>
            </div>
            <div className="step" data-target="#tests-l-3">
              <button className="step-trigger">
                <span className="bs-stepper-label1">About Employees</span>
              </button>

            </div>
          </div>
          <div className="stepper-content">
            <div id="tests-l-1" className="content small_font">
              <LoadMyTeamTable />
            </div>
            <div id="tests-l-2" className="content  pl-0  small_font">
              <ManagerReportsTab />
            </div>
            <div id="tests-l-3" className="content pl-2 small_font">
              <Row style={this.state.abtall === true ? {} : { display: 'none' }}>
                <Col lg="3" md="3" sm="12" className="pl-2">
                  <Card className="border">
                    <CardHeader className="pb-0 pt-4">
                      <h6 className="font-weight-bolder">
                        OTHA (948)
                                </h6>
                    </CardHeader>
                    <CardBody className="py-1 font-11">
                      <div className="font-10">
                        Activity Created : 4/01/2020
                                </div>
                      <div className="font-10">
                        Activity Time Approver : Jessy Lake
                                </div>
                    </CardBody>
                    <CardFooter>
                      <div>
                        <MDBBtn onClick={() => this.setState({ abtall: false, abtemp: true, abtact: false })} size="lg" className="round-btn">
                          <i className="fa fa-users" aria-hidden="true"></i>
                        </MDBBtn>
                        <MDBBtn onClick={() => this.setState({ abtall: false, abtact: true, abtemp: false })} size="lg" className="round-btn">
                          <i className="fa fa-book" aria-hidden="true"></i>
                        </MDBBtn>
                      </div>
                    </CardFooter>
                  </Card>
                </Col>
                <Col lg="3" md="3" sm="12">
                  <Card className="border">
                    <CardHeader className="pb-0 pt-4">
                      <h6 className="font-weight-bolder">
                        CLA (712)
                                </h6>
                    </CardHeader>
                    <CardBody className="py-1 font-11">
                      <div className="font-10">
                        Activity Created : 4/01/2020
                                </div>
                      <div className="font-10">
                        Activity Time Approver : Jessy Lake
                                </div>
                    </CardBody>
                    <CardFooter>
                      <div>
                        <MDBBtn onClick={() => this.setState({ abtall: false, abtemp: true, abtact: false })} size="lg" className="round-btn">
                          <i className="fa fa-users" aria-hidden="true"></i>
                        </MDBBtn>
                        <MDBBtn onClick={() => this.setState({ abtall: false, abtact: true, abtemp: false })} size="lg" className="round-btn">
                          <i className="fa fa-book" aria-hidden="true"></i>
                        </MDBBtn>
                      </div>
                    </CardFooter>
                  </Card>
                </Col>
              </Row>
              <div className="mt-5" style={this.state.abtemp === true ? {} : { display: 'none' }}>
                <div class="col-12 row mr-0 pr-0 pl-0 ml-0 mb-3">
                  <div className="text-left float-left col-lg-9 col-md-9 col-xl-9 col-sm-12 pl-0">
                    <p onClick={() => this.setState({ abtall: true, abtact: false, abtemp: false })} class=" cursor-pointer font-weight-bolder blue-color"><i className="fa fa-angle-left pr-2"></i>Activities</p>
                    <span className="text-muted">
                      Settings for Employees under Activity : OHTA
                        </span>
                  </div>
                </div>
                <EmployeeList />
              </div>
              <div className="mt-5" style={this.state.abtact === true ? {} : { display: 'none' }}>
                <div class="col-12 row mr-0 pr-0 pl-0 ml-0 mb-3">
                  <div className="text-left float-left col-lg-9 col-md-9 col-xl-9 col-sm-12 pl-0">
                    <p onClick={() => this.setState({ abtall: true, abtact: false, abtemp: false })} class="font-weight-bolder blue-color cursor-pointer"><i className="fa fa-angle-left pr-2"></i>Activities</p>
                    <span className="text-muted">
                      View Policies for Activity : OHTA
                        </span>
                  </div>
                </div>
                <ActivityList />
              </div>
            </div>
          </div>
        </div>
      </div>
    );
  }
}

export default MyTeamTabs;
