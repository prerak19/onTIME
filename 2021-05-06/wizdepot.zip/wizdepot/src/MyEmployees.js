import React from 'react';
import {Container} from 'react-bootstrap';
import 'bootstrap/dist/css/bootstrap.min.css';
import './App.css';
import AdminHeader from './components/AdminHeader.js';
import MyTeamTabs from './components/MyTeamTabs.js';

class MyTeam extends React.Component {  
render() {
  return (
    <div className="App">
      <Container>   
        <header className="admin-header">
            <AdminHeader />
        </header>
        <div className="content">
        <div className="contentwrapper pt-1 pb-5 mb-5">
         <MyTeamTabs />
        </div>
        </div>
      </Container>
      
    </div>
  );
  }
}

export default MyTeam;
