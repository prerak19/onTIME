import React, { Component } from 'react';
import moment from 'moment';
import DatePicker from "react-datepicker";
import "react-datepicker/dist/react-datepicker.css";
import 'bs-stepper/dist/css/bs-stepper.min.css';
import Stepper from 'bs-stepper';
import { Row, Col } from "react-bootstrap";
import { apiGet, apiPut, getBlobImage, uploadImage } from '../Api.js';
import { stateDetails } from '../helpers/GeneralHelper.js';
import { cloneDeep, isEmpty } from 'lodash';
import SuperAdminUser from './SuperAdminUser.js';

class OrganizationTabs extends Component {
  constructor(props) {
    super(props);
    this.state = {
      biweeklyStart: moment().day(0).format('YYYY-MM-DD'),
      orgImage: null,
      name: 'React',
      editable: true,
      timeedit: true,
      timeeditable: true,
      editdetails: {},
      originalData: {},
      errors: {},
      error_message: '',
      orgImageFile: {},
    };
  }
  componentDidMount() {
    this.stepper = new Stepper(document.querySelector('#stepper1'), {
      linear: false,
      animation: true
    })
    this.getFunction();
    this.getOrgImage();
  }

  getOrgImage = async () => {
    let imageSrc = '';
    const getRequest = {
      method: `employees/images?id=${localStorage.orgid}&itemtype=org_logo`
    };
    await getBlobImage(getRequest).then((response) => {
      if (response.data && response.data.size) {
        imageSrc = URL.createObjectURL(response.data);
        this.setState({ orgImage: imageSrc, orgImageFile: new File([response.data], "image.jpeg") });
      }
    }).catch(error => {
      console.log(error);
    });
  }

  handleFormChange = (e) => {
    let editdetails = this.state.editdetails;
    editdetails[e.target.name] = e.target.value;
    let errors = this.state.errors;
    if (isEmpty(e.target.value)) {
      errors[e.target.name] = 'form-control is-invalid';
    } else {
      errors[e.target.name] = 'form-control is-valid';
    }
    this.setState({ editdetails, errors });
  }

  validateForm() {
    const { editdetails } = this.state;
    let errors = {};
    let formIsValid = true;

    let requiredFields = ['name', 'tin', 'address1', 'city', 'zip', 'state', 'country', 'phone', 'email'];

    requiredFields.map((x) => {
      if (!editdetails[x]) {
        formIsValid = false;
        errors[x] = "form-control is-invalid";
      }
    });
    if (!formIsValid) {
      this.setState({
        error_message: 'Please fill all * Required Fields!'
      });
      window.scroll({ top: 0, left: 0, behavior: 'smooth' })
    } else {
      this.setState({
        error_message: ''
      });
    }

    this.setState({
      errors: errors
    });
    return formIsValid;
  }
  uploadPicture = (e) => {
    this.setState({
      orgImage: URL.createObjectURL(e.target.files[0]),
      orgImageFile: e.target.files[0]
    })
  };

  editRecord = (e) => {
    const { editdetails, orgImageFile } = this.state;
    let orgId = localStorage.orgid;
    if (this.validateForm()) {
      let requestDetails3 = { method: `employees/images?id=${orgId}&itemtype=org_logo` };
      let orgImageData = new FormData();
      if (orgImageFile) {
        orgImageData.append("file", orgImageFile);
      }
      uploadImage(requestDetails3, orgImageData).then((response) => {
      }).catch(error => {
        console.log(error)
      });

      let requestDetails = {
        method: 'organizations/' + orgId + '?user_id=' + localStorage.userid,
        params: {
          id: orgId,
          address1: editdetails.address1,
          address2: editdetails.address2,
          city: editdetails.city,
          state: editdetails.state,
          country: editdetails.country,
          zip: editdetails.zip,
          phone: editdetails.phone,
          email: editdetails.email,
          fax: editdetails.fax,
          website: editdetails.website,
          recPeriod: editdetails.recPeriod,
          dateFormat: editdetails.dateFormat,
          timeFormat: editdetails.timeFormat,
          biweeklyStart:editdetails.biweeklyStart,
        }
      };
      apiPut(requestDetails, true).then((res) => {
        if (res.data && res.status === 200) {
          this.setState({ editable: true })
          this.getFunction();
          return;
        }
        if (res.request.response && res.request.status !== 200) {
          let obj = JSON.parse(res.request.response);
          this.setState({ error_message: obj.msg });
          return;
        }
      }).catch(error => {
        console.log(error)
      });
    }
  }
  editRecord1 = (e) => {
    const { editdetails, biweeklyStart } = this.state;
    if (this.validateForm()) {
      let requestDetails = {
        method: 'organizations/' + localStorage.orgid + '?user_id=' + localStorage.userid,
        params: {
          id: localStorage.orgid,
          address1: editdetails.address1,
          address2: editdetails.address2,
          city: editdetails.city,
          state: editdetails.state,
          country: editdetails.country,
          zip: editdetails.zip,
          phone: editdetails.phone,
          email: editdetails.email,
          fax: editdetails.fax,
          website: editdetails.website,
          recPeriod: editdetails.recPeriod,
          dateFormat: editdetails.dateFormat,
          timeFormat: editdetails.timeFormat,
        }
      };
      if (editdetails.recPeriod === 'Bi-Weekly') {
        requestDetails.params.biweeklyStart = biweeklyStart
      }
      apiPut(requestDetails, true).then((res) => {
        if (res.data && res.status === 200) {
          this.setState({ timeedit: true, timeeditable: true })
          this.getFunction();
          return;
        }
        if (res.request.response && res.request.status !== 200) {
          let obj = JSON.parse(res.request.response);
          this.setState({ error_message: obj.msg });
          return;
        }
      }).catch(error => {
        console.log(error)
      });
    }
  }

  getFunction = (e) => {
    let requestDetails = {
      method: 'organizations/' + localStorage.orgid,
      params: { user_id: localStorage.userid }
    };
    apiGet(requestDetails, true).then((response) => {
      this.setState({ originalData: cloneDeep(response.data), editdetails: response.data });
      if (response.data.biweeklyStart) {
        this.setState({ biweeklyStart: moment(response.data.biweeklyStart).format('YYYY-MM-DD') });
      }
    }).catch(error => {
      console.log(error)
    });
  }

  isWeekday = (date) => {
    const day = date.getDay()
    return day === 0
  }

  ExampleCustomInput = ({ value, onClick }) => (
    <div className="inner-addon right-addon">
      <i className="fa fa-calendar"></i>
      <input disabled={this.state.timeeditable} onChange={() => { }} onClick={onClick} value={value} type="text" className="form-control" placeholder="Select Date" name="biweeklyStart" />
    </div>
  );
  render() {
    const { biweeklyStart, errors, editdetails, orgImage, editable, originalData } = this.state;
    return (
      <div>
        <div id="stepper1" className="bs-stepper">
          <div className="bs-stepper-header">
            <div className="step" data-target="#test-l-1">
              <button className="step-trigger">
                <span className="bs-stepper-label">Organization Profile</span>
              </button>
            </div>
            <div className="step" data-target="#test-l-2">
              <button className="step-trigger">
                <span className="bs-stepper-label">Date/Time Preferences</span>
              </button>
            </div>
            <div className="step" data-target="#test-l-3">
              <button className="step-trigger">
                <span className="bs-stepper-label">Manage Super/Admin User</span>
              </button>

            </div>
          </div>
          <div className="bs-stepper-content">
            <div id="test-l-1" className="content  pl-1 width-80 small_font">
              <p className="text-danger text-center">{this.state.error_message}</p>
              <div className="form-group row">
                <div className="col-xl-6 col-lg-6 col-md-6 col-sm-12">
                  <label for="exampleInputEmail1">Organization Name*</label>
                  <input type="text" value={editdetails.name} name="name" onChange={this.handleFormChange} disabled className={(errors["name"] ? errors["name"] : 'form-control')} id="exampleInputEmail1" placeholder="Enter Organization Name" />
                </div>
                <div className="col-xl-6 col-lg-6 col-md-6 col-sm-12">
                  <label>TIN Number*</label>
                  <input type="text" value={editdetails.tin} name="tin" onChange={this.handleFormChange} disabled className={(errors["tin"] ? errors["tin"] : 'form-control')} placeholder="TIN Number" />
                </div>
              </div>
              <div className="form-group">
                <label for="exampleInputEmail1">Upload Logo</label>
                <Row className="">
                  <Col lg="3" md="3" sm="12" className="mt-1">
                    <img alt="Banner" width="45%"
                      src={orgImage ? orgImage : require("./assets/img/user-default.png").default} />
                  </Col>
                  <Col lg="3" md="3" sm="12" className="mt-3">
                    <input type="file" name="image" onChange={this.uploadPicture} disabled={editable} accept=".png, .jpg, .jpeg" />
                    <p className="mt-1">File size limit: 1 MB</p>
                  </Col>
                </Row>
              </div>
              <div className="form-group">
                <label>Address*</label>
                <input type="text" value={editdetails.address1} name="address1" onChange={this.handleFormChange} disabled={editable} className={(errors["address1"] ? errors["address1"] : 'form-control')} placeholder="Enter Address" />
              </div>
              <div className="form-group">
                <label>Address 2</label>
                <input type="text" value={editdetails.address2} name="address2" onChange={this.handleFormChange} disabled={editable} className="form-control" placeholder="Enter Address 2" />
              </div>
              <div className="row form-group">
                <div className="col-xl-4 col-lg-4 col-md-4 col-sm-12">
                  <label>City*</label>
                  <input type="text" value={editdetails.city} name="city" onChange={this.handleFormChange} disabled={editable} className={(errors["city"] ? errors["city"] : 'form-control')} placeholder="City" />
                </div>
                <div className="col-xl-4 col-lg-4 col-md-4 col-sm-12">
                  <label>State*</label>
                  <select placeholder="State" value={editdetails.state} name="state" onChange={this.handleFormChange} disabled={editable} className={(errors["state"] ? errors["state"] : 'form-control')}>
                    {stateDetails.map((x, key) => (
                      <option value={x.value} key={key}>{x.label}</option>
                    ))}
                  </select>
                </div>
                <div className="col-xl-4 col-lg-4 col-md-4 col-sm-12">
                  <label>Zip Code*</label>
                  <input type="text" value={editdetails.zip} name="zip" onChange={this.handleFormChange} disabled={editable} className={(errors["zip"] ? errors["zip"] : 'form-control')} placeholder="Zip Code" />
                </div>
              </div>
              <div className="row form-group">
                <div className="col-xl-4 col-lg-4 col-md-4 col-sm-12">
                  <label>Country*</label>
                  <input type="text" value={editdetails.country} name="country" onChange={this.handleFormChange} disabled={editable} className={(errors["country"] ? errors["country"] : 'form-control')} placeholder="Country" />
                </div>
                <div className="col-xl-4 col-lg-4 col-md-4 col-sm-12">
                  <label>Phone Number*</label>
                  <input type="text" value={editdetails.phone} name="phone" onChange={this.handleFormChange} disabled={editable} className={(errors["phone"] ? errors["phone"] : 'form-control')} placeholder="Phone Number" />
                </div>
                <div className="col-xl-4 col-lg-4 col-md-4 col-sm-12">
                  <label>Fax Number</label>
                  <input type="text" value={editdetails.fax} name="fax" onChange={this.handleFormChange} disabled={editable} className="form-control" placeholder="Fax Number" />
                </div>
              </div>
              <div className="row form-group">
                <div className="col-xl-4 col-lg-4 col-md-4 col-sm-12">
                  <label>Email*</label>
                  <input type="email" value={editdetails.email} name="email" onChange={this.handleFormChange} disabled={editable} className={(errors["email"] ? errors["email"] : 'form-control')} placeholder="Email" />
                </div>
                <div className="col-xl-4 col-lg-4 col-md-4 col-sm-12">
                  <label>Website</label>
                  <input type="text" value={editdetails.website} name="website" onChange={this.handleFormChange} disabled={editable} className="form-control" placeholder="Website" />
                </div>
              </div>
              {editable && <ul className="row form-group mr-0 mt-4 pr-0 list-inline pull-right">
                <li><button onClick={() => this.setState({ editable: false })} className="button resend-btn py-2 px-4 m-0 mr-2">Edit</button></li>
              </ul>}
              {!editable && <ul className="row form-group mr-0 mt-4 pr-0 list-inline pull-right">
                <li><button onClick={() => this.setState({ editable: true, editdetails: cloneDeep(originalData), errors: {}, error_message: null })} className="button cancel-btn py-2 px-4 m-0 mr-2">Cancel</button></li>
                <li><button data-tag={editdetails.id} onClick={this.editRecord} className="button resend-btn py-2 px-4 m-0">Save Changes</button></li>
              </ul>}
            </div>
            <div id="test-l-2" className="content  pl-1 width-80 small_font">
              <div className="row form-group">
                <div className="col-xl-6 col-lg-6 col-md-6 col-sm-12">
                  <label>Timesheet Recording Period*</label>
                  <select value={editdetails.recPeriod} name="recPeriod" onChange={this.handleFormChange} placeholder="Select" disabled={this.state.timeeditable} className="form-control">
                    <option value='Weekly'>Weekly</option>
                    <option value='Bi-Weekly'>Bi-Weekly</option>
                  </select>
                </div>
                {editdetails.recPeriod === 'Bi-Weekly' &&
                  <div className="col-xl-6 col-lg-6 col-md-6 col-sm-12">
                    <label>Initial First Week Date</label>
                    <DatePicker
                      disabled={this.state.timeeditable}
                      selected={new Date(biweeklyStart)}
                      value={biweeklyStart}
                      name="biweeklyStart"
                      className="form-control"
                      customInput={<this.ExampleCustomInput />}
                      filterDate={this.isWeekday}
                      onChange={(date) => {
                        this.setState({
                          biweeklyStart: moment(date).format('YYYY-MM-DD')
                        })
                      }}
                      dateFormat="yyyy-MM-dd"
                      placeholderText="yyyy-MM-dd"
                    />
                  </div>
                }
              </div>
              <div className="row form-group">
                <div className="col-xl-6 col-lg-6 col-md-6 col-sm-12">
                  <label>Date Format*</label>
                  <select value={editdetails.dateFormat} name="dateFormat" onChange={this.handleFormChange} placeholder="Select" disabled={this.state.timeeditable} className="form-control">
                    <option value='mm/dd/yyyy'>mm/dd/yyyy</option>
                    <option value='dd-mm-yyyy'>dd-mm-yyyy</option>
                  </select>
                </div>
                <div className="col-xl-6 col-lg-6 col-md-6 col-sm-12">
                  <label>Time Format*</label>
                  <select value={editdetails.timeFormat} name="timeFormat" onChange={this.handleFormChange} placeholder="Select" disabled={this.state.timeeditable} className="form-control">
                    <option value='HH:MM AM/PM'>HH:MM AM/PM</option>
                    <option value='HH:MM:SS AM/PM'>HH:MM:SS AM/PM</option>
                  </select>
                </div>
              </div>
              <ul style={this.state.timeedit === true ? {} : { display: 'none' }} className="row form-group mr-0 mt-4 pr-0 list-inline pull-right">
                <li><button onClick={() => this.setState({ timeedit: false, timeeditable: false })} className="button resend-btn py-2 px-4 m-0 mr-2">Edit</button></li>
              </ul>
              <ul style={this.state.timeedit === true ? { display: 'none' } : {}} className="row form-group mr-0 mt-4 pr-0 list-inline pull-right">
                <li><button onClick={() => this.setState({ editdetails: cloneDeep(originalData), timeedit: true, timeeditable: true, errors: {}, error_message: null })} className="button cancel-btn py-2 px-4 m-0 mr-2">Cancel</button></li>
                <li><button onClick={() => this.editRecord1()} className="button resend-btn py-2 px-4 m-0">Save Changes</button></li>
              </ul>
            </div>
            <div id="test-l-3" className="content pl-1 small_font">
              <SuperAdminUser />
            </div>
          </div>
        </div>
      </div>
    );
  }
}

export default OrganizationTabs;
