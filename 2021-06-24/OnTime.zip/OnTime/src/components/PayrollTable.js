import React from 'react';
import "react-datepicker/dist/react-datepicker.css";
import '../App.css';
import { toNumber } from '../helpers/GeneralHelper';
import moment from 'moment';
import html2pdf from 'html2pdf.js';

class PayrollTable extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      printData: false
    };
  }

  download_csv = () => {
    var html = "<html><head><meta charset='utf-8' /></head><body>" + document.getElementById('payRollReport').outerHTML + "</body></html>";
    var blob = new Blob([html], { type: "application/vnd.ms-excel" });
    var a = document.getElementById("payrollDD");
    a.download = `payRollReport.xls`;
    // Use URL.createObjectURL() method to generate the Blob URL for the a tag.
    a.href = URL.createObjectURL(blob);
  }

  savePDF = (e) => {
    e.preventDefault();
    this.setState({ printData: true });
    let obj = {
      unit: 'cm', format: 'ledger', orientation: 'landscape',
    }
    let content = document.getElementById('payRollReport');
    setTimeout(() => {
      var opt = {
        margin: [0, 1, 0, 1],
        filename: `payroll_report.pdf`,
        html2canvas: { y: 0, scrollY: 0, useCORS: true },
        jsPDF: obj
      };
      html2pdf().set(opt).from(content).save();
    }, 1000)
    setTimeout(() => { this.setState({ printData: false }) }, 2000);
  }

  render() {
    const { dutyCodeArr, payRollArr, withourDutyCodeArr, finalTotalPayRoll, startDate, endDate, orgImage, companyDetails = {} } = this.props;
    const { finalRegHoursTtl, allDutyTotal, dutyWiseTotal, allActTotal, printData } = finalTotalPayRoll;
    return (
      <div className="mx-4 timesheetReport pb-5">
        <div className="buttonLine container">
          <h6 className="text-center">Report Preview</h6>
          <a id="payrollDD" onClick={(e) => this.download_csv(e)} className="button small_font mt-0 resend-btn float-right mb-3">Save As Excel</a>
          <button onClick={(e) => this.savePDF(e)} className="button resend-btn mt-0 ml-2 float-right mb-3">Save As PDF</button>
        </div>
        <div className="payrollform">
          {payRollArr && payRollArr.length > 0 &&
            <div id="payRollReport" className={!printData ? "mt-4 overflow-auto reportHeight" : "mt-4"} >
              <div className="m-2">
                <table className="text-center text-black w-100">
                  <thead>
                    <tr>
                      <th colSpan="2" rowSpan="5" className="border-0">
                        {orgImage && <img src={orgImage} height="100px" alt="orgImage"/>}
                      </th>
                      <th className="border border-white" colSpan={3 + dutyCodeArr.length + withourDutyCodeArr.length}>
                        <h6 className="mb-0">{companyDetails && companyDetails.name} PAYROLL SUMMARY REPORT</h6></th>
                      <th className="border border-white" colSpan={3}>&nbsp;</th>
                    </tr>
                    <tr>
                      <th className="border border-white" colSpan={3 + dutyCodeArr.length + withourDutyCodeArr.length}>
                      {companyDetails ? <h6 className="mb-0">
                          {companyDetails.address1 ? `${companyDetails.address1},` : ''}
                          {companyDetails.address2 ? ` ${companyDetails.address2},` : ''}
                          {companyDetails.city ? ` ${companyDetails.city},` : ''}
                          {companyDetails.zip ? ` ${companyDetails.zip},` : ''}
                          {companyDetails.state ? ` ${companyDetails.state},` : ''}
                        </h6> : <h6>&nbsp;</h6> }
                      </th>
                      <th className="border border-white" colSpan={3}>&nbsp;</th>
                    </tr>
                    <tr>
                      <th className="border-white border-bottom-0" colSpan={3 + dutyCodeArr.length + withourDutyCodeArr.length}>
                        <h6 className="mb-0">FROM {moment(startDate).format('MM/DD/YYYY')} TO {moment(endDate).format('MM/DD/YYYY')}</h6>
                      </th>
                      <th className="border border-white" colSpan={3}>&nbsp;</th>
                    </tr>
                    <tr><th className="border-white border-bottom-0" colSpan={2 + dutyCodeArr.length + withourDutyCodeArr.length}>
                    </th>
                      <th colSpan={2} className="px-0 border-0 text-right">Certified By :</th>
                      <th colSpan={2} className="border-0 text-left pr-0">_________________</th>
                    </tr>
                    <tr>
                      <th className="border-white border-bottom-0" colSpan={2 + dutyCodeArr.length + withourDutyCodeArr.length}>
                      </th>
                      <th colSpan={2} className="px-0 border-0 text-right">Print Name :</th>
                      <th colSpan={2} className="border-0 text-left pr-0">{JSON.parse(localStorage.userdetails).firstName} {JSON.parse(localStorage.userdetails).lastName}</th>
                    </tr>

                    <tr>
                      <th rowSpan='3'>GROUP ID</th>
                      <th colSpan='2'>NAME</th>
                      <th rowSpan='3'>FINAL REG HOURS</th>
                      <th rowSpan='3'>EVENT ATTENTION</th>
                      <th rowSpan='3'>HOURS ADJUST</th>
                      <th colSpan={dutyCodeArr.length + withourDutyCodeArr.length + 2}>FROM {moment(startDate).format('MM/DD/YYYY')} TO {moment(endDate).format('MM/DD/YYYY')}</th>
                    </tr>
                    <tr>
                      <th rowSpan='2'>LAST NAME</th>
                      <th rowSpan='2'>FIRST NAME</th>
                      <th rowSpan='2'>TOTAL</th>
                      <th rowSpan='2'>TOTAL REG LABOR</th>
                      {payRollArr && payRollArr.map((x, i) => {
                        return <React.Fragment key={i}>
                          {i === 0 && x.actTypeArr.map((actType, k) => {
                            return <th key={k} colSpan={actType === 'DUTY' ? dutyCodeArr.length : null}>{actType}</th>
                          })}
                        </React.Fragment>
                      })}
                    </tr>
                    <tr>
                      {dutyCodeArr && dutyCodeArr.map((actId, k) => (<th key={k} >{actId}</th>))}
                      {payRollArr && payRollArr.map((x, i) => {
                        return <React.Fragment key={i}>
                          {i === 0 && Object.entries(x.timeObj).map((actType, k) => {
                            return actType[0] !== 'DUTY' ? <th key={k}>{actType[1][0].code}</th> : null
                          })}
                        </React.Fragment>
                      })}
                    </tr>
                  </thead>
                  <tbody>
                    {payRollArr && payRollArr.map((x, i) => {
                      return <React.Fragment key={i}>
                        <tr>
                          <td>{x.groupCode}</td>
                          <td>{x.firstName}</td>
                          <td>{x.lastName}</td>
                          <td className="background-blue">{toNumber(x.allTotal + (x.hoursAdjust || 0.0))}</td>
                          <td />
                          <td />
                          <td>{toNumber(x.allTotal)}</td>
                          <td>{toNumber(x.dutyTotal)}</td>
                          {Object.values(x.timeObj) && Object.values(x.timeObj).map((data, key) => {
                            return data.map((actSum, sKey) => {
                              return <React.Fragment>
                                <td key={sKey}> {toNumber(actSum.value)}</td>
                              </React.Fragment>
                            })
                          })}
                        </tr>
                      </React.Fragment>
                    })}
                    <tr>
                      <td colSpan={8 + dutyCodeArr.length + withourDutyCodeArr.length}></td>
                    </tr>
                    <tr className="background-blue">
                      <td />
                      <td className="font-weight-bold">Total</td>
                      <td />
                      <td className="font-weight-bold">{finalRegHoursTtl}</td>
                      <td />
                      <td />
                      <td className="font-weight-bold">{allActTotal}</td>
                      <td className="font-weight-bold">{allDutyTotal}</td>
                      {dutyWiseTotal && dutyWiseTotal.map((dt, wkey) => <td key={wkey} className="font-weight-bold">{toNumber(dt.value)}</td>)}
                    </tr>
                    <tr>
                      <td colSpan={8 + dutyCodeArr.length + withourDutyCodeArr.length}></td>
                    </tr>
                    <tr>
                      <td /><td className="background-green"></td><td>New Hire</td><td></td><td></td><td></td><td></td>
                      <td></td>
                      <td colSpan={dutyCodeArr.length + withourDutyCodeArr.length}></td>
                    </tr>
                    <tr>
                      <td></td><td className="bg-orange"></td><td>Attention</td><td></td><td></td><td></td><td></td>
                      <td></td>
                      <td colSpan={dutyCodeArr.length + withourDutyCodeArr.length}></td>
                    </tr>
                    <tr>
                      <td></td><td className="background-red"></td><td>Terminated</td><td></td><td></td><td></td><td></td>
                      <td></td>
                      <td colSpan={dutyCodeArr.length + withourDutyCodeArr.length}></td>
                    </tr>
                  </tbody>
                </table>
              </div>
            </div>}
        </div>
      </div>
    );
  }
}
export default PayrollTable;