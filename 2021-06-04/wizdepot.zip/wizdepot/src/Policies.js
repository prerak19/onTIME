import React from 'react';
import { Container } from 'react-bootstrap';
import 'bootstrap/dist/css/bootstrap.min.css';
import './App.css';
import PoliciesTabs from './components/PoliciesTabs.js';

class Policies extends React.Component {
  render() {
    return (
      <div className="App">
        <Container>
          <div className="contentwrapper pt-1 pb-5 mb-5">
            <PoliciesTabs />
          </div>
        </Container>
      </div>
    );
  }
}

export default Policies;
