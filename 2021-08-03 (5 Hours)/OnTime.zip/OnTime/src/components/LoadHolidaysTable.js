import React from 'react';
import DatePicker from "react-datepicker";
import "react-datepicker/dist/react-datepicker.css";
import '../App.css';
import { Modal, Table } from "react-bootstrap";
import { apiPost, apiGet, apiPut, apiDelete } from '../Api.js';
import DualListBox from 'react-dual-listbox';
import 'react-dual-listbox/lib/react-dual-listbox.css';
import { momentDate, subStringVal } from '../helpers/GeneralHelper';
import { confirmPopup } from '../helpers/Helpers';
import ReactTable from './common/ReactTable';

class LoadHolidaysTable extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      show: false,
      editshow: false,
      timedisabled: true,
      startdisabled: true,
      enddisabled: true,
      isChecked: false,
      holidayshow: false,
      rowresult: [],
      editdetails: [],
      options: [],
      selected: [],
      holidayList: [],
      fields: {},
      errors: {},
      error_message: '',
      extraholidays: [],
      ehfields: [],
      editbtn: false,
      ehfieldsedit: []
    };
  }
  handleFormChange = (e) => {
    let editdetails = this.state.editdetails;
    let errors = this.state.errors;
    editdetails[e.target.name] = e.target.value;
    errors[e.target.name] = "form-control is-valid";
    this.setState({
      editdetails
    });
  }
  handleHFormChange = (name, value) => {
    let ehfields = this.state.ehfields;
    let errors = this.state.errors;
    ehfields[name] = value;
    errors[name] = "form-control is-valid";
    this.setState({
      ehfields
    });
  }
  validateForm() {

    let editdetails = this.state.editdetails;
    let errors = {};
    let formIsValid = true;

    if (!editdetails["name"]) {
      formIsValid = false;
      errors["name"] = "form-control is-invalid";
    }
    if (!formIsValid) {
      this.setState({
        error_message: 'Please fill all * Required Fields!'
      });
    } else {
      this.setState({
        error_message: ''
      });
    }

    this.setState({
      errors: errors
    });
    return formIsValid;
  }
  onChange = (selected) => {
    let data = this.state.options;
    this.setState({ holidayList: [] });
    let arr1 = [];
    selected.map((item) => {
      let obj = data.find(o => o.value === item);
      arr1.push({ hid: obj.labelid, desc: obj.value, hDate: obj.labeldate })
      return null;
    })
    this.setState({ holidayList: arr1, selected });
  };

  deleteProcess = (e) => {
    var dv = e.currentTarget.dataset.tag;
    confirmPopup(() => this.deleteRecord(dv));
  }
  deleteRecord = (id) => {
    let requestDetails = {
      method: `policies/holidaypolicies/${id}`,
      params: {}
    };
    apiDelete(requestDetails).then((res) => {
      if (res && res.status === 200 && res.data) {
        this.getHolidayPolicies();
      }
      if (res.request.response && res.request.status !== 200) {
        let obj = JSON.parse(res.request.response);
        obj.msg ? window.alert(obj.msg) : window.alert('Something Went Wrong!');
        return;
      }
    }).catch(error => {
      console.log(error)
    });
  }
  editRecord = (e) => {
    if (this.validateForm()) {
      let requestDetails = {
        method: 'policies/holidaypolicies/' + e.currentTarget.dataset.tag,
        params: {
          pid: e.currentTarget.dataset.tag,
          name: this.state.editdetails.name,
          description: this.state.editdetails.description,
          holidayList: this.state.holidayList
        }
      };
      apiPut(requestDetails).then((res) => {
        if (res && res.status === 200 && res.data) {
          this.setState({ editshow: false });
          this.getHolidayPolicies();
        }
        if (res.request.response && res.request.status !== 200) {
          let obj = JSON.parse(res.request.response);
          obj.msg ? window.alert(obj.msg) : window.alert('Something Went Wrong!');
          return;
        }
      }).catch(error => {
        console.log(error)
      });
    } else {

    }
  }
  addRecord = (e) => {
    if (this.validateForm()) {
      let requestDetails = {
        method: 'policies/holidaypolicies',
        params: {
          orgID: localStorage.orgid,
          name: this.state.editdetails.name,
          description: this.state.editdetails.description,
          holidayList: this.state.holidayList
        }
      };
      apiPost(requestDetails).then((res) => {
        if (res && res.status === 200 && res.data) {
          this.setState({ show: false });
          this.getHolidayPolicies();
        }
        if (res.request.response && res.request.status !== 200) {
          let obj = JSON.parse(res.request.response);
          obj.msg ? window.alert(obj.msg) : window.alert('Something Went Wrong!');
          return;
        }
      }).catch(error => {
        console.log(error)
      });
    }
  }
  addProcess = (d) => {
    this.setState({ show: true });
    this.setState({ editdetails: [] });
    this.setState({ selected: [] });
    this.setState({ holidayList: [] });
    this.setState({ options: [] });
    let requestDetails1 = {
      method: 'policies/stdholidays',
      params: {}
    };
    apiGet(requestDetails1).then((response) => {
      let arr1 = this.state.options;
      Array.isArray(response.data) && response.data.map((item) => (
        arr1.push({ value: item.desc, label: item.desc + '(' + item.hDate + ')', labelid: item.hid, labeldate: item.hDate })
      ))
      this.setState({ options: arr1 });
    }).catch(error => {
      console.log(error)
    });
  }
  editProcess = (d) => {
    this.setState({ editshow: true });
    this.setState({ editdetails: [] });
    this.setState({ selected: [] });
    this.setState({ holidayList: [] });
    this.setState({ options: [] });
    this.setState({ extraholidays: [] });
    let requestDetails1 = {
      method: 'policies/stdholidays',
      params: {}
    };
    apiGet(requestDetails1).then((response) => {
      let arr1 = this.state.options;
      Array.isArray(response.data) && response.data.map((item) => (
        arr1.push({ value: item.desc, label: item.desc + '(' + item.hDate + ')', labelid: item.hid, labeldate: item.hDate })
      ))
      this.setState({ options: arr1 });
    }).catch(error => {
      console.log(error)
    });
    let requestDetails = {
      method: 'policies/holidaypolicies/' + d.currentTarget.dataset.tag,
      params: {}
    };
    apiGet(requestDetails).then((response) => {
      this.setState({ editdetails: response.data });

      let arr = this.state.selected;
      let arr1 = this.state.options;
      let arr2 = this.state.holidayList;
      let arr3 = this.state.extraholidays;
      let arr4 = [];
      Array.isArray(arr1) && arr1.map((item2) => {
        if (arr4.indexOf(item2.value) == -1) {
          arr4.push(item2.value);
        }
        return null;
      })
      Array.isArray(response.data.holidayList) && response.data.holidayList.map((item1) => {
        if (arr4.indexOf(item1.desc) == -1) {
          arr3.push({ hDate: item1.hDate, desc: item1.desc });
        }
        if (arr.indexOf(item1.desc) == -1) {
          arr.push(item1.desc);
        }

        arr2.push({ hid: item1.hid, hDate: item1.hDate, desc: item1.desc });
        arr1.push({ value: item1.desc, label: item1.desc + '(' + item1.hDate + ')', labelid: item1.hid, labeldate: item1.hDate })
      })
      this.setState({ extraholidays: arr3, selected: arr, holidayList: arr2, options: this.getUnique(arr1, 'value') });
    }).catch(error => {
      console.log(error)
    });
  }
  getUnique(arr, index) {

    const unique = arr
      .map(e => e[index])

      // store the keys of the unique objects
      .map((e, i, final) => final.indexOf(e) === i && i)

      // eliminate the dead keys & store unique objects
      .filter(e => arr[e]).map(e => arr[e]);

    return unique;
  }
  addextraholidays = (e) => {
    let arr = this.state.extraholidays;
    arr.push({ hDate: this.state.ehfields.ehDate, desc: this.state.ehfields.ehDesc });
    console.log(arr);
    this.setState({ extraholidays: arr });
    let arr1 = this.state.options;
    {
      Array.isArray(this.state.extraholidays) && this.state.extraholidays.map((item) => (
        arr1.push({ value: item.desc, label: item.desc + '(' + item.hDate + ')', labelid: '', labeldate: item.hDate })
      ))
    }
    this.setState({ options: this.getUnique(arr1, 'value') });
    let ehfields = this.state.ehfields;
    ehfields['ehDate'] = '';
    ehfields['ehDesc'] = '';
    this.setState({ ehfields });
  }
  editEHProcess = (e) => {
    this.setState({ editbtn: true });
    let ehfields = this.state.ehfields;
    let ehfieldsedit = this.state.ehfieldsedit;
    ehfieldsedit['ehDate'] = this.state.ehfields.date;
    ehfieldsedit['ehDesc'] = e.currentTarget.dataset.desc;
    ehfields['ehDate'] = e.currentTarget.dataset.date;
    ehfields['ehDesc'] = e.currentTarget.dataset.desc;
    this.setState({ ehfields });
    this.setState({ ehfieldsedit });
  }
  deleteEHProcess = (f) => {
    let editdesc = f.currentTarget.dataset.desc;
    let exarr = this.state.extraholidays;
    this.setState({ extraholidays: [] });
    let arr = [];
    {
      Array.isArray(exarr) && exarr.map((item) => {
        if (item.desc == editdesc) {

        } else {
          arr.push({ hDate: item.hDate, desc: item.desc })
        }
      })
    }
    this.setState({ extraholidays: arr });
    let exarro = this.state.options;
    this.setState({ options: [] });
    let arro = [];
    {
      Array.isArray(exarro) && exarro.map((item) => {
        if (item.value == editdesc) {
          arro.push({ labeldate: this.state.ehfields.ehDate, label: item.value + '(' + item.labeldate + ')', labelid: item.labelid, value: this.state.ehfields.ehDesc })
        } else {
          arro.push({ value: item.value, label: item.value + '(' + item.labeldate + ')', labelid: item.labelid, labeldate: item.labeldate })
        }
      })
    }
    this.setState({ options: arro });

    let exarrs = this.state.selected;
    this.setState({ selected: [] });
    let arrs = [];
    {
      Array.isArray(exarrs) && exarrs.map((item) => {
        if (item == editdesc) {
        } else {
          arrs.push(item)
        }
      })
    }
    this.setState({ selected: arrs });

    this.onChange(this.state.selected);

    let ehfields = this.state.ehfields;
    ehfields['ehDate'] = '';
    ehfields['ehDesc'] = '';
    this.setState({ ehfields });
  }
  handleEditRec = (e) => {
    this.setState({ holidayshow: true })
    //this.editProcess();
  }
  editEHRecord = (f) => {
    let editdesc = f.currentTarget.dataset.desc;
    this.setState({ editbtn: false });
    let exarr = this.state.extraholidays;
    this.setState({ extraholidays: [] });
    let arr = [];
    Array.isArray(exarr) && exarr.map((item) => {
      if (item.desc == editdesc) {
        arr.push({ hDate: this.state.ehfields.ehDate, desc: this.state.ehfields.ehDesc })
      } else {
        arr.push({ hDate: item.hDate, desc: item.desc })
      }
    })
    this.setState({ extraholidays: arr });
    let exarro = this.state.options;
    this.setState({ options: [] });
    let arro = [];
    Array.isArray(exarro) && exarro.map((item) => {
      if (item.value == editdesc) {
        arro.push({ labeldate: this.state.ehfields.ehDate, label: item.value + '(' + item.labeldate + ')', labelid: item.labelid, value: this.state.ehfields.ehDesc })
      } else {
        arro.push({ value: item.value, label: item.value + '(' + item.labeldate + ')', labelid: item.labelid, labeldate: item.labeldate })
      }
    })
    this.setState({ options: arro });
    this.onChange(this.state.selected);
    let ehfields = this.state.ehfields;
    ehfields['ehDate'] = '';
    ehfields['ehDesc'] = '';
    this.setState({ ehfields });
    /*let arr1 = this.state.options;
    { Array.isArray(this.state.extraholidays) &&  this.state.extraholidays.map((item) =>(  
      arr1.push({ value: item.desc , label: item.desc+'('+item.hDate+')', labelid: '', labeldate: item.hDate })
    ))
    }
    this.setState({ options: arr1 });  */
  }

  componentDidMount() {
    this.getHolidayPolicies();
  }

  getHolidayPolicies = async () => {
    let requestDetails = {
      method: 'policies/holidaypolicies/all/' + localStorage.orgid,
      params: {}
    };
    await apiGet(requestDetails).then((response) => {
      let result = response.data;
      let arr = [];
      Array.isArray(result) && result.map((item) => {
        let holidaysArr = [];
        if (item.holidayList && item.holidayList.length > 0) {
          holidaysArr = item.holidayList.map((x) => x.desc);
        }
        let paidStr = holidaysArr.join(', ');
        arr.push({
          name: item.name,
          description: item.description,
          paid: <span>{paidStr.length > 60 ? subStringVal(paidStr, 60) : paidStr}</span>,
          edit: <i className="fa fa-edit" data-tag={item.pid} onClick={this.editProcess}></i>,
          delete: <i className="fa fa-trash" data-tag={item.pid} onClick={this.deleteProcess}></i>,
        })
        return null;
      })
      this.setState({ rowresult: arr });
    }).catch(error => {
      console.log(error)
    });
  }

  ExampleCustomInput = ({ value, onClick }) => (
    <div className="inner-addon right-addon">
      <i className="fa fa-calendar" onClick={onClick}></i>
      <input onClick={onClick} value={value} onChange={() => { }} type="text" className="form-control" placeholder="Select Date" name="date" />
    </div>
  );

  render() {
    const defaultColumns = [
      {
        text: 'Policy Name',
        dataField: 'name',
      },
      {
        text: 'Policy Description',
        dataField: 'description',
      },
      {
        text: 'Reoccuring Paid Holidays',
        dataField: 'paid',
      },
      {
        text: 'Edit',
        dataField: 'edit',
      },
      {
        text: 'Delete',
        dataField: 'delete',
      },
    ];

    return (
      <div className="content pl-1 small_font">
        <div className="col-12 row mr-0 pr-0 pl-0 ml-0 mb-3">
          <div className="text-left float-left col-lg-9 col-md-9 col-xl-9 col-sm-12 pl-0">
            <h6 className="mb-0">Holiday Policies</h6>
            <span className="text-muted">These Policies affect how Holidays are handled in the timekeeping system </span>
          </div>
          <button onClick={this.addProcess} className="h-35 button resend-btn py-2 px-4 col-lg-3 col-xl-3 col-md-3 col-sm-4 m-0"><i className="fa fa-plus pr-2"></i>Add New Holiday Policy</button>
        </div>
        <ReactTable
          className="timesheets"
          columns={defaultColumns}
          showPagination={true}
          data={this.state.rowresult}
        />
        <Modal scrollable={true} size="lg"
          show={this.state.holidayshow}
          aria-labelledby="contained-modal-title-vcenter">
          <Modal.Header>
            <Modal.Title className="m-auto h6" >
              Manage Extra Holiday
        </Modal.Title>
          </Modal.Header>
          <Modal.Body className="show-grid small_font">
            <div className="row">
              <div className="col-xl-4 col-lg-4 col-md-4 col-sm-12">
                <div className="form-group">
                  <label>Holiday Title*</label>
                  <input type="text" name='ehDesc' value={this.state.ehfields.ehDesc} onChange={this.handleHFormChange} className="form-control" placeholder="Enter Holiday Title" />
                </div>
                <div className="form-group">
                  <label>Date*</label>
                  <DatePicker
                    selected={this.state.ehfields.ehDate ? momentDate(this.state.ehfields.ehDate) : null}
                    value={this.state.ehfields.ehDate}
                    name="ehDate"
                    showMonthDropdown
                    showYearDropdown
                    dropdownMode="select"
                    className='form-control'
                    customInput={<this.ExampleCustomInput />}
                    onChange={(date) => this.handleHFormChange('ehDate', date)}
                    dateFormat="yyyy-MM-dd"
                    placeholderText="yyyy-MM-dd"
                  />
                </div>
                <button onClick={this.addextraholidays} style={this.state.editbtn === false ? {} : { display: 'none' }} className="button resend-btn py-2 px-4 m-0">Save</button>
                <button onClick={this.editEHRecord} data-desc={this.state.ehfieldsedit.ehDesc} style={this.state.editbtn === true ? {} : { display: 'none' }} className="button resend-btn py-2 px-4 m-0">Update</button>
              </div>
              <div className="col-xl-8 col-lg-8 col-md-8 col-sm-12">
                <Table responsive bordered className="activityloadtable overflow">
                  <thead>
                    <tr>
                      <th>Title</th>
                      <th>Date</th>
                      <th>Edit</th>
                      <th>Delete</th>
                    </tr>
                  </thead>
                  <tbody>
                    {Array.isArray(this.state.extraholidays) && this.state.extraholidays.map((item, i) => {
                      return <tr key={i}>
                        <td>{item.desc}</td>
                        <td>{item.hDate}</td>
                        <td><i className="fa fa-edit" data-desc={item.desc} data-date={item.hDate} onClick={this.editEHProcess}></i></td>
                        <td><i className="fa fa-trash" data-desc={item.desc} data-date={item.hDate} onClick={this.deleteEHProcess}></i></td>
                      </tr>
                    })}
                  </tbody>
                </Table>
              </div>
            </div>
          </Modal.Body>
          <Modal.Footer>
            <ul className="row form-group mr-0 mt-4 pr-0 list-inline pull-right">
              <li><button onClick={() => this.setState({ holidayshow: false })} className="button cancel-btn py-2 px-4 m-0 mr-2">Close</button></li>
            </ul>
          </Modal.Footer>
        </Modal>
        <Modal scrollable={true} size="lg" onHide={() => this.setState({ show: false })}
          show={this.state.show}>
          <Modal.Header closeButton>
            <Modal.Title className="h6" >
              Add Holiday Policy
        </Modal.Title>
          </Modal.Header>
          <Modal.Body className="show-grid small_font px-5">
            <div className="text-danger col-12 text-center">{this.state.error_message}</div>
            <div className="form-group">
              <label>Policy Name*</label>
              <input type="text" value={this.state.editdetails.name} name="name" onChange={this.handleFormChange} className={(this.state.errors["name"] ? this.state.errors["name"] : '')} className="form-control" placeholder="Policy Name" />
            </div>
            <div className="form-group">
              <label>Policy Description</label>
              <textarea type="email" value={this.state.editdetails.description} name="description" onChange={this.handleFormChange} className={(this.state.errors["description"] ? this.state.errors["description"] : '')} className="form-control" placeholder="Policy Description"></textarea>
            </div>
            <div className="form-group row">
              <div className="col-xl-12 col-lg-12 col-md-12 col-sm-12">
                <label className="mr-2">Reoccuring Paid Holidays</label>
                <button className="button resend-btn py-2 px-4 m-0 text-center" onClick={() => this.setState({ holidayshow: true, extraholidays: [] })}>Add/Edit/Delete Extra Holiday</button>

                <DualListBox lang={{
                  selectedHeader: 'Selected Holidays',
                  availableHeader: 'Available Holidays'
                }}
                  showHeaderLabels={true}
                  options={this.state.options}
                  selected={this.state.selected}
                  onChange={this.onChange} className="mt-2" icons={{
                    moveLeft: '<',
                    moveAllLeft: '<<',
                    moveRight: '>',
                    moveAllRight: '>>'
                  }}
                />

              </div>
            </div>
          </Modal.Body>
          <Modal.Footer>
            <ul className="row form-group mr-0 mt-4 pr-0 list-inline pull-right">
              <li><button onClick={() => this.setState({ show: false })} className="button cancel-btn py-2 px-4 m-0 mr-2">Cancel</button></li>
              <li><button onClick={this.addRecord} className="button resend-btn py-2 px-4 m-0">Save</button></li>
            </ul>
          </Modal.Footer>
        </Modal>
        <Modal scrollable={true} size="lg" onHide={() => this.setState({ editshow: false })}
          show={this.state.editshow}>
          <Modal.Header closeButton>
            <Modal.Title className="h6" >
              Edit Holiday Policy
        </Modal.Title>
          </Modal.Header>
          <Modal.Body className="show-grid small_font px-5">
            <div className="text-danger col-12 text-center">{this.state.error_message}</div>
            <div className="form-group">
              <label>Policy Name*</label>
              <input type="text" value={this.state.editdetails.name} name="name" onChange={this.handleFormChange} className={(this.state.errors["name"] ? this.state.errors["name"] : '')} className="form-control" placeholder="Policy Name" />
            </div>
            <div className="form-group">
              <label>Policy Description</label>
              <textarea type="email" value={this.state.editdetails.description} name="description" onChange={this.handleFormChange} className={(this.state.errors["description"] ? this.state.errors["description"] : '')} className="form-control" placeholder="Policy Description"></textarea>
            </div>
            <div className="form-group row">
              <div className="col-xl-12 col-lg-12 col-md-12 col-sm-12">
                <label className="mr-2">Reoccuring Paid Holidays</label>
                <button className="button resend-btn py-2 px-4 m-0 text-center" onClick={this.handleEditRec}>Add/Edit/Delete Extra Holiday</button>

                <DualListBox lang={{
                  selectedHeader: 'Selected Holidays',
                  availableHeader: 'Available Holidays'
                }}
                  showHeaderLabels={true} allowDuplicates={false}
                  options={this.state.options}
                  selected={this.state.selected}
                  onChange={this.onChange} className="mt-2" icons={{
                    moveLeft: '<',
                    moveAllLeft: '<<',
                    moveRight: '>',
                    moveAllRight: '>>'
                  }}
                />

              </div>
            </div>
          </Modal.Body>
          <Modal.Footer>
            <ul className="row form-group mr-0 mt-4 pr-0 list-inline pull-right">
              <li><button onClick={() => this.setState({ editshow: false })} className="button cancel-btn py-2 px-4 m-0 mr-2">Cancel</button></li>
              <li><button data-tag={this.state.editdetails.pid} onClick={this.editRecord} className="button resend-btn py-2 px-4 m-0">Save Changes</button></li>
            </ul>
          </Modal.Footer>
        </Modal>
      </div>
    );
  }
}
export default LoadHolidaysTable;