import React from 'react';

// Libs
import { get, find, isEmpty, isEqual, includes } from 'lodash';
import moment from 'moment';
import { MDBDataTable, MDBBtn } from 'mdbreact';
import DatePicker from "react-datepicker";
import "react-datepicker/dist/react-datepicker.css";
import 'bootstrap/dist/css/bootstrap.min.css';
/* import "mdbreact/dist/css/mdb.css";
import "@fortawesome/fontawesome-free/css/all.min.css"; */
import '../App.css';
import { Modal, Row, Col, Nav } from "react-bootstrap";
import { NavLink } from "react-router-dom";
import { apiGet, apiPost } from '../Api.js';
import * as GeneralHelper from '../helpers/GeneralHelper';

const TimesheetOperation = {
  approve: 1,
  reject: 2
};

const DashboardButtonFunctionality = {
  archivable: 1,
  archived: 2
};

class LoadTimesheetsTable extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      displayMassEntryForm: false,
      displayMassEntryDate: '',
      displayUserApprovalForm: false,
      selectedStartWeekDate: '',
      selectedEndWeekDate: '',
      approvedcount: false,
      archivedcount: false,
      timesheetstatus: 'Approvable',
      timesheetStatusCode: 400,
      displayas: 'Weekly',
      startweeklyDate: '',
      endweeklyDate: '',
      summaryDetails: {},
      rowresult: [],
      currentRecordingPeriod: false,
      employeeType: '',
      employeeTypeCode: '',
      activityId: '',
      selectedTimesheets: [],
      isSelectAll: false,
      activitiesInOrg: [],
      activityDropdownOptions: [
        {
          actID: 0,
          name: 'All'
        }
      ],
      activityColumns: [],
      approveBtnDisabled: true,
      rejectBtnDisabled: true,
      archivableBtnDisabled: true,
      archivedBtnDisabled: true,
      massEntryHour: '',
      massEntryComments: '',
      massEntryActivity: '',
      massEntryDate: '',
      massEntryFormSubmitBtn: false,
      uniqueActivityTableCols: [],
      selectedTimesheetOperation: null,
      validTimesheets: [], // array of timesheet IDs
      counter: 0,
      validTimesheetCounter: 0,
      isUserCommentRequired: false,
      userComments: '',
      displayWarningModal: false,
      selectedButtonFunctionality: null,
      displayInformationModal: false,
      contentForInformationModal: ''
    };
  }

  componentDidMount() {
    const sunday = new Date(moment().day(0));
    const nextSunday = new Date(moment().day(7));
    this.setState({
      selectedStartWeekDate: sunday,
      startweeklyDate: moment.utc(sunday).format('YYYY-MM-DD'),
      selectedEndWeekDate: nextSunday,
      endweeklyDate: moment.utc(nextSunday).format('YYYY-MM-DD'),
    })
    this.getSummary(sunday, nextSunday);
    this.getTimesheets(sunday, nextSunday);
    this.getActivitiesInOrganisation();
  }

  selectAllHandler = (evt) => {
    const isChecked = evt.target.checked;
    this.setState({
      isSelectAll: isChecked
    }, () => {
      this.setState({
        selectedTimesheets: isChecked ? this.state.rowresult.map(res => res.tid.toString()) : []
      }, () => {
        this.setState({
          rowresult: this.state.rowresult.map((x, i) => {
            return {
              ...x, check: (
                <input
                  key={`${x.tid}`}
                  type='checkbox'
                  id={`${x.tid}`}
                  value={`${x.tid}`}
                  checked={this.state.selectedTimesheets.includes(`${x.tid}`)}
                  onChange={(e) => this.checkboxHandler(e.target.value)}
                />
              )
            }
          }),
          approveBtnDisabled: this.state.selectedTimesheets.length < 1,
          rejectBtnDisabled: this.state.selectedTimesheets.length < 1,
        })
      })
    })
  }

  handleStartWeekChange = (date) => {
    this.setState({
      selectedStartWeekDate: date,
      startweeklyDate: moment.utc(date).format('YYYY-MM-DD'),
      currentRecordingPeriod: false
    }, () => {
      this.getSummary(date, this.state.selectedEndWeekDate);
      this.getTimesheets(date, this.state.selectedEndWeekDate);
    })
  }

  handleEndWeekChange = (date) => {
    this.setState({
      selectedEndWeekDate: date,
      endweeklyDate: moment.utc(date).format('YYYY-MM-DD'),
      currentRecordingPeriod: false
    }, () => {
      this.getSummary(this.state.selectedStartWeekDate, date);
      this.getTimesheets(this.state.selectedStartWeekDate, date);
    })
  }

  changeStatus = (evt) => {
    const timeSheetFilterStatus = evt.target.value;
    const status = find(GeneralHelper.timesheet_status, { name: timeSheetFilterStatus });
    if (!isEmpty(status) && isEqual(status.name, 'Approved')) {
      if (get(localStorage, 'userdetails.adminType') < 80 || this.state.selectedTimesheets.length < 1) {
        this.setState({ archivableBtnDisabled: true })
      }
    }
    if (!isEmpty(status) && isEqual(status.name, 'Archivable')) {
      if (get(localStorage, 'userdetails.adminType') < 80 || this.state.selectedTimesheets.length < 1) {
        this.setState({ archivedBtnDisabled: true })
      }
    }

    this.setState({
      timesheetstatus: timeSheetFilterStatus,
      timesheetStatusCode: isEqual(timeSheetFilterStatus, 'all') ? '' : parseInt(status.code),
    }, () => {
      this.getSummary(this.state.startweeklyDate, this.state.endweeklyDate);
      this.getTimesheets(this.state.startweeklyDate, this.state.endweeklyDate);
    });
  }

  isWeekday = (date) => {
    const day = date.getDay()
    return day === 0
  }

  ExampleCustomInput = ({ value, onClick }) => (
    <div className="inner-addon right-addon">
      <i className="fa fa-calendar"></i>
      <input onClick={onClick} value={value} type="text" className="example-custom-input form-control" placeholder="Select Date" name="date" />
    </div>
  );

  ExampleCustomInput1 = ({ value, onClick }) => (
    <div className="inner-addon right-addon">
      <i className="fa fa-calendar"></i>
      <input onClick={onClick} value={value} type="text" className="example-custom-input form-control" placeholder="Select Date" name="date" />
    </div>
  );

  getSummary = (sunday, nextSunday) => {
    const requestDetails = {
      method: `timesheets/summary/${localStorage.orgid}`,
      params: {
        from: !isEmpty(sunday.toString()) ? moment(sunday).format('YYYY-MM-DD') : '',
        to: !isEmpty(nextSunday.toString()) ? moment(nextSunday).format('YYYY-MM-DD') : ''
      }
    };

    apiGet(requestDetails, true).then((response) => {
      this.setState({
        summaryDetails: response.data,
        selectedTimesheets: [],
        approveBtnDisabled: true,
        rejectBtnDisabled: true,
        // archivableBtnDisabled: true,
        // archivedBtnDisabled: true
      });
    }).catch(error => {
      console.log(error);
    });
  }

  getActivitiesInOrganisation = () => {
    const request = {
      method: `activities/all/${localStorage.orgid}`,
      params: {}
    }

    apiGet(request, true).then((res) => {
      if (!isEmpty(res.data)) {
        const activityInfo = []
        res.data.forEach((activity) => {
          activityInfo.push({
            actID: activity.actID,
            name: activity.name
          });
        })
        this.setState({
          activitiesInOrg: res.data,
          activityDropdownOptions: [
            ...this.state.activityDropdownOptions,
            ...activityInfo
          ]
        })
      }
    }).catch(err => {
      console.log(err);
    })
  }

  checkboxHandler = (timesheetId) => {
    const timesheet = this.state.selectedTimesheets.find(checkboxId => isEqual(checkboxId, timesheetId));
    if (isEmpty(timesheet)) {
      this.setState({
        selectedTimesheets: [
          ...this.state.selectedTimesheets,
          timesheetId
        ]
      }, () => {
        this.setState({
          rowresult: this.state.rowresult.map((x, i) => {
            if (x.tid == timesheetId) {
              return {
                ...x,
                check: (
                  <input
                    key={`${x.tid}`}
                    type='checkbox'
                    id={`${x.tid}`}
                    value={`${x.tid}`}
                    checked={this.state.selectedTimesheets.includes(`${x.tid}`)}
                    onChange={(e) => this.checkboxHandler(e.target.value)}
                  />
                ),
              }
            }
            else {
              return x;
            }
          }),
          isSelectAll: this.state.selectedTimesheets.length === this.state.rowresult.length,
          approveBtnDisabled: this.state.selectedTimesheets.length < 1,
          rejectBtnDisabled: this.state.selectedTimesheets.length < 1,
        })
      })
    } else {
      this.setState({
        selectedTimesheets: this.state.selectedTimesheets.filter(checkboxId => !isEqual(checkboxId, timesheetId))
      }, () => {
        this.setState({
          rowresult: this.state.rowresult.map((x, i) => {
            if (x.tid == timesheetId) {
              return {
                ...x,
                check: (
                  <input
                    key={`${x.tid}`}
                    type='checkbox'
                    id={`${x.tid}`}
                    value={`${x.tid}`}
                    checked={this.state.selectedTimesheets.includes(`${x.tid}`)}
                    onChange={(e) => this.checkboxHandler(e.target.value)}
                  />
                ),
              }
            }
            else {
              return x;
            }
          }),
          isSelectAll: this.state.selectedTimesheets.length === this.state.rowresult.length,
          approveBtnDisabled: this.state.selectedTimesheets.length < 1,
          rejectBtnDisabled: this.state.selectedTimesheets.length < 1
        })
      })
    }
  }

  getTimesheets = (sunday, nextSunday) => {
    const requestDetails = {
      method: 'timesheets/management',
      params: {
        from: !isEmpty(sunday.toString()) ? moment(sunday).format('YYYY-MM-DD') : '',
        to: !isEmpty(nextSunday.toString()) ? moment(nextSunday).format('YYYY-MM-DD') : '',
        approver_id: 7,
        org_id: localStorage.orgid,
        status: this.state.timesheetStatusCode,
        employee_type: this.state.employeeTypeCode,
        activity_id: this.state.activityId
      }
    };
    apiGet(requestDetails, true).then((response) => {
      const result = get(response.data, 'timsheets', []);
      const arr = [];
      const activityTimesheetInfo = [];
      const activityTableColumns = [];
      result.forEach((timesheet) => {
        const activityTypes = timesheet.activityTime;
        activityTypes.forEach((activity) => {
          activityTableColumns.push({
            id: activity.activityID,
            label: `${activity.activityName} Hours`,
            field: `${activity.activityName}`.toLowerCase(),
          })
          activityTimesheetInfo.push({
            timesheetId: activity.timesheetID,
            activityId: activity.activityID,
            label: `${activity.activityName} Hours`,
            field: `${activity.activityName}`.toLowerCase(),
            totalHours: Object.values(GeneralHelper.DAYS_OF_WEEK).map((day) => activity[`${day.toLowerCase()}Hour`]).reduce((a, b) => a + b, 0)
          })
        })
      });
      const uniqueActivityTableCols = [];
      !isEmpty(activityTableColumns) && activityTableColumns.forEach((col) => {
        const record = uniqueActivityTableCols.filter((uniqueCol) => uniqueCol.id === col.id)
        if (isEmpty(record)) {
          uniqueActivityTableCols.push(col);
        }
      })
      const activityHours = (timesheetId) => {
        const rowValues = [];
        uniqueActivityTableCols.forEach((col) => {
          const record = find(activityTimesheetInfo, { timesheetId, activityId: col.id });
          rowValues.push({
            [col.field]: isEmpty(record) ? '0.0' : record.totalHours
          })
        })
        return Object.assign({}, ...rowValues);
      }
      Array.isArray(result) && result.map((item) => {
        arr.push({
          ...item,
          check: (
            <input
              key={`${item.tid}`}
              type='checkbox'
              id={`${item.tid}`}
              value={`${item.tid}`}
              checked={false}
              onChange={(e) => this.checkboxHandler(e.target.value)}
            />
          ),
          start: (<Nav.Link
            as={NavLink}
            to={{ pathname: "/TimesheetChart/", displayas: this.state.displayas, stateid: item.tid }}
            className="xs_font text-decoration-underline blue-color p-0"
          >
            {moment(item.startDate).format('YYYY-MM-DD')}
          </Nav.Link>),
          timesheetStatus: item.status,
          status: GeneralHelper.timesheet_status_codes[`${item.status}`],
          last_name: item.userLastname,
          first_name: item.userFirstname,
          total: item.overtimeHours + item.regularHours,
          overtime: item.overtimeHours,
          maxot: '0.00',
          regular: item.regularHours,
          ...activityHours(item.tid)
        })
      });
      this.setState({
        rowresult: arr,
        selectedTimesheets: [],
        approveBtnDisabled: true,
        rejectBtnDisabled: true,
        // archivableBtnDisabled: true,
        // archivedBtnDisabled: true,
        uniqueActivityTableCols,
        isSelectAll: false
      });
    }).catch(error => {
      console.log(error);
    });
  }

  setCurrentRecordingPeriod = (checkboxState) => {
    this.setState({ currentRecordingPeriod: !checkboxState });
    const getRequest = {
      method: `timesheets/cur-rec-period/${localStorage.orgid}`,
      params: {}
    };
    apiGet(getRequest, true).then((response) => {
      const start = new Date(get(response.data, 'startDate'));
      const end = new Date(get(response.data, 'endDate'));
      this.setState({
        selectedStartWeekDate: start,
        selectedEndWeekDate: end,
        startweeklyDate: moment.utc(start).format('YYYY-MM-DD'),
        endweeklyDate: moment.utc(end).format('YYYY-MM-DD')
      }, () => {
        this.getSummary(start, end);
        this.getTimesheets(start, end);
      });
    }).catch(error => {
      console.log(error);
    });
  }

  filterByEmployeeType = (evt) => {
    const employeeType = evt.target.value;
    const status = find(GeneralHelper.employeeTypes, { name: employeeType });
    this.setState({
      employeeType,
      employeeTypeCode: isEqual(employeeType, 'all') ? '' : parseInt(status.code)
    }, () => {
      this.getSummary(this.state.startweeklyDate, this.state.endweeklyDate);
      this.getTimesheets(this.state.startweeklyDate, this.state.endweeklyDate);
    });
  }

  filterByActivity = (evt) => {
    const activityCode = evt.target.value;
    this.setState({
      activityId: isEqual(activityCode, '0') ? '' : parseInt(activityCode)
    }, () => {
      this.getSummary(this.state.startweeklyDate, this.state.endweeklyDate);
      this.getTimesheets(this.state.startweeklyDate, this.state.endweeklyDate);
    });
  }

  completeTimesheetOperation = () => {
    const counter = this.state.counter;
    const request = {
      method: this.state.selectedTimesheetOperation === 1 ? 'timesheets/approve' : 'timesheets/disapprove',
      params: {
        timesheetID: parseInt(this.state.validTimesheets[this.state.validTimesheetCounter]),
        madeBy: get(localStorage, 'userid', ''),
        reason: this.state.userComments
      }
    };

    apiPost(request).then((response) => {
      if (counter < this.state.selectedTimesheets.length - 1) {
        this.setState({
          counter: this.state.counter + 1,
          displayUserApprovalForm: false,
          userComments: ''
        }, () => {
          setTimeout(() => {
            this.approveOrRejectTimesheets(this.state.selectedTimesheetOperation)
          }, 500)
        });
      } else {
        this.getSummary(this.state.startweeklyDate, this.state.endweeklyDate);
        this.getTimesheets(this.state.startweeklyDate, this.state.endweeklyDate);
        const message = `${this.state.validTimesheets.length} out of ${this.state.selectedTimesheets.length} selected timesheet${this.state.validTimesheets.length > 1 ? 's' : ''} successfully ${this.state.selectedTimesheetOperation === 1 ? 'approved' : 'rejected'}`
        console.log(message);
      }
    }).catch((err) => console.log(err));
  }

  openUserApprovalForm = () => {
    const { rowresult, selectedTimesheets } = this.state;
    let arr = rowresult.filter((x, i) => selectedTimesheets.includes(`${x.tid}`));
    const maxDate = new Date(Math.max(...arr.map(e => new Date(e.startDate))));
    const minDate = new Date(Math.min(...arr.map(e => new Date(e.startDate))));
    const sunday = moment.utc(minDate).day(0).format('ddd MMM DD, YYYY');
    const nextSunday = moment.utc(maxDate).day(7).format('ddd MMM DD, YYYY');
    this.setState({
      displayUserApprovalForm: true,
      displayMassEntryDate: `${sunday} - ${nextSunday}`
    });
  }

  closeUserApprovalForm = () => {
    this.setState({
      displayUserApprovalForm: false,
      counter: 0,
      validTimesheetCounter: 0,
      validTimesheets: [],
      selectedTimesheetOperation: null,
      isUserCommentRequired: false,
      userComments: '',
      displayMassEntryDate: '',
    }, () => {
      this.getSummary(this.state.startweeklyDate, this.state.endweeklyDate);
      this.getTimesheets(this.state.startweeklyDate, this.state.endweeklyDate);
    })
  }

  approveOrRejectTimesheets = (operation) => {
    const userApprovalFormStatus = this.state.displayUserApprovalForm;
    this.setState({ selectedTimesheetOperation: operation })

    if (!userApprovalFormStatus) {
      const timesheetIds = this.state.selectedTimesheets;
      const tableRecords = this.state.rowresult;
      const timesheetToValidate = timesheetIds[this.state.counter];
      if (!isEmpty(timesheetToValidate) && !includes(this.state.validTimesheets, timesheetToValidate)) {
        const timesheet = find(tableRecords, { tid: parseInt(timesheetToValidate) });
        switch (operation) {
          case 1:
            if (!isEmpty(timesheet) && timesheet.timesheetStatus > 400) {
              this.setState({
                counter: this.state.counter + 1,
                displayUserApprovalForm: false,
                isUserCommentRequired: false
              }, () => {
                return this.approveOrRejectTimesheets(operation);
              })
            } else {
              this.setState({
                validTimesheets: [...this.state.validTimesheets, timesheetToValidate],
                validTimesheetCounter: this.state.validTimesheetCounter + 1,
              }, () => {
                return this.openUserApprovalForm()
              })
            }
            break;
          case 2:
            if (!isEmpty(timesheet) && (timesheet.timesheetStatus !== 300 && timesheet.timesheetStatus !== 400)) {
              this.setState({
                counter: this.state.counter + 1,
                displayUserApprovalForm: false,
                isUserCommentRequired: false
              }, () => {
                return this.approveOrRejectTimesheets(operation);
              })
            } else {
              this.setState({
                validTimesheets: [...this.state.validTimesheets, timesheetToValidate],
                validTimesheetCounter: this.state.validTimesheetCounter + 1,
                isUserCommentRequired: (timesheet.timesheetStatus === 100 || timesheet.timesheetStatus === 200) ? true : false
              }, () => {
                return this.openUserApprovalForm()
              })
            }
            break;
          default:
            break;
        }
      }
    }
  }

  updateTimesheetStatusToArchivedOrArchivable = () => {
    const validTimesheets = [];
    const tableRecords = this.state.rowresult
    const timesheetIds = this.state.selectedTimesheets
    if (!isEmpty(timesheetIds)) {
      timesheetIds.forEach((timesheetId) => {
        const timesheet = find(tableRecords, { tid: parseInt(timesheetId) });
        switch (this.state.selectedButtonFunctionality) {
          case DashboardButtonFunctionality.archivable:
            if (timesheet.timesheetStatus === 500) {
              validTimesheets.push(parseInt(timesheetId));
            }
            break;
          case DashboardButtonFunctionality.archived:
            if (timesheet.timesheetStatus === 600) {
              validTimesheets.push(parseInt(timesheetId));
            }
            break;
          default:
            break;
        }
      })
    }

    if (!isEmpty(validTimesheets)) {
      const request = {
        method: this.state.selectedButtonFunctionality === DashboardButtonFunctionality.archivable
          ? 'timesheets/set-archivable' : 'timesheets/set-archived',
        params: {
          tidList: validTimesheets,
          madeBy: get(localStorage, 'userid', '')
        }
      }
      apiPost(request, true).then((response) => {
        this.setState({
          displayWarningModal: false,
          selectedButtonFunctionality: null
        }, () => {
          this.getSummary(this.state.startweeklyDate, this.state.endweeklyDate);
          this.getTimesheets(this.state.startweeklyDate, this.state.endweeklyDate);
        })
      }).catch((error) => {
        console.log(error);
      });
    }
  }

  isMassEntryFormFieldsEmpty = () => {
    const { massEntryActivity, massEntryComments, massEntryDate, massEntryHour } = this.state;
    return isEmpty(massEntryActivity) || isEmpty(massEntryComments) || isEmpty(massEntryDate) || isEmpty(massEntryHour);
  }

  onSubmitMassTimeEntry = () => {
    if (!isEmpty(this.state.massEntryHour) &&
      !isEmpty(this.state.massEntryDate) &&
      !isEmpty(this.state.massEntryComments) &&
      !isEmpty(this.state.massEntryActivity)) {
      // TODO: check if the selected timesheets fall within the same week
      // TODO: if not, display the popup
      const request = {
        method: 'timesheets/masshour',
        params: {
          tidList: this.state.selectedTimesheets.map((timesheetId) => parseInt(timesheetId)),
          activityID: parseInt(this.state.massEntryActivity),
          day: moment(new Date(this.state.massEntryDate)).day(),
          hour: this.state.massEntryHour,
          reason: this.state.massEntryComments,
          madeBy: get(localStorage, 'userid', '')
        }
      };
      apiPost(request, true).then((response) => {
        this.getSummary(this.state.startweeklyDate, this.state.endweeklyDate);
        this.getTimesheets(this.state.startweeklyDate, this.state.endweeklyDate);
      }).catch((error) => {
        console.log(error);
      });
    }
  }

  handleUserComments = (evt) => this.setState({ userComments: evt.target.value })

  handleMassEntryComments = (evt) => this.setState({ massEntryComments: evt.target.value })

  closeWarningModal = () => {
    this.setState({
      displayWarningModal: false,
      isSelectAll: false,
      selectedTimesheets: [],
    }, () => {
      this.getSummary(this.state.startweeklyDate, this.state.endweeklyDate);
      this.getTimesheets(this.state.startweeklyDate, this.state.endweeklyDate);
    })
  }

  completeButtonOperation = () => {
    switch (this.state.selectedButtonFunctionality) {
      case DashboardButtonFunctionality.archivable:
      case DashboardButtonFunctionality.archived:
        return this.updateTimesheetStatusToArchivedOrArchivable()
      default:
        break;
    }
  }

  openMassEntryForm = () => {
    const { rowresult, selectedTimesheets } = this.state;
    let arr = rowresult.filter((x, i) => selectedTimesheets.includes(`${x.tid}`));
    const maxDate = new Date(Math.max(...arr.map(e => new Date(e.startDate))));
    const minDate = new Date(Math.min(...arr.map(e => new Date(e.startDate))));
    if (moment(minDate).format('YYYY-MM-DD') === moment(maxDate).format('YYYY-MM-DD')) {
      const sunday = moment.utc(minDate).day(0).format('ddd MMM DD, YYYY');
      const nextSunday = moment.utc(maxDate).day(7).format('ddd MMM DD, YYYY');
      this.setState({
        displayMassEntryForm: true,
        displayMassEntryDate: `${sunday} - ${nextSunday}`
      })
    } else {
      window.alert('Please Select Same week for Mass Entry!');
      return;
    }
  }
  closeInformationModal = () => this.setState({ displayInformationModal: false })

  selectActivityForMassEntry = (evt) => this.setState({ massEntryActivity: evt.target.value })

  render() {
    const { isSelectAll, uniqueActivityTableCols, rowresult, currentRecordingPeriod, selectedStartWeekDate, selectedEndWeekDate, startweeklyDate,
      endweeklyDate, timesheetstatus, activityDropdownOptions, summaryDetails, approveBtnDisabled, rejectBtnDisabled, selectedTimesheets, displayMassEntryForm,
      displayMassEntryDate, massEntryDate, massEntryActivity, massEntryHour, massEntryComments, displayUserApprovalForm, selectedTimesheetOperation, displayWarningModal,

    } = this.state;
    const defaultColumns = [
      {
        label: 'Week Start',
        field: 'start',
        width: '10%',
      },
      {
        label: 'Status',
        field: 'status',
      },
      {
        label: 'Last Name',
        field: 'last_name',
      },
      {
        label: 'First Name',
        field: 'first_name',
      },
      {
        label: 'Ttl Hrs',
        field: 'total',
      },
      {
        label: (<span>Overtime<br /> Hours</span>),
        field: 'overtime',
      },
      {
        label: (<span>Max OT<br /> Allowed</span>),
        field: 'maxot',
      },
      {
        label: (<span>{'Regular Hours'}<br />{' <= 40'}</span>),
        field: 'regular',
      },
    ];
    const datatable = {
      columns: [
        {
          label: (
            <input
              type="checkbox"
              id="colhead_checkbox"
              onChange={this.selectAllHandler}
              checked={isSelectAll}
            />
          ),
          field: 'check',
          sort: 'asc'
        },
        ...defaultColumns,
        ...uniqueActivityTableCols
      ],
      rows: rowresult,
    }
    return (
      <div>
        <div className="p-3 mb-3 small_font bg-amber border-0">
          <Row>
            <Col lg="4" md="4" sm="12">
              <label className="pr-2 float-left">Date Range : </label>
              <input
                style={{ float: 'left', width: '25px', marginTop: '3px' }}
                type="checkbox"
                name="current-recording"
                className="form-control"
                onChange={() => this.setCurrentRecordingPeriod(currentRecordingPeriod)}
                checked={currentRecordingPeriod}
              />
              <label
                onClick={() => this.setCurrentRecordingPeriod(currentRecordingPeriod)}
                style={{ fontSize: '9pt' }}
              >
                Current Recording Period
              </label>
              <Row>
                <Col lg="6" md="6" sm="6">
                  <label className="pr-2">Start Week</label>
                  <DatePicker
                    selected={selectedStartWeekDate}
                    value={startweeklyDate}
                    name="startDate"
                    className="form-control"
                    customInput={<this.ExampleCustomInput />}
                    filterDate={this.isWeekday}
                    onChange={this.handleStartWeekChange}
                    dateFormat="yyyy-MM-dd"
                    placeholderText="yyyy-MM-dd"
                  />
                </Col>
                <Col lg="6" md="6" sm="6">
                  <label className="pr-2">End Week</label>
                  <DatePicker
                    selected={selectedEndWeekDate}
                    value={endweeklyDate}
                    name="startDate"
                    className="form-control"
                    customInput={<this.ExampleCustomInput1 />}
                    filterDate={this.isWeekday}
                    onChange={this.handleEndWeekChange}
                    dateFormat="yyyy-MM-dd"
                    placeholder="yyyy-MM-dd"
                  />
                </Col>
              </Row>
            </Col>
            <Col lg="3" md="3" sm="12" className="mb-0 mt-auto">
              <label>Timesheet Status</label>
              <select onChange={this.changeStatus} placeholder="Select" className="form-control" name="state">
                <option value="all">All</option>
                <option value="Active" selected={timesheetstatus === 'Active' ? 'selected' : ''}>Active</option>
                <option value="Inactive" selected={timesheetstatus === 'Inactive' ? 'selected' : ''}>Inactive</option>
                <option value="Submitted" selected={timesheetstatus === 'Submitted' ? 'selected' : ''}>Submitted</option>
                <option value="Approvable" selected={timesheetstatus === 'Approvable' ? 'selected' : ''}>Approvable</option>
                <option value="Approved" selected={timesheetstatus === 'Approved' ? 'selected' : ''}>Approved</option>
                <option value="Archivable" selected={timesheetstatus === 'Archivable' ? 'selected' : ''}>Archivable</option>
                <option value="Archived" selected={timesheetstatus === 'Archived' ? 'selected' : ''}>Archived</option>
              </select>
            </Col>
            <Col lg="2" md="2" sm="12" className="mb-0 mt-auto">
              <label>Activity</label>
              <select onChange={this.filterByActivity} placeholder="Select" className="form-control" name="state">
                {activityDropdownOptions.map(activity => <option key={activity.actID} value={activity.actID}>{activity.name}</option>)}
              </select>
            </Col>
            <Col lg="3" md="3" sm="12" className="mb-0 mt-auto">
              <label>Employee Type</label>
              <select onChange={this.filterByEmployeeType} placeholder="Select" className="form-control" name="state">
                <option value="all">All</option>
                <option value="Salaried">Salaried</option>
                <option value="Full-Time Hourly">Full Time Hourly</option>
                <option value="Part-Time Hourly">PT Hourly</option>
                <option value="Temporary">Temporary</option>
                <option value="SubContractor">SUB</option>
                <option value="Intern">Intern</option>
              </select>
            </Col>
          </Row>
        </div>
        <p className="small_font mb-2 mt-2 ">Summary on Number of Timesheets in this Period :
          <label className="label label-info"> Active : {get(summaryDetails, 'numOfActive', 0)}</label>
          <label className="label label-danger"> Inactive : {get(summaryDetails, 'numOfInactive', 0)}</label>
          <label className="label label-success2"> Submitted : {get(summaryDetails, 'numOfSubmitted', 0)}</label>
          <label className="label label-warning"> Approvable : {get(summaryDetails, 'numOfApprovable', 0)}</label>
          <label className="label label-success1"> Approved : {get(summaryDetails, 'numOfApproved', 0)}</label>
          <label className="label label-primary"> Archivable : {get(summaryDetails, 'numOfArchivable', 0)}</label>
          <label className="label label-default"> Archived : {get(summaryDetails, 'numOfArchived', 0)}</label>
        </p>
        <div className="col-12 row mr-0 pr-0 pl-0 ml-0 mb-3">
          <div className="text-left float-left col-lg-7 col-md-7 col-xl-7 col-sm-12 pl-0">
            <MDBBtn
              disabled={approveBtnDisabled}
              onClick={() => this.approveOrRejectTimesheets(TimesheetOperation.approve)}
              color="success"
              data-toggle="tooltip"
              title="Approve"
            >
              <i className="fa fa-thumbs-up text-white"></i>
            </MDBBtn>
            <MDBBtn
              disabled={rejectBtnDisabled}
              onClick={() => this.approveOrRejectTimesheets(TimesheetOperation.reject)}
              className="ml-2"
              color="danger"
              data-toggle="tooltip"
              title="Reject"
            >
              <i className="fa fa-thumbs-down text-white"></i>
            </MDBBtn>
            <MDBBtn
              // disabled={archivableBtnDisabled}
              onClick={() => this.setState({ selectedButtonFunctionality: DashboardButtonFunctionality.archivable, displayWarningModal: true })}
              style={timesheetstatus === 'Approved' ? {} : { display: 'none' }}
              color="success"
              className="ml-2"
            >
              Set to Archivable
            </MDBBtn>
            <MDBBtn
              // disabled={this.state.archivedBtnDisabled}
              onClick={() => this.setState({ selectedButtonFunctionality: DashboardButtonFunctionality.archived, displayWarningModal: true })}
              style={timesheetstatus === 'Archivable' ? {} : { display: 'none' }}
              color="success"
              className="ml-2"
            >
              Set to Archived
            </MDBBtn>
          </div>
          <div className="row col-lg-3 col-xl-3 col-md-3 col-sm-12 px-1"></div>
          <div className="col-lg-2 col-xl-2 col-md-2 col-sm-12 px-1">
            <button
              onClick={() => this.openMassEntryForm()}
              className="button resend-btn py-2 px-3 m-0 float-right"
              disabled={isEmpty(selectedTimesheets)}
            >
              Mass Time Entry
              <i className="fa fa-book pl-2"></i>
            </button>
          </div>
        </div>
        <MDBDataTable
          className="activitytable timesheets"
          responsive={true}
          noBottomColumns
          striped
          info={false}
          bordered
          hover
          displayEntries={false}
          data={datatable}
          searching={false}
          paging={false}
        />
        {/** Modal to perform mass entry form operation */}
        { displayMassEntryForm && <Modal
          scrollable={true}
          size="md"
          onHide={() => this.setState({ displayMassEntryForm: false })}
          show={displayMassEntryForm}
        >
          <Modal.Header closeButton className="h6 background-blue1">
            <Modal.Title className="h6 text-white" id="contained-modal-title-vcenter">
              Mass Time Entry
            </Modal.Title>
          </Modal.Header>
          <Modal.Body className="show-grid small_font px-5">
            <p className="xs_font text-dark text-center">
              {`Add a punch or time entry for the ${selectedTimesheets.length} selected employee${selectedTimesheets.length > 1 ? 's' : ''} for the week of:`}
            </p>
            <p className="small_font font-weight-bold text-center">
              {displayMassEntryDate}
            </p>
            <div className="form-group row">
              <div className="col-lg-6 col-md-6 col-xl-6 col-sm-12">
                <label htmlFor="exampleInputEmail1">Date:</label>
                <input
                  type="date"
                  className="form-control"
                  placeholder="04/24/2016"
                  value={massEntryDate}
                  onChange={(evt) => this.setState({ massEntryDate: evt.target.value })}
                />
                {isEmpty(massEntryDate) && (<p style={{ color: 'red' }}>This is required</p>)}
              </div>
              <div className="col-lg-6 col-md-6 col-xl-6 col-sm-12">
                <label htmlFor="exampleInputEmail1">Activity Name:</label>
                <select onChange={this.selectActivityForMassEntry} defaultValue={''} placeholder="Select" className="form-control" name="state">
                  {activityDropdownOptions.slice(1).map(activity => <option key={activity.actID} value={activity.actID}>{activity.name}</option>)}
                </select>
                {isEmpty(massEntryActivity) && (<p style={{ color: 'red' }}>This is required</p>)}
              </div>
            </div>
            <div className="form-group row">
              <div className="col-lg-6 col-md-6 col-xl-6 col-sm-12">
                <label htmlFor="exampleInputEmail1">Hour:</label>
                <input
                  type="text"
                  className="form-control"
                  placeholder=""
                  value={massEntryHour}
                  onChange={(evt) => this.setState({ massEntryHour: evt.target.value })}
                />
                {isEmpty(massEntryHour) && (<p style={{ color: 'red' }}>This is required</p>)}
              </div>
              <div className="col-lg-6 col-md-6 col-xl-6 col-sm-12">
                <label htmlFor="exampleInputEmail1">Comments*:</label>
                <textarea
                  onChange={this.handleMassEntryComments}
                  type="text"
                  className="form-control"
                  placeholder="Enter Activity Description"
                  value={massEntryComments}
                />
                {isEmpty(massEntryComments) && (<p style={{ color: 'red' }}>This is required</p>)}
              </div>
            </div>
            {/* <p className="small_font text-center">If there is support document, please<span className="pl-1 link-style text-decoration-underline">upload</span></p> */}
          </Modal.Body>
          <Modal.Footer>
            <div className="col-12 row mt-2">
              <p className="small_font text-dark text-center mx-auto mb-2">Are you sure you would like to continue with this mass time entry?</p>
              <div className="col-6">
                <button
                  onClick={() => this.setState({ displayMassEntryForm: false, displayMassEntryDate: '' })}
                  className="button resend-btn background-red px-2 float-left"
                >
                  No, Cancel
                </button>
              </div>
              <div className="col-6">
                <button
                  disabled={() => this.isMassEntryFormFieldsEmpty()}
                  className="button resend-btn float-right px-4"
                  onClick={this.onSubmitMassTimeEntry}
                >
                  Yes, Continue
                </button>
              </div>
            </div>
          </Modal.Footer>
        </Modal>
        }
        {/** Modal for user approval to approve or reject a timesheet */}
        <Modal
          scrollable={true}
          size="md"
          onHide={this.closeUserApprovalForm}
          show={displayUserApprovalForm}
        >
          <Modal.Header closeButton className="h6 background-green1">
            <Modal.Title className="h6 text-white small_font" id="contained-modal-title-vcenter">
              {`User Approval Form`}
            </Modal.Title>
          </Modal.Header>
          <Modal.Body className="show-grid small_font px-5">
            <p className="xs_font text-dark text-center">
              {`You are about to ${isEqual(TimesheetOperation.approve, selectedTimesheetOperation) ? 'approve' : 'reject'} the selected timesheet(s). Please confirm to continue`}
            </p>
            <p className="small_font font-weight-bold text-center">
              {displayMassEntryDate}
            </p>
            {
              this.state.isUserCommentRequired && (
                <div className="form-group row">
                  <div className="col-lg-12 col-md-12 col-xl-12 col-sm-12 text-center">
                    <label htmlFor="exampleInputEmail1">Comment :</label>
                    <textarea className="form-control" value={this.state.userComments} onChange={this.handleUserComments}></textarea>
                  </div>
                </div>
              )
            }
          </Modal.Body>
          <Modal.Footer>
            <div className="col-12 row mt-2">
              <div className="col-6">
                <button
                  onClick={this.closeUserApprovalForm}
                  className="button resend-btn background-red px-2 float-left"
                >
                  No, Cancel
                </button>
              </div>
              <div className="col-6">
                <button
                  onClick={this.completeTimesheetOperation}
                  className="button resend-btn float-right px-4"
                >
                  Yes, Confirm
                </button>
              </div>
            </div>
          </Modal.Footer>
        </Modal>
        {/** Modal for archivable and archived feature */}
        <Modal
          scrollable={true}
          size="md"
          onHide={this.closeWarningModal}
          show={displayWarningModal}
        >
          <Modal.Header closeButton className="h6 background-green1">
            <Modal.Title className="h6 text-white small_font" id="contained-modal-title-vcenter">
              {`Warning`}
            </Modal.Title>
          </Modal.Header>
          <Modal.Body className="show-grid small_font px-5">
            <p className="xs_font text-dark text-center">
              {`Please confirm to continue`}
            </p>
            <p className="small_font font-weight-bold text-center">
              {`${moment.utc(this.state.startweeklyDate).format('ddd MMM DD, YYYY')} - ${moment.utc(this.state.endweeklyDate).format('ddd MMM DD, YYYY')}`}
            </p>
          </Modal.Body>
          <Modal.Footer>
            <div className="col-12 row mt-2">
              <div className="col-6">
                <button
                  onClick={this.closeWarningModal}
                  className="button resend-btn background-red px-2 float-left"
                >
                  No, Cancel
                </button>
              </div>
              <div className="col-6">
                <button
                  onClick={this.completeButtonOperation}
                  className="button resend-btn float-right px-4"
                >
                  Yes, Confirm
                </button>
              </div>
            </div>
          </Modal.Footer>
        </Modal>
        {/** Modal to show information to user */}
        <Modal
          scrollable={true}
          size="md"
          onHide={this.closeInformationModal}
          show={this.state.displayInformationModal}
        >
          <Modal.Header closeButton className="h6 background-green1">
            <Modal.Title className="h6 text-white small_font" id="contained-modal-title-vcenter">
              {`Information`}
            </Modal.Title>
          </Modal.Header>
          <Modal.Body className="show-grid small_font px-5">
            <p className="xs_font text-dark text-center">
              {this.state.contentForInformationModal}
            </p>
          </Modal.Body>
          <Modal.Footer>
            <div className="col-12 row mt-2">
              <div className="col-6">
              </div>
              <div className="col-6">
                <button
                  onClick={this.closeInformationModal}
                  className="button resend-btn float-right px-4"
                >
                  Ok
                </button>
              </div>
            </div>
          </Modal.Footer>
        </Modal>
      </div>
    )
  }
}

export default LoadTimesheetsTable;