import React from 'react';
import ReactDOM from 'react-dom';
import './index.css';
import App from './App';
import AccountCreated from './AccountCreated';
import Login from './Login';
import Manager from './Manager';
import Organization from './Organization';
import Activities from './Activities';
import Policies from './Policies';
import Employees from './Employees';
import MyProfile from './MyProfile';
import Timesheets from './Timesheets';
import Reporting from './Reporting';
import ForgotPassword from './ForgotPassword';
import ResetPassword from './ResetPassword';
import Dashboard from './Dashboard';
import ManagerOrganization from './ManagerOrganization';
import MyEmployees from './MyEmployees.js';
import reportWebVitals from './reportWebVitals';
import { Route, Switch, Redirect, BrowserRouter } from "react-router-dom";
import EmployeeProfile from './EmployeeProfile';
import TimesheetSubmitPreview from './TimesheetSubmitPreview';
import TimesheetSubmitted from './TimesheetSubmitted';

ReactDOM.render(
  <BrowserRouter>
    <Switch>
      <Route exact path="/" render={(props) => <App {...props} />} />
      <Route path="/account_created" render={(props) => <AccountCreated {...props} />} />
      <Route exact path="/login" render={(props) => <Login {...props} />} />
      <Route exact path="/organization" render={(props) => <Organization {...props} />} />
      <Route exact path="/activities" render={(props) => <Activities {...props} />} />
      <Route exact path="/policies" render={(props) => <Policies {...props} />} />
      <Route exact path="/employees" render={(props) => <Employees {...props} />} />
      <Route exact path="/MyProfile" render={(props) => <MyProfile {...props} />} />
      <Route exact path="/EmployeeProfile" render={(props) => <EmployeeProfile {...props} />} />
      <Route exact path="/timesheets" render={(props) => <Timesheets {...props} />} />
      <Route exact path="/reporting" render={(props) => <Reporting {...props} />} />
      <Route exact path="/ForgotPassword" render={(props) => <ForgotPassword {...props} />} />
      <Route exact path="/ResetPassword" render={(props) => <ResetPassword {...props} />} />
      <Route exact path="/Dashboard" render={(props) => <Dashboard {...props} />} />
      <Route exact path="/employee_timesheets" render={(props) => <ManagerOrganization {...props} />} />
      <Route exact path="/MyEmployees" render={(props) => <MyEmployees {...props} />} />
      <Route exact path="/TimesheetSubmitPreview" render={(props) => <TimesheetSubmitPreview {...props} />} />
      <Route exact path="/TimesheetSubmitted" render={(props) => <TimesheetSubmitted {...props} />} />
      <Route exact path="/employee" render={(props) => <Manager {...props} />} />
      <Redirect to="/" />
    </Switch>
  </BrowserRouter>,
  document.getElementById('root')
);

// If you want to start measuring performance in your app, pass a function
// to log results (for example: reportWebVitals(console.log))
// or send to an analytics endpoint. Learn more: https://bit.ly/CRA-vitals
reportWebVitals();
