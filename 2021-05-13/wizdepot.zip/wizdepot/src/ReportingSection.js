import React from 'react';
import 'bootstrap/dist/css/bootstrap.min.css';
import './App.css';
import PayrollTable from './components/PayrollTable.js';
import TimesheetPreview from './components/TimesheetPreview.js';
import DatePicker from "react-datepicker";
import "react-datepicker/dist/react-datepicker.css";
import { apiPost, apiGet } from './Api';
import { chunk, difference, groupBy, isEmpty, isEqual, mapValues, omit, sortBy, sum, uniqBy } from 'lodash';
import { exampleReportData } from './exampleReportData';
import { DAYS_OF_WEEK, employeeStatus, toNumber, wayToPack } from './helpers/GeneralHelper';
import moment from 'moment';

class ReportingSection extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      startDate: new Date(moment().day(0).format('YYYY-MM-DD')),
      endDate: new Date(moment().day(6).format('YYYY-MM-DD')),
      employee_type: 'active',
      grpIds: [],
      actIds: [],
      indIds: [],
      groupData: [],
      activityData: [],
      individualData: [],
      activityTimeArr: [],
      summaryArr: [],
      reportLoading: false,
      semiMonthlyDate: null,
      MonthlyDate: null,
      weeklyDate: null,
      biWeeklyDate: null,
      TimePeriod: 'weekly',
      includesReport: 'allemployees',
      reportingHours: 'allhours',
      packEmployees: 'alphabet',
      subPackEmp: 'group-alphabet',
      preview: 'timesheet',
      showreport: '',
      showreportcss: false,
    };
  }

  componentDidMount = () => {
    this.getData();
  }

  getData = async () => {
    const groupsParams = { method: `groups/all/${localStorage.orgid}`, params: {} };
    const activityParams = { method: `activities/all/${localStorage.orgid}`, params: {} };
    const individualsParams = { method: `employees/notadmin/${localStorage.orgid}`, params: {} };

    const groupApi = apiGet(groupsParams, true, false);
    const activityApi = apiGet(activityParams, true, false);
    const individualApi = apiGet(individualsParams, true, false);

    await Promise.all([groupApi, activityApi, individualApi]).then(([grpRes, actRes, indRes]) => {
      this.setState({
        groupData: grpRes.data || [],
        activityData: actRes.data || [],
        individualData: indRes.data || []
      })
    }).catch(error => {
      this.setState({
        groupData: [],
        activityData: [],
        individualData: []
      })
      console.log(`Error in promises ${error}`)
    });
  }

  loadPreview = async (e) => {
    e.preventDefault();
    const { employee_type, subPackEmp, packEmployees, startDate, endDate, grpIds, actIds, indIds } = this.state;
    let empStatus = employeeStatus[employee_type];
    let packEmp = wayToPack[packEmployees !== 'groups' ? packEmployees : subPackEmp];
    this.setState({ reportLoading: true });
    const request = {
      method: `timesheets/reports/${localStorage.orgid}`,
      params: {
        startDate: startDate ? moment(startDate).format('YYYY-MM-DD') : null,
        endDate: endDate ? moment(endDate).format('YYYY-MM-DD') : null,
        employees: indIds,
        groups: grpIds,
        activitiesOfUser: actIds,
        employeeStatus: empStatus,
        wayToPack: packEmp
      }
    }
    apiPost(request).then((response) => {
      if (isEqual(response.status, 200) && response.data) {
        this.updateLayoutData(response.data);
      } else if (isEmpty(response.data)) {
        window.alert('Something went wrong!');
        this.setState({ reportLoading: false, summaryArr: [], activityTimeArr: [] });
        return;
      }
    }).catch((err) => {
      this.setState({ reportLoading: false, summaryArr: [], activityTimeArr: [] });
    })
  }

  getDaysBetweenDates = () => {
    const { startDate, endDate } = this.state;
    let now = moment(startDate).clone();
    let dates = [];

    while (now.isSameOrBefore(moment(endDate))) {
      dates.push(now.format('YYYY-MM-DD'));
      now.add(1, 'days');
    }
    return dates;
  };

  updateLayoutData = (response) => {
    if (response.timsheets.length > 0) {
      let activityTimeArr = response.timsheets.map((x) => x.activityTime).flat();
      activityTimeArr = sortBy(uniqBy(activityTimeArr, function (e) { return e.activityName; }), 'activityName');
      activityTimeArr = activityTimeArr.map((x) => x.activityName);
      let reportArr = response.timsheets.map((x) => ({ ...x, fullName: `${x.userFirstname} ${x.userLastname}` }));
      reportArr = groupBy(reportArr, 'fullName');
      let dates = this.getDaysBetweenDates();
      let summaryArr = [];
      let detailsArr = [];
      Object.values(reportArr).map((x, i) => {
        let firstName = x[0].userFirstname;
        let lastName = x[0].userLastname;
        let dArr = {};
        let regularHours = 0.0;
        let overtimeHours = 0.0;
        x.map((actList) => {
          let startD = actList.startDate;
          let sortArr = sortBy(actList.activityTime, 'activityName');
          regularHours = actList.regularHours;
          overtimeHours = actList.overtimeHours;
          sortArr.map((act) => {
            let month = moment(dates[0]).format('MMMM');
            let dayValue = 0;
            dates.map((dt, i) => {
              if (month !== moment(dt).format('MMMM')) {
                month = moment(dt).format('MMMM');
                dayValue = 0;
              }
              dayValue++;
              let obj = {
                [`D${dayValue}_${month}-${dayValue}`]: dt === startD ? sum(Object.values(DAYS_OF_WEEK).map((day) => act[`${day.toLowerCase()}Hour`])) : 0.0,
              };
              let actFull = `${act.activityName}_${act.activityID}`;
              if (dArr[actFull]) {
                dArr[actFull] = { ...dArr[actFull], ...obj }
              } else {
                dArr[actFull] = obj;
              }
            })
          })
        })
        detailsArr.push({  ...dArr, firstName, lastName, regularHours, overtimeHours });
      })
      Object.values(reportArr).map((x, i) => {
        let firstName = x[0].userFirstname;
        let lastName = x[0].userLastname;
        let regularHours = 0.0;
        let overtimeHours = 0.0;
        let obj = {};
        x.map((actList) => {
          let sortArr = sortBy(actList.activityTime, 'activityName');
          let actArr = [];
          regularHours = regularHours + Number(actList.regularHours);
          overtimeHours = overtimeHours + Number(actList.overtimeHours);
          sortArr.map((act) => {
            actArr.push(act.activityName);
            if (obj.hasOwnProperty(act.activityName)) {
              obj[act.activityName] = parseFloat(obj[act.activityName]) + sum(Object.values(DAYS_OF_WEEK).map((day) => act[`${day.toLowerCase()}Hour`]));
            } else {
              obj[act.activityName] = sum(Object.values(DAYS_OF_WEEK).map((day) => act[`${day.toLowerCase()}Hour`]));
            }
          })
          let compareArr = difference(activityTimeArr, actArr);
          compareArr.map((x) => {
            if (!obj[x]) {
              obj = { ...obj, [x]: 0.0 }
            }
          });
          obj = Object.keys(obj).sort().reduce((newObj, key) => { newObj[key] = obj[key]; return newObj; }, {});
        })
        summaryArr.push({ firstName, lastName, regularHours, groupName: 'Group1', overtimeHours, timeObj: { ...obj } });
      })
      this.setState({
        showreport: this.state.preview,
        summaryArr,
        detailsArr,
        activityTimeArr,
        reportLoading: false
      });
    } else {
      this.setState({
        showreport: this.state.preview,
        reportLoading: false,
        summaryArr: [], activityTimeArr: []
      });
    }
  }
  isWeekday = (date) => {
    const day = date.getDay()
    return day === 0
  }
  isMonthly = (date) => {
    const day = date.getDate()
    return day === 1
  }
  isSemiMonthly = (date) => {
    const day = date.getDate()
    return day === 1 || day === 16;
  }
  handleOnChange = (e) => {
    this.setState({
      preview: e.target.value
    })
  }

  changeGroup = (event, name) => {
    let value = Array.from(event.target.selectedOptions, option => Number(option.value));
    this.setState({ [name]: value });
  }
  render() {
    const { groupData, grpIds, actIds, reportLoading, showreport,
      activityTimeArr, summaryArr, detailsArr,
      activityData, indIds, individualData, includesReport, reportingHours } = this.state;
    return (
      <div className="contentwrapper pt-2 pb-5 mb-5 text-left small_font">
        <h5 className="mt-2">Timesheet Reporting</h5>
        <form onSubmit={this.onSubmit} className="payrollform mt-3">
          <div className="form-group row col-12">
            <label className="col-xl-2 col-lg-2 col-md-2 col-sm-10 p-0 permission-label">Report Time Period</label>
            <div className="col-xl-3 col-lg-3 col-md-3 col-sm-6 inner-addon right-addon">
              <i class="fa fa-calendar pr-3"></i>
              <DatePicker className="form-control col-xl-12 col-lg-12 col-md-12 col-sm-12 ml-4" placeholderText="Start Date"
                selected={this.state.startDate}
                onChange={date => this.setState({ startDate: date })}
                selectsStart
                startDate={this.state.startDate}
                endDate={this.state.endDate}
              />
            </div>
            <div className="col-xl-3 col-lg-3 col-md-3 col-sm-6 inner-addon right-addon">
              <i class="fa fa-calendar pr-3"></i>
              <DatePicker className="form-control col-xl-12 col-lg-12 col-md-12 col-sm-12 ml-4" placeholderText="End Date"
                selected={this.state.endDate}
                onChange={date => this.setState({ endDate: date })}
                selectsEnd
                startDate={this.state.startDate}
                endDate={this.state.endDate}
                minDate={this.state.startDate}
              />
            </div>
          </div>
          <div className="form-group row col-12 mb-1">
            <label className="col-xl-2 col-lg-2 col-md-2 col-sm-10 p-0 permission-label">Report Includes</label>
            <div className="col-xl-2 col-lg-2 col-md-2 col-sm-10 p-0">
              <input type="radio" value="allemployees" defaultChecked onClick={() => this.setState({ includesReport: 'allemployees' })} className="form-control permission-checkbox" name="includesReport" />
              <label className="permission-label">All Employees</label>
            </div>
            <div className="col-xl-2 col-lg-2 col-md-2 col-sm-10 p-0">
              <input type="radio" value="groups" onClick={() => this.setState({ includesReport: 'groups', grpIds: [], actIds: [], indIds: [] })} className="form-control permission-checkbox" name="includesReport" />
              <label className="permission-label">Groups</label>
            </div>
            <div className="col-xl-2 col-lg-2 col-md-2 col-sm-10 p-0">
              <input type="radio" value="activities" onClick={() => this.setState({ includesReport: 'activities', grpIds: [], actIds: [], indIds: [] })} className="form-control permission-checkbox" name="includesReport" />
              <label className="permission-label">Activities</label>
            </div>
            <div className="col-xl-2 col-lg-2 col-md-2 col-sm-10 p-0">
              <input type="radio" value="individuals" onClick={() => this.setState({ includesReport: 'individuals', grpIds: [], actIds: [], indIds: [] })} className="form-control permission-checkbox" name="includesReport" />
              <label className="permission-label">Individuals</label>
            </div>
          </div>
          {includesReport === 'groups' && <div className="form-group row col-xl-8 col-lg-8 col-md-8 offset-md-4 offset-lg-4 col-sm-10">
            <label className="permission-label pl-0">Select Group</label>
            <select className="form-control col-xl-3 col-lg-3 col-md-3 col-sm-10 ml-0" multiple='multiple'
              onChange={(event) => this.changeGroup(event, 'grpIds')}
              value={grpIds}>
              {groupData && groupData.map((grp) => {
                return <option value={grp.id} key={grp.id}>{grp.name}</option>
              })}
            </select>
          </div>}
          {includesReport === 'activities' && <div className="form-group row col-xl-8 col-lg-8 col-md-8 offset-md-6 offset-lg-6 col-sm-10">
            <label className="permission-label pl-0">Select Activities</label>
            <select className="form-control col-xl-3 col-lg-3 col-md-3 col-sm-10 ml-0" multiple='multiple'
              onChange={(event) => this.changeGroup(event, 'actIds')}
              value={actIds}>
              {activityData && activityData.map((act) => {
                return <option value={act.actID} key={act.actID}>{act.name}</option>
              })}
            </select>
          </div>}
          {includesReport === 'individuals' && <div className="form-group row col-xl-8 col-lg-8 col-md-8 col-md-4 offset-md-8 offset-lg-8 col-sm-10" >
            <label className="permission-label pl-0">Select Employee</label>
            <select className="form-control col-xl-3 col-lg-3 col-md-3 col-sm-10 ml-0" multiple='multiple'
              onChange={(event) => this.changeGroup(event, 'indIds')}
              value={indIds}>
              {individualData && individualData.map((ind) => {
                return <option value={ind.userID} key={ind.userID}>{ind.lastName} {ind.firstName}</option>
              })}
            </select>
          </div>}
          <div className="form-group row col-12" style={includesReport !== 'individuals' ? {} : { display: 'none' }}>
            <label className="col-xl-2 col-lg-2 col-md-2 col-sm-10 p-0 permission-label">Select Employee Type</label>
            <div className="col-xl-2 col-lg-2 col-md-2 col-sm-10 p-0">
              <input type="radio" value='active' defaultChecked onClick={() => this.setState({ employee_type: 'active' })} className="form-control permission-checkbox" name="employee_type" />
              <label className="permission-label">Active Employees</label>
            </div>
            <div className="col-xl-2 col-lg-2 col-md-2 col-sm-10 p-0">
              <input type="radio" value='inactive' onClick={() => this.setState({ employee_type: 'inactive' })} className="form-control permission-checkbox" name="employee_type" />
              <label className="permission-label">Inactive Employees</label>
            </div>
            <div className="col-xl-2 col-lg-2 col-md-2 col-sm-10 p-0">
              <input type="radio" value='both' onClick={() => this.setState({ employee_type: 'both' })} className="form-control permission-checkbox" name="employee_type" />
              <label className="permission-label">both</label>
            </div>
          </div>
          <div className="form-group row col-12 mb-1">
            <label className="col-xl-2 col-lg-2 col-md-2 col-sm-10 p-0 permission-label">Hours to be Reported</label>
            <div className="col-xl-2 col-lg-2 col-md-2 col-sm-10 p-0">
              <input type="radio" value="allhours" defaultChecked onClick={() => this.setState({ reportingHours: 'allhours' })} className="form-control permission-checkbox" name="reportinghours" />
              <label className="permission-label">All Hours</label>
            </div>
            <div className="col-xl-2 col-lg-2 col-md-2 col-sm-10 p-0">
              <input type="radio" value="activities" onClick={() => this.setState({ reportingHours: 'activities' })} className="form-control permission-checkbox" name="reportinghours" />
              <label className="permission-label">Activities</label>
            </div>
          </div>
          {reportingHours === 'activities' && <div className="form-group row col-xl-8 col-lg-8 col-md-8 offset-md-4 offset-lg-4 col-sm-10">
            <label className="permission-label pl-0">Select Activities</label>
            <select className="form-control col-xl-3 col-lg-3 col-md-3 col-sm-10 ml-0" multiple='multiple'
              onChange={(event) => this.changeGroup(event, 'actIds')}
              value={actIds}>
              {activityData && activityData.map((act) => {
                return <option value={act.actID} key={act.actID}>{act.name}</option>
              })}
            </select>
          </div>}
          <div className="form-group row col-12 mb-1">
            <label className="col-xl-2 col-lg-2 col-md-2 col-sm-10 p-0 permission-label">Pack Employees in Report</label>
            <div className="col-xl-2 col-lg-2 col-md-2 col-sm-10 p-0">
              <input type="radio" value="alphabet" defaultChecked onClick={() => this.setState({ packEmployees: 'alphabet' })} className="form-control permission-checkbox" name="packemployees" />
              <label className="permission-label">Alphabetically</label>
            </div>
            <div className="col-xl-2 col-lg-2 col-md-2 col-sm-10 p-0">
              <input type="radio" value="groups" onClick={() => this.setState({ packEmployees: 'groups' })} className="form-control permission-checkbox" name="packemployees" />
              <label className="permission-label">Groups</label>
            </div>
            <div className="col-xl-2 col-lg-2 col-md-2 col-sm-10 p-0">
              <input type="radio" value="wage" onClick={() => this.setState({ packEmployees: 'wage' })} className="form-control permission-checkbox" name="packemployees" />
              <label className="permission-label">Wage Category</label>
            </div>
          </div>
          {this.state.packEmployees === 'groups' && <div className="form-group row col-xl-8 col-lg-8 col-md-8 offset-md-4 offset-lg-4 col-sm-10 pl-0">
            <label className="permission-label pl-0">How to Pack within Group</label>
            <div className="col-xl-12 col-lg-12 col-md-12 col-sm-10 ml-0 pl-0">
              <input type="radio" value="group-alphabet" defaultChecked onClick={() => this.setState({ subPackEmp: 'group-alphabet' })} className="form-control mt-0 permission-checkbox" name="packemployeesgroup" />
              <label className="permission-label">Alphabetically</label>
            </div>
            <div className="col-xl-12 col-lg-12 col-md-12 col-sm-10 ml-0 pl-0">
              <input type="radio" value="group-wage" onClick={() => this.setState({ subPackEmp: 'group-wage' })} className="form-control mt-0 permission-checkbox" name="packemployeesgroup" />
              <label className="permission-label">Wage Category</label>
            </div>
          </div>}
          <div className="form-group row col-12">
            <label className="col-xl-2 col-lg-2 col-md-2 col-sm-10 p-0 permission-label">Report Type</label>
            <select value={this.state.preview} onChange={this.handleOnChange} className="form-control col-xl-6 col-lg-6 col-md-6 col-sm-10 ml-2">
              <option value="timesheet">Timesheet Report</option>
              <option value="original">Original Timesheet Receipt</option>
              <option value="payroll">Payroll Report</option>
              <option value="quickbook">Export Report for QuickBook</option>
            </select>
          </div>
          <div className="form-group row col-12 h-auto m-auto pt-3">
            <button onClick={this.loadPreview} class="button resend-btn m-auto">{reportLoading ? 'Please Wait...' : 'Generate Report'}</button>
          </div>
        </form>
        { showreport === 'payroll' && <PayrollTable />}
        { showreport === 'timesheet' && <TimesheetPreview activityTimeArr={activityTimeArr} summaryArr={summaryArr} detailsArr={detailsArr} />}
      </div>
    );
  }
}

export default ReportingSection;
