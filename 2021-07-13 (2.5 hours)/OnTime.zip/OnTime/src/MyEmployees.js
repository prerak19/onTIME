import React from 'react';
import { Container } from 'react-bootstrap';
import 'bootstrap/dist/css/bootstrap.min.css';
import './App.css';
import TimesheetPreview from './components/TimesheetPreview';
import TimesheetReciept from './components/timesheetRecieptReport';
import moment from 'moment';
import 'bs-stepper/dist/css/bs-stepper.min.css';
import Stepper from 'bs-stepper';
import LoadMyTeamTable from './components/LoadMyTeamTable';
import AboutEmployees from './components/AboutEmployees';
import ManagerReportingSection from './components/ManagerReportingSection';

class MyTeam extends React.Component {

  constructor(props) {
    super(props);
    this.state = {
      startDate: moment().day(0).format('YYYY-MM-DD'),
      endDate: moment().day(6).format('YYYY-MM-DD'),
      activityTimeArr: [],
      summaryArr: [],
      disFilterArr: [],
      originalArr: [],
      showreport: null,
      companyDetails: {},
    };
  }

  componentDidMount() {
    this.stepper = new Stepper(document.querySelector('#stepper2'), {
      linear: false,
      animation: true
    })
  }

  setProps = (props) => {
    const { showreport, summaryArr, originalArr, detailsArr, orgImage, activityTimeArr, disFilterArr, startDate, endDate, companyDetails } = props;
    if (showreport === 'original') {
      this.setState({
        showreport, originalArr, startDate, endDate, companyDetails, orgImage
      });
    } else {
      this.setState({
        showreport, summaryArr, detailsArr, activityTimeArr,
        disFilterArr, startDate, endDate, companyDetails, orgImage
      });
    }

  }

  render() {
    const { showreport, startDate, endDate, activityTimeArr, summaryArr, detailsArr, disFilterArr, orgImage, companyDetails, originalArr } = this.state;
    return (
      <div className="App">
        <Container>
          <div className="contentwrapper pt-1 pb-5">
            <div id="stepper2" className="bs-stepper">
              <div className="bs-stepper-header">
                <div className="step" data-target="#tests-l-1">
                  <button className="step-trigger" onClick={() => this.setState({ showreport: null })}>
                    <span className="bs-stepper-label1">Manage Employee Time</span>
                  </button>
                </div>
                <div className="step" data-target="#tests-l-2">
                  <button className="step-trigger">
                    <span className="bs-stepper-label1">Run Reports</span>
                  </button>
                </div>
                <div className="step" data-target="#tests-l-3" onClick={() => this.setState({ showreport: null })}>
                  <button className="step-trigger">
                    <span className="bs-stepper-label1">About Employees</span>
                  </button>

                </div>
              </div>
              <div className="stepper-content">
                <div id="tests-l-1" className="content small_font">
                  <LoadMyTeamTable />
                </div>
                <div id="tests-l-2" className="content  pl-0  small_font">
                  <ManagerReportingSection setProps={this.setProps} />
                </div>
                <div id="tests-l-3" className="content pl-2 small_font">
                  <AboutEmployees />
                </div>
              </div>
            </div>
          </div>
        </Container>
        {showreport === 'timesheet' && <TimesheetPreview orgImage={orgImage} companyDetails={companyDetails} activityTimeArr={activityTimeArr} summaryArr={summaryArr} detailsArr={detailsArr} startDate={startDate} endDate={endDate} disFilterArr={disFilterArr} />}
        {showreport === 'original' && <TimesheetReciept orgImage={orgImage} companyDetails={companyDetails} startDate={startDate} endDate={endDate} originalArr={originalArr} />}
      </div>
    );
  }
}

export default MyTeam;
