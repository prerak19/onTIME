import React from 'react';

class Customers extends React.Component {
  render() {
    return (
      <h1>Customers</h1>
    );
  }
}

export default Customers;
