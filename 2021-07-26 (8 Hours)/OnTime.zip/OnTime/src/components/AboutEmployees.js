import React, { Component } from 'react';
import { Row, Col, Card } from "react-bootstrap";
import EmployeeList from './EmployeeList.js';
import ActivityList from './ActivityList.js';
import { CardBody, CardFooter, CardHeader } from 'reactstrap';
import { MDBBtn } from 'mdbreact';
import "react-datepicker/dist/react-datepicker.css";
import { apiGet } from '../Api.js';
import moment from 'moment';
import { isEqual } from 'lodash';

class AboutEmployees extends Component {
  constructor(props) {
    super(props);
    this.state = {
      activities: [],
      currentActivity: null,
      employeeList: false,
      policies: false
    };
  }

  componentDidMount = () => {
    this.getActivities();
  }

  getActivities = () => {
    const getRequest = {
      method: `activities?manager=${localStorage.userid}`,
      params: {}
    };
    apiGet(getRequest, false).then((response) => {
      if (isEqual(response.status, 200) && response.data) {
        this.setState({ activities: response.data });
      } else {
        this.setState({ activities: [] });
      }
    }).catch(error => {
      this.setState({ activities: [] });
    });
  }

  getActivityEmployees = (activity, name = 'emp') => {
    this.setState({
      employeeList: name === 'emp' ? true : false,
      policies: name !== 'emp' ? true : false,
      currentActivity: activity,
    })
  }

  resetActivity = () => {
    this.setState({
      employeeList: false,
      policies: false,
      currentActivity: null,
    })
  }

  render() {
    const { activities, employeeList, policies, currentActivity } = this.state;
    return (
      <div>
        {!employeeList && !policies && <Row>
          {activities && activities.length > 0 &&
            activities.map((act, key) => {
              return <Col lg="3" md="3" sm="12" key={key}>
                <Card className="border">
                  <CardHeader className="pb-0 pt-4">
                    <h6 className="font-weight-bolder">{act.name} ({act.code})</h6>
                  </CardHeader>
                  <CardBody className="py-1 font-11">
                    <div className="font-10"> Activity Created : {moment(act.createdOn).format('MM/DD/YYYY')} </div>
                  </CardBody>
                  <CardFooter>
                    <MDBBtn title="View Employee" onClick={() => this.getActivityEmployees(act)} size="lg" className="round-btn">
                      <i className="fa fa-users" aria-hidden="true"></i>
                    </MDBBtn>
                    <MDBBtn title="View Policy" onClick={() => this.getActivityEmployees(act, 'policy')} size="lg" className="round-btn">
                      <i className="fa fa-book" aria-hidden="true"></i>
                    </MDBBtn>
                  </CardFooter>
                </Card>
              </Col>
            })}
        </Row>}
        {employeeList && !policies ? <EmployeeList activity={currentActivity} backToMenu={this.resetActivity} /> : null}
        {!employeeList && policies ? <ActivityList activity={currentActivity} backToMenu={this.resetActivity} /> : null}
      </div>
    );
  }
}

export default AboutEmployees;
