import { isEmpty } from 'lodash';
import React, { Component } from 'react';
import { Modal, Container } from "react-bootstrap";
import { confirmAlert } from 'react-confirm-alert';
import 'react-confirm-alert/src/react-confirm-alert.css';
import { apiPost, apiGet, apiPut, apiDelete } from '../Api.js';

class SuperAdminUser extends Component {
  constructor(props) {
    super(props);
    this.componentRef = React.createRef();
    this.state = {
      show: false,
      editshow: false,
      supershow: false,
      editsupershow: false,
      reset: false,
      audetails: {},
      error_message: '',
      auerrors: {},
      auerror_message: '',
      adminusers: [],
      employeesList: [],
      resetname: '',
      resetId: '',
      newPassword: '',
      confirmNewPassword: '',
    };
  }
  componentDidMount() {
    this.getAdminUsers();
  }

  handleAuFormChange = (e) => {
    let audetails = this.state.audetails;
    let auerrors = this.state.auerrors;
    audetails[e.target.name] = e.target.value;
    auerrors[e.target.name] = "form-control is-valid";
    this.setState({ audetails });
  }

  handlePermissionCheckbox = (e) => {
    let audetails = this.state.audetails;
    let auerrors = this.state.auerrors;
    audetails[e.target.name] = e.target.checked === true ? 1 : 0;
    auerrors[e.target.name] = "form-control is-valid";
    this.setState({ audetails });
  }

  validateAuForm() {
    const { audetails, editsupershow, editshow } = this.state;
    let auerrors = {};
    let auformIsValid = true;

    if (!audetails["firstName"]) {
      auformIsValid = false;
      auerrors["firstName"] = "form-control is-invalid";
    }
    if (!audetails["lastName"]) {
      auformIsValid = false;
      auerrors["lastName"] = "form-control is-invalid";
    }
    if (!audetails["userName"]) {
      auformIsValid = false;
      auerrors["userName"] = "form-control is-invalid";
    }
    if (!audetails["email"]) {
      auformIsValid = false;
      auerrors["email"] = "form-control is-invalid";
    }
    if (!editsupershow && !editshow && !audetails["password"]) {
      auformIsValid = false;
      auerrors["password"] = "form-control is-invalid";
    }
    if (!auformIsValid) {
      this.setState({
        auerror_message: 'Please fill all * Required Fields!'
      });
      window.scroll({ top: 0, left: 0, behavior: 'smooth' })
    } else {
      this.setState({ auerror_message: '' });
    }
    this.setState({ auerrors: auerrors });
    return auformIsValid;
  }

  addManagerProcess = (d) => {
    this.setState({ editshow: false, show: true, audetails: {} });
  }

  clearModal = () => {
    this.setState({
      auerror_message: null, editshow: false, show: false, editsupershow: false, supershow: false, audetails: {},
    })
  }

  addEditManagerRecord = (e) => {
    const { audetails, editshow } = this.state;
    if (this.validateAuForm()) {
      if (editshow) {
        let userID = audetails.userID;
        let requestDetails = {
          method: 'adminusers/' + userID,
          params: {
            userID,
            userType: audetails.userType,
            ...this.getUserObject()
          }
        };
        apiPut(requestDetails, true).then((res) => {
          if (res && res.status === 200 && res.data) {
            this.clearModal();
            this.getAdminUsers();
          }
          if (res.request.response && res.request.status !== 200) {
            let obj = JSON.parse(res.request.response);
            this.setState({ auerror_message: obj.msg });
            return;
          }
        }).catch(error => {
          console.log(error)
        });
      } else {
        let requestDetails = {
          method: 'adminusers',
          params: {
            org_id: localStorage.orgid,
            userType: 50,
            ...this.getUserObject()
          }
        };
        apiPost(requestDetails, true).then((res) => {
          if (res && res.status === 200 && res.data) {
            this.clearModal();
            this.getAdminUsers();
          }
          if (res.request.response && res.request.status !== 200) {
            let obj = JSON.parse(res.request.response);
            this.setState({ auerror_message: obj.msg });
            return;
          }
        }).catch(error => {
          console.log(error)
        });
      }
    }
  }


  addEditSuperUserRecord = (e) => {
    const { audetails } = this.state;
    if (this.validateAuForm()) {
      let userID = audetails.userID;
      let requestDetails = {
        method: 'adminusers/' + userID,
        params: {
          userID,
          userType: audetails.userType,
          ...this.getUserObject()
        }
      };
      apiPut(requestDetails, true).then((res) => {
        if (res && res.status === 200 && res.data) {
          this.clearModal();
          this.getAdminUsers();
        }
        if (res.request.response && res.request.status !== 200) {
          let obj = JSON.parse(res.request.response);
          this.setState({ auerror_message: obj.msg });
          return;
        }
      }).catch(error => {
        console.log(error)
      });
    }
  }

  getUserObject = (details = {}) => {
    let audetails = !isEmpty(details) ? details : this.state.audetails;
    let obj = {
      userName: audetails.userName,
      password: audetails.password,
      firstName: audetails.firstName,
      lastName: audetails.lastName,
      email: audetails.email,
      rightsTimesheet: audetails.rightsTimesheet,
      rightsPolicy: audetails.rightsPolicy,
      rightsActivity: audetails.rightsActivity,
      rightsEmployee: audetails.rightsEmployee,
      rightsReport: audetails.rightsReport
    }
    return obj;
  }

  editAdminUserProcess = async (d, name = '') => {
    let userID = d.currentTarget.dataset.tag;
    if (name === 'manager') {
      this.setState({ editshow: true, show: true, audetails: {} });
    } else {
      this.setState({ editsupershow: true, supershow: true, audetails: {} });
    }
    const userDetails = { method: `adminusers/${userID}` };

    await apiGet(userDetails, true, false).then((userRes) => {
      if (userRes.status === 200 && userRes.data) {
        this.setState({ audetails: userRes.data });
      }
    }).catch(error => {
      this.clearModal();
      console.log(`Error in promises ${error}`)
    });
  }
  resetPassword = (e) => {
    this.setState({ reset: true, audetails: {}, resetId: e.currentTarget.dataset.tagid, resetname: e.currentTarget.dataset.tag });
  }
  resetPasswordProcess = (d) => {
    const { resetId, confirmNewPassword, newPassword } = this.state;
    if (confirmNewPassword !== newPassword) {
      this.setState({ auerror_message: 'Password and Conifrm Password Does not Match!' });
      return;
    } else {
      this.setState({ auerror_message: '' });
    }
    let requestDetails = {
      method: 'employees/password-reset',
      params: {
        userID: resetId,
        newPassword: newPassword,
        managerID: localStorage.userid
      }
    };
    apiPost(requestDetails, true).then((res) => {
      if (res.status === 200 && res.data) {
        window.alert('Password Reset Successfully.');
        this.closeResetPassword();
      } else if (res.request.response && res.request.status !== 200) {
        let obj = JSON.parse(res.request.response);
        obj.msg ? window.alert(obj.msg) : window.alert('Something Went Wrong!');
        return;
      } else {
        window.alert('Something Went Wrong!')
      }
    }).catch(error => {
      console.log(error);
      window.alert('Something Went Wrong!');
    });
  }

  deleteProcess = (e) => {
    var dv = e.currentTarget.dataset.tag;
    confirmAlert({
      customUI: ({ onClose }) => {
        return (
          <div className='custom-ui'>
            <h3>Are you sure?</h3>
            <p>You want to delete this?</p>
            <button data-tag={dv} onClick={() => { this.deleteRecord({ dv }); onClose(); }}>Yes, Delete it</button>
            <button onClick={onClose}>No, Cancel</button>
          </div>
        );
      }
    });
  }
  deleteRecord = (e) => {
    let requestDetails = {
      method: 'adminusers/' + e.dv,
      params: {}
    };
    apiDelete(requestDetails, true).then((res) => {
      if (res.request.response && res.request.status !== 200) {
        let obj = JSON.parse(res.request.response);
        window.alert(obj.msg);
        return;
      } else {
        this.getAdminUsers();
      }
    }).catch(error => {
      console.log(error)
    });
  }

  getAdminUsers = (e) => {
    let requestDetails = {
      method: 'adminusers/all/' + localStorage.orgid,
      params: {}
    };
    apiGet(requestDetails, true, false).then((response) => {
      let arr = [];
      let arr1 = [];
      Array.isArray(response.data) && response.data.map((item, i) => {
        if (Number(item.userType) === 50) { arr.push(item); }
        else if (Number(item.userType) === 90) { arr1.push(item); }
        return null;
      })
      this.setState({ adminusers: arr, superusers: arr1 });
    }).catch(error => {
      console.log(error)
    });
  }

  closeResetPassword = () => {
    this.setState({ reset: false, auerror_message: '', audetails: {}, newPassword: '', confirmNewPassword: '' });
  }

  render() {
    const { editshow, audetails, newPassword, confirmNewPassword } = this.state;
    return (
      <div>
        <h6>Account Holder (Super User) Management</h6>
        {Array.isArray(this.state.superusers) && this.state.superusers.map((item, i) => {
          return <div className="row form-group border-bottom" key={i}>
            <div className="col-xl-3 col-lg-3 col-md-3 col-sm-12">
              <label>{item.firstName + ' ' + item.lastName}</label>
              <p><span className="link-style pl-0" data-tag={item.userID} onClick={(e) => this.editAdminUserProcess(e)}>Edit</span> |
                <span className="link-style" data-tagid={item.userID} data-tag={item.userName} onClick={this.resetPassword}>Reset Password</span></p>
            </div>
          </div>
        })}
        <h6 className="mt-4">Manager Account Management</h6>
        <label>Add Manager<button type="button" onClick={this.addManagerProcess} className="button resend-btn mt-1">Add</button></label>
        <p className="mt-1 font-weight-bold">Manage Manager Information and Rights</p>
        {Array.isArray(this.state.adminusers) && this.state.adminusers.map((item, i) => {
          return <div className="row form-group border-bottom" key={i}>
            <div className="col-xl-3 col-lg-3 col-md-3 col-sm-12">
              <label>{item.firstName + ' ' + item.lastName}</label>
              <p><span className="link-style pl-0" data-tag={item.userID} onClick={(e) => this.editAdminUserProcess(e, 'manager')}>Edit</span> |
                    <span className="link-style" data-tag={item.userID} onClick={this.deleteProcess}>Remove</span> |
                    <span className="link-style" data-tagid={item.userID} data-tag={item.userName} onClick={this.resetPassword}>Reset Password</span></p>
            </div>
            <div className="col-xl-9 col-lg-9 col-md-9 col-sm-12 row">
              <div className="col-xl-3 col-lg-3 col-md-3 col-sm-12 p-0">
                <input type="checkbox" checked={item.rightsActivity === 1 ? true : false} disabled className="form-control permission-checkbox" name="rightsActivity" />
                <label className="permission-label">Modify Activities</label>
              </div>
              <div className="col-xl-3 col-lg-3 col-md-3 col-sm-12 p-0">
                <input type="checkbox" checked={item.rightsEmployee === 1 ? true : false} disabled className="form-control permission-checkbox" name="rightsEmployee" />
                <label className="permission-label">Modify Employees</label>
              </div>
              <div className="col-xl-3 col-lg-3 col-md-3 col-sm-12 p-0">
                <input type="checkbox" checked={item.rightsPolicy === 1 ? true : false} disabled className="form-control permission-checkbox" name="rightsPolicy" />
                <label className="permission-label">Modify Policies</label>
              </div>
              <div className="col-xl-3 col-lg-3 col-md-3 col-sm-12 p-0">
                <input type="checkbox" checked={item.rightsReport === 1 ? true : false} disabled className="form-control permission-checkbox" name="rightsReport" />
                <label className="permission-label pl-1">Do Reporting</label>
              </div>
              <div className="col-xl-4 col-lg-4 col-md-4 col-sm-12 p-0">
                <input type="checkbox" checked={item.rightsTimesheet === 1 ? true : false} disabled className="form-control permission-checkbox" name="rightsTimesheet" />
                <label className="permission-label">Timesheets Approval</label>
              </div>
            </div>
          </div>
        })}
        <Modal scrollable={true} size="lg" onHide={() => this.clearModal()}
          show={this.state.supershow}
          aria-labelledby="example-modal-sizes-title-lg">
          <Modal.Header closeButton>
            <Modal.Title className="h6" id="example-modal-sizes-title-lg">
              Edit Super User
        </Modal.Title>
          </Modal.Header>
          <Modal.Body className="show-grid small_font" ref={this.componentRef}>
            <Container>
              <div className="text-danger col-12 text-center">{this.state.auerror_message}</div>
              <div className="form-group row">
                <div className="col-xl-6 col-lg-6 col-md-6 col-sm-12">
                  <label htmlFor="firstName">First Name*</label>
                  <input value={audetails.firstName} name="firstName" onChange={this.handleAuFormChange} type="text" className="form-control" id="firstName" placeholder="Enter First Name" />
                </div>
                <div className="col-xl-6 col-lg-6 col-md-6 col-sm-12">
                  <label htmlFor="lastName">Last Name*</label>
                  <input value={audetails.lastName} name="lastName" onChange={this.handleAuFormChange} type="text" className="form-control" id="lastName" placeholder="Enter Last Name" />
                </div>
              </div>
              <div className="form-group">
                <label htmlFor="email">Email*</label>
                <input value={audetails.email} name="email" onChange={this.handleAuFormChange} type="email" className="form-control" placeholder="Enter Email" />
              </div>
              <div className="form-group">
                <label>Login Name*</label>
                <input value={audetails.userName} name="userName" onChange={this.handleAuFormChange} type="text" className="form-control" placeholder="Enter Login Name" />
              </div>
            </Container>
          </Modal.Body>
          <Modal.Footer>
            <ul className="row form-group mr-0 mt-4 pr-0 list-inline pull-right">
              <li><button onClick={() => this.clearModal()} className="button cancel-btn py-2 px-4 m-0 mr-2">Close</button></li>
              <li><button onClick={this.addEditSuperUserRecord} className="button resend-btn py-2 px-4 m-0">Save</button></li>
            </ul>
          </Modal.Footer>
        </Modal>
        <Modal scrollable={true} size="xl" onHide={() => this.clearModal()}
          show={this.state.show}
          aria-labelledby="example-modal-sizes-title-lg">
          <Modal.Header closeButton>
            <Modal.Title className="h6" id="example-modal-sizes-title-lg">
              {editshow ? 'Edit' : 'Add'} Manager
        </Modal.Title>
          </Modal.Header>
          <Modal.Body className="show-grid small_font">
            <Container>
              <div className="text-danger col-12 text-center">{this.state.auerror_message}</div>
              <div className="form-group row">
                <div className="col-xl-6 col-lg-6 col-md-6 col-sm-12">
                  <label htmlFor="firstName">First Name*</label>
                  <input value={audetails.firstName} name="firstName" onChange={this.handleAuFormChange} type="text" className="form-control" id="firstName" placeholder="Enter First Name" />
                </div>
                <div className="col-xl-6 col-lg-6 col-md-6 col-sm-12">
                  <label htmlFor="lastName">Last Name*</label>
                  <input value={audetails.lastName} name="lastName" onChange={this.handleAuFormChange} type="text" className="form-control" id="lastName" placeholder="Enter Last Name" />
                </div>
              </div>
              <div className="form-group">
                <label htmlFor="email">Email*</label>
                <input value={audetails.email} name="email" onChange={this.handleAuFormChange} type="email" className="form-control" placeholder="Enter Email" />
              </div>
              <div className="form-group">
                <label>Login Name*</label>
                <input value={audetails.userName} name="userName" onChange={this.handleAuFormChange} type="text" className="form-control" placeholder="Enter Login Name" />
              </div>
              {!editshow && <div className="form-group">
                <label>Password*</label>
                <input value={audetails.password} name="password" onChange={this.handleAuFormChange} type="password" className="form-control" placeholder="Enter Password" />
              </div>}
              <div className="form-group row">
                <div className="col-xl-2 col-lg-2 col-md-2 col-sm-12 p-0">
                  <input type="checkbox" checked={audetails.rightsActivity === 1 ? true : false} onChange={this.handlePermissionCheckbox} className="form-control permission-checkbox" name="rightsActivity" />
                  <label className="permission-label">Modify Activities</label>
                </div>
                <div className="col-xl-3 col-lg-3 col-md-3 col-sm-12 pr-0">
                  <input type="checkbox" checked={audetails.rightsEmployee === 1 ? true : false} onChange={this.handlePermissionCheckbox} className="form-control permission-checkbox" name="rightsEmployee" />
                  <label className="permission-label">Modify Employees</label>
                </div>
                <div className="col-xl-2 col-lg-2 col-md-2 col-sm-12 pl-0">
                  <input type="checkbox" checked={audetails.rightsPolicy === 1 ? true : false} onChange={this.handlePermissionCheckbox} className="form-control permission-checkbox" name="rightsPolicy" />
                  <label className="permission-label">Modify Policies</label>
                </div>
                <div className="col-xl-2 col-lg-2 col-md-2 col-sm-12">
                  <input type="checkbox" checked={audetails.rightsReport === 1 ? true : false} onChange={this.handlePermissionCheckbox} className="form-control permission-checkbox" name="rightsReport" />
                  <label className="permission-label pl-1">Do Reporting</label>
                </div>
                <div className="col-xl-3 col-lg-3 col-md-3 col-sm-12">
                  <input type="checkbox" checked={audetails.rightsTimesheet === 1 ? true : false} onChange={this.handlePermissionCheckbox} className="form-control permission-checkbox" name="rightsTimesheet" />
                  <label className="permission-label">Timesheets Approval</label>
                </div>
              </div>
            </Container>
          </Modal.Body>
          <Modal.Footer>
            <ul className="row form-group mr-0 mt-4 pr-0 list-inline pull-right">
              <li><button onClick={() => this.clearModal()} className="button cancel-btn py-2 px-4 m-0 mr-2">Close</button></li>
              <li><button onClick={this.addEditManagerRecord} className="button resend-btn py-2 px-4 m-0">Save</button></li>
            </ul>
          </Modal.Footer>
        </Modal>
        <Modal scrollable={true} size="md" onHide={() => this.closeResetPassword()}
          show={this.state.reset}
          aria-labelledby="example-modal-sizes-title-lg">
          <Modal.Header closeButton>
            <Modal.Title className="h6" id="example-modal-sizes-title-lg">
              Reset Password
        </Modal.Title>
          </Modal.Header>
          <Modal.Body className="show-grid small_font">
            <Container>
              <div className="text-danger col-12 text-center">{this.state.auerror_message}</div>
              <div className="form-group">
                <label>New Password*</label>
                <input type="password" value={newPassword} name='newPassword' onChange={(e) => this.setState({ [e.target.name]: e.target.value })} className="form-control" placeholder="Enter new password" />
              </div>
              <div className="form-group">
                <label>Confirm New Password*</label>
                <input type="password" value={confirmNewPassword} name='confirmNewPassword' onChange={(e) => this.setState({ [e.target.name]: e.target.value })} className="form-control mt-2" placeholder="Confirm new password" />
              </div>
            </Container>
          </Modal.Body>
          <Modal.Footer>
            <button onClick={() => this.closeResetPassword()} className="button cancel-btn py-2 px-4 m-0 mr-2">Close</button>
            <button
              disabled={!confirmNewPassword || !newPassword}
              onClick={this.resetPasswordProcess}
              className="button resend-btn py-2 px-4 m-0">
              Save
              </button>
          </Modal.Footer>
        </Modal>
      </div>
    );
  }
}

export default SuperAdminUser;
