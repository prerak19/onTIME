import React from 'react';
import { Container, Row, Col, Modal } from 'react-bootstrap';
import AdminHeader from './components/AdminHeader.js';
import { apiPost, apiGet, apiPut, uploadImage, getBlobImage } from './Api.js';
import { isEqual } from 'lodash';
import { Redirect } from 'react-router';
import { userTypes } from './helpers/GeneralHelper.js';
import { confirmAlert } from 'react-confirm-alert';
import 'react-confirm-alert/src/react-confirm-alert.css';

class MyProfile extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      userPreviewImg: null,
      userProfile_file: null,
      approvalList: [],
      userImgEditable: true,
      nameeditable: true,
      emaileditable: true,
      designation: true,
      reset: false,
      userDetails: localStorage.userdetails,
      email: '',
      userName: '',
      password: '',
      userID: localStorage.userdetails && JSON.parse(localStorage.userdetails).alternate.userID,
      npassword: '',
      cnpassword: '',
      error_message: ''
    };
  }

  componentDidMount = async () => {
    await this.getUserData();
    await this.getUserProfileImg();
    if (localStorage.usertype === 'manager') {
      this.getApproverData();
    }
  }

  getUserData = async () => {
    let requestDetails1 = {
      method: 'employees/' + localStorage.userid,
      params: {}
    };
    await apiGet(requestDetails1, false).then((response) => {
      if (response.status === 200 && response.data) {
        const { alternate } = response.data;
        localStorage.setItem("userdetails", JSON.stringify(response.data));
        this.setState({
          userID: alternate && alternate.userID,
          email: response.data.email,
          userName: response.data.userName,
          password: response.data.password,
          userDetails: response.data
        });
      }
    }).catch(error => {
      console.log(error)
    });
  }

  getUserProfileImg = async (e) => {
    let imageSrc = '';
    const getRequest = {
      method: `employees/images?id=${localStorage.userid}&itemtype=user_photo`
    };
    await getBlobImage(getRequest).then((response) => {
      if (response.data && response.data.size) {
        imageSrc = URL.createObjectURL(response.data);
        this.setState({ userPreviewImg: imageSrc });
        localStorage.setItem('userImg', imageSrc);
      }
    }).catch(error => {
      console.log(error);
    });
  }

  getApproverData = () => {
    const getRequest = {
      method: `employees/alternates?org=${localStorage.orgid}&manager=${localStorage.userid}`,
      params: {}
    };
    apiGet(getRequest, false).then((response) => {
      if (isEqual(response.status, 200) && response.data) {
        const arr = response.data.filter((x) => x.userID !== Number(localStorage.userid));
        this.setState({ approvalList: arr })
      } else {
        this.setState({ approvalList: [] })
      }
    }).catch(error => {
      this.setState({ approvalList: [] })
    });
  }


  changeApproval = (sameName = false) => {
    const { userID } = this.state;
    const requestDetails = {
      method: `employees/alternates?samenameok=${sameName ? 1 : 0}`,
      params: {
        type: "user",
        userID: localStorage.userid,
        alternate: {
          userID: userID === 'No alternate' ? 0 : Number(userID)
        }
      }
    };
    apiPost(requestDetails).then((res) => {
      const obj = JSON.parse(res.request.response);
      if (isEqual(res.status, 200) && res.data) {
        this.setState({ designation: true });
        this.getUserData();
      }
      if (res.request && res.request.response && res.request.status !== 200) {
        if (obj.code === -10) {
          this.sameApprover();
        } else {
          obj.msg ? window.alert(obj.msg) : window.alert('Something Went Wrong!');
          return;
        }
      }
    })
  }

  sameApprover = () => {
    confirmAlert({
      customUI: ({ onClose }) => {
        return (
          <div className='custom-ui'>
            <p>The selected Designated Approver has same name as one of your approvers, are they the same person?
              (If yes, please select a different Designated Approver.) </p>
            <button onClick={onClose}>Yes, Let me change it</button>
            <button onClick={async () => {
              await this.changeApproval(true);
              onClose();
            }}>No, continue</button>
          </div>
        );
      },
    });
  }

  handleFormChange = (e) => {
    const name = e.target.name;
    this.setState({ [name]: e.target.value });
  }

  resetPassword = (e) => {
    const { password, userName, npassword, cnpassword } = this.state;
    if (password && npassword === cnpassword) {
      let requestDetails1 = {
        method: 'employees/password-reset',
        params: {
          userName: userName,
          oldPassword: password,
          newPassword: npassword
        }
      };
      apiPost(requestDetails1).then((res) => {
        if (res.data && res.status === 200) {
          this.setState({ reset: false, npassword: '', cnpassword: '' });
          this.getUserData();
        }
        if (res.request && res.request.response && res.request.status !== 200) {
          const obj = JSON.parse(res.request.response);
          obj.msg ? this.setState({ error_message: obj.msg }) : this.setState({ error_message: 'Something Went Wrong!' });
          return;
        }
      });
    } else {
      this.setState({ error_message: 'New Password and Confirm New Password are not Same!' });
    }
  }

  updateUser = (e) => {
    const { userDetails, userName, password, email } = this.state;
    let requestDetails = {
      method: 'employees/' + localStorage.userid,
      params: {
        type: "user",
        userID: localStorage.userid,
        userName,
        password,
        email,
        employeeType: userDetails.employeeType,
        firstName: userDetails.firstName,
        group: userDetails.group,
        lastName: userDetails.lastName,
        status: userDetails.status,
        timeApprover: userDetails.timeApprover,
        timingMethod: userDetails.timingMethod,
        userActivities: userDetails.userActivities,
        userProfile: userDetails.userProfile,
        userType: userDetails.userType,
        wage_category: userDetails.wage_category,
      }
    };
    apiPut(requestDetails).then((res) => {
      if (res.data && res.status === 200) {
        this.setState({ nameeditable: true, emaileditable: true });
        this.getUserData();
      }
      if (res.request && res.request.response && res.request.status !== 200) {
        const obj = JSON.parse(res.request.response);
        obj.msg ? window.alert(obj.msg) : window.alert('Something Went Wrong!');
        return;
      }
    }).catch(error => {
      console.log(error)
    });
  }

  userLogoChange = event => {
    const fileUploaded = event.target.files[0];
    if (fileUploaded) {
      const size = fileUploaded.size / 1024;
      if (size > 1024) {
        window.alert('File size can not exceed more than 1MB');
        event.target.value = '';
        return;
      }
      this.setState({ userPreviewImg: URL.createObjectURL(fileUploaded), userProfile_file: fileUploaded, userImgEditable: false });
    } else {
      this.setState({ userPreviewImg: '', userProfile_file: '', userImgEditable: true });
    }
  };

  updateEmpImage = (e) => {
    e.preventDefault();
    const { userProfile_file } = this.state;
    let userid = localStorage.userid;
    let requestDetails3 = { method: `employees/images?id=${userid}&itemtype=user_photo` };
    let empUserImg = new FormData();
    if (userProfile_file) {
      empUserImg.append("file", userProfile_file);
    }
    uploadImage(requestDetails3, empUserImg).then(async (response) => {
      if (response.status === 200 && response.data) {
        localStorage.removeItem('userImg');
        this.setState({ userImgEditable: true });
        window.location.reload();
      }
    }).catch(error => {
      console.log(error)
    });
  }

  clearPass = () => {
    const { userDetails } = this.state;
    this.setState({ reset: false, password: userDetails.password, npassword: '', cnpassword: '' });
  }

  render() {
    const userType = localStorage.usertype;
    if (!userType) return <Redirect to="/" />
    const userdet = JSON.parse(localStorage.userdetails);
    const { userPreviewImg, userImgEditable, userDetails, email, password, userName } = this.state;
    return (
      <div className="App">
        <Container>
          <AdminHeader />
          <div className="content mt-3 pl-2 width-80 small_font">
            <div>
              <h6>{userTypes[userdet.userType] || 'User'} Profile - {userdet.firstName ? userdet.firstName : ""} {userDetails.lastName ? userdet.lastName : ''} ({userdet.email})</h6>
              <p className="">Manage User Information</p>
            </div>
            <div className="my-4">
              <div className="row form-group">
                <div className="col-xl-2 col-lg-2 col-md-2 col-sm-12 pt-2">
                  <label>Login Name</label>
                </div>
                <div className="col-xl-6 col-lg-6 col-md-6 col-sm-12">
                  <input type="text" disabled={this.state.nameeditable} className="form-control" value={userName} placeholder="Enter Login Name" onChange={this.handleFormChange} name="userName" />
                </div>
                <div style={this.state.nameeditable === true ? { display: 'none' } : {}} className="col-xl-2 col-lg-2 col-md-2 col-sm-12 pt-2">
                  <p>
                    <span className="link-style pl-0" onClick={() => this.setState({ nameeditable: true, userName: userDetails.userName })}>Cancel</span> |
                    <span className="link-style pl-2" onClick={this.updateUser}>Save</span>
                  </p>
                </div>
                <div style={this.state.nameeditable === true ? {} : { display: 'none' }} className="col-xl-2 col-lg-2 col-md-2 col-sm-12 pt-2">
                  <p>
                    <span className="link-style pl-0 mt-1" onClick={() => this.setState({ nameeditable: false })}>Change</span>
                  </p>
                </div>
              </div>
              <div className="row form-group">
                <div className="col-xl-2 col-lg-2 col-md-2 col-sm-12 pt-2">
                  <label>Email</label>
                </div>
                <div className="col-xl-6 col-lg-6 col-md-6 col-sm-12">
                  <input type="email" disabled={this.state.emaileditable} className="form-control" value={email} placeholder="Enter Email" onChange={this.handleFormChange} name="email" />
                </div>
                <div style={this.state.emaileditable === true ? { display: 'none' } : {}} className="col-xl-2 col-lg-2 col-md-2 col-sm-12 pt-2">
                  <p>
                    <span className="link-style pl-0" onClick={() => this.setState({ emaileditable: true, email: userDetails.email })}>Cancel</span> |
                    <span className="link-style pl-2" onClick={this.updateUser}>Save</span>
                  </p>
                </div>
                <div style={this.state.emaileditable === true ? {} : { display: 'none' }} className="col-xl-2 col-lg-2 col-md-2 col-sm-12 pt-2">
                  <p>
                    <span className="link-style pl-0 mt-1" onClick={() => this.setState({ emaileditable: false })}>Change</span>
                  </p>
                </div>
              </div>
              <div className="row form-group">
                <div className="col-xl-2 col-lg-2 col-md-2 col-sm-12 pt-2">
                  <label>Password</label>
                </div>
                <div className="col-xl-6 col-lg-6 col-md-6 col-sm-12">
                  <input type="password" disabled='disabled' className="form-control" value={password} placeholder="Enter Password" onChange={this.handleFormChange} name="password" />
                </div>
                <div className="col-xl-2 col-lg-2 col-md-2 col-sm-12 pt-2">
                  <p>
                    <span className="link-style pl-0" onClick={() => this.setState({ reset: true })}>Reset</span>
                  </p>
                </div>
              </div>
            </div>
            <div>
              <div className="border-bottom">
                <p className="mb-0">Change Your Profile Photo</p>
              </div>
              <Row className="p-3 text-center">
                <Col lg="3" md="3" sm="12">
                  <p className="text-muted">Upload Photo</p>
                  <img alt="Banner" className="profile-img" width="50%"
                    src={userPreviewImg ? userPreviewImg : require("./components/assets/img/user-default.png").default} />
                  <p>File size limit: 1 MB</p>
                </Col>
                <Col lg="9" md="9" sm="12" className="mt-6 text-left">
                  {userImgEditable ? <label className="button resend-btn py-2 px-4 m-0 cursor-pointer">
                    <input id="userSignature" type="file" onChange={this.userLogoChange} accept=".png, .jpg, .jpeg" style={{ display: 'none' }} />
                      Choose File
                      </label> :
                    <div>
                      <button className="button cancel-btn py-2 px-4 m-0 cursor-pointer mr-2" onClick={() => { this.setState({ userImgEditable: true }); this.getUserProfileImg() }}>Cancel</button>
                      <button className="button resend-btn py-2 px-4 m-0 cursor-pointer" onClick={this.updateEmpImage}>Save</button>
                    </div>}
                </Col>
              </Row>
            </div>
            {(userType === 'manager' && userDetails.rightsTimesheet === 1) &&
              <div>
                <div className="border-bottom my-2"></div>
                <div className="row form-group pb-5 pt-3">
                  <div className="col-xl-2 col-lg-2 col-md-2 col-sm-12 pt-2">
                    <label>Select Designated Approver</label>
                  </div>
                  <div className="col-xl-6 col-lg-6 col-md-6 col-sm-12">
                    <select value={this.state.userID} disabled={this.state.designation} name="type" onChange={(e) => this.setState({ userID: e.target.value })} placeholder="Select" className="form-control">
                      <option value="No alternate">No alternate</option>
                      {Array.isArray(this.state.approvalList) && this.state.approvalList.map((item, i) => {
                        return <option value={item.userID} key={i}>{item.firstName} {item.lastName}</option>
                      })
                      }
                    </select>
                  </div>
                  {!this.state.designation &&
                    <div className="col-xl-2 col-lg-2 col-md-2 col-sm-12 pt-2">
                      <p>
                        <span className="link-style pl-0" onClick={() => this.setState({ designation: true, userID: userDetails.alternate.userID })}>Cancel</span> |
                    <span className="link-style pl-2" onClick={() => this.changeApproval()}>Save</span>
                      </p>
                    </div>}
                  {this.state.designation &&
                    <div className="col-xl-2 col-lg-2 col-md-2 col-sm-12 pt-2">
                      <p>
                        <span className="link-style pl-0 mt-1" onClick={() => this.setState({ designation: false })}>Change</span>
                      </p>
                    </div>}
                </div>
              </div>}
            <Modal size="md" onHide={() => this.clearPass()}
              show={this.state.reset}>
              <Modal.Header closeButton>
                <Modal.Title className="h6">
                  Reset Password
        </Modal.Title>
              </Modal.Header>
              <Modal.Body className="show-grid small_font">
                <Container>
                  <span className="text-danger small_font">{this.state.error_message}</span>
                  <div className="form-group">
                    <label>Current Password*</label>
                    <input type="password" value={password} name="password" onChange={this.handleFormChange} className="form-control" placeholder="Enter Current Password" />
                  </div>
                  <div className="form-group">
                    <label>New Password*</label>
                    <input type="password" value={this.state.npassword} name="npassword" onChange={(e) => this.setState({ npassword: e.target.value })} className="form-control" placeholder="Enter New Password" />
                  </div>
                  <div className="form-group">
                    <label>Confirm New Password*</label>
                    <input type="password" value={this.state.cnpassword} name="cnpassword" onChange={(e) => this.setState({ cnpassword: e.target.value })} className="form-control" placeholder="Enter Confirm New Password" />
                  </div>
                </Container>
              </Modal.Body>
              <Modal.Footer>
                <ul className="row form-group mr-0 mt-4 pr-0 list-inline pull-right">
                  <li><button onClick={() => this.clearPass()} className="button cancel-btn py-2 px-4 m-0 mr-2">Close</button></li>
                  <li><button onClick={this.resetPassword} className="button resend-btn py-2 px-4 m-0">Save</button></li>
                </ul>
              </Modal.Footer>
            </Modal>
          </div>
        </Container>

      </div>
    );
  }
}

export default MyProfile;
