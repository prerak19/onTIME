import React from 'react';
import Logo from './components/assets/img/login-logo.png';
import 'bootstrap/dist/css/bootstrap.min.css';
import './components/assets/css/login.css';
import 'font-awesome/css/font-awesome.css';
import { Nav } from 'react-bootstrap';
import { NavLink } from "react-router-dom";
import { apiGet, apiPost } from './Api.js';
import { isEmpty, isEqual } from 'lodash';
import { rightsRoutes } from './helpers/GeneralHelper';


class Login extends React.Component {
  constructor(props) {
    localStorage.clear();
    super(props);
    this.state = {
      errors: {},
      fields: {},
      errorAlert: false,
      messageTitle: "",
      messageContent: "",
      success_msg: (this.props && this.props.location && this.props.location.state) ? this.props.location.state.msg : '',
    }
    this.emailInput = React.createRef();
  }
  componentDidMount() {
    this.emailInput.current.focus();
  }
  handleChange(field, e) {
    let fields = this.state.fields;
    fields[field] = e.target.value;
    this.setState({ fields });
  }
  handleValidation() {
    let fields = this.state.fields;
    let errors = {};
    let formIsValid = true;
    //password
    if (!fields["password"]) {
      formIsValid = false;
      errors["password"] = "Cannot be empty";
    }
    //userName
    if (!fields["userName"]) {
      formIsValid = false;
      errors["userName"] = "Cannot be empty";
    }
    this.setState({ errors: errors });
    if (!formIsValid) {
      this.setState({
        error_message: 'Please fill all *Required Fields!'
      });
    } else {
      this.setState({
        error_message: ''
      });
    }
    return formIsValid;
  }
  forceLogin = async (e) => {
    e.preventDefault();
    let data = null;
    let fields = this.state.fields;
    if (this.handleValidation()) {
      let requestLogin = {
        method: 'employees/login',
        params: {
          userName: fields['userName'],
          passWord: fields['password'],
        }
      };
      await apiPost(requestLogin).then((res) => {
        if (isEqual(res.status, 200) && res.data) {
          localStorage.setItem("access_token", res.data.msg);
          data = res.data;
        }
        if (res.request && res.request.response && res.request.status !== 200) {
          let obj = JSON.parse(res.request.response);
          this.setState({ error_message: obj.msg || 'Invalid login or Account Not Activated!' })
          return;
        }
      }).catch(error => {
        this.setState({ error_message: 'Invalid login or Account Not Activated!' })
      });
      if (data && data.returnValue !== '' && !isEmpty(localStorage.access_token)) {
        let requestDetails1 = {
          method: 'employees/' + data.returnValue,
          params: {}
        };
        await apiGet(requestDetails1).then((loginD) => {
          if (isEqual(loginD.status, 200) && loginD.data) {
            const uDetails = loginD.data;
            localStorage.setItem("userid", uDetails.userID);
            localStorage.setItem("orgid", uDetails.org_id);
            localStorage.setItem("userdetails", JSON.stringify(uDetails));
            if (uDetails.userType === 1) {
              localStorage.setItem("usertype", 'employee');
              this.props.history.push("/employee_timesheets");
            } else if (uDetails.userType === 50) {
              localStorage.setItem("usertype", 'manager');
              const rightObj = rightsRoutes.find((x) => uDetails[x.name] === 1);
              if (rightObj) {
                this.props.history.push(rightObj.path);
              } else {
                this.props.history.push("/MyProfile");
              }
            } else {
              localStorage.setItem("usertype", 'superuser');
              this.props.history.push("/Organization");
            }
          }
          if (loginD.request && loginD.request.response && loginD.request.status !== 200) {
            let obj = JSON.parse(loginD.request.response);
            this.setState({ error_message: obj.msg || 'Invalid login or Account Not Activated!' })
            return;
          }
        }).catch(error => {
          console.log(error)
        });

      } else {
        this.setState({ error_message: 'Invalid login or Account Not Activated!' });
      }
    }
  }
  render() {
    return (
      <div className="background min-h-100">
        <div className="container">
          <div className="row h-100 justify-content-center align-items-center m-0">
            <div className="col-12 my-6">
              <div className="login-form text-center col-lg-4 col-md-5 col-sm-9">
                <img src={Logo} width="86%" alt="Logo" />
                <img alt="Banner" width="15%" src={require("./components/assets/img/time-icon.png").default} />
                <p className="font-weight-bold font-11 mb-2">OnTime, The Timesheet Solution</p>
                <p className="font-11 mb-2">User Login</p>
                <span className="text-danger small_font">{this.state.error_message}</span>
                <span className="text-success small_font">{this.state.success_msg}</span>
                <form>
                  <div className="input-group mb-3">
                    <div className="input-group-prepend">
                      <span className="input-group-text"><i style={{ fontSize: '12px' }} className="fa fa-envelope" aria-hidden="true"></i></span>
                    </div>
                    <input type="text" className={(this.state.errors["userName"] ? 'form-control is-invalid' : 'form-control')}
                      ref={this.emailInput}
                      name="email" onChange={this.handleChange.bind(this, "userName")} value={this.state.userName} placeholder="User Name*" />
                  </div>
                  <div className="input-group mb-3">
                    <div className="input-group-prepend">
                      <span className="input-group-text"><i className="fa fa-lock" aria-hidden="true"></i></span>
                    </div>
                    <input type="password"
                      className={(this.state.errors["password"] ? 'form-control is-invalid' : 'form-control')}
                      name="password" onChange={this.handleChange.bind(this, "password")} value={this.state.password} placeholder="Password*" />
                  </div>
                  <p className="small_font float-left px-1">
                    <input type="checkbox" id="remember" className="form-control w-auto float-left mt-1 mr-1" />
                    <label htmlFor="remember" className="d-inline">Remember me</label>
                  </p>
                  <Nav.Link as={NavLink} to='/ForgotPassword' className="small_font float-right text-decoration-underline blue-color p-0">
                    Forgot Password?
              </Nav.Link>
                  <input type="submit" onClick={(e) => this.forceLogin(e)} className="button w-100 py-2" value="Login" />
                </form>
                <p className="xs_font light_color px-2 mt-3 mb-0">By continuing, you're confirming that you've read our <a href="!#" className="text-decoration-underline blue-color">Terms & Conditions</a> and <a href="!#" className="text-decoration-underline blue-color">Cookie Policy</a></p>
              </div>
              <p className="col-12 text-center xs_font light_color px-2 mt-2 mb-0">(c) 2021 WizDepot. All Rights Reserved</p>
              <p className="col-12 text-center font-11 px-2 mt-3">Don't have an account?<Nav.Link href="#home" className="blue-color px-3">Sign Up</Nav.Link></p>
            </div>
          </div>
        </div></div>
    );
  }
}

export default Login;
